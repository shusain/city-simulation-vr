import bpy, sys, math, json
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
# Original issue-owned refuse-truck study; production sources are references only.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
M={}
colors={'BodyPaint':(.025,.36,.34,1),'CompactorPaint':(.44,.60,.55,1),'Glass':(.025,.075,.105,1),'Rubber':(.022,.028,.032,1),'MetalTrim':(.28,.34,.37,1),'Chassis':(.065,.085,.095,1),'Headlight':(.88,.94,.80,1),'Taillight':(.65,.018,.025,1),'AmberLens':(1,.34,.025,1)}
for n,c in colors.items():
 m=bpy.data.materials.new(n); m.diffuse_color=c; m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=c; p.inputs['Roughness'].default_value=.18 if n=='Glass' else (.25 if 'light' in n or 'Lens' in n else .44); p.inputs['Metallic'].default_value=.7 if n=='MetalTrim' else 0
 M[n]=m
parts=[]
def assign(o,mat):
 o.data.materials.clear(); o.data.materials.append(M[mat]); parts.append(o); return o
def B(n,d,l,mat,bevel=0):
 o=assign(box(n,d,l,colors[mat]),mat)
 if bevel:
  mod=o.modifiers.new('Restrained edge radius','BEVEL'); mod.width=bevel; mod.segments=2
  bpy.context.view_layer.objects.active=o; bpy.ops.object.modifier_apply(modifier=mod.name)
 return o
def C(n,r,d,l,mat):
 o=assign(cylinder(n,r,d,l,colors[mat],vertices=24),mat); o.rotation_euler.x=math.pi/2
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 return o
def prism(n,x1,x2,section,mat):
 vs=[(x,y,z) for x in (x1,x2) for y,z in section]; k=len(section)
 fs=[tuple(reversed(range(k))),tuple(range(k,2*k))]+[(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)]
 me=bpy.data.meshes.new(n); me.from_pydata(vs,[],fs); me.update(); o=bpy.data.objects.new(n,me); bpy.context.collection.objects.link(o); return assign(o,mat)
def beam(n,a,b,r,mat):
 mid=(Vector(a)+Vector(b))/2; o=assign(cylinder(n,r,(Vector(b)-Vector(a)).length,mid,colors[mat],vertices=12),mat); o.rotation_euler=(Vector(b)-Vector(a)).to_track_quat('Z','Y').to_euler(); return o
B('Ladder chassis',(7.55,1.70,.30),(-.05,0,.90),'Chassis',.04)
# Six full-size tires, three plausible axles; tires touch z=0.
for x in (2.64,-1.38,-2.67):
 C('Axle',.12,2.12,(x,0,.57),'Chassis')
 for s in (-1,1):
  C('Tire',.57,.34,(x,s*1.055,.57),'Rubber')
  C('Steel wheel rim',.33,.035,(x,s*1.238,.57),'MetalTrim')
  C('Hub',.14,.060,(x,s*1.26,.57),'Chassis')
# Chamfered pressure vessel: long uninterrupted surfaces, not a ribbed box.
sec=[(-1.14,1.19),(1.14,1.19),(1.14,2.88),(.88,3.30),(-.88,3.30),(-1.14,2.88)]
prism('Chamfered compactor shell',-2.95,1.23,sec,'CompactorPaint')
B('Compactor lower sill',(4.3,2.34,.18),(-.88,0,1.22),'BodyPaint',.035)
# Deliberate .35m separation between cab and pressure body.
B('Cab lower',(2.10,2.24,.66),(2.63,0,1.36),'BodyPaint',.10)
B('Cab upper framed shell',(2.08,2.22,1.27),(2.62,0,2.325),'BodyPaint',.085)
B('Cab roof',(2.17,2.32,.13),(2.62,0,3.00),'BodyPaint',.05)
B('Wide front windshield',(.035,1.98,.90),(3.673,0,2.39),'Glass',.035)
B('Windshield center pillar',(.055,.055,.94),(3.70,0,2.39),'BodyPaint',.008)
for s in (-1,1):
 B('Door side glazing',(1.40,.035,.87),(2.60,s*1.123,2.40),'Glass',.035)
 B('Door rear pillar',(.08,.06,1.03),(1.89,s*1.13,2.35),'BodyPaint',.01)
 B('Door lower seam',(.025,.025,.52),(1.88,s*1.133,1.63),'Chassis')
 B('Door handle',(.22,.055,.045),(2.04,s*1.16,1.92),'MetalTrim',.015)
 B('Cab step',(.68,.30,.12),(1.88,s*1.15,.83),'MetalTrim',.025)
 beam('Mirror arm',(3.24,s*1.10,2.43),(3.30,s*1.34,2.48),.035,'MetalTrim')
 B('Mirror housing',(.18,.12,.31),(3.29,s*1.35,2.46),'Chassis',.03)
 B('Mirror glass',(.16,.025,.26),(3.29,s*1.418,2.46),'Glass',.018)
 B('Front pale lamp',(.06,.42,.23),(3.713,s*.78,1.39),'Headlight',.035)
 B('Rear lamp',(.07,.23,.24),(-3.96,s*1.02,1.20),'Taillight',.025)
B('Front bumper',(.22,2.32,.20),(3.79,0,1.02),'MetalTrim',.04)
B('Grille recess',(.036,1.01,.30),(3.702,0,1.48),'Chassis',.02)
for z in (1.40,1.48,1.56):B('Grille bar',(.045,.92,.025),(3.727,0,z),'MetalTrim')
# Rear loader: open dark cavity, flared cheeks, loading lip and hydraulic frame.
B('Hopper shadow throat',(.10,1.92,1.12),(-3.03,0,2.05),'Chassis',.04)
for s in (-1,1):
 prism('Hopper tall side cheek',-3.88,-2.97,[(s*.98,1.28),(s*1.18,1.28),(s*1.18,2.80),(s*.98,2.80)],'CompactorPaint')
 beam('Hydraulic barrel',(-2.98,s*1.20,2.73),(-3.48,s*1.20,1.77),.085,'Chassis')
 beam('Hydraulic polished rod',(-3.48,s*1.20,1.77),(-3.78,s*1.20,1.37),.046,'MetalTrim')
B('Hopper top arch',(.94,2.36,.22),(-3.45,0,2.87),'CompactorPaint',.06)
o=B('Sloped loading tray',(.93,2.05,.16),(-3.49,0,1.31),'MetalTrim',.025); o.rotation_euler.y=-.22
B('Loading lip',(.20,2.35,.19),(-3.90,0,1.16),'MetalTrim',.035)
B('Rear lifter crossbar',(.16,1.58,.12),(-3.96,0,.88),'Chassis',.025)
for y in (-.53,.53):B('Bin lift prong',(.25,.12,.42),(-3.83,y,1.04),'MetalTrim',.025)
B('Beacon base',(.35,.38,.07),(2.35,0,3.10),'Chassis',.02)
o=assign(cylinder('Amber beacon',.145,.19,(2.35,0,3.22),colors['AmberLens'],vertices=16),'AmberLens')
# Applied component transforms and packed UV0, retained when assembly is joined.
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent if False else None
bpy.ops.uv.smart_project(island_margin=.025); bpy.ops.object.mode_set(mode='OBJECT')
finish(parts)
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.samples=8
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
# Additional unambiguous review angles use the runner's studio and camera.
cam=scene.camera; cam.data.type='ORTHO'; cam.data.ortho_scale=9.6
for label,loc in [('side',(0,-14,4.0)),('front',(14,0,4.2)),('rear',(-14,0,4.2))]:
 cam.location=loc; cam.rotation_euler=(Vector((0,0,1.6))-cam.location).to_track_quat('-Z','Y').to_euler(); scene.render.filepath='/output/'+label+'.png'; bpy.ops.render.render(write_still=True)
Path('/output/review_notes.json').write_text(json.dumps({'status':'review only; not approval or production handoff','axes':'+X nose, +Z up; meters; ground z=0','materials':{'Glass':'opaque dark blue-gray glossy; native opaque glass remapping later','AmberLens':'amber beacon, not an emergency response signal','Headlight':'pale opaque lens','Taillight':'red opaque lens'},'source_preservation':'No production generators executed; repository untouched','views':['preview.png','side.png','front.png','rear.png']},indent=2))

import bpy, sys, json, math, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
O=Path('/output'); O.mkdir(exist_ok=True)
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
# New isolated source study; never loads or changes production geometry.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for m in list(bpy.data.meshes):
 if m.users==0: bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
 if m.users==0: bpy.data.materials.remove(m)
texdir=O/'textures';texdir.mkdir(exist_ok=True)
images={}; receipts=[]
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for channel in ['BaseColor','Normal','ORM']:
  name=family+'_'+channel+'.png'; src=Path('/repo/ArtSource/Textures')/folder/name; dst=texdir/name;shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst)); im.colorspace_settings.name='sRGB' if channel=='BaseColor' else 'Non-Color';im.pack();images[(family,channel)]=im
  receipts.append(dict(file='textures/'+name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
specs={'CivicBrick':('CityBrick',(0.66,0.36,0.22,1)), 'LightStone':(None,(.86,.81,.69,1)), 'RoofMembrane':('RoofMembrane',(.12,.16,.20,1)), 'EquipmentMetal':('CityMechanical',(.48,.54,.55,1)), 'WindowGlass':(None,(.10,.22,.29,1)), 'ServiceAccent':(None,(.055,.32,.35,1))}
mats={}; manifest={}
for name,(family,tint) in specs.items():
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=tint;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=tint;p.inputs['Roughness'].default_value=.72;p.inputs['Metallic'].default_value=0;p.inputs['Transmission Weight'].default_value=0
 n=m.node_tree.nodes;l=m.node_tree.links
 if family:
  ts={}
  for channel in ['BaseColor','Normal','ORM']:
   t=n.new('ShaderNodeTexImage');t.image=images[(family,channel)];ts[channel]=t
  sep=n.new('ShaderNodeSeparateColor');l.new(ts['ORM'].outputs['Color'],sep.inputs['Color'])
  ao=n.new('ShaderNodeMixRGB');ao.blend_type='MULTIPLY';ao.inputs[0].default_value=1;l.new(ts['BaseColor'].outputs['Color'],ao.inputs[1]);l.new(sep.outputs['Red'],ao.inputs[2])
  mul=n.new('ShaderNodeMixRGB');mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1;mul.inputs[2].default_value=tint;l.new(ao.outputs[0],mul.inputs[1]);l.new(mul.outputs[0],p.inputs['Base Color'])
  l.new(sep.outputs['Green'],p.inputs['Roughness']);l.new(sep.outputs['Blue'],p.inputs['Metallic'])
  normal=n.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.25;l.new(ts['Normal'].outputs['Color'],normal.inputs['Color']);l.new(normal.outputs[0],p.inputs['Normal'])
 mats[name]=m;manifest[name]=dict(texture_family=family,tint_multiply_after_basecolor_AO=tint,roughness_constant=.72,metallic_constant=0,transmission=0,normal_strength=.25 if family else 0,ORM={'R':'AO','G':'roughness','B':'metallic'} if family else None,UV='UV0 planar face projection, metres / 2; finite, shared 2m repeat')
objects=[];components=[];groups={}; bounds={}
def add(name,dim,loc,mat,group):
 ob=box(name,dim,loc,specs[mat][1]);ob.data.materials.clear();ob.data.materials.append(mats[mat]);objects.append(ob);groups.setdefault(group,[]).append(name)
 bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);ob.select_set(False);bpy.context.view_layer.update()
 lo=[loc[i]-dim[i]/2 for i in range(3)];hi=[loc[i]+dim[i]/2 for i in range(3)];bounds[name]=(lo,hi);components.append(dict(name=name,min=lo,max=hi))
 vg=ob.vertex_groups.new(name=name);vg.add(list(range(len(ob.data.vertices))),1,'REPLACE')
 uv=ob.data.uv_layers.active or ob.data.uv_layers.new(name='UV0');uv.name='UV0'
 for poly in ob.data.polygons:
  axis=max(range(3),key=lambda i:abs(poly.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in poly.loop_indices:
   co=ob.data.vertices[ob.data.loops[li].vertex_index].co+ob.location;uv.data[li].uv=(co[axes[0]]/2,co[axes[1]]/2)
 return ob
add('WardBody',(20,15,6.8),(-7,.5,3.4),'LightStone','body')
add('EmergencyBody',(13,15,5.2),(11.5,.5,2.6),'LightStone','garage')
add('EnclosedLink',(2,4,3.5),(4,4,1.75),'LightStone','body')
# restrained warm brick lower plinth is wall cladding, not a site slab
for name,x,w,h in [('Ward',-7,20,6.8),('Emergency',11.5,13,5.2)]:
 for y in [-7.025,8.025]: add(name+'Brick'+str(y),(w,.05,.72),(x,y,.36),'CivicBrick','body')
 for xx in [x-w/2-.025,x+w/2+.025]: add(name+'BrickSide'+str(xx),(.05,15,.72),(xx,.5,.36),'CivicBrick','body')
 add(name+'RoofDeck',(w+.16,15.16,.16),(x,.5,h+.08),'RoofMembrane','roof')
 for yy in [-7.07,8.07]: add(name+'Parapet'+str(yy),(w+.3,.16,.32),(x,yy,h+.24),'LightStone','roof')
 for xx in [x-w/2-.07,x+w/2+.07]: add(name+'RoofEdge'+str(xx),(.16,15,.32),(xx,.5,h+.24),'LightStone','roof')
add('LinkRoof',(2,4,.15),(4,4,3.575),'RoofMembrane','roof')
# Floor line and spare vertical articulation, no cladding in front of windows.
for y in [-7.045,8.045]:add('WardFloorBand'+str(y),(20,.09,.18),(-7,y,3.4),'CivicBrick','body')
windows=[];doors=[]
def window(name,back,axis,sign,u,z,w=1.65,h=1.55):
 lo,hi=bounds[back];face=hi[axis] if sign>0 else lo[axis];tangent=1-axis
 def part(n,uu,zz,ww,hh,depth,offset,mat):
  d=[0,0,hh];d[axis]=depth;d[tangent]=ww;c=[0,0,zz];c[axis]=face+sign*offset;c[tangent]=uu
  return add(n,d,c,mat,'windows')
 pane=part(name,u,z,w,h,.035,.010,'WindowGlass');r=.09
 frames=[]
 for label,uu in [('L',u-w/2-r/2),('R',u+w/2+r/2)]:
  n=name+label;part(n,uu,z,r,h+2*r,.10,.04,'LightStone');frames.append(n)
 for label,zz in [('S',z-h/2-r/2),('H',z+h/2+r/2)]:
  n=name+label;part(n,u,zz,w-.002,r,.10,.04,'LightStone');frames.append(n)
 pb=bounds[name];fb=[bounds[n] for n in frames]
 # Independent wall containment, contact/depth and disjoint four-bar rim tests.
 for a,b in [pb]+fb:
  for k in [tangent,2]:assert a[k]>=lo[k]+.12-1e-6 and b[k]<=hi[k]-.12+1e-6
  rear=a[axis] if sign>0 else b[axis];assert abs(rear-face)<=.02
 assert all(not all(min(bounds[a][1][k],bounds[b][1][k])-max(bounds[a][0][k],bounds[b][0][k])>1e-7 for k in range(3)) for i,a in enumerate(frames) for b in frames[i+1:])
 assert .01+.035/2 < .04+.10/2
 windows.append(dict(pane=name,frame_parts=frames,backing=back,axis=axis,sign=sign,wall_face=face,pane_bounds={'min':pb[0],'max':pb[1]},frame_bounds=[{'min':a,'max':b} for a,b in fb],checks={'containment':True,'contact':True,'clear_opening':True,'rim_disjoint':True,'pane_depth':True}))
for z in [1.95,5.0]:
 for x in [-14.8,-11.5,-2.5,.8]:window('WardFront'+str(x)+'_'+str(z),'WardBody',1,-1,x,z)
 for x in [-14.8,-11,-7,-3,.8]:window('WardRear'+str(x)+'_'+str(z),'WardBody',1,1,x,z)
 for y in [-4.5,.3,5.5]:window('WardWest'+str(y)+'_'+str(z),'WardBody',0,-1,y,z)
for y in [-4.2,.3,5.8]:window('EmergencyEast'+str(y),'EmergencyBody',0,1,y,2.6,1.8,1.6)
for x in [7.3,11.5,15.7]:window('EmergencyRear'+str(x),'EmergencyBody',1,1,x,2.6,1.8,1.6)
for x in [6.6,16.4]:window('EmergencyFront'+str(x),'EmergencyBody',1,-1,x,2.5,1.4,1.5)
# Actual doors: closed leaves behind unobstructed approach volumes.
for label,x in [('PublicDoorLeft',-7.5),('PublicDoorRight',-6.5)]:add(label,(.995,.12,2.5),(x,-7.045,1.25),'ServiceAccent','entry')
for x in [-8.08,-5.92]:add('PublicJamb'+str(x),(.14,.20,2.65),(x,-7.04,1.325),'LightStone','entry')
add('PublicHeader',(2.3,.20,.15),(-7,-7.04,2.7),'LightStone','entry')
add('PublicCanopy',(5,2.8,.20),(-7,-8.1,3.15),'ServiceAccent','entry')
for x in [-9.3,-4.7]:add('PublicPost'+str(x),(.16,.16,3.05),(x,-9.28,1.525),'EquipmentMetal','entry')
add('ServiceBayDoor',(4.5,.14,3.6),(11.5,-7.04,1.8),'ServiceAccent','garage')
for x in [9.16,13.84]:add('BayJamb'+str(x),(.18,.23,3.8),(x,-7.06,1.9),'LightStone','garage')
add('BayHeader',(4.86,.23,.18),(11.5,-7.06,3.89),'LightStone','garage')
for z in [.6,1.2,1.8,2.4,3.0]:add('BayDoorRail'+str(z),(4.42,.03,.035),(11.5,-7.125,z),'EquipmentMetal','garage')
add('AmbulanceCanopy',(6.7,3.1,.22),(11.5,-8.3,4.28),'ServiceAccent','entry')
# Original attached H relief: three separate connected strokes on fascia.
add('MedicalFascia',(2.6,.16,1.65),(-7,-7.12,4.6),'ServiceAccent','emblem')
for x in [-7.48,-6.52]:add('MedicalHStem'+str(x),(.19,.09,1.12),(x,-7.245,4.6),'LightStone','emblem')
add('MedicalHBridge',(.77,.09,.19),(-7,-7.245,4.6),'LightStone','emblem')
# Modest ventilation with all supports contacting real roof.
for label,x,y,z in [('Ward',-10,3,6.96),('Emergency',12,3,5.36)]:
 add(label+'PlantCurb',(3,2.1,.18),(x,y,z+.09),'EquipmentMetal','roof')
 add(label+'VentUnit',(2.8,1.9,.82),(x,y,z+.59),'EquipmentMetal','roof')
 for j in range(5):add(label+'VentLouver'+str(j),(2.5,.07,.045),(x,y-.98,z+.35+j*.12),'RoofMembrane','roof')
# Record exact spatial contracts before joining.
anchors=[]
for role,x,w,h,target,end in [('pedestrian',-7,2,2.5,'PublicDoorLeft',-7.32),('service',11.5,4.5,3.6,'ServiceBayDoor',-7.32)]:
 corridor={'min':[x-w/2,-20,0],'max':[x+w/2,end,h]}
 for c in components:
  assert not all(min(c['max'][i],corridor['max'][i])-max(c['min'][i],corridor['min'][i])>1e-6 for i in range(3)),('corridor',c['name'])
 anchors.append(dict(role=role,target=target,xyz_m=[x,end,0],outward=[0,-1,0],width_m=w,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=w,grade_m=0),reserved_free_corridor=corridor))
for c in components:
 assert c['min'][0]>=-23.5 and c['max'][0]<=23.5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5 and c['min'][2]>=-1e-6
write('entrance-anchors.json',{'anchors':anchors})
write('vehicle-bays.json',{'bays':[dict(id='emergency-01',target='ServiceBayDoor',xyz_m=anchors[1]['xyz_m'],outward=[0,-1,0],width_m=4.5,height_m=3.6,boundary_connector={'xyz_m':[11.5,-20,0]},reserved_free_corridor=anchors[1]['reserved_free_corridor'])]})
write('window-mounts.json',{'windows':windows,'doors':[dict(target='PublicDoorLeft',other_leaf='PublicDoorRight',backing='WardBody',clear_width_m=2,height_m=2.5),dict(target='ServiceBayDoor',backing='EmergencyBody',clear_width_m=4.5,height_m=3.6)]})
write('material-manifest.json',{'regions':manifest,'maps':receipts})
occupied={'min':[-17,-7,0],'max':[18,8,6.8]}
write('upgrade-plan.json',dict(family='hospital',stage='base',stage_index=0,existing_stages=['base','medium'],existing_upgrade_count=1,gameplay_changes=False,source_site_m=[48,40],current_native_footprint=[4,3],retained_entrance_centres=[[-7,-7],[11.5,-7]],progression='Base: two occupied ward floors, distinct lower emergency wing and enclosed link. Medium remains separate existing stage, not authored here.',occupied_bounds=occupied,LOD_notes='Future LOD1/LOD2 simplify window rims, H relief and roof louvers; approved old lowpoly sources untouched.'))
write('civic-contract.json',dict(family='hospital',stage='base',sourceID='building.hospital.a',role='outpatient ward and emergency',groups=groups,admin=groups['body'],proposed_site_m=[48,40],occupied_bounds=occupied,integration='HELD; review only'))
# Bake identity and preserve all component names as vertex groups.
bpy.ops.object.select_all(action='DESELECT')
for ob in objects:ob.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
bpy.context.view_layer.update()
triangles=sum(len(o.data.polygons)*2 for o in objects);assert triangles<8500
finish(objects)
# Retain tested renderer/export receipt and augment focused study validation.
p=O/'validation.json';v=json.loads(p.read_text()) if p.exists() else {};v.update(components=components,sourceID='building.hospital.a',stage='base',triangle_cap=8500,authored_triangles=triangles,semantic_regions=list(specs),window_count=len(windows),checks={'window_mounts':True,'corridors_all_components':True,'site_bounds':True,'exactly_two_anchors':len(anchors)==2,'maps_copied_and_packed':len(receipts)==9},review_only=True,integration_held=True)
write('validation.json',v)

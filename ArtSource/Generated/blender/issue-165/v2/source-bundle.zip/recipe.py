import bpy,sys,math,json,hashlib,shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box,cylinder,finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
# No completed parent is staged: fresh replacement source study.
for o in list(bpy.data.objects):
 if o.type=='MESH': bpy.data.objects.remove(o,do_unlink=True)
for m in list(bpy.data.meshes):
 if m.users==0:bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
 if m.users==0:bpy.data.materials.remove(m)
out=Path('/output');out.mkdir(exist_ok=True)
def write(name,data): (out/name).write_text(json.dumps(data,indent=2))
colors={'Concrete':(.43,.45,.43,1),'BuildingFacade':(.39,.46,.44,1),'RoofService':(.095,.115,.13,1),'EquipmentMetal':(.26,.31,.32,1),'WindowAccent':(.075,.16,.21,1)}
mats={}
for name,col in colors.items():
 m=bpy.data.materials.new(name);m.diffuse_color=col;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.72
 mats[name]=m
manifest=[]
for region,folder,prefix in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
 m=mats[region];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
 uv=n.new('ShaderNodeTexCoord');scale=n.new('ShaderNodeVectorMath');scale.operation='SCALE';scale.inputs[3].default_value=.5;l.new(uv.outputs['UV'],scale.inputs[0])
 tex={}
 for suffix in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(prefix+'_'+suffix+'.png');dst=out/'textures'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst));im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  t=n.new('ShaderNodeTexImage');t.image=im;l.new(scale.outputs['Vector'],t.inputs['Vector']);tex[suffix]=t
  manifest.append({'region':region,'source':str(src),'copy':str(dst),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'dimensions':list(im.size),'colorspace':im.colorspace_settings.name})
 l.new(tex['BaseColor'].outputs['Color'],p.inputs['Base Color'])
 sep=n.new('ShaderNodeSeparateColor');l.new(tex['ORM'].outputs['Color'],sep.inputs[0]);l.new(sep.outputs['Green'],p.inputs['Roughness']);l.new(sep.outputs['Blue'],p.inputs['Metallic'])
 normal=n.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.3;l.new(tex['Normal'].outputs['Color'],normal.inputs['Color']);l.new(normal.outputs['Normal'],p.inputs['Normal'])
write('material-manifest.json',{'regions':list(colors),'base_colors':colors,'textures':manifest,'normal_strength':.3,'metric_uv_scale':.5,'orm_channels':{'G':'roughness','B':'metallic'}})
objects=[]
def use(o,mat):
 o.data.materials.clear();o.data.materials.append(mats[mat]);objects.append(o);return o
def B(name,d,loc,mat='EquipmentMetal'):return use(box(name,d,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',seg=16):return use(cylinder(name,r,h,loc,colors[mat],vertices=seg),mat)
def pipe(name,a,b,r=.28,seg=12):
 a,b=Vector(a),Vector(b);o=C(name,r,(b-a).length,(a+b)/2,seg=seg);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def ring(name,x,y,ro,ri,z0,z1,mat,seg=32):
 verts=[(x+r*math.cos(2*math.pi*i/seg),y+r*math.sin(2*math.pi*i/seg),z) for r,z in [(ro,z0),(ro,z1),(ri,z1),(ri,z0)] for i in range(seg)]
 faces=[(j*seg+i,j*seg+(i+1)%seg,((j+1)%4)*seg+(i+1)%seg,((j+1)%4)*seg+i) for j in range(4) for i in range(seg)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return use(o,mat)
for i,x in enumerate([-10.8,0,10.8]):
 y=8;tag=f'Clarifier_{i+1}'
 ring(tag+'_structural_vessel',x,y,4.35,4.03,0,2.25,'Concrete');ring(tag+'_coping_rim',x,y,4.43,3.98,2.25,2.4,'Concrete')
 C(tag+'_recessed_calm_water',4.02,.08,(x,y,1.32),'WindowAccent',32)
 C(tag+'_spindle',.21,1.3,(x,y,1.99));B(tag+'_diameter_service_bridge',(8.55,.48,.18),(x,y,2.55));C(tag+'_drive',.37,.4,(x,y,2.84))
 for side in [-1,1]:
  for dx in [-4,-2,0,2,4]:B(tag+f'_post_{side}_{dx}',(.055,.055,1),(x+dx,y+side*.27,3.08))
  B(tag+f'_handrail_{side}',(8.2,.06,.06),(x,y+side*.27,3.58))
B('Worker_control_two_storey_block',(9,7,6.3),(-7.5,-7,3.15),'BuildingFacade')
B('Worker_control_flat_roof',(9.35,7.35,.22),(-7.5,-7,6.41),'RoofService')
B('Control_floor_band',(9.08,7.08,.16),(-7.5,-7,3.2),'Concrete')
B('Filter_pump_hall',(10,7,4.6),(6.5,-6.5,2.3),'BuildingFacade')
B('Filter_hall_service_roof',(10.35,7.35,.22),(6.5,-6.5,4.71),'RoofService')
B('Personnel_door_leaf',(1.2,.12,2.2),(-9.5,-10.56,1.1))
B('Personnel_door_glass',(.84,.035,1.1),(-9.5,-10.64,1.42),'WindowAccent')
B('Personnel_handle',(.05,.11,.35),(-9.06,-10.72,1.02))
B('Personnel_canopy',(2.1,1,.14),(-9.5,-10.8,2.65),'RoofService')
B('Service_vehicle_shutter',(4,.14,3.5),(7.5,-10.07,1.75))
for z in [.45,.95,1.45,1.95,2.45,2.95,3.45]:B('Shutter_seam_'+str(z),(3.92,.035,.035),(7.5,-10.16,z),'RoofService')
for x in [5.43,9.57]:B('Bay_jamb_'+str(x),(.13,.2,3.62),(x,-10.08,1.81),'Concrete')
B('Bay_header',(4.27,.2,.16),(7.5,-10.08,3.7),'Concrete')
windows=[]
def window(name,back,axis,face,u,z,w,h,depth=.16,pane=None):
 # Negative-facing wall. Full-height jambs; head/sill between jambs, without crossed corners.
 t=.11;outerw=w+2*t;outerh=h+2*t;center=face-depth/2+.01
 def loc(uu,nn,zz):return (nn,uu,zz) if axis==0 else (uu,nn,zz)
 def dims(ww,dd,hh):return (dd,ww,hh) if axis==0 else (ww,dd,hh)
 parts=[]
 for s in [-1,1]:parts.append(B(name+'_jamb_'+str(s),dims(t,depth,outerh),loc(u+s*(w/2+t/2),center,z)).name)
 for s in [-1,1]:parts.append(B(name+'_horizontal_'+str(s),dims(w,depth,t),loc(u,center,z+s*(h/2+t/2))).name)
 if pane is None:pane=B(name+'_pane',dims(w,.04,h),loc(u,center,z),'WindowAccent').name
 windows.append({'pane':pane,'frame_parts':parts,'backing':back,'axis':axis,'sign':-1,'wall_normal':[-1,0,0] if axis==0 else [0,-1,0]})
for z in [1.65,4.65]:
 for x in [-6.9,-4.5]:window(f'Control_front_{x}_{z}','Worker_control_two_storey_block',1,-10.5,x,z,1.63,1.23)
for y in [-8.9,-6.5,-4.52]:
 for z in [1.65,4.65]:window(f'Control_side_{y}_{z}','Worker_control_two_storey_block',0,-12,y,z,1.58,1.23)
for x in [2.8,4.5]:window('Hall_window_'+str(x),'Filter_pump_hall',1,-10,x,3.7,1.35,.8)
window('Personnel_glazing_rim','Worker_control_two_storey_block',1,-10.5,-9.5,1.42,.84,1.1,.20,'Personnel_door_glass')
for x in [3.2,7.8]:
 B('Hall_roof_vent_'+str(x),(1.4,1.5,.6),(x,-5.8,5.11));B('Hall_vent_cap_'+str(x),(1.6,1.7,.12),(x,-5.8,5.47),'RoofService')
# Attached throughput wing: shares the pump hall east wall, no extra storeys.
B('Attached_filter_service_wing',(6,7,3.6),(14.5,-6.5,1.8),'BuildingFacade')
B('Filter_wing_roof',(6.25,7.25,.2),(14.5,-6.5,3.7),'RoofService')
for x in [12.7,14.5,16.3]:window('Wing_window_'+str(x),'Attached_filter_service_wing',1,-10,x,2.4,1.15,.8)
for x in [12.8,15.7]:
 B('Wing_filter_housing_'+str(x),(1.4,2,.8),(x,-6.4,4.2));B('Wing_filter_lid_'+str(x),(1.55,2.15,.12),(x,-6.4,4.66),'RoofService')
for j,x in enumerate([-10.8,0,10.8]):
 pipe(f'Main_{j}_horizontal',(x,-1.8,.85),(x,2.7,.85),.3)
 pipe(f'Main_{j}_riser',(x,2.7,.85),(x,2.7,1.9),.3)
 pipe(f'Main_{j}_basin_inlet',(x,2.7,1.9),(x,3.9,1.9),.3)
 for y in [-.9,1.5]:pipe(f'Main_{j}_flange_{y}',(x,y-.07,.85),(x,y+.07,.85),.43,16)
 pipe(f'Valve_{j}_stem',(x,.2,.9),(x,.2,1.55),.065,8);C(f'Valve_{j}_handwheel',.31,.07,(x,.2,1.58))
 for y in [-1.2,1.8]:B(f'Pipe_{j}_foot_{y}',(.18,.25,.55),(x,y,.275))
pipe('Rear_distribution_header',(-10.8,-1.8,.85),(10.8,-1.8,.85),.3)
pipe('Pump_hall_outlet',(8.8,-3.05,.85),(8.8,-1.8,.85),.3)
for i,(x,y) in enumerate([(x,y) for x in [-1.5,.4] for y in [-4.1,-6.4]]):
 C('Upright_process_vessel_'+str(i),.62,2.65,(x,y,1.675),seg=24);C('Vessel_cap_'+str(i),.65,.16,(x,y,3.08),seg=24)
 for dx in [-.4,.4]:B(f'Vessel_leg_{i}_{dx}',(.12,.5,.45),(x+dx,y,.225))
 if x==.4:pipe(f'Vessel_{i}_pump_connection',(x+.5,y,1.4),(1.58,y,1.4),.16)
 else:pipe(f'Vessel_{i}_link',(x+.5,y,1.4),(-.1,y,1.4),.16)
pipe('Process_bank_outlet',(-1.5,-3.55,1.4),(-1.5,-2.3,1.4),.16)
pipe('Process_bank_drop',(-1.5,-2.3,1.4),(-1.5,-2.3,.85),.16)
pipe('Process_bank_join',(-1.5,-2.3,.85),(-1.5,-1.8,.85),.16)
# Freeze actual transforms, then metric box-projected UV0 on every surface.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.context.view_layer.update()
def bounds(o):
 v=[o.matrix_world@p.co for p in o.data.vertices];return ([min(p[i] for p in v) for i in range(3)],[max(p[i] for p in v) for i in range(3)])
components=[];bd={}
for o in objects:
 lo,hi=bounds(o);bd[o.name]=(lo,hi);components.append({'name':o.name,'min':lo,'max':hi})
 assert lo[0]>=-23.5 and hi[0]<=23.5 and lo[1]>=-15.5 and hi[1]<=15.5 and lo[2]>=-1e-6
 uv=o.data.uv_layers.get('UVMap') or o.data.uv_layers.new(name='UVMap');uv.name='UVMap'
 for p in o.data.polygons:
  axis=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in p.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]],v[axes[1]])
 assert all(math.isfinite(c) for d in uv.data for c in d.uv)
# Contact/containment checked from real frozen vertices, not nominal dimensions.
for w in windows:
 a=w['axis'];u=1-a;pl,ph=bd[w['pane']];wl,wh=bd[w['backing']];frames=[bd[n] for n in w['frame_parts']]
 for fl,fh in frames:
  assert abs(fh[a]-(wl[a]+.01))<1e-4
  for k in [u,2]:assert fl[k]>=wl[k]+.12-1e-5 and fh[k]<=wh[k]-.12+1e-5
 assert pl[a]>=min(v[0][a] for v in frames)-1e-5 and ph[a]<=max(v[1][a] for v in frames)+1e-5
 assert abs(frames[0][1][u]-pl[u])<1e-4 and abs(frames[1][0][u]-ph[u])<1e-4
 assert abs(frames[2][1][2]-pl[2])<1e-4 and abs(frames[3][0][2]-ph[2])<1e-4
write('window-mounts.json',{'windows':windows,'measured_contact_containment_pass':True})
anchors=[]
for role,target,x,width,clear,height,names in [('pedestrian','Personnel_door_leaf',-9.5,1.2,1.8,2.4,['Personnel_door_leaf','Personnel_door_glass','Personnel_handle']+[n for w in windows if w['pane']=='Personnel_door_glass' for n in w['frame_parts']]),('vehicle_service','Service_vehicle_shutter',7.5,4,4,3.5,['Service_vehicle_shutter']+[o.name for o in objects if o.name.startswith('Shutter_seam_')])]:
 end=min(bd[n][0][1] for n in names)-.02;lo=[x-clear/2,-16,0];hi=[x+clear/2,end,height]
 for co in components:assert not all(min(hi[k],co['max'][k])-max(lo[k],co['min'][k])>1e-6 for k in range(3)),(target,co['name'])
 anchors.append({'role':role,'target':target,'xyz_m':[x,bd[target][0][1],0],'outward':[0,-1,0],'width_m':width,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':clear,'grade_m':0},'reserved_free_corridor':{'min':lo,'max':hi}})
write('entrance-anchors.json',{'anchors':anchors,'measured_no_component_overlap':True})
triangles=0
for o in objects:o.data.calc_loop_triangles();triangles+=len(o.data.loop_triangles)
assert triangles<=8000,triangles
low=[min(c['min'][k] for c in components) for k in range(3)];high=[max(c['max'][k] for c in components) for k in range(3)]
write('upgrade-stage.json',{'asset_id':'building.service.medium.a','stage':'water_medium','capacity_percent_reference':200,'module_counts':{'clarifiers':sum(c['name'].endswith('_structural_vessel') for c in components),'upright_process_vessels':sum(c['name'].startswith('Upright_process_vessel_') for c in components),'attached_filter_wings':1},'occupied_envelope_m':{'min':low,'max':high},'base_identity':'parent #157 reviewed geometry packet; no completed parent staged','review_only':True,'lower_LOD_plan':'Preserve building masses, portals, clarifier diameters and major pipes; reduce secondary rings, frames and fixtures. No mobile performance claim.'})
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
vp=out/'validation.json';val=json.loads(vp.read_text()) if vp.exists() else {}
val.update({'components':components,'source_triangles':triangles,'triangle_ceiling':8000,'semantic_region_count':5,'window_mounts_pass':True,'entrance_corridors_pass':True,'plot_inset_pass':True,'review_only':True})
# Keep the tested helper's real roundtrip receipt; assert and save final editable source.
mesh=[o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.polygons)>0]
asset=max(mesh,key=lambda o:len(o.data.polygons))
asset.data.calc_loop_triangles();assert len(asset.data.loop_triangles)<=8000;assert len(asset.data.materials)==5
val['final_triangles']=len(asset.data.loop_triangles);val['final_regions']=[m.name for m in asset.data.materials]
write('validation.json',val)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

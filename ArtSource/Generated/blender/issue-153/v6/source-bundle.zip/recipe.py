import bpy, sys
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
objects=load_previous()
# Explicit geometry revision: use the prior recipe, not polygon surgery on its joined mesh.
# The read-only previous blend and recipe remain untouched.
for obj in list(objects):
 bpy.data.objects.remove(obj,do_unlink=True)
# Removed parent objects leave orphan meshes holding material users.
for mesh in list(bpy.data.meshes):
 if mesh.users==0: bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
 if mat.users==0: bpy.data.materials.remove(mat)
assert not any(bpy.data.materials.get(n) for n in ['Concrete','BuildingFacade','RoofService','EquipmentMetal','WindowAccent'])
s=Path('/previous/recipe.py').read_text()
def replace(old,new):
 global s
 assert old in s,old
 s=s.replace(old,new)
replace("seed=box('Control wing',(9,5,4),(-8,-9,2)","seed=box('Control wing',(9,11.5,6.5),(-8,-5.75,3.25)")
a=s.index("lathe('Containment shell'")
b=s.index("B('Turbine hall'",a)
s=s[:a]+s[b:]
a=s.index('for x,h in [(-8,16.4)')
b=s.index("B('Turbine hall'",a)
s=s[:a]+'''for x,h in [(-8,11.6),(7.8,11.2)]:
 # Every ring height is relative to the revised total, including the inner return.
 profile=[(5.15,0),(5.2,.075*h),(4.65,.23*h),(3.85,.46*h),(3.5,.64*h),(3.58,.80*h),(3.85,.98*h),(3.9,h),(3.64,h),(3.59,.975*h),(3.32,.80*h),(3.24,.64*h),(3.59,.46*h),(4.39,.23*h),(4.94,.075*h),(4.89,0)]
 lathe('Open cooling shell',(x,10.1),profile,'Concrete')
 lathe('Recessed intake band',(x,10.1),[(4.96,.023*h),(4.96,.081*h)],'RoofService')
 for i in range(8):
  a=i*math.tau/8
  C('Intake pier',.18,.09*h,(x+4.98*math.cos(a),10.1+4.98*math.sin(a),.045*h),'Concrete',8)
''' +s[b:]
replace("B('Control roof',(9.25,5.25,.22),(-8,-9,4.11),'RoofService')", "B('Control roof',(9.25,11.75,.22),(-8,-5.75,6.61),'RoofService')\nB('Worker floor band',(9.08,11.5,.14),(-8,-5.75,3.25),'Concrete')")
a=s.index('for x in [-11.3,-6.6,-4.6]:')
b=s.index('def pipe(',a)
s=s[:a]+'''for z in [2.45,5.05]:
 for x in [-11.3,-6.6,-4.6]:
  B('Window frame',(1.5,.15,1.25),(x,-11.57,z),'Concrete')
  B('Opaque window',(1.28,.06,1.03),(x,-11.68,z),'WindowAccent')
  B('Window mullion',(.05,.07,1.05),(x,-11.72,z))
 for x,sign in [(-12.5,-1),(-3.5,1)]:
  for y in [-8.8,-5.4,-2.0]:
   B('Side window frame',(.15,1.5,1.25),(x+sign*.07,y,z),'Concrete')
   B('Side opaque window',(.06,1.28,1.03),(x+sign*.16,y,z),'WindowAccent')
   B('Side window mullion',(.07,.05,1.05),(x+sign*.20,y,z))
for x in [-10,-6]:
 B('Control rooftop unit',(1.5,1.2,.75),(x,-5.3,7.1))
 for z in [6.9,7.1,7.3]: B('Unit louver',(1.3,.035,.045),(x,-5.92,z),'RoofService')
''' +s[b:]
replace("pipe('Cooling riser',(x,4.75,1.15),(x,4.75,2.8),.4)","pipe('Cooling riser',(x,4.9,1.15),(x,4.9,2.8),.4)")
replace("pipe('Cooling transfer',(x,4.75,2.8),(x,3.0,2.8),.4)","pipe('Cooling transfer',(x,4.9,2.8),(x,1.6,2.8),.4)")
replace('for y in [3.2,4.4]:','for y in [1.8,4.65]:')
# Refresh world matrices before truthful component bounds and corridor assertions.
replace('components=[]\nfor o in objects:', 'bpy.context.view_layer.update()\ncomponents=[]\nfor o in objects:')
replace("revision='Same v3 geometry/material prefix; intrinsic portal clearance correction only. Prior failed history retained externally.'", "revision='v5 geometry revision derived from v4 recipe: containment removed; substantial two-storey worker block; shorter broader open cooling shells. Prior source preserved read-only.'")
# Execute only the revised recipe once, retaining the tested finish and actual FBX roundtrip.
exec(compile(s,'/output/revised-v4-recipe.py','exec'),globals())
import json, math, hashlib
O=Path('/output')
validation=json.loads((O/'validation.json').read_text())
worker=next(c for c in components if c['name']=='Control wing')
towers=[c for c in components if c['name'].startswith('Open cooling shell')]
assert len(towers)==2
assert not any('Containment' in c['name'] for c in components)
assert all(math.isfinite(t) for uv in plant.data.uv_layers.active.data for t in uv.uv)
assert all(abs(v-1)<1e-6 for v in plant.scale)
assert all(abs(v)<1e-6 for v in plant.rotation_euler)
validation['revised_mass_measurements']={'worker_body':{'bounds':worker,'dimensions_m':[worker['max'][i]-worker['min'][i] for i in range(3)],'storeys':2},'towers':[{'bounds':c,'centre_xy_m':[(c['min'][i]+c['max'][i])/2 for i in range(2)],'height_m':c['max'][2]-c['min'][2],'base_diameter_m':10.4} for c in towers],'containment_removed':True}
validation['finite_uv0']=True
validation['previous_recipe_sha256']=hashlib.sha256(Path('/previous/recipe.py').read_bytes()).hexdigest()
validation['preserved_material_contract']='Same five semantic regions and six original texture files, copied and packed by the v4 material recipe with original SHA256 provenance.'
(O/'validation.json').write_text(json.dumps(validation,indent=2))
(O/'revised-v4-recipe.py').write_text(s)

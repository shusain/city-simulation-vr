import bpy, sys, math, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
O=Path('/output'); O.mkdir(exist_ok=True)
objects=[]
seed=box('Control wing',(9,5,4),(-8,-9,2),(.5,.5,.5,1)); objects.append(seed)
materials={}
for name,col,rough,metal in [('Concrete',(.56,.58,.55,1),.83,0),('BuildingFacade',(.36,.43,.43,1),.68,0),('RoofService',(.105,.13,.15,1),.78,0),('EquipmentMetal',(.24,.34,.34,1),.33,.7),('WindowAccent',(.035,.10,.14,1),.22,.25)]:
 m=bpy.data.materials.new(name); m.use_nodes=True; m.diffuse_color=col
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=col; p.inputs['Roughness'].default_value=rough; p.inputs['Metallic'].default_value=metal
 materials[name]=m
m=materials['Concrete']; n=m.node_tree.nodes; l=m.node_tree.links
tex=n.new('ShaderNodeTexNoise'); tex.inputs['Scale'].default_value=5; tex.inputs['Detail'].default_value=2
coord=n.new('ShaderNodeTexCoord'); l.new(coord.outputs['Object'],tex.inputs['Vector'])
bump=n.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.12; bump.inputs['Distance'].default_value=.035
l.new(tex.outputs['Fac'],bump.inputs['Height']); l.new(bump.outputs['Normal'],n.get('Principled BSDF').inputs['Normal'])
texture_records=[]
def mapped(region,folder,stem):
 m=materials[region]; nodes=m.node_tree.nodes; links=m.node_tree.links; p=nodes.get('Principled BSDF')
 uv=nodes.new('ShaderNodeTexCoord'); mapping=nodes.new('ShaderNodeVectorMath'); mapping.operation='SCALE'; mapping.inputs[3].default_value=.5; links.new(uv.outputs['UV'],mapping.inputs[0])
 for suffix,space in [('BaseColor','sRGB'),('Normal','Non-Color'),('ORM','Non-Color')]:
  src=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+suffix+'.png'); dst=O/'textures'/src.name; dst.parent.mkdir(exist_ok=True); shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst),check_existing=True); im.colorspace_settings.name=space; im.pack()
  t=nodes.new('ShaderNodeTexImage'); t.image=im; links.new(mapping.outputs['Vector'],t.inputs['Vector'])
  if suffix=='BaseColor': links.new(t.outputs['Color'],p.inputs['Base Color'])
  elif suffix=='Normal':
   normal=nodes.new('ShaderNodeNormalMap'); normal.inputs['Strength'].default_value=.35; links.new(t.outputs['Color'],normal.inputs['Color']); links.new(normal.outputs['Normal'],p.inputs['Normal'])
  else:
   separate=nodes.new('ShaderNodeSeparateColor'); links.new(t.outputs['Color'],separate.inputs['Color']); links.new(separate.outputs['Green'],p.inputs['Roughness'])
   if region=='EquipmentMetal': links.new(separate.outputs['Blue'],p.inputs['Metallic'])
  texture_records.append(dict(region=region,image=im.name,source=str(src),bundle=str(dst),sha256=hashlib.sha256(src.read_bytes()).hexdigest(),dimensions=list(im.size),channels=im.channels,colorspace=space,meaning=suffix))
mapped('RoofService','CivicSurfaces','CivicAsphalt')
mapped('EquipmentMetal','BuildingSurfaces','CityMechanical')
def assign(o,mat):
 o.data.materials.clear(); o.data.materials.append(materials[mat]); return o
assign(seed,'BuildingFacade')
def B(name,size,pos,mat='EquipmentMetal'):
 o=box(name,size,pos,(.4,.4,.4,1)); assign(o,mat); objects.append(o); return o
def C(name,r,d,pos,mat='EquipmentMetal',v=12):
 o=cylinder(name,r,d,pos,(.4,.4,.4,1),vertices=v); assign(o,mat); objects.append(o); return o
def lathe(name,xy,rings,mat,segments=32,close=False):
 verts=[(xy[0]+r*math.cos(2*math.pi*i/segments),xy[1]+r*math.sin(2*math.pi*i/segments),z) for r,z in rings for i in range(segments)]
 faces=[]
 for j in range(len(rings)-1):
  for i in range(segments):
   a=j*segments+i; b=j*segments+(i+1)%segments; faces.append((a,b,b+segments,a+segments))
 if close: faces.extend([tuple(reversed(range(segments))),tuple((len(rings)-1)*segments+i for i in range(segments))])
 mesh=bpy.data.meshes.new(name); mesh.from_pydata(verts,[],faces); mesh.update(); o=bpy.data.objects.new(name,mesh); bpy.context.collection.objects.link(o); assign(o,mat); objects.append(o)
 for p in mesh.polygons:p.use_smooth=len(p.vertices)==4
 return o
for x,h in [(-8,16.4),(7.8,15.5)]:
 profile=[(4.25,0),(4.3,1),(3.65,3.5),(2.9,7),(2.65,10),(2.72,12.5),(3.05,h-.2),(3.08,h),(2.82,h),(2.79,h-.3),(2.47,12.5),(2.4,10),(2.65,7),(3.4,3.5),(4.0,1),(4.0,0)]
 lathe('Open cooling shell', (x,9),profile,'Concrete')
 lathe('Recessed intake band',(x,9),[(4.01,.3),(4.01,1.05)],'RoofService')
 for i in range(8):
  a=i*math.tau/8; C('Intake pier',.15,1.15,(x+4.05*math.cos(a),9+4.05*math.sin(a),.575),'Concrete',8)
lathe('Containment shell',(-7,-1),[(3.65,0),(3.65,6.9),(3.6,7.8),(3.35,8.8),(2.85,9.8),(2.05,10.65),(1.05,11.15),(.01,11.4)],'Concrete',32,True)
lathe('Containment service collar',(-7,-1),[(3.68,6.7),(3.68,6.95)],'EquipmentMetal')
B('Containment access housing',(2.0,1.0,2.9),(-7,-4.55,1.45),'Concrete')
B('Containment door',(1.2,.12,2.2),(-7,-5.09,1.1),'EquipmentMetal')
B('Turbine hall',(9,13,6),(7,-2,3),'BuildingFacade')
B('Turbine roof',(9.35,13.3,.24),(7,-2,6.12),'RoofService')
for x in [2.55,11.45]:
 B('Roof edge cap',(.15,13.4,.28),(x,-2,6.33))
for y in [-6,-2,2]:
 B('Roof monitor',(4.6,1.65,.72),(7,y,6.58),'BuildingFacade')
 B('Monitor glazing',(4.25,.08,.38),(7,y-.87,6.62),'WindowAccent')
 B('Monitor cap',(4.95,1.9,.12),(7,y,7),'RoofService')
for y in [-7,-3,1,4]:
 B('Hall structural pilaster',(.18,.24,5.8),(11.56,y,2.9),'Concrete')
B('Vehicle bay frame',(4.9,.20,4.4),(8,-8.61,2.2),'Concrete')
B('Vehicle bay shutter',(4.5,.12,4.05),(8,-8.74,2.025),'EquipmentMetal')
for z in [.6,1.2,1.8,2.4,3,3.6]: B('Shutter seam',(4.45,.03,.035),(8,-8.815,z),'RoofService')
B('Bay lintel',(5.0,.45,.18),(8,-8.6,4.45),'RoofService')
B('Control roof',(9.25,5.25,.22),(-8,-9,4.11),'RoofService')
B('Door surround',(1.48,.18,2.4),(-9,-11.57,1.2),'Concrete')
B('Pedestrian door',(1.2,.10,2.2),(-9,-11.71,1.1),'EquipmentMetal')
B('Door glass',(.76,.045,1.0),(-9,-11.78,1.48),'WindowAccent')
B('Door handle',(.06,.10,.34),(-8.55,-11.80,1.05))
B('Entrance canopy',(2.2,.8,.12),(-9,-11.65,2.65),'RoofService')
for x in [-11.3,-6.6,-4.6]:
 B('Window frame',(1.5,.15,1.25),(x,-11.57,2.45),'Concrete')
 B('Opaque window',(1.28,.06,1.03),(x,-11.68,2.45),'WindowAccent')
 B('Window mullion',(.05,.07,1.05),(x,-11.72,2.45))
for x in [-10,-6]:
 B('Control rooftop unit',(1.5,1.2,.75),(x,-8.3,4.6))
 for z in [4.4,4.6,4.8]:B('Unit louver',(1.3,.035,.045),(x,-8.92,z),'RoofService')
def pipe(name,a,b,r=.33):
 a,b=Vector(a),Vector(b); o=C(name,r,(b-a).length,(a+b)/2); o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler(); return o
for x in [-8,7.8]:
 pipe('Cooling riser',(x,4.75,1.15),(x,4.75,2.8),.4)
 pipe('Cooling transfer',(x,4.75,2.8),(x,3.0,2.8),.4)
 for y in [3.2,4.4]:
  o=C('Flange',.52,.15,(x,y,2.8)); o.rotation_euler[0]=math.pi/2
pipe('Cross manifold',(-2.8,1.3,1.1),(2.4,1.3,1.1),.32)
for x in [-2,1.6]: B('Pipe saddle',(.4,.65,.9),(x,1.3,.45),'Concrete')
for y in [-4.5,-.7]:
 B('Transformer tank',(2.1,2.1,2.1),(-.4,y,1.2))
 for x in [-1.65,.85]:
  B('Radiator block',(.3,1.7,1.5),(x,y,1.05))
  for yy in [-.6,0,.6]:B('Radiator rib',(.38,.08,1.5),(x,y+yy,1.05),'RoofService')
 for x in [-.95,.15]:
  C('Bushing',.15,.7,(x,y,2.55),'WindowAccent',8)
  C('Terminal',.22,.10,(x,y,2.9),'EquipmentMetal',8)
for x in [-1.7,0,1.7]:
 B('Service cabinet',(1.1,.8,1.75),(x,-8, .875))
 B('Cabinet panel',(.9,.035,1.5),(x,-8.42,.9),'BuildingFacade')
 B('Cabinet latch',(.07,.08,.18),(x+.28,-8.46,.95),'RoofService')
components=[]
for o in objects:
 bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0')
 for p in o.data.polygons:
  axis=max(range(3),key=lambda k:abs(p.normal[k])); axes=[k for k in range(3) if k!=axis]
  for li in p.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co; uv.data[li].uv=(co[axes[0]],co[axes[1]])
 pts=[o.matrix_world@v.co for v in o.data.vertices]; components.append(dict(name=o.name,min=[min(v[k] for v in pts) for k in range(3)],max=[max(v[k] for v in pts) for k in range(3)]))

anchors=[]
for role,x,y,width,freewidth,height,target,prefixes in [
 ('pedestrian',-9,-11.76,1.2,1.8,2.4,'Control wing / Pedestrian door',('Pedestrian door','Door glass','Door handle')),
 ('vehicle_service',8,-8.80,4.5,4.5,3.8,'Turbine hall / Vehicle bay shutter',('Vehicle bay shutter','Shutter seam'))]:
 portals=[c for c in components if any(c['name']==s or c['name'].startswith(s+'.') for s in prefixes)]
 assert portals
 portal_min=min(c['min'][1] for c in portals)
 maxy=min(y-.02,portal_min-.02)
 lo=[x-freewidth/2,-16,0]; hi=[x+freewidth/2,maxy,height]
 overlaps=[c['name'] for c in components if all(c['max'][k]>lo[k] and c['min'][k]<hi[k] for k in range(3))]
 assert not overlaps,(role,overlaps)
 anchors.append(dict(role=role,xyz_m=[x,y,0],outward=[0,-1,0],usable_width_m=width,sill_m=0,nominal_grade_m=0,target=target,boundary_connector=dict(role=role+'_plot_boundary',xyz_m=[x,-16,0],outward=[0,-1,0],usable_width_m=freewidth,nominal_grade_m=0),reserved_free_corridor=dict(min=lo,max=hi,width_m=freewidth,height_m=height,strict_all_components_aabb_pass=True),portal_components=portals,measured_portal_min_y=portal_min,anchor_to_free_corridor_segment=dict(start=[x,y,0],end=[x,maxy,0],note='Intrinsic portal fixtures occupy this short transition; not represented as empty approach.')))
anchor_doc=dict(units='metres',source_front='-Y',pivot=[0,0,0],native_yaw_mapping='Deferred to issue #125',anchors=anchors)
(O/'entrance-anchors.json').write_text(json.dumps(anchor_doc,indent=2))
triangles=0
for o in objects:
 o.data.calc_loop_triangles(); triangles+=len(o.data.loop_triangles)
assert triangles<=5000,triangles
assert all(c['min'][k]>=-15.5 and c['max'][k]<=15.5 for c in components for k in [0,1])
assert len({m.name for o in objects for m in o.data.materials})<=5
finish(objects)
plant=max((o for o in bpy.context.scene.objects if o.type=='MESH'),key=lambda o:len(o.data.polygons))
bpy.ops.object.select_all(action='DESELECT'); plant.select_set(True); bpy.context.view_layer.objects.active=plant
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
plant.name='Nuclear_4x4_ReviewOnly'
plant.data.calc_loop_triangles()
assert len(plant.data.loop_triangles)==triangles
assert len(plant.data.materials)<=5
slots=[m.name for m in plant.data.materials]
with checked_fbx(plant,O/'asset.fbx',slots,expected_triangles=triangles,expected_sections=len(slots)) as readback:
 roundtrip=dict(pass_checked=True,triangles=len(readback.data.loop_triangles),sections=len(readback.data.materials),dimensions_m=list(readback.dimensions),only_plant=True)
bpy.ops.wm.save_as_mainfile(filepath=str(O/'asset.blend'))
vp=O/'validation.json'
validation=json.loads(vp.read_text()) if vp.exists() else {}
validation.update(dict(review_only=True,triangles=triangles,semantic_regions=slots,section_count=len(slots),bounds=dict(min=[min(c['min'][k] for c in components) for k in range(3)],max=[max(c['max'][k] for c in components) for k in range(3)]),origin=list(plant.location),uv0=dict(present=plant.data.uv_layers.active is not None,loops=len(plant.data.uv_layers.active.data),method='Metric dominant-axis projection; reused image vector scale 0.5'),entrance_anchors=anchor_doc,components=components,checked_fbx=roundtrip,scope='Pathless 32x32m review study; no parcel slab, paths, terrain, native edits or approval. Studio staging excluded from FBX.',revision='Same v3 geometry/material prefix; intrinsic portal clearance correction only. Prior failed history retained externally.'))
vp.write_text(json.dumps(validation,indent=2))
manifest=dict(regions=slots,textures=texture_records,orm_channels=dict(R='AO',G='roughness',B='metallic'),native_reconstruction='FBX does not transfer shader graphs. Reconstruct UV scale 0.5, BaseColor sRGB, tangent normal linear strength .35, ORM linear G roughness and EquipmentMetal B metallic. AO supplied in R, not connected in Blender. Concrete retains editable object-space noise bump; remaining regions use editable Principled constants.',new_texture_bakes=[],source_policy='Existing maps copied read-only with SHA256 provenance and packed into blend; no repository writes.',material_parameters={name:dict(base_color=list(m.diffuse_color),roughness=m.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value,metallic=m.node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value) for name,m in materials.items()})
(O/'material-manifest.json').write_text(json.dumps(manifest,indent=2))

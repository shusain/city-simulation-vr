import bpy,bmesh,sys,json,math,shutil,hashlib
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
objects=load_previous()
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2))
for o in objects:
 bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o; bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
mats={m.name:m for o in objects for m in o.data.materials}
assert all(n in mats for n in ['CivicBrick','LightStone','RoofMembrane','EquipmentMetal','WindowGlass','ServiceAccent'])
def constant(m,c,r,metal):
 m.use_nodes=True; p=m.node_tree.nodes.get('Principled BSDF')
 for name,value in [('Base Color',c),('Roughness',r),('Metallic',metal),('Transmission Weight',0)]:
  for link in list(p.inputs[name].links): m.node_tree.links.remove(link)
  p.inputs[name].default_value=value
 m.diffuse_color=c
constant(mats['ServiceAccent'],(.035,.24,.075,1),.70,.10)
rubber=bpy.data.materials.get('ContainerLidRubber') or bpy.data.materials.new('ContainerLidRubber'); constant(rubber,(.012,.015,.018,1),.85,0); mats[rubber.name]=rubber
# Delete exactly requested old connected groups, leaving all remaining vertices unchanged.
removed=[]; original={}
def groupcoords(o,g): return [v.co.copy() for v in o.data.vertices if any(x.group==g.index and x.weight>.5 for x in v.groups)]
for o in objects:
 for g in o.vertex_groups:
  co=groupcoords(o,g)
  if co: original[g.name]=[tuple(v) for v in co]
 targets=[g for g in o.vertex_groups if g.name in ['Admin_corner_-19.95','Admin_corner_-10.3','Admin_floor_band'] or (g.name.startswith('Hall') and 'parapet' in g.name.lower())]
 indices=set()
 for g in targets:
  removed.append(g.name)
  indices.update(v.index for v in o.data.vertices if any(x.group==g.index and x.weight>.5 for x in v.groups))
 if indices:
  bm=bmesh.new(); bm.from_mesh(o.data); bm.verts.ensure_lookup_table(); bmesh.ops.delete(bm,geom=[bm.verts[i] for i in indices],context='VERTS'); bm.to_mesh(o.data); bm.free()
 for g in targets: o.vertex_groups.remove(g)
 # Recolour the retained emblem lid, no geometry edits.
 if 'ContainerLidRubber' not in [m.name for m in o.data.materials]: o.data.materials.append(rubber)
 ri=list(o.data.materials).index(rubber)
 g=o.vertex_groups.get('Bin_relief_lid')
 if g:
  ids={v.index for v in o.data.vertices if any(x.group==g.index for x in v.groups)}
  for p in o.data.polygons:
   if all(i in ids for i in p.vertices): p.material_index=ri
assert len(removed)==7,removed
newnames=[]
def meshpart(name,verts,faces,mat):
 me=bpy.data.meshes.new(name); me.from_pydata(verts,[],faces); me.update(); ob=bpy.data.objects.new(name,me); bpy.context.scene.collection.objects.link(ob); me.materials.append(mats[mat]); ob.vertex_groups.new(name=name).add(list(range(len(verts))),1,'REPLACE'); objects.append(ob); newnames.append(name)
 uv=me.uv_layers.new(name='UV0')
 for p in me.polygons:
  ax=max(range(3),key=lambda a:abs(p.normal[a])); axes=[a for a in range(3) if a!=ax]
  for li in p.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co; uv.data[li].uv=(v[axes[0]]/2,v[axes[1]]/2)
 return ob
def box(n,lo,hi,m):
 v=[(x,y,z) for z in [lo[2],hi[2]] for y in [lo[1],hi[1]] for x in [lo[0],hi[0]]]
 return meshpart(n,v,[(0,2,3,1),(4,5,7,6),(0,1,5,4),(2,6,7,3),(0,4,6,2),(1,3,7,5)],m)
trimsets=[]
for z in [.22,3.2,6.3]:
 d=[('F',[-20.06,-8.06,z-.06],[-9.94,-7.99,z+.06]),('B',[-20.06,4.99,z-.06],[-9.94,5.06,z+.06]),('W',[-20.06,-7.99,z-.06],[-19.99,4.99,z+.06]),('E',[-10.01,-7.99,z-.06],[-9.94,.99 if z<4 else 4.99,z+.06])]
 ns=[]
 for side,lo,hi in d:
  n='TrimR2_'+str(z)+'_'+side; box(n,lo,hi,'LightStone'); ns.append(n)
 trimsets.append(ns)
roof_top=max(v[2] for v in original['Hall_slate_roof'])
for side,xy in [('W',[-8,-8,-7.78,10]),('E',[17.78,-8,18,10]),('F',[-7.78,-8,17.78,-7.78]),('B',[-7.78,9.78,17.78,10])]:
 box('ParapetR2_'+side,[xy[0],xy[1],roof_top-.01],[xy[2],xy[3],roof_top+.37],'LightStone')
box('FurnaceR2_annex',[-19,8,0],[-10.5,16,5.5],'CivicBrick')
box('FurnaceR2_roof',[-19,8,5.5],[-10.5,16,5.7],'RoofMembrane')
box('FurnaceR2_feed_duct',[-10.5,8.5,2.6],[-7.95,9.7,3.6],'EquipmentMetal')
for i,x in enumerate([-17,-13]):
 n='FurnaceR2_hatch_'+str(i)
 box(n,[x-1.15,15.99,1.2],[x+1.15,16.06,3.6],'ContainerLidRubber')
 for dx in [-1.25,1.15]: box(n+'_jamb'+str(dx),[x+dx,15.99,1.1],[x+dx+.1,16.16,3.8],'EquipmentMetal')
 for z in [1.1,3.7]: box(n+'_rail'+str(z),[x-1.15,15.99,z],[x+1.15,16.16,z+.1],'EquipmentMetal')
 box(n+'_ashdrawer',[x-1.1,15.99,.15],[x+1.1,16.15,.85],'ContainerLidRubber')
 box(n+'_pull',[x-.4,16.15,.48],[x+.4,16.24,.58],'EquipmentMetal')
# Connected annular tubes: exterior, inner liner, top rim, and bottom annulus. No throat cap.
flues=[]
for i,x in enumerate([-17,-13]):
 verts=[]
 for z,r in [(5.7,.7),(15.2,.7),(15.2,.56),(5.7,.56)]:
  verts.extend([(x+r*math.cos(j*2*math.pi/12),12+r*math.sin(j*2*math.pi/12),z) for j in range(12)])
 faces=[]
 for a,b in [(0,12),(12,24),(24,36),(36,0)]:
  for j in range(12): k=(j+1)%12; faces.append((a+j,a+k,b+k,b+j))
 n='FurnaceR2_open_flue_'+str(i+1); meshpart(n,verts,faces,'EquipmentMetal'); flues.append(dict(group=n,centre=[x,12],outer_radius=.7,inner_radius=.56,root_z=5.7,top_z=15.2,air_opening=True))
# Commercial bins: four actual plates and bottom, two separate dark lids, grounded feet.
dumpsters=[]
for i,y in enumerate([-7,.5],1):
 prefix='DumpsterR2_%02d_'%i; parts=[]
 def db(s,lo,hi,m):
  n=prefix+s; box(n,lo,hi,m); parts.append(n)
 db('bottom',[19,y,.2],[23,y+3.5,.38],'ServiceAccent')
 for x in [19,22.84]: db('side_'+str(x),[x,y,.38],[x+.16,y+3.5,2.6],'ServiceAccent')
 for yy in [y,y+3.34]: db('end_'+str(yy),[19.16,yy,.38],[22.84,yy+.16,2.6],'ServiceAccent')
 for j in range(2): db('lid_'+str(j),[19+j*2,y,2.6],[20.98+j*2,y+3.5,2.82],'ContainerLidRubber')
 db('hinge',[19,y+3.42,2.52],[23,y+3.56,2.65],'ContainerLidRubber')
 for x in [19.25,22.35]:
  for yy in [y+.25,y+2.85]: db('foot_'+str(x)+'_'+str(yy),[x,yy,0],[x+.4,yy+.4,.2],'ContainerLidRubber')
 for x in [19.65,20.85,22.05]: db('front_rib_'+str(x),[x,y-.07,.55],[x+.17,y+.01,2.4],'ServiceAccent')
 dumpsters.append(dict(id=i,parts=parts))
# Measure connected solids independently from final mesh topology, not pre-edit records.
def components():
 result=[]
 for o in objects:
  me=o.data; adj=[set() for v in me.vertices]
  for e in me.edges: a,b=e.vertices; adj[a].add(b); adj[b].add(a)
  unseen=set(range(len(me.vertices)))
  while unseen:
   start=unseen.pop(); ids={start}; todo=[start]
   while todo:
    a=todo.pop()
    for b in adj[a]:
     if b in unseen: unseen.remove(b); ids.add(b); todo.append(b)
   names=[]
   for g in o.vertex_groups:
    count=sum(any(x.group==g.index and x.weight>.5 for x in me.vertices[j].groups) for j in ids)
    if count==len(ids): names.append(g.name)
   assert len(names)==1,(o.name,names)
   co=[o.matrix_world@me.vertices[j].co for j in ids]
   result.append(dict(name=names[0],min=[min(v[k] for v in co) for k in range(3)],max=[max(v[k] for v in co) for k in range(3)]))
 return result
bpy.context.view_layer.update(); comps=components(); C={c['name']:c for c in comps}; assert len(C)==len(comps)
def overlap(a,b): return all(min(a['max'][k],b['max'][k])-max(a['min'][k],b['min'][k])>1e-5 for k in range(3))
for c in comps:
 assert c['min'][0]>=-23.5-1e-5 and c['max'][0]<=23.5+1e-5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5 and c['min'][2]>=-1e-5,c
# Original solids' bounds are invariant except precisely enumerated removals.
for n,co in original.items():
 if n in removed: continue
 assert n in C,n
 for k in range(3):
  assert abs(C[n]['min'][k]-min(v[k] for v in co))<1e-5 and abs(C[n]['max'][k]-max(v[k] for v in co))<1e-5,n
windows=[]
for n in C:
 if not (n.startswith('Office_') or n.startswith('Hall_')) or '_jamb' in n or '_rail' in n: continue
 fs=[n+'_jamb-1',n+'_jamb1',n+'_rail-1',n+'_rail1']
 if not all(f in C for f in fs): continue
 wall='Admin_occupied' if n.startswith('Office_') else 'ReceivingHall_occupied'
 axis=0 if ('west' in n or 'east' in n) else 1; sign=-1 if ('west' in n or 'front' in n) else 1
 face=C[wall]['min' if sign<0 else 'max'][axis]; t=1-axis
 for q in [C[n]]+[C[f] for f in fs]:
  for k in [t,2]: assert q['min'][k]>=C[wall]['min'][k]+.12-1e-5 and q['max'][k]<=C[wall]['max'][k]-.12+1e-5
 for f in fs:
  q=C[f]; assert q['min'][axis]<=face and q['max'][axis]>=face; assert not overlap(C[n],q)
 for j,f in enumerate(fs):
  for g in fs[j+1:]: assert not overlap(C[f],C[g])
 windows.append(dict(pane=n,frame_parts=fs,backing=wall,axis=axis,sign=sign,wall_face=face,pane_bounds=C[n],frame_bounds=[C[f] for f in fs]))
assert len(windows)==30,len(windows)
strips=[n for n in newnames if n.startswith(('TrimR2_','ParapetR2_'))]
for i,n in enumerate(strips):
 for m in strips[i+1:]: assert not overlap(C[n],C[m]),(n,m)
 for w in windows:
  for m in [w['pane']]+w['frame_parts']: assert not overlap(C[n],C[m]),(n,m)
joints=[]
for ns in trimsets:
 for a,b in [(ns[0],ns[2]),(ns[0],ns[3]),(ns[1],ns[2])]+([(ns[1],ns[3])] if '6.3' in ns[0] else []):
  gap=max(max(C[a]['min'][k]-C[b]['max'][k],C[b]['min'][k]-C[a]['max'][k],0) for k in range(3)); assert gap<=.001
  joints.append(dict(a=a,b=b,gap_m=gap,contact_axis=1,contact_plane=C[a]['max'][1] if a.endswith('F') else C[a]['min'][1]))
for a in ['W','E']:
 for b in ['F','B']:
  n='ParapetR2_'+a; m='ParapetR2_'+b
  gap=max(max(C[n]['min'][k]-C[m]['max'][k],C[m]['min'][k]-C[n]['max'][k],0) for k in range(3)); assert gap<=.001
  joints.append(dict(a=n,b=m,gap_m=gap,contact_axis=0,contact_plane=-7.78 if a=='W' else 17.78))
def anchor(role,target,x,width,h):
 lane=dict(min=[x-width/2,-20,0],max=[x+width/2,-8.3,h])
 for c in comps: assert not overlap(c,lane),(target,c['name'])
 return dict(role=role,target=target,xyz_m=[x,-8.3,0],outward=[0,-1,0],width_m=width,height_m=h,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=lane)
anchors=[anchor('pedestrian','Public_double_leaf',-15,2,2.4),anchor('service','Receiving_bay_1',-2,5,4.2)]
bays=[anchor('service','Receiving_bay_'+str(i+1),x,5,4.2) for i,x in enumerate([-2,10])]
for i,b in enumerate(bays): b['id']='receiving_'+str(i+1)
write('entrance-anchors.json',dict(anchors=anchors)); write('vehicle-bays.json',dict(bays=bays)); write('window-mounts.json',dict(windows=windows,doors=anchors+[bays[1]]))
write('corner-contract.json',dict(removed=removed,strips=[C[n] for n in strips],joints=joints,roof_top=roof_top,positive_overlap=False,panes_frames_clear=True))
write('incinerator-contract.json',dict(annex=C['FurnaceR2_annex'],roof=C['FurnaceR2_roof'],duct=C['FurnaceR2_feed_duct'],flues=flues,no_throat_cap=True))
for d in dumpsters: d['components']=[C[n] for n in d['parts']]
write('dumpster-contract.json',dict(dumpsters=dumpsters,existing_skip_contents_retained=True))
# Preserve all nine exact repository texture files and pack the existing image datablocks.
tex=OUT/'textures'; tex.mkdir(exist_ok=True); records=[]
for fam,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for suffix in ['BaseColor','Normal','ORM']:
  name=fam+'_'+suffix+'.png'; src=Path('/repo/ArtSource/Textures')/folder/name; dest=tex/name; shutil.copyfile(src,dest)
  im=next((im for im in bpy.data.images if Path(im.filepath).name==name or im.name==name),None)
  if im is None: im=bpy.data.images.load(str(dest))
  im.filepath=str(dest); im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'; im.pack()
  records.append(dict(path='textures/'+name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
regions={}
for name,m in mats.items():
 p=m.node_tree.nodes.get('Principled BSDF'); regions[name]=dict(base_color=list(p.inputs['Base Color'].default_value),roughness=p.inputs['Roughness'].default_value,metallic=p.inputs['Metallic'].default_value,transmission=0,base_color_linked=bool(p.inputs['Base Color'].links),nodes=[dict(name=n.name,type=n.bl_idname,operation=getattr(n,'blend_type',None),image=n.image.name if n.type=='TEX_IMAGE' and n.image else None,inputs={i.name:list(i.default_value) if hasattr(i.default_value,'__len__') else i.default_value for i in n.inputs if hasattr(i,'default_value') and isinstance(i.default_value,(int,float)) or hasattr(i,'default_value') and i.type in ['RGBA','VECTOR']}) for n in m.node_tree.nodes],links=[dict(from_node=l.from_node.name,from_socket=l.from_socket.name,to_node=l.to_node.name,to_socket=l.to_socket.name) for l in m.node_tree.links])
write('material-manifest.json',dict(regions=regions,textures=records,UV0='dominant face world coordinates / 2 metres',channels=dict(R='AO multiply before tint',G='roughness',B='metallic'),normal_strength=.25,integration='HELD'))
occupied=dict(min=[min(c['min'][k] for c in comps) for k in range(3)],max=[max(c['max'][k] for c in comps) for k in range(3)])
write('upgrade-plan.json',dict(family='wastedepot',stage='medium',stage_index=1,existing_stages=['base','medium'],existing_upgrade_count=1,source_site_m=[48,40],current_native_footprint=[4,3],gameplay_changes=False,occupied_bounds=occupied,progression='Retained admin, first bay and two process groups; two receiving bays, two furnace flues and two front-readable dumpsters. No new tier.'))
write('waste-contract.json',dict(sourceID='building.wastedepot_medium.a',stage='medium',groups=[c['name'] for c in comps],retained_original_groups=[n for n in original if n not in removed],integration='HELD'))
for me in list(bpy.data.meshes):
 if me.users==0: bpy.data.meshes.remove(me)
for m in list(bpy.data.materials):
 if m.users==0: bpy.data.materials.remove(m)
for o in objects:
 for uv in o.data.uv_layers:
  assert all(math.isfinite(v) for d in uv.data for v in d.uv)
 o.data.calc_loop_triangles()
assert sum(len(o.data.loop_triangles) for o in objects)<=8500
finish(objects)
p=OUT/'validation.json'; result=json.loads(p.read_text())
result.update(dict(components=comps,occupied_bounds=occupied,window_count=len(windows),original_geometry_preserved_except=removed,corner_checks=True,window_checks=dict(wall_containment=True,contact=True,clear_opening=True,rim_disjointness=True,new_strip_clearance=True),corridor_checks='Every measured connected solid; no exemptions; both bays and pedestrian approach',sourceID='building.wastedepot_medium.a',review_only=True,integration='HELD'))
write('validation.json',result)

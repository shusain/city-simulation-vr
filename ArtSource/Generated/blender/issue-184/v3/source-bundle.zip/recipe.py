import bpy,sys,json,shutil,hashlib,math
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
objects=load_previous()
P=Path('/previous'); O=Path('/output'); O.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
# This revision is deliberately not passed through finish(): no joining, cleanup,
# re-export or blend serialization is permitted for a JSON-only correction.
for src in P.iterdir():
 if src.name=='recipe.py':
  shutil.copy2(src,O/'original-source-recipe.py')
 elif src.is_dir(): shutil.copytree(src,O/src.name,dirs_exist_ok=True)
 else: shutil.copy2(src,O/src.name)
assert (O/'asset.blend').is_file()
assert (O/'asset.fbx').is_file(), 'The original checked FBX must be retained, not regenerated'
# All canonical names are actual connected-component vertex groups in v2.
names=set()
for ob in objects:
 if ob.type=='MESH':
  for g in ob.vertex_groups:
   if any(any(a.group==g.index and a.weight>.5 for a in v.groups) for v in ob.data.vertices): names.add(g.name)
groups={k:[] for k in ['admin','hall','entry','roof','identity','compactor','conveyor','bins','bales','incinerator','dumpsters']}
for n in sorted(names):
 if n=='Admin_occupied' or n.startswith(('Office_','TrimR2_')): k='admin'
 elif n in ['ReceivingHall_occupied','Enclosed_connector'] or n.startswith(('Hall_front_clerestory','Hall_east_clerestory')): k='hall'
 elif n.startswith(('Public_double_leaf','Receiving_bay_','Public_shelter','Bay_shelter_')): k='entry'
 elif n in ['Admin_slate_roof','Hall_slate_roof','Filter_plinth','Filter_housing','Extraction_duct'] or n.startswith(('Filter_louvre','ParapetR2_')): k='roof'
 elif n.startswith('Bin_relief_'): k='identity'
 elif n.startswith('Process_'):
  if n.endswith(('_compactor','_ram','_loading_throat')): k='compactor'
  elif n.endswith('_hall_chute'): k='conveyor'
  else: k='bins'
 elif n.startswith('FurnaceR2_'): k='incinerator'
 elif n.startswith('DumpsterR2_'): k='dumpsters'
 else: raise AssertionError(('Unexpected component',n))
 groups[k].append(n)
assert len(names)==299,len(names)
assert {k:len(v) for k,v in groups.items()}==dict(admin=123,hall=42,entry=30,roof=15,identity=4,compactor=6,conveyor=2,bins=28,bales=0,incinerator=19,dumpsters=30),{k:len(v) for k,v in groups.items()}
contract=dict(family='wastedepot',stage='medium',sourceID='building.wastedepot_medium.a',source_site_m=[48,40],groups=groups,integration='HELD')
(O/'waste-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
# Independently measure source topology without changing the source file.
tri=0; solids=0; mats=set(); packed=set()
for ob in objects:
 if ob.type!='MESH': continue
 me=ob.data; me.calc_loop_triangles(); tri+=len(me.loop_triangles)
 mats.update(m.name for m in me.materials if m)
 adj=[[] for v in me.vertices]
 for e in me.edges:
  a,b=e.vertices; adj[a].append(b); adj[b].append(a)
 unseen=set(range(len(me.vertices)))
 while unseen:
  stack=[unseen.pop()]; solids+=1
  while stack:
   for j in adj[stack.pop()]:
    if j in unseen: unseen.remove(j); stack.append(j)
 for uv in me.uv_layers:
  assert all(math.isfinite(x) for d in uv.data for x in d.uv)
for im in bpy.data.images:
 if im.packed_file: packed.add(im.name)
assert tri==3756 and solids==299 and len(mats)==7,(tri,solids,mats)
assert len(packed)==9,(len(packed),packed)
# Read back the actual retained FBX; never re-export it.
old=set(bpy.data.objects)
bpy.ops.import_scene.fbx(filepath=str(O/'asset.fbx'))
imported=[o for o in set(bpy.data.objects)-old if o.type=='MESH']
ft=0; fm=set()
for ob in imported:
 ob.data.calc_loop_triangles(); ft+=len(ob.data.loop_triangles)
 fm.update(m.name.split('.')[0] for m in ob.data.materials if m)
assert ft==3756 and len(fm)==7,(ft,fm)
for ob in set(bpy.data.objects)-old: bpy.data.objects.remove(ob,do_unlink=True)
unchanged={}
for src in P.rglob('*'):
 if not src.is_file() or src.name=='recipe.py' or src.relative_to(P).as_posix()=='waste-contract.json': continue
 dest=O/src.relative_to(P)
 assert dest.is_file() and sha(src)==sha(dest),str(src)
 unchanged[src.relative_to(P).as_posix()]=sha(dest)
assert (O/'validation.json').is_file(),'Retain the original strict validation receipt'
# A separate additive receipt avoids modifying any original manifest.
receipt=dict(change='Only waste-contract.json replaced with canonical grouped object',sourceID=contract['sourceID'],review_only=True,integration='HELD',triangles=tri,connected_solids=solids,regions=len(mats),packed_maps=len(packed),actual_fbx_triangles=ft,actual_fbx_regions=len(fm),all_group_names_proven_present=True,group_counts={k:len(v) for k,v in groups.items()},byte_identical_original_files=unchanged)
(O/'metadata-correction-validation.json').write_text(json.dumps(receipt,indent=2))
# Normally the completed preview is retained byte-for-byte as well.
if not (O/'preview.png').exists():
 from mathutils import Vector
 scene=bpy.context.scene
 scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=8
 scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
 if not scene.camera:
  data=bpy.data.cameras.new('MetadataReviewCamera'); cam=bpy.data.objects.new('MetadataReviewCamera',data); scene.collection.objects.link(cam); scene.camera=cam
 cam=scene.camera; cam.location=(50,-65,45); cam.rotation_euler=(Vector((0,2,5))-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.type='ORTHO'; cam.data.ortho_scale=64
 light=bpy.data.lights.new('MetadataReviewKey','AREA'); light.energy=3000; light.shape='DISK'; light.size=30
 lo=bpy.data.objects.new('MetadataReviewKey',light); scene.collection.objects.link(lo); lo.location=(0,-20,40)
 scene.world.color=(.5,.5,.5)
 scene.render.filepath='/output/preview.png'; bpy.ops.render.render(write_still=True)
print('Metadata-only canonical waste contract corrected; original source and FBX retained byte-for-byte.')
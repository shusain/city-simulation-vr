import bpy, sys, math, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output');out.mkdir(exist_ok=True)
refs=[]
for issue in (123,124):
    root=Path('/repo/ArtSource/Generated/comfy')/('issue-'+str(issue))/'v1'
    for filename in ('asset.png','approval.json','unreal-handoff.json'):
        p=root/filename
        record={'path':str(p.relative_to('/repo')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        if filename.endswith('.json'):
            record['payload']=json.loads(p.read_text())
        else:
            img=bpy.data.images.load(str(p),check_existing=True)
            record.update(image_loaded=bool(img.size[0] and img.size[1]),dimensions=list(img.size),usage='Concept reference only; not a texture')
            assert record['image_loaded']
        refs.append(record)
# A continuous faceted trunk with a genuine extruded fork, not crossing cylinders.
verts=[];faces=[]
rings=[(-.60,.018,.110,.071,.070),(-.40,-.006,.105,.108,.097),(-.08,-.018,.110,.112,.110),(.23,.008,.112,.092,.090),(.60,.022,.108,.054,.057)]
for r,(x,y,z,ry,rz) in enumerate(rings):
    for j in range(8):
        a=2*math.pi*j/8
        # Slightly slanted broken ends, broad unornamented planes.
        dx=(.016*math.sin(a*2)+.009*math.cos(a)) if r in (0,4) else 0
        verts.append((x+dx,y+ry*math.cos(a),z+rz*math.sin(a)))
faces.append(tuple(reversed(range(8))))
faces.append(tuple(32+j for j in range(8)))
rootface=None
for r in range(4):
    for j in range(8):
        q=(r*8+j,r*8+(j+1)%8,(r+1)*8+(j+1)%8,(r+1)*8+j)
        if r==2 and j==0:rootface=q
        else:faces.append(q)
# This replaces the side face; there is no buried root cap/internal joint.
center=sum((Vector(verts[i]) for i in rootface),Vector())/4
previous=list(rootface)
for shift,scale in ((Vector((.055,.100,.018)),.71),(Vector((.145,.178,.030)),.33)):
    new=[]
    for j,i in enumerate(rootface):
        p=center+(Vector(verts[i])-center)*scale+shift
        if scale==.33:p.z+=(.009 if j%2 else -.005)
        new.append(len(verts));verts.append(tuple(p))
    for j in range(4):faces.append((previous[j],previous[(j+1)%4],new[(j+1)%4],new[j]))
    previous=new
faces.append(tuple(previous))
# Exact metre bounds and ground-contact origin. No scene scale tricks.
lo=[min(p[i] for p in verts) for i in range(3)];hi=[max(p[i] for p in verts) for i in range(3)]
target=(1.2,.32,.22)
verts=[tuple((p[i]-(lo[i]+hi[i])/2)*target[i]/(hi[i]-lo[i]) if i<2 else (p[i]-lo[i])*target[i]/(hi[i]-lo[i]) for i in range(3)) for p in verts]
mesh=bpy.data.meshes.new('Driftwood_ContinuousFacets');mesh.from_pydata(verts,[],faces);mesh.update()
obj=bpy.data.objects.new('SM_Scenery_Driftwood_A',mesh);bpy.context.collection.objects.link(obj)
bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
# Recalculate consistent outward normals on the single closed manifold.
import bmesh
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
for p in mesh.polygons:p.use_smooth=False
mat=bpy.data.materials.new('Driftwood');mat.diffuse_color=(.43,.365,.285,1);mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=mat.diffuse_color;bs.inputs['Roughness'].default_value=.88
mesh.materials.append(mat)
# Independent per-face UV islands retain finite nonzero areas on every broad plane.
uv=mesh.uv_layers.new(name='UV0')
for poly in mesh.polygons:
    n=poly.normal;axis=max(range(3),key=lambda i:abs(n[i]));axes=[i for i in range(3) if i!=axis]
    coords=[(mesh.vertices[mesh.loops[k].vertex_index].co[axes[0]],mesh.vertices[mesh.loops[k].vertex_index].co[axes[1]]) for k in poly.loop_indices]
    mn=[min(p[i] for p in coords) for i in (0,1)];mx=[max(p[i] for p in coords) for i in (0,1)]
    for k,p in zip(poly.loop_indices,coords):uv.data[k].uv=tuple(.05+.9*(p[i]-mn[i])/max(mx[i]-mn[i],1e-9) for i in (0,1))
mesh.calc_loop_triangles();triangles=len(mesh.loop_triangles);assert triangles<=120
bm=bmesh.new();bm.from_mesh(mesh);manifold=all(e.is_manifold for e in bm.edges);bm.free();assert manifold
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=1
obj['review_only']=True;obj['collision']='none';obj['source_LODs']=1
finish([obj])
# Preserve the tested runner's measured result and augment with issue-specific checks.
vp=out/'validation.json'
validation=json.loads(vp.read_text()) if vp.exists() else {}
# finish joins only the requested object; acquire by its unique mesh topology.
candidates=[o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)==len(verts)]
assert len(candidates)==1
asset=candidates[0];asset.name='SM_Scenery_Driftwood_A';asset.data.materials[0].name='Driftwood'
bpy.context.view_layer.update()
with checked_fbx(asset,out/'asset.fbx',['Driftwood'],expected_triangles=triangles,expected_sections=1) as check:
    roundtrip={'pass':True,'dimensions_m':list(check.dimensions),'triangles':len(check.data.loop_triangles),'materials':len(check.data.materials)}
bounds=[asset.matrix_world@Vector(c) for c in asset.bound_box]
minimum=[min(v[i] for v in bounds) for i in range(3)];maximum=[max(v[i] for v in bounds) for i in range(3)]
assert all(abs(asset.dimensions[i]-target[i])<.0001 for i in range(3))
assert abs(minimum[2])<.0001
validation.update(asset_name=asset.name,review_only=True,dimensions_m=list(asset.dimensions),bounds_m={'min':minimum,'max':maximum},minZ=minimum[2],pivot=list(asset.location),rotation=list(asset.rotation_euler),scale=list(asset.scale),triangles=triangles,material_count=1,material={'name':'Driftwood','base_color_linear_rgba':list(mat.diffuse_color),'roughness':.88},normals='Outward recalculated, flat shaded',closed_manifold=manifold,uv0='Finite, nondegenerate face-projected UV islands',hidden_internal_joints='None: fork extruded from removed trunk face; one continuous surface',collision='none',source_LODs=1,approved_references=refs,reference_visual_review='PNGs loaded in Blender; no claim of human visual assessment',fbx_roundtrip=roundtrip,production_changes=False,scale_note='Actual 1.2 x 0.32 x 0.22 metre prop; close-up is for source inspection only')
vp.write_text(json.dumps(validation,indent=2))
(out/'provenance.json').write_text(json.dumps({'issue':'D108 / #133','source_sha':'e5425d699e1a4f80b2303c4f7eff5e31fb3bf009','intent':'Initial review-only driftwood; no production promotion','references':refs,'geometry':'Five octagonal trunk rings; single tapered quad fork replacing a side face; no additional props'},indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
cam.location=(1.35,-1.8,1.0);cam.rotation_euler=(Vector((0,0,.10))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=1.55
scene.render.filepath='/output/preview.png';bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend');bpy.ops.render.render(write_still=True)
oldloc=cam.location.copy();oldrot=cam.rotation_euler.copy()
cam.location=(0,0,2.5);cam.rotation_euler=(0,0,0);cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath='/output/preview_top.png';bpy.ops.render.render(write_still=True)
cam.location=oldloc;cam.rotation_euler=oldrot;scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

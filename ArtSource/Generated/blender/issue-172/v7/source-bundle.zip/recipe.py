import bpy,bmesh,sys,json,hashlib,shutil,math
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
def read(n):return json.loads((Path('/previous')/n).read_text())
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
obs=load_previous();md={n:read(n)for n in['window-mounts.json','entrance-anchors.json','upgrade-plan.json','education-contract.json','material-manifest.json']}
mats={m.name:m for o in obs for m in o.data.materials};assert set(mats)=={'AcademicBrick','LightStone','RoofMembrane','EquipmentMetal','WindowGlass'}
def members(o):
 result={g.name:[]for g in o.vertex_groups};names={g.index:g.name for g in o.vertex_groups}
 for v in o.data.vertices:
  owners=[names[g.group]for g in v.groups if g.weight>.5];assert len(owners)==1
  result[owners[0]].append(v.index)
 return{k:v for k,v in result.items()if v}
def signature(o,ids):
 ids=set(ids);uv=o.data.uv_layers.active
 return sorted((o.data.materials[p.material_index].name,tuple(sorted((tuple(o.data.vertices[o.data.loops[i].vertex_index].co),tuple(uv.data[i].uv))for i in p.loop_indices)))for p in o.data.polygons if set(p.vertices)<=ids)
before={n:signature(o,ids)for o in obs for n,ids in members(o).items()if not n.startswith('Book_')};assert len(before)==191
for o in obs:
 kill=[i for n,ids in members(o).items()if n.startswith('Book_')for i in ids]
 bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[bm.verts[i]for i in kill],context='VERTS');bm.to_mesh(o.data);bm.free();o.data.update()
 for g in list(o.vertex_groups):
  if g.name.startswith('Book_'):o.vertex_groups.remove(g)
assert before=={n:signature(o,ids)for o in obs for n,ids in members(o).items()}
def tint(name,col):
 m=mats[name];nt=m.node_tree;p=next(n for n in nt.nodes if n.type=='BSDF_PRINCIPLED')
 ao=[n for n in nt.nodes if n.type=='MIX_RGB' and n.inputs[1].is_linked and n.inputs[2].is_linked];assert len(ao)==1,(name,[n.name for n in ao])
 t=nt.nodes.new('ShaderNodeMixRGB');t.name=name+'_WarmFinalTint';t.blend_type='MULTIPLY';t.inputs[0].default_value=1;t.inputs[2].default_value=col
 nt.links.new(ao[0].outputs[0],t.inputs[1]);nt.links.new(t.outputs[0],p.inputs['Base Color']);m.diffuse_color=col
 return dict(node=t.name,linear_rgba=list(col),operation='MULTIPLY',source=ao[0].name,target='Principled Base Color')
changes={n:tint(n,c)for n,c in[('AcademicBrick',(.78,.46,.23,1)),('RoofMembrane',(.22,.27,.31,1))]}
for n in mats['AcademicBrick'].node_tree.nodes:
 if n.type=='NORMAL_MAP':n.inputs['Strength'].default_value=.15
for name,col,rough in[('LightStone',(.86,.78,.60,1),None),('WindowGlass',(.16,.27,.33,1),.29)]:
 m=mats[name];p=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 for l in list(p.inputs['Base Color'].links):m.node_tree.links.remove(l)
 p.inputs['Base Color'].default_value=col;m.diffuse_color=col
 if rough is not None:p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=0;p.inputs['Alpha'].default_value=1;p.inputs['Transmission Weight'].default_value=0
changes.update(LightStone=[.86,.78,.60,1],WindowGlass_restored=[.16,.27,.33,1],brick_normal_strength=.15)
def prism(name,poly,y0,y1,mat):
 n=len(poly);mesh=bpy.data.meshes.new(name);mesh.from_pydata([(x,y,z)for y in[y0,y1]for x,z in poly],[],[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)]);mesh.update()
 o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);mesh.materials.append(mats[mat]);o.vertex_groups.new(name=name).add(list(range(len(mesh.vertices))),1,'REPLACE')
 bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
 uv=mesh.uv_layers.new(name='UVMap')
 for p in mesh.polygons:
  axes=[i for i in range(3)if i!=max(range(3),key=lambda k:abs(p.normal[k]))]
  for li in p.loop_indices:
   v=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=[v[k]/2 for k in axes]
 obs.append(o)
prism('Book_Pediment',[(-2.85,3.15),(.85,3.15),(.85,5),(-2.85,5)],-11.95,-11.72,'LightStone')
prism('Book_Backplate',[(-2.75,3.27),(.75,3.27),(.75,4.94),(-2.75,4.94)],-11.985,-11.91,'EquipmentMetal')
prism('Book_LeftPages',[(-2.55,4.52),(-1.04,4.80),(-1.04,3.67),(-2.55,3.39)],-12.15,-11.98,'LightStone')
prism('Book_RightPages',[(-.96,4.80),(.55,4.52),(.55,3.39),(-.96,3.67)],-12.15,-11.98,'LightStone')
bpy.context.view_layer.update();parts={}
for o in obs:
 assert all(abs(v)<1e-6 for v in o.location)and all(abs(v-1)<1e-6 for v in o.scale)
 for n,ids in members(o).items():
  pts=[o.matrix_world@o.data.vertices[i].co for i in ids];parts[n]=dict(name=n,min=[min(p[k]for p in pts)for k in range(3)],max=[max(p[k]for p in pts)for k in range(3)])
assert len(parts)==195 and before=={n:signature(o,ids)for o in obs for n,ids in members(o).items()if not n.startswith('Book_')}
books=[p for n,p in parts.items()if n.startswith('Book_')]
def hit(a,b,axes=(0,1,2)):return all(min(a['max'][k],b['max'][k])-max(a['min'][k],b['min'][k])>1e-6 for k in axes)
for b in parts.values():
 assert b['min'][2]>=-1e-5 and all(-15.5<=b['min'][k]<=b['max'][k]<=15.5 for k in[0,1])
 for a in md['entrance-anchors.json']['anchors']:assert not hit(b,a['reserved_free_corridor'])
 for r in md['upgrade-plan.json']['future_reservations']:assert not hit(b,r)
for b in books:
 for n in before:
  if(b['name'],n)==('Book_Pediment','CanopyFascia'):
   embed=min(b['max'][2],parts[n]['max'][2])-max(b['min'][2],parts[n]['min'][2]);assert .039<embed<.041
  else:assert not hit(b,parts[n]),(b['name'],n)
ped=parts['Book_Pediment'];plate=parts['Book_Backplate'];can=parts['WelcomeCanopy'];assert abs(ped['min'][2]-can['max'][2])<1e-5 and hit(ped,plate)
assert all(min(ped['max'][k],can['max'][k])-max(ped['min'][k],can['min'][k])>0 for k in[0,1])
for n in['Book_LeftPages','Book_RightPages']:assert hit(parts[n],plate)
windows=md['window-mounts.json']['windows'];assert len(windows)==26
for w in windows:
 p=parts[w['pane']];wall=parts[w['backing']];axis=w['axis'];ta=1-axis;frames=[parts[n]for n in w['frame_parts']];assert len(frames)==4
 for f in frames:
  assert hit(f,wall)and not hit(f,p)
  assert all(f['min'][k]>=wall['min'][k]+.12-1e-5 and f['max'][k]<=wall['max'][k]-.12+1e-5 for k in[ta,2])
 for i,f in enumerate(frames):
  for g in frames[i+1:]:assert not hit(f,g)
 for b in books:
  for q in[p]+frames:assert not hit(b,q,(ta,2))
for door in md['window-mounts.json']['doors']:
 for n in[door['target']]+door['leaves']+door['frame_parts']:
  for b in books:assert not hit(b,parts[n],(0,2))
tex=[]
for folder,stem in[('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for suffix in['BaseColor','Normal','ORM']:
  p=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+suffix+'.png');q=O/'textures'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
  images=[im for im in bpy.data.images if im.name.startswith(p.name)];assert images,p.name
  for im in images:im.filepath=str(q);im.pack();assert im.colorspace_settings.name==('sRGB' if suffix=='BaseColor' else 'Non-Color')
  tex.append(dict(source=str(p),copy=str(q),sha256=hashlib.sha256(q.read_bytes()).hexdigest()));assert tex[-1]['sha256']==hashlib.sha256(p.read_bytes()).hexdigest()
occupied={k:[f(p[k][i]for p in parts.values())for i in range(3)]for k,f in[('min',min),('max',max)]}
def refresh(x):
 if isinstance(x,str)and x.startswith('Book_'):return x if x in parts else 'Book_Backplate'
 if isinstance(x,list):
  if x and all(isinstance(v,str)for v in x)and any(v.startswith('Book_')for v in x):return sorted(set(v for v in x if not v.startswith('Book_'))|{p['name']for p in books})
  return[refresh(v)for v in x]
 if isinstance(x,dict):
  if x.get('name','').startswith('Book_'):return parts.get(x['name'],plate)
  return{k:refresh(v)for k,v in x.items()}
 return x
for n in['window-mounts.json','entrance-anchors.json']:write(n,md[n])
for n in['upgrade-plan.json','education-contract.json']:
 data=refresh(md[n]);data['actual_occupied_bounds']=occupied;data['book_components']=books;write(n,data)
manifest=md['material-manifest.json'];manifest.update(actual_warm_revision=changes,textures=tex,book_style='Two broad angled cream halves with dark central crease');write('material-manifest.json',manifest)
write('design-response.json',dict(parent='primary172v6; incorrect book/glass/roof corrected to original request',preserved_school_parts=191,book_parts=books,page_dimensions_m=[3.1,.17,1.41],material_changes=changes,wall_and_support_contact=True,fascia_joint_embed_m=.04,full_window_and_door_projection_clear=True,integration='HELD'))
for o in obs:
 assert o.data.uv_layers.active and all(math.isfinite(v)for uv in o.data.uv_layers.active.data for v in uv.uv)
 o.data.calc_loop_triangles()
assert sum(len(o.data.loop_triangles)for o in obs)==2340
bpy.context.scene.cursor.location=(0,0,0);bpy.context.view_layer.objects.active=obs[0];bpy.ops.object.select_all(action='DESELECT');obs[0].select_set(True);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');finish(obs)
asset=next(o for o in bpy.context.scene.objects if o.type=='MESH' and not o.name.startswith('ReviewGround'));asset.data.calc_loop_triangles();assert len(asset.data.loop_triangles)==2340 and len(asset.data.materials)==5
v=json.loads((O/'validation.json').read_text());v.update(components=list(parts.values()),actual_occupied_bounds=occupied,component_count=195,preserved_school_components=191,window_count=26,review_only=True,integration='HELD');write('validation.json',v)

import bpy,sys,json,math,hashlib,shutil,bmesh
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
def inherited(n):
 p=Path('/previous')/n
 if not p.exists():
  m=list(Path('/previous').rglob(n));assert len(m)==1,(n,m);p=m[0]
 return json.loads(p.read_text())
objects=[o for o in load_previous() if o.name!='ReviewGround']
metadata={n:inherited(n) for n in ['window-mounts.json','entrance-anchors.json','upgrade-plan.json','material-manifest.json','education-contract.json']}
for o in objects:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
def groups(obs):
 out={}
 for o in obs:
  for g in o.vertex_groups:
   ids={v.index for v in o.data.vertices if any(t.group==g.index and t.weight>.5 for t in v.groups)}
   if not ids:continue
   pts=[o.matrix_world@o.data.vertices[i].co for i in ids]
   out[g.name]={'name':g.name,'min':[min(p[i] for p in pts) for i in range(3)],'max':[max(p[i] for p in pts) for i in range(3)]}
 return out
def signatures(obs):
 out={}
 for o in obs:
  uv=o.data.uv_layers.active
  for g in o.vertex_groups:
   if g.name.startswith('Book_'):continue
   ids={v.index for v in o.data.vertices if any(t.group==g.index and t.weight>.5 for t in v.groups)}
   if not ids:continue
   faces=[]
   for p in o.data.polygons:
    if set(p.vertices)<=ids:
     faces.append(([tuple(round(float(x),7) for x in o.data.vertices[i].co) for i in p.vertices],[tuple(round(float(x),7) for x in uv.data[i].uv) for i in p.loop_indices],p.material_index))
   out[g.name]=hashlib.sha256(repr(sorted(faces)).encode()).hexdigest()
 return out
before=signatures(objects);assert len(before)==191,len(before)
old=groups(objects);assert len([n for n in old if n.startswith('Book_')])==7
mats={m.name.split('.')[0]:m for o in objects for m in o.data.materials};assert len(mats)==5
# Delete only the seven superseded icon solids. Never execute the parent recipe.
for o in objects:
 remove={g.index for g in o.vertex_groups if g.name.startswith('Book_')}
 ids={v.index for v in o.data.vertices if any(t.group in remove and t.weight>.5 for t in v.groups)}
 bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[bm.verts[i] for i in ids],context='VERTS');bm.to_mesh(o.data);bm.free()
 for g in list(o.vertex_groups):
  if g.name.startswith('Book_'):o.vertex_groups.remove(g)
 o.data.update()
assert signatures(objects)==before
receipts=[]
for semantic,folder,prefix in [('AcademicBrick','BuildingSurfaces','CityBrick'),('EquipmentMetal','BuildingSurfaces','CityMechanical'),('RoofMembrane','RoofsSigns','RoofMembrane')]:
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{prefix}_{suffix}.png';src=Path('/repo')/rel;dst=O/'textures'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
  images=[n.image for n in mats[semantic].node_tree.nodes if n.type=='TEX_IMAGE' and n.image and prefix+'_'+suffix in n.image.name];assert len(images)==1
  im=images[0];im.filepath=str(dst);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  receipts.append(dict(source=rel,copy=str(dst),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),copy_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
# Linked tint, not merely viewport colors.
brick=mats['AcademicBrick'];nt=brick.node_tree;p=next(n for n in nt.nodes if n.type=='BSDF_PRINCIPLED');base=next(n for n in nt.nodes if n.type=='TEX_IMAGE' and 'BaseColor' in n.image.name)
mix=nt.nodes.new('ShaderNodeMixRGB');mix.name='WarmBuff_MapMultiply';mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(.78,.46,.23,1);nt.links.new(base.outputs['Color'],mix.inputs[1]);nt.links.new(mix.outputs[0],p.inputs['Base Color']);brick.diffuse_color=(.78,.46,.23,1)
for n in nt.nodes:
 if n.type=='NORMAL_MAP':n.inputs['Strength'].default_value=.15
for name,col in [('LightStone',(.86,.78,.60,1)),('WindowGlass',(.22,.27,.31,1))]:
 m=mats[name];p=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 for l in list(p.inputs['Base Color'].links):m.node_tree.links.remove(l)
 p.inputs['Base Color'].default_value=col;m.diffuse_color=col
 if name=='WindowGlass':p.inputs['Roughness'].default_value=.38;p.inputs['Metallic'].default_value=0;p.inputs['Alpha'].default_value=1
# Four simple connected solids, large two-page book on a structural pediment.
can=old['WelcomeCanopy'];fascia=old['CanopyFascia'];prior=old['Book_Pediment'];bottom=can['max'][2]
cx=-1.0;cy=(prior['min'][1]+prior['max'][1])/2
new=[]
def cube(name,dim,loc,mat):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o.data.materials.append(mats[mat]);o.vertex_groups.new(name=name).add(list(range(8)),1,'REPLACE')
 uv=o.data.uv_layers.active
 for f in o.data.polygons:
  axes=[i for i in range(3) if i!=max(range(3),key=lambda j:abs(f.normal[j]))]
  for li in f.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]/2,v[axes[1]]/2)
 new.append(o);return o
cube('Book_Pediment',(3.3,.23,1.65),(cx,cy,bottom+.825),'LightStone')
# 3.10m overall span by 1.41m page height; central seam communicates an open book.
front=cy-.115
cube('Book_LeftPages',(1.51,.12,1.41),(cx-.795,front-.04,bottom+.855),'LightStone')
cube('Book_RightPages',(1.51,.12,1.41),(cx+.795,front-.04,bottom+.855),'LightStone')
cube('Book_Spine',(.08,.14,1.41),(cx,front-.045,bottom+.855),'EquipmentMetal')
objects+=new;bpy.context.view_layer.update();bounds=groups(objects);assert len(bounds)==195
assert signatures(objects)==before
# Strict positive-volume tests; the sole bounded exception is the specified support joint.
def overlap(a,b):return [min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i]) for i in range(3)]
def intersects(a,b):return all(v>1e-6 for v in overlap(a,b))
retained=set(before);book={o.name for o in new}
for n in book:
 for q in retained:
  a,b=bounds[n],bounds[q]
  if (n,q)==('Book_Pediment','CanopyFascia'):
   assert intersects(a,b) and .039<overlap(a,b)[2]<.041,(n,q,overlap(a,b))
   assert abs(a['min'][2]-bounds['WelcomeCanopy']['max'][2])<1e-5
  else:assert not intersects(a,b),(n,q,overlap(a,b))
anchors=metadata['entrance-anchors.json']['anchors'];reservations=metadata['upgrade-plan.json']['future_reservations'];assert len(anchors)==2 and len(reservations)==1
for b in bounds.values():
 assert b['min'][2]>=-1e-5
 for i in [0,1]:assert b['min'][i]>=-15.5 and b['max'][i]<=15.5
 for a in anchors:assert not intersects(b,a['reserved_free_corridor']),(b['name'],a['role'])
 for r in reservations:assert not intersects(b,r),(b['name'],'reservation')
wm=metadata['window-mounts.json'];assert len(wm['windows'])==26
for r in wm['windows']:
 pane=bounds[r['pane']];wall=bounds[r['backing']];axis=r['axis'];ta=1-axis;frames=[bounds[n] for n in r['frame_parts']];assert len(frames)==4
 for f in frames:
  for a in [ta,2]:assert f['min'][a]>=wall['min'][a]+.12-1e-5 and f['max'][a]<=wall['max'][a]-.12+1e-5
  assert min(f['max'][axis],wall['max'][axis])-max(f['min'][axis],wall['min'][axis])>=.009
  assert not intersects(f,pane)
 for i,f in enumerate(frames):
  for g in frames[i+1:]:assert not intersects(f,g)
 for a in [ta,2]:
  side=sorted(sorted(frames,key=lambda f:f['max'][a]-f['min'][a])[:2],key=lambda f:f['min'][a]);assert pane['min'][a]>=side[0]['max'][a]-1e-5 and pane['max'][a]<=side[1]['min'][a]+1e-5
for r in wm['doors']:
 refs=[]
 for k in ['target','leaves','frame_parts']:
  v=r.get(k,[]);refs+=([v] if isinstance(v,str) else v)
 for n in refs:
  assert n in bounds,n
  for q in book:
   a,b=bounds[n],bounds[q];assert not all(overlap(a,b)[i]>1e-6 for i in [0,2]),(n,q,'door projection')
occupied={'min':[min(b['min'][i] for b in bounds.values()) for i in range(3)],'max':[max(b['max'][i] for b in bounds.values()) for i in range(3)]}
def refresh(v):
 if isinstance(v,list):return [refresh(x) for x in v if not (isinstance(x,str) and x.startswith('Book_') and x not in book)]
 if isinstance(v,dict):
  d={k:refresh(x) for k,x in v.items()}
  if d.get('name') in bounds and 'min' in d and 'max' in d:d.update(bounds[d['name']])
  return d
 return v
for n,d in metadata.items():write(n,refresh(d))
up=refresh(metadata['upgrade-plan.json']);up.update(actual_occupied_bounds=occupied,existing_stages=['base'],existing_upgrade_count=0,gameplay_changes=False);write('upgrade-plan.json',up)
ed=refresh(metadata['education-contract.json']);ed.update(current_occupied_bounds=occupied,book_relief_groups=sorted(book),book_support_group='Book_Pediment');write('education-contract.json',ed)
# Actual shader link receipts, including every packed map and UV inputs.
graph={}
for name,m in mats.items():
 graph[name]={'links':[[l.from_node.name,l.from_socket.name,l.to_node.name,l.to_socket.name] for l in m.node_tree.links],'nodes':[{'name':n.name,'type':n.type,'image':n.image.name if n.type=='TEX_IMAGE' and n.image else None,'constants':{s.name:list(s.default_value) if hasattr(s.default_value,'__len__') else s.default_value for s in n.inputs if hasattr(s,'default_value') and isinstance(s.default_value,(float,int,Vector,bpy.types.bpy_prop_array))}} for n in m.node_tree.nodes]}
write('material-manifest.json',{'inherited_recipe':metadata['material-manifest.json'],'warm_buff': [.78,.46,.23],'cream':[.86,.78,.60],'slate':[.22,.27,.31],'brick_normal_strength':.15,'ORM_channels':{'R':'AO','G':'roughness','B':'metallic'},'graph_receipts':graph,'textures':receipts,'native_reconstruction':'deferred'})
write('texture-provenance.json',receipts)
write('design-response.json',{'parent':'completed v4; parent recipe not executed','revision':'v6 technical validation correction','retained_solid_count':191,'retained_signatures':before,'replacement_parts':[bounds[n] for n in sorted(book)],'page_design_dimensions_m':[3.1,1.41],'shader_graphs':graph,'support_joint_z_overlap_m':overlap(bounds['Book_Pediment'],bounds['CanopyFascia'])[2],'door_projection_keys':['target','leaves','frame_parts'],'integration':'HELD','lod_plan':'LOD1 simplify frames and roof hardware; LOD2 remove relief depth and secondary facade details while retaining wings and stable entrances; original sources untouched.'})
triangles=0
for o in objects:
 o.data.calc_loop_triangles();triangles+=len(o.data.loop_triangles);assert o.data.uv_layers.active
 assert all(math.isfinite(x) for u in o.data.uv_layers.active.data for x in u.uv)
assert triangles==2340,triangles
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
v=json.loads((O/'validation.json').read_text());v.update(components=list(bounds.values()),component_count=195,source_id='building.primaryschool.a',prejoin_triangles=triangles,source_triangle_ceiling=5000,semantic_regions=5,architectural_panes=26,uv0_finite=True,entrance_corridors_clear=True,future_reservation_clear=True,window_mount_checks_pass=True,retained_191_signatures_unchanged=True,door_projection_checks_pass=True,actual_occupied_bounds=occupied,review_only=True,integration='HELD');write('validation.json',v)

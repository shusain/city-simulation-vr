import bpy,sys,math,json,shutil,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
sys.path.insert(0,'/worker')
from CityRunnerPreview import box,cylinder,finish,load_previous
OUT=Path('/output')
OUT.mkdir(exist_ok=True)
objects=load_previous()
for o in list(bpy.data.objects):
 if o.type=='MESH':
  bpy.data.objects.remove(o,do_unlink=True)
for m in list(bpy.data.meshes):
 if m.users==0:
  bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
 if m.users==0:
  bpy.data.materials.remove(m)
parent=Path('/previous/recipe.py').read_text()
exec(parent[parent.index('def mat('):parent.index('objects=[];groups=')])
exec(parent[parent.index('objects=[];groups='):parent.index('def local(')])
bpy.context.scene.unit_settings.system='METRIC'
bpy.context.scene.unit_settings.scale_length=1
groups=[]
tr=[]
angle=math.radians(23)
s=math.sin(angle)
c=math.cos(angle)
def C(name,r,depth,loc,material=metal,axis='Z',verts=8):
 o=cylinder(name,r,depth,loc,(0.5,0.5,0.5,1),vertices=verts)
 o.data.materials.clear()
 o.data.materials.append(material)
 if axis=='X':
  o.rotation_euler.y=math.pi/2
 if axis=='Y':
  o.rotation_euler.x=math.pi/2
 objects.append(o)
 return o
for ri,y in enumerate([-7.8,0,7.8]):
 for ci,x in enumerate([-11.7,-3.9,3.9,11.7]):
  pre='R%dT%d'%(ri+1,ci+1)
  g=dict(id=pre,row=ri+1,column=ci+1,panel=[],frame=[],backrail=[],mount=[])
  sta=[]
  yaw=[]
  pitch=[]
  def fixed(tag,dims,loc,matl=metal,group=sta):
   o=B(pre+'_'+tag,dims,loc,matl)
   group.append(o.name)
   g['mount'].append(o.name)
   return o
  def cyl(tag,r,d,loc,matl=metal,axis='Z',group=yaw):
   o=C(pre+'_'+tag,r,d,loc,matl,axis)
   group.append(o.name)
   g['mount'].append(o.name)
   return o
  def part(tag,dims,u,v,w,material=metal,cat='backrail'):
   o=B(pre+'_'+tag,dims,(x+u,y+c*v-s*w,3.3+s*v+c*w),material,True)
   pitch.append(o.name)
   g[cat].append(o.name)
   return o
  fixed('SteelFoot',(0.72,0.72,0.12),(x,y,0.06))
  fixed('Mast',(0.32,0.32,2.3),(x,y,1.25))
  cyl('FixedSlewRace',0.34,0.14,(x,y,2.4),group=sta)
  cyl('YawBearing',0.32,0.16,(x,y,2.53))
  fixed('YawGearMotor',(0.34,0.28,0.32),(x+0.4,y,2.49),dark,yaw)
  fixed('MotorBridge',(0.19,0.18,0.14),(x+0.26,y,2.49),metal,yaw)
  fixed('YokeCrosshead',(1.65,0.16,0.18),(x,y,2.65),metal,yaw)
  for k,u in enumerate([-0.74,0.74]):
   fixed('Fork%d'%k,(0.16,0.14,0.565),(x+u,y,2.9325),metal,yaw)
   cyl('TiltBearing%d'%k,0.1,0.23,(x+u,y,3.3),dark,'X',yaw)
  cyl('PitchGearMotor',0.16,0.3,(x+1.6,y,3.3),dark,'X',yaw)
  fixed('PitchMotorStatorBracket',(0.92,0.1,0.1),(x+1.18,y+0.18,3.17),metal,yaw)
  fixed('PitchMotorStatorEnd',(0.1,0.18,0.1),(x+1.6,y+0.09,3.17),metal,yaw)
  cyl('TorqueTube',0.075,3.5,(x,y,3.3),metal,'X',pitch)
  for k,u in enumerate([-1.15,1.15]):
   part('PitchStandOff%d'%k,(0.12,0.12,0.4),u,0,0.2)
   part('PitchSpine%d'%k,(0.12,2.64,0.12),u,0,0.39)
  part('PV',(5.64,3.84,0.045),0,0,0.565,pv,'panel')
  part('Backsheet',(5.68,3.88,0.045),0,0,0.517,dark,'panel')
  for k,u in enumerate([-2.86,2.86]):
   part('FrameSide%d'%k,(0.08,4,0.14),u,0,0.54,metal,'frame')
  for k,v in enumerate([-1.96,1.96]):
   part('FrameEdge%d'%k,(5.64,0.08,0.14),0,v,0.54,metal,'frame')
  for k,v in enumerate([-1.25,1.25]):
   part('Backrail%d'%k,(5.5,0.12,0.14),0,v,0.425)
  part('PanelCableTray',(5.4,0.1,0.08),0,1.25,0.32,dark)
  for k,(a,b)in enumerate([((1.2,0,0.03),(1.38,0,0.18)),((1.38,0,0.18),(1.38,0,0.34)),((1.38,0,0.34),(1.15,0,0.39))]):
   def world(q):
    return(x+q[0],y+c*q[1]-s*q[2],3.3+s*q[1]+c*q[2])
   o=beam(pre+'_FlexiblePitchLoop%d'%k,world(a),world(b),0.035,dark)
   pitch.append(o.name)
   g['backrail'].append(o.name)
  fixed('MastCableRiser',(0.045,0.045,2.35),(x,y-0.185,1.175),dark)
  fixed('YawServiceLoop',(0.08,0.08,0.25),(x,y-0.18,2.43),dark,yaw)
  groups.append(g)
  tr.append(dict(id=pre,row=ri+1,column=ci+1,stationary_components=sta,yaw_components=yaw,pitch_components=pitch,yaw_pivot_m=[x,y,2.53],yaw_axis=[0,0,1],tilt_pivot_m=[x,y,3.3],tilt_axis_at_yaw0=[1,0,0],rest_yaw_degrees=0,rest_tilt_degrees=23))
for ri,y in enumerate([-7.8,0,7.8]):
 B('GroundRowDuct%d'%ri,(27.2,0.1,0.1),(1.8,y,0.05),dark)
B('EastGroundDuct',(0.12,21,0.1),(15.4,-2.7,0.05),dark)
B('CabinetGroundFeed',(5.3,0.12,0.1),(12.8,-13.2,0.05),dark)
section=parent[parent.index('for ci,x in enumerate([10.2,7.4]):'):parent.index('# Apply first;')]
section=section.replace('-8.9','-13.2').replace('-9.468','-13.768').replace('-9.494','-13.794').replace('-9.51','-13.81').replace('-9.50','-13.80').replace('-9.525','-13.825').replace('-8.6','-12.9')
exec(section)
bpy.ops.object.select_all(action='DESELECT')
for o in objects:
 o.select_set(True)
 bpy.context.view_layer.objects.active=o
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 o.select_set(False)
bpy.context.view_layer.update()
cs=[]
geo={}
for o in objects:
 pts=[o.matrix_world@v.co for v in o.data.vertices]
 o.data.calc_loop_triangles()
 cs.append(dict(name=o.name,min=[min((v[i]for v in pts))for i in range(3)],max=[max((v[i]for v in pts))for i in range(3)]))
 geo[o.name]=dict(vertices_world_m=[list(v)for v in pts],triangles=[list(t.vertices)for t in o.data.loop_triangles])
 vg=o.vertex_groups.new(name=o.name)
 vg.add(list(range(len(pts))),1,'REPLACE')
 if o.name.endswith('_PV'):
  uv=o.data.uv_layers.active
  if not uv:
   uv=o.data.uv_layers.new(name='UVMap')
  inv=Matrix.Rotation(-angle,4,'X')
  for loop in o.data.loops:
   q=inv@o.data.vertices[loop.vertex_index].co
   uv.data[loop.index].uv=(q.x/5.64+0.5,q.y/3.84+0.5)
lookup={e['name']:e for e in cs}
assert all((e['min'][i]>=-15.501 and e['max'][i]<=15.501 for e in cs for i in[0,1]))
assert min((e['min'][2]for e in cs))>=-1e-05
for t in tr:
 p=Vector(t['tilt_pivot_m'])
 local=[]
 for n in t['pitch_components']:
  for v in geo[n]['vertices_world_m']:
   local.append(Matrix.Rotation(-angle,4,'X')@(Vector(v)-p))
 radius=max((v.length for v in local))
 lower=min((min((v.y*math.sin(a)+v.z*math.cos(a)for a in[0,math.radians(65)]+([math.atan2(-v.y,-v.z)]if 0<=math.atan2(-v.y,-v.z)<=math.radians(65)else[])))for v in local))+3.3
 assert radius<=3.6 and lower>0
 slo=[1000000000.0]*3
 shi=[-1000000000.0]*3
 for tilt in range(0,66,5):
  rx=Matrix.Rotation(math.radians(tilt),3,'X')
  for yawdeg in range(0,360,15):
   rz=Matrix.Rotation(math.radians(yawdeg),3,'Z')
   for v in local:
    q=rz@(rx@v)+p
    for i in range(3):
     slo[i]=min(slo[i],q[i])
     shi[i]=max(shi[i],q[i])
 t['measured_sweep']=dict(actual_vertex_radius_m=radius,continuous_ground_clearance_m=lower,continuous_xy_min=[p.x-radius,p.y-radius],continuous_xy_max=[p.x+radius,p.y+radius],independent_neighbor_gap_m=7.8-2*radius,sampled_bounds=dict(min=slo,max=shi),sample_yaw_step_degrees=15,sample_tilt_step_degrees=5)
 assert abs(p.x)+radius<=15.5 and abs(p.y)+radius<=15.5
maxrad=max((t['measured_sweep']['actual_vertex_radius_m']for t in tr))
equipment=[e for e in cs if e['name'].startswith('Inverter')]
eg=-7.8-maxrad-max((e['max'][1]for e in equipment))
assert eg>0
corridor=dict(min=[9.6,-16,0],max=[10.8,-13.86,2.2])
hits=[e['name']for e in cs if all((e['max'][i]>corridor['min'][i]+1e-06 and e['min'][i]<corridor['max'][i]-1e-06 for i in range(3)))]
assert not hits
sc=[]
for t in tr:
 x,y,z=t['tilt_pivot_m']
 panel_names=[n for n in t['pitch_components']if any((k in n for k in['PV','Backsheet','Frame']))]
 pvlocal=[Matrix.Rotation(-angle,4,'X')@(Vector(v)-Vector([x,y,z]))for n in panel_names for v in geo[n]['vertices_world_m']]
 w=min((v.z for v in pvlocal))
 central_clear=w*math.cos(math.radians(65))-0.1*math.sin(math.radians(65))-0.1
 assert central_clear>0
 sc.append(dict(id=t['id'],panel_vs_fork_bearing_vertical_clearance_m=central_clear,pitch_spine_outside_fork_x_gap_m=1.09-0.855,backrails_outside_fork_tilt_axis_distance_m=1.19,yoke_crosshead_top_m=2.74,pitch_spine_min_z_over_range_m=3.3-1.32*math.sin(math.radians(65))+0.33*math.cos(math.radians(65)),note='Spines outside forkX; rails outside yoke; tube-bearing contact intended; wire outside fork.'))
def write(n,d):
 (OUT/n).write_text(json.dumps(d,indent=2))
write('tracking-contract.json',dict(units='metres',coordinate_system='Zup/front-Y',runtime_tracking_implemented=False,source_is_static=True,range=dict(yaw_degrees=[0,360],tilt_degrees=[0,65]),tables=tr,component_meshes=geo,rest_pose_formula='Pitch l=Rx(-23)*(v-tiltPivot); v=yawPivot+Rz(yaw)*(tiltPivot-yawPivot+Rx(tilt)*l). Yaw-only v=yawPivot+Rz(yaw)*(v-yawPivot). Degrees/right-handed.',continuous_method='Vertex radius bounds continuous XY; exact sinusoid extrema bound grade for tilt0..65. Neighbor gap7.8-2R.',equipment_clearance_m=eg,self_contact_checks=sc,intended_mating_pairs=[dict(table=t['id'],pairs=[[t['id']+'_TorqueTube',t['id']+'_TiltBearing0'],[t['id']+'_TorqueTube',t['id']+'_TiltBearing1'],[t['id']+'_TorqueTube',t['id']+'_PitchGearMotor'],[t['id']+'_FixedSlewRace',t['id']+'_YawBearing']])for t in tr],wire_policy='Duct/riser fixed; yaw loop yaws; pitch loop pitches. Future flexible cable deformation required.',certification='Stylized static source, no engineering or runtime tracking certification.'))
write('entrance-anchors.json',dict(anchors=[dict(role='maintenance',target='Inverter0_FlushDoor',xyz_m=[10.2,-13.86,0],outward=[0,-1,0],width_m=1.2,grade_m=0,boundary_connector=dict(xyz_m=[10.2,-16,0],outward=[0,-1,0],width_m=1.2,grade_m=0),reserved_free_corridor=corridor)],all_component_nonintersection=True,intersection_names=hits,future_access='External service access from south boundary to actual inverter front; no intrinsic pavement.'))
rowbounds=[]
for row in range(1,4):
 ns=[n for g in groups if g['row']==row for cat in['panel','frame','backrail']for n in g[cat]]
 rowbounds.append([min((lookup[n]['min'][1]for n in ns)),max((lookup[n]['max'][1]for n in ns))])
write('landmark-contract.json',dict(site_m=[32,32],proposal_only=True,previous_site_m=[32,24],rows=3,tables_per_row=4,groups=groups,tilt_degrees=23,row_y_bounds_m=rowbounds,row_clear_gaps_m=[rowbounds[i+1][0]-rowbounds[i][1]for i in range(2)],continuous_neighbor_gap_m=7.8-2*maxrad,cabinet_service_target='Inverter0_FlushDoor',lod_plan='Later LOD: simplify bearings/motors/rails, bake cells; retain raised mounts. V1 preserved.'))
write('material-manifest.json',dict(maps=maps,regions=[metal.name,paint.name,dark.name,pv.name],hardware_recipe='Inherited maps: sRGB BaseColor; Non-Color Normal/ORM; normal .35, G roughness/B metal/R AO.',pv=dict(cell_grid=[12,8],uv='Normalized per table',roughness=0.48,metallic=0.12),native_reconstruction='Static FBX; reconstruct shared four shaders and PV grid later.'))
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT')
objects[0].select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
objects[0].select_set(False)
finish(objects)
p=OUT/'validation.json'
v=json.loads(p.read_text())
asset=next((o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)>500))
asset.data.calc_loop_triangles()
assert len(asset.data.loop_triangles)<=6500
assert len(asset.data.materials)==4
assert asset.data.uv_layers.active and all((math.isfinite(a)for uv in asset.data.uv_layers.active.data for a in uv.uv))
v.update(components=cs,proposed_site_m=[32,32],triangles=len(asset.data.loop_triangles),finite_uv0=True,source_identity=dict(parent='/previous/asset.blend',revision='Raised two-axis trackers, static review only',production_inputs_unchanged=True),maintenance_corridor_clear=True,continuous_equipment_gap_m=eg,continuous_neighbor_gap_m=7.8-2*maxrad,tracking_implemented=False)
write('validation.json',v)

import bpy, sys, math, json, shutil, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
# Original source-only study; approved source files are never modified.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
bpy.context.scene.unit_settings.system='METRIC'; bpy.context.scene.unit_settings.scale_length=1

def mat(name,color,rough=.65,metal=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=(*color,1)
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 return m
metal=mat('Mechanical_shared_3maps',(.42,.46,.49),.6,.4)
paint=mat('Neutral_cabinet_paint',(.56,.61,.63),.68)
dark=mat('Dark_mechanical',(.085,.105,.12),.72,.15)
pv=mat('Deep_blue_PV_with_subtle_cells',(.015,.045,.095),.48,.12)
textures=OUT/'textures';textures.mkdir(exist_ok=True);maps=[]
nt=metal.node_tree;p=nt.nodes.get('Principled BSDF')
for suffix,cs in [('BaseColor','sRGB'),('Normal','Non-Color'),('ORM','Non-Color')]:
 src=Path('/repo/ArtSource/Textures/BuildingSurfaces/CityMechanical_'+suffix+'.png');dst=textures/src.name;shutil.copyfile(src,dst)
 im=bpy.data.images.load(str(dst),check_existing=True);im.colorspace_settings.name=cs;im.pack()
 tex=nt.nodes.new('ShaderNodeTexImage');tex.image=im
 if suffix=='BaseColor':nt.links.new(tex.outputs['Color'],p.inputs['Base Color'])
 elif suffix=='Normal':
  normal=nt.nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.35;nt.links.new(tex.outputs['Color'],normal.inputs['Color']);nt.links.new(normal.outputs['Normal'],p.inputs['Normal'])
 else:
  sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(tex.outputs['Color'],sep.inputs['Color']);nt.links.new(sep.outputs['Green'],p.inputs['Roughness']);nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
 maps.append(dict(path='textures/'+src.name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=cs))
# UV-cell pattern is shader-only: no tiny separate solids. 12 x 8 understated cells per table.
nt=pv.node_tree;p=nt.nodes.get('Principled BSDF');uv=nt.nodes.new('ShaderNodeTexCoord');sep=nt.nodes.new('ShaderNodeSeparateXYZ');nt.links.new(uv.outputs['UV'],sep.inputs[0]);lines=[]
for axis,count in [('X',12),('Y',8)]:
 mul=nt.nodes.new('ShaderNodeMath');mul.operation='MULTIPLY';mul.inputs[1].default_value=count;nt.links.new(sep.outputs[axis],mul.inputs[0])
 fract=nt.nodes.new('ShaderNodeMath');fract.operation='FRACT';nt.links.new(mul.outputs[0],fract.inputs[0])
 less=nt.nodes.new('ShaderNodeMath');less.operation='LESS_THAN';less.inputs[1].default_value=.018;nt.links.new(fract.outputs[0],less.inputs[0]);lines.append(less)
 mx=nt.nodes.new('ShaderNodeMath');mx.operation='MAXIMUM'
for i,v in enumerate(lines):nt.links.new(v.outputs[0],mx.inputs[i])
mix=nt.nodes.new('ShaderNodeMixRGB');mix.inputs[1].default_value=(.012,.033,.072,1);mix.inputs[2].default_value=(.055,.095,.145,1);nt.links.new(mx.outputs[0],mix.inputs[0]);nt.links.new(mix.outputs[0],p.inputs['Base Color'])
objects=[];groups=[];angle=math.radians(23);s=math.sin(angle);c=math.cos(angle)
def B(name,dims,loc,material=metal,tilt=False):
 o=box(name,dims,loc,(.5,.5,.5,1));o.data.materials.clear();o.data.materials.append(material)
 if not o.data.uv_layers:o.data.uv_layers.new(name='UVMap')
 # Physical metre UVs on hardware; normalized planar UVs on PV.
 uv=o.data.uv_layers.active
 for f in o.data.polygons:
  for li in f.loop_indices:
   v=o.data.vertices[o.data.loops[li].vertex_index].co
   # box helper may use scaled unit cubes; dimensions below are final requested sizes
   uv.data[li].uv=(v.x+.5,v.y+.5) if material==pv else (v.x*dims[0],v.y*dims[1]+v.z*dims[2])
 if tilt:o.rotation_euler.x=angle
 objects.append(o);return o

def beam(name,a,b,width,material=metal):
 a,b=Vector(a),Vector(b);o=B(name,(width,width,(b-a).length),(a+b)/2,material);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o

def local(x,y,u,v,w):return (x+u,y+c*v-s*w,1.65+s*v+c*w)
for ri,y in enumerate([-5.2,.8,6.8]):
 for ti,x in enumerate([-10.2,-3.4,3.4,10.2]):
  prefix='R%dT%d'%(ri+1,ti+1);g=dict(id=prefix,row=ri+1,column=ti+1,panel=[],frame=[],backrail=[],leg=[],brace=[])
  def part(tag,dims,u,v,w,material,category):
   o=B(prefix+'_'+tag,dims,local(x,y,u,v,w),material,True);g[category].append(o.name);return o
  part('PV',(5.64,3.84,.045),0,0,.065,pv,'panel')
  part('Backsheet',(5.68,3.88,.045),0,0,.017,dark,'panel')
  for j,u in enumerate([-2.86,2.86]):part('FrameSide%d'%j,(.08,4,.14),u,0,.04,metal,'frame')
  for j,v in enumerate([-1.96,1.96]):part('FrameEdge%d'%j,(5.64,.08,.14),0,v,.04,metal,'frame')
  for j,v in enumerate([-1.25,1.25]):
   part('Backrail%d'%j,(5.5,.12,.14),0,v,-.075,metal,'backrail')
   for k,u in enumerate([-1.95,1.95]):
    # Vertical legs terminate on the lower sloped rail surface, not below it.
    px,py,pz=local(x,y,u,v,-.145)
    o=B(prefix+'_Leg%d%d'%(j,k),(.14,.14,pz),(px,py,pz/2));g['leg'].append(o.name)
  for k,u in enumerate([-1.95,1.95]):
   a=local(x,y,u,-1.25,-.145);b=local(x,y,u,1.25,-.145)
   o=beam(prefix+'_Diagonal%d'%k,(a[0],a[1],.18),b,.085);g['brace'].append(o.name)
  # Protected trunk tray attached to rear rail inside table envelope.
  part('CableTray',(5.5,.16,.10),0,1.25,-.19,dark,'backrail')
  groups.append(g)
# Edge-routed service collection: no crossing of the walking lanes within array width.
for ri,y in enumerate([-5.2,.8,6.8]):
 yy=y+c*1.25; zz=1.65+s*1.25-c*.19
 B('Row%d_CollectionTray'%ri,(2.5,.16,.10),(13.8,yy,zz),dark)
 B('Row%d_TrayDrop'%ri,(.12,.12,zz),(14.98,yy,zz/2),dark)
B('PerimeterCableDuct',(.18,16.9,.16),(14.98,-.7,.08),dark)
B('CabinetFeedDuct',(4.78,.18,.16),(12.59,-8.9,.08),dark)
# Free-standing equipment, grounded on their own metal legs, no foundation or pad.
for ci,x in enumerate([10.2,7.4]):
 pre='Inverter%d'%ci
 B(pre+'_Body',(1.8,1.1,1.9),(x,-8.9,1.2),paint)
 for k,dx in enumerate([-.65,.65]):B(pre+'_Foot%d'%k,(.16,.65,.25),(x+dx,-8.9,.125))
 B(pre+'_FlushDoor',(1.58,.035,1.65),(x,-9.468,1.2),paint)
 B(pre+'_Handle',(.045,.065,.26),(x+.57,-9.51,1.24),dark)
 for k,dx in enumerate([-.73,.73]):B(pre+'_DoorRimSide%d'%k,(.035,.025,1.7),(x+dx,-9.494,1.2))
 for k,z in enumerate([.35,2.05]):B(pre+'_DoorRimEnd%d'%k,(1.49,.025,.035),(x,-9.494,z))
 # Surface-mounted shallow vent slats with attached rim.
 B(pre+'_VentBacking',(.72,.025,.30),(x,-9.50,.67),dark)
 for k in range(4):B(pre+'_VentSlat%d'%k,(.72,.025,.025),(x,-9.525,.56+k*.072))
 for k,dx in enumerate([-.38,.38]):B(pre+'_VentRim%d'%k,(.035,.03,.34),(x+dx,-9.515,.67))
B('EquipmentLink',(1,.15,.12),(8.8,-8.6,.35),dark)
# Apply first; measure EVERY disconnected solid with exact world bounds.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:
 o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o.select_set(False)
bpy.context.view_layer.update()
components=[]
for o in objects:
 pts=[o.matrix_world@Vector(v) for v in o.bound_box];components.append(dict(name=o.name,min=[min(p[i] for p in pts) for i in range(3)],max=[max(p[i] for p in pts) for i in range(3)]))
lookup={e['name']:e for e in components}
assert all(e['min'][0]>=-15.5 and e['max'][0]<=15.5 and e['min'][1]>=-11.5 and e['max'][1]<=11.5 and e['min'][2]>=-1e-5 for e in components)
rowbounds=[]
for row in range(1,4):
 names=[n for g in groups if g['row']==row for cat in ['panel','frame','backrail','leg','brace'] for n in g[cat]]
 rowbounds.append([min(lookup[n]['min'][1] for n in names),max(lookup[n]['max'][1] for n in names)])
gaps=[rowbounds[i+1][0]-rowbounds[i][1] for i in range(2)];assert min(gaps)>=1.5
corridor={'min':[9.6,-12,0],'max':[10.8,-9.56,2.2]}
intersections=[e['name'] for e in components if all(e['max'][i]>corridor['min'][i]+1e-6 and e['min'][i]<corridor['max'][i]-1e-6 for i in range(3))];assert not intersections
# Geometric rail/leg mating verified by local-plane construction; record measured world endpoints.
contacts=[]
for g in groups:
 for n in g['leg']:
  e=lookup[n];top=[(e['min'][0]+e['max'][0])/2,(e['min'][1]+e['max'][1])/2,e['max'][2]]
  rail=lookup[g['backrail'][int(n[-2])]]
  assert rail['min'][2]-1e-5<=top[2]<=rail['max'][2]+1e-5
  contacts.append(dict(leg=n,rail=g['backrail'][int(n[-2])],leg_top_m=top,plane_contact_error_m=0.0))
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2))
write('entrance-anchors.json',dict(anchors=[dict(role='maintenance',target='Inverter0_FlushDoor',xyz_m=[10.2,-9.56,0],outward=[0,-1,0],width_m=1.2,grade_m=0,boundary_connector=dict(xyz_m=[10.2,-12,0],outward=[0,-1,0],width_m=1.2,grade_m=0),reserved_free_corridor=corridor)],all_component_nonintersection=True,intersection_names=intersections,future_access='Future external service traffic reaches inverter front from negative Y; no path geometry authored.'))
write('landmark-contract.json',dict(asset='Solar farm source detail study',site_m=[32,24],solid_limits_m=[31,23],rows=3,tables_per_row=4,tilt_degrees=23,table_size_m=[5.8,4],groups=groups,row_y_bounds_m=rowbounds,row_clear_gaps_m=gaps,contacts=contacts,panel_frame_contact='Inset PV reaches inner frame faces at local x +/-2.82 and y +/-1.92; overlapping edge seam; backsheet meets rails at local z=-0.005.',cabinet_service_target='Inverter0_FlushDoor',components=components,lod_plan='Retain old low-poly asset as historical input. New LOD1: merge table backsheet/frame into one six-sided tilted silhouette, remove braces and vents, bake cell grid; LOD2: twelve tilted plates on paired simplified legs and two cabinet boxes. Preserve 23 degree tilt, three-row gaps, source bounds and service entrance. No runtime or performance validation.'))
write('material-manifest.json',dict(maps=maps,regions=['Mechanical_shared_3maps','Neutral_cabinet_paint','Dark_mechanical','Deep_blue_PV_with_subtle_cells'],hardware_recipe='BaseColor sRGB to base; normal Non-Color via Normal Map strength 0.35; ORM Non-Color G roughness / B metallic, R retained occlusion for native reconstruction. Metre-scale UV0.',paint=dict(base_color=[.56,.61,.63],roughness=.68,metallic=0),pv=dict(base_color=[.012,.033,.072],roughness=.48,metallic=.12,cell_grid=[12,8],line_fraction=.018),native_reconstruction='FBX does not carry shader graphs. Rebuild UV PV fractional 12x8 subtle grid or bake into existing material strategy; reconstruct packed ORM and normal with supplied exact maps. No extra texture pack.'))
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR');objects[0].select_set(False)
finish(objects)
# Retain tested helper's strict FBX readback report and augment it with source checks.
vpath=OUT/'validation.json';v=json.loads(vpath.read_text()) if vpath.exists() else {}
asset=next(o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)>500)
asset.data.calc_loop_triangles();tri=len(asset.data.loop_triangles);assert tri<=5500
assert len(asset.data.materials)<=5
assert asset.data.uv_layers.active and all(math.isfinite(a) for uv in asset.data.uv_layers.active.data for a in uv.uv)
v.update(components=components,triangles=tri,semantic_regions=len(asset.data.materials),row_clear_gaps_m=gaps,maintenance_corridor_clear=True,proposed_site_m=[32,24],source_identity={'commit':'2b0beb7e2b38627804aabcac6e6b50bcf4dc54d4','reference':'ArtSource/Blender/CityAlternativeFacilityKit.blend','object':'SM_Building_SolarPower_A','policy':'Original replacement geometry; approved inputs unchanged; review only'},finite_uv0=True,contacts=contacts)
write('validation.json',v)

import bpy, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import snapshot, checked_fbx
objects=load_previous()
assert len(objects)==1
asset=objects[0]
before=snapshot(asset)
original_dims=list(asset.dimensions)
original_matrix=[list(r) for r in asset.matrix_world]
assert len(asset.data.materials)==1
mat=asset.data.materials[0]
mat.use_nodes=True
mat.diffuse_color=(.50,.405,.285,1)
p=mat.node_tree.nodes.get('Principled BSDF')
p.inputs['Base Color'].default_value=mat.diffuse_color
p.inputs['Roughness'].default_value=.88
p.inputs['Metallic'].default_value=0
p.inputs['Alpha'].default_value=1
finish(objects)
scene=bpy.context.scene
asset=next(o for o in scene.objects if o.type=='MESH' and len(o.data.vertices)==len(before['vertices']))
assert snapshot(asset)==before, 'Geometry/UV/face assignments changed'
assert all(abs(a-b)<1e-6 for a,b in zip(asset.dimensions,original_dims))
# Presentation objects are explicitly excluded from the asset FBX.
for o in list(scene.objects):
    if o.type=='LIGHT' or (o.type=='MESH' and o!=asset):
        bpy.data.objects.remove(o,do_unlink=True)
scene.render.engine='CYCLES'
scene.cycles.device='CPU'
scene.cycles.samples=12
scene.render.resolution_x=512
scene.render.resolution_y=512
scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.view_settings.exposure=-.65
scene.world.use_nodes=True
bg=scene.world.node_tree.nodes.get('Background')
bg.inputs['Color'].default_value=(.24,.22,.20,1)
bg.inputs['Strength'].default_value=.35
# Neutral warm-gray seamless review floor, not a ground base in the asset.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.001))
floor=bpy.context.object
floor.name='Review_Backdrop_NOT_ASSET'
m=bpy.data.materials.new('Review_WarmGray')
m.use_nodes=True
bs=m.node_tree.nodes.get('Principled BSDF')
bs.inputs['Base Color'].default_value=(.23,.215,.195,1)
bs.inputs['Roughness'].default_value=.95
floor.data.materials.append(m)
def area(name,loc,power,size):
    data=bpy.data.lights.new(name,'AREA'); data.energy=power; data.shape='DISK'; data.size=size
    ob=bpy.data.objects.new(name,data); scene.collection.objects.link(ob); ob.location=loc
    ob.rotation_euler=(Vector((0,0,.23))-ob.location).to_track_quat('-Z','Y').to_euler()
area('Soft_key',(-.65,-.8,1.15),65,.65)
area('Gentle_fill',(.8,-.25,.65),18,.7)
area('Handle_separation',(.2,.65,.95),40,.5)
camera=scene.camera
camera.data.type='ORTHO'
center=Vector((0,0,.235))
def view(path,pos,scale):
    camera.location=pos
    camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.ortho_scale=scale
    scene.render.filepath=path
    bpy.ops.render.render(write_still=True)
view('/output/preview.png',(.72,-1.1,.79),.63)
view('/output/front_1m.png',(0,-1,.235),1.0)
view('/output/side.png',(1,0,.38),.61)
camera.location=(.72,-1.1,.79)
camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.ortho_scale=.63
scene.render.filepath='/output/preview.png'
asset.data.calc_loop_triangles()
triangles=len(asset.data.loop_triangles)
assert 160<=triangles<=300
assert snapshot(asset)==before
with checked_fbx(asset,Path('/output/asset.fbx'),['Fabric'],expected_triangles=triangles,expected_sections=1): pass
import bmesh
bm=bmesh.new(); bm.from_mesh(asset.data)
nonmanifold=sum(not e.is_manifold for e in bm.edges); bm.free()
assert nonmanifold==0
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True); bpy.context.view_layer.objects.active=asset
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
report={'issue':'D108 Resident open beach tote','revision':'v2 presentation/material only','status':'review-only; no export approval or integration','geometry_snapshot_unchanged':snapshot(asset)==before,'dimensions_m':list(asset.dimensions),'triangles':triangles,'materials':[mat.name],'nonmanifold_edges':nonmanifold,'fbx_roundtrip_pass':True,'origin_m':list(asset.location),'original_world_matrix':original_matrix,'units':'meters Z-up','views':{'three_quarter':'preview.png','front_1m_vertical_field':'front_1m.png','side':'side.png'},'presentation_floor_excluded_from_fbx':True,'production_inputs_modified':False,'visual_acceptance':'pending human review'}
Path('/output/validation.json').write_text(json.dumps(report,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'asset':asset.name,'source':'asset.blend','export':'asset.fbx','review':report},indent=2))

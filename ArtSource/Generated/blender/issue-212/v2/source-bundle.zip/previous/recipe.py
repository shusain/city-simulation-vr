import bpy, sys, math, json
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
# One closed opaque shell with a shallow recessed mouth; two closed broad straps.
verts=[]; faces=[]
def ring(w,d,z,c):
    coords=[(-w/2+c,-d/2),(w/2-c,-d/2),(w/2,-d/2+c),(w/2,d/2-c),(w/2-c,d/2),(-w/2+c,d/2),(-w/2,d/2-c),(-w/2,-d/2+c)]
    ids=[]
    for x,y in coords: ids.append(len(verts)); verts.append((x,y,z))
    return ids
def bridge(a,b):
    for i in range(len(a)):
        j=(i+1)%len(a); faces.append((a[i],a[j],b[j],b[i]))
a=ring(.36,.16,0,.025); b=ring(.45,.22,.30,.035)
c=ring(.426,.196,.30,.030); d=ring(.406,.176,.245,.028)
bridge(a,b); bridge(b,c); bridge(c,d)
faces.append(tuple(reversed(a))); faces.append(tuple(d))
for y in [-.087,.087]:
    sections=[]
    for i in range(12):
        t=math.pi-math.pi*i/11
        x=.125*math.cos(t); z=.280+.187*math.sin(t)
        # In-plane normal to the elliptical arch, broad fabric strap.
        nx=math.cos(t)/.125; nz=math.sin(t)/.187
        length=math.hypot(nx,nz); nx/=length; nz/=length
        ids=[]
        for s,q in [(-1,-1),(1,-1),(1,1),(-1,1)]:
            ids.append(len(verts)); verts.append((x+s*.013*nx,y+q*.004,z+s*.013*nz))
        sections.append(ids)
    for j in range(11): bridge(sections[j],sections[j+1])
    faces.append(tuple(reversed(sections[0]))); faces.append(tuple(sections[-1]))
mesh=bpy.data.meshes.new('Closed_tapered_shell_and_broad_loop_straps'); mesh.from_pydata(verts,[],faces); mesh.update()
obj=bpy.data.objects.new('Resident_Open_Beach_Tote',mesh); bpy.context.collection.objects.link(obj)
bpy.context.view_layer.objects.active=obj; obj.select_set(True)
# Recalculate consistent closed-surface winding.
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.object.mode_set(mode='OBJECT')
mat=bpy.data.materials.new('Fabric'); mat.diffuse_color=(.78,.70,.55,1); mat.use_nodes=True
p=mat.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=mat.diffuse_color; p.inputs['Roughness'].default_value=.9
obj.data.materials.append(mat)
obj['review_only']=True; obj['description']='Cream neutral open beach tote; closed opaque shell and two broad fabric handles; no contents.'
finish([obj])
# Keep the tested preview setup, with asset-scale orthographic review framing.
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
asset=next(o for o in scene.objects if o.type=='MESH' and len(o.data.vertices)==len(verts))
asset.name='Resident_Open_Beach_Tote'
# Ground-contact origin, identity transforms, exactly one semantic material.
scene.cursor.location=(0,0,0); bpy.context.view_layer.objects.active=asset
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True)
bpy.ops.object.origin_set(type='ORIGIN_CURSOR'); bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
asset.data.materials.clear(); asset.data.materials.append(mat)
for poly in asset.data.polygons: poly.material_index=0
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
camera=scene.camera; camera.data.type='ORTHO'; camera.data.ortho_scale=.68
center=Vector((0,0,.24))
def view(path,position,scale=.68):
    camera.location=position; camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler(); camera.data.ortho_scale=scale
    scene.render.filepath=path; bpy.ops.render.render(write_still=True)
view('/output/preview.png',(.8,-1.2,.85))
view('/output/front_1m.png',(0,-1,.24),1.0)
view('/output/side.png',(1,0,.35),.68)
camera.location=(.8,-1.2,.85); camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler(); camera.data.ortho_scale=.68
asset.data.calc_loop_triangles(); triangles=len(asset.data.loop_triangles)
with checked_fbx(asset,Path('/output/asset.fbx'),['Fabric'],expected_triangles=triangles,expected_sections=1): pass
import bmesh
bm=bmesh.new(); bm.from_mesh(asset.data); nonmanifold=sum(not e.is_manifold for e in bm.edges); bm.free()
assert 160<=triangles<=300
assert nonmanifold==0
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
report={'issue':'D108 Resident open beach tote','status':'review-only; not approved for integration','triangles':triangles,'dimensions_m':list(asset.dimensions),'materials':['Fabric'],'closed_geometry_nonmanifold_edges':nonmanifold,'fbx_roundtrip_pass':True,'origin':'ground contact center','units':'meters Z-up','transforms_applied':True,'opening_depth_m':.055,'views':{'three_quarter':'preview.png','front_1m_vertical_field':'front_1m.png','side':'side.png'},'no_contents_no_brand_no_ground_base':True,'production_inputs_modified':False}
Path('/output/validation.json').write_text(json.dumps(report,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'asset':'Resident_Open_Beach_Tote','source':'asset.blend','export':'asset.fbx','review':report},indent=2))

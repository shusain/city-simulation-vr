import bpy, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
objects=load_previous()
def geom_signature(obs):
    data=[]
    for ob in obs:
        data.append({'vertices':[list(v.co) for v in ob.data.vertices],'faces':[list(p.vertices) for p in ob.data.polygons]})
    return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
before=geom_signature(objects)
# Presentation revision only: retain the approved mesh, vertex tints and material.
finish(objects)
assets=[o for o in objects if o.name in bpy.data.objects and o.type=='MESH']
assert assets, 'Source asset missing'
asset=assets[0]
assert geom_signature(assets)==before, 'Source geometry changed'
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'; scene.view_settings.exposure=-0.7
# Set a neutral medium sand/gray stage, never included in the checked asset FBX.
stage=bpy.data.materials.new('ReviewStage_SandGray'); stage.use_nodes=True
p=stage.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(.24,.225,.20,1); p.inputs['Roughness'].default_value=.85
stage.diffuse_color=(.24,.225,.20,1)
for ob in list(scene.objects):
    if ob.type=='MESH' and ob not in assets:
        ob.data.materials.clear(); ob.data.materials.append(stage)
        ob['presentation_only']=True
if not any(o.type=='MESH' and o not in assets for o in scene.objects):
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0,0,-.003))
    ground=bpy.context.object; ground.name='ReviewGround_NotAsset'; ground.data.materials.append(stage); ground['presentation_only']=True
world=scene.world
if world is None:
    world=bpy.data.worlds.new('ReviewWorld'); scene.world=world
world.use_nodes=True
bg=world.node_tree.nodes.get('Background'); bg.inputs['Color'].default_value=(.24,.23,.21,1); bg.inputs['Strength'].default_value=.45
for ob in list(scene.objects):
    if ob.type=='LIGHT': bpy.data.objects.remove(ob,do_unlink=True)
def area(name,loc,energy,size):
    data=bpy.data.lights.new(name,'AREA'); data.energy=energy; data.shape='DISK'; data.size=size
    ob=bpy.data.objects.new(name,data); scene.collection.objects.link(ob); ob.location=loc
    ob.rotation_euler=(Vector((0,0,.07))-ob.location).to_track_quat('-Z','Y').to_euler()
area('SoftKey',(-1.5,-1.8,2.5),110,1.7)
area('GentleFill',(1.8,.5,1.8),45,2.0)
cam=scene.camera; cam.data.type='ORTHO'
points=[ob.matrix_world @ v.co for ob in assets for v in ob.data.vertices]
def view(location,target,scale=None):
    cam.location=location; cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    if scale is None:
        inv=cam.rotation_euler.to_matrix().transposed(); xs=[(inv@v).x for v in points]; ys=[(inv@v).y for v in points]
        scale=max((max(xs)-min(xs))/.70,(max(ys)-min(ys))/.75)
    cam.data.ortho_scale=scale
view((1.05,-1.45,1.10),(0,0,.085))
iso_loc=cam.location.copy(); iso_rot=cam.rotation_euler.copy(); iso_scale=cam.data.ortho_scale
scene.render.filepath='/output/preview.png'; bpy.ops.render.render(write_still=True)
view((0,0,2),(0,0,0),.8/.70)
scene.render.filepath='/output/top.png'; bpy.ops.render.render(write_still=True)
view((1.05,-1.45,1.10),(0,0,.085),1.0)
scene.render.filepath='/output/scale_1m.png'; bpy.ops.render.render(write_still=True)
cam.location=iso_loc; cam.rotation_euler=iso_rot; cam.data.ortho_scale=iso_scale
scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json'); receipt=json.loads(p.read_text())
asset.data.calc_loop_triangles()
import bmesh
bm=bmesh.new(); bm.from_mesh(asset.data); nonmanifold=sum(not e.is_manifold for e in bm.edges); bm.free()
receipt['presentation_revision']={'geometry_sha256_before':before,'geometry_sha256_after':geom_signature(assets),'unchanged_geometry':True,'triangles':len(asset.data.loop_triangles),'bounds_m':list(asset.dimensions),'slots':[m.name for m in asset.data.materials],'uv0_present':bool(asset.data.uv_layers),'nonmanifold_edges':nonmanifold,'iso_orthographic_width_m':iso_scale,'exposure':-.7,'scale_view_width_m':1.0,'contact':'Unchanged source contact; no geometry edits','visual_acceptance':'Pending human review'}
p.write_text(json.dumps(receipt,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 Natural beach-pebble mound','revision':'Presentation-only revision of v1','source':'/previous/asset.blend','geometry_preserved':True,'review_only':True,'production_changes':False,'outputs':['asset.blend','asset.fbx','preview.png','top.png','scale_1m.png','validation.json'],'scale_view':'Orthographic image width exactly 1 meter; ground is presentation only, excluded from FBX','notes':'Preserved all original stones, mesh topology, tint, material slot and origin. Neutral stage, softened key/fill, reduced exposure and close framing. No visual approval claimed.'},indent=2))
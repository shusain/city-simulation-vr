import bpy, sys, math, json, bmesh
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
objects=load_previous()
# Explicit replacement request: retire the joined mound from this review copy only.
for ob in objects:
    if ob.name in bpy.data.objects: bpy.data.objects.remove(ob,do_unlink=True)
verts=[]
N=8
# Broad closed crown and small planar contact patch, no polar apex.
for ri,(z,r) in enumerate([(0,.43),(.019,1.0),(.049,.91),(.070,.40)]):
    for i in range(N):
        a=2*math.pi*i/N
        irregular=1+.035*math.sin(3*a+.4)+.022*math.cos(2*a+.8)
        x=.09*r*math.cos(a)*irregular + (.0015 if ri==2 else 0)
        y=.065*r*math.sin(a)*(1+.035*math.sin(a+.8))
        verts.append((x,y,z))
# Normalize bounds exactly while keeping ground-center origin.
for axis,extent in [(0,.18),(1,.13)]:
    lo=min(v[axis] for v in verts); hi=max(v[axis] for v in verts)
    verts=[tuple(((v[k]-(lo+hi)/2)*extent/(hi-lo)) if k==axis else v[k] for k in range(3)) for v in verts]
faces=[tuple(reversed(range(N)))]
for r in range(3):
    for i in range(N):
        j=(i+1)%N
        faces.append((r*N+i,r*N+j,(r+1)*N+j,(r+1)*N+i))
faces.append(tuple(range(24,32)))
mesh=bpy.data.meshes.new('Pebble_Closed_60tri'); mesh.from_pydata(verts,[],faces); mesh.update()
asset=bpy.data.objects.new('Medium_Beach_Pebble',mesh); bpy.context.scene.collection.objects.link(asset)
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True); bpy.context.view_layer.objects.active=asset
# Independent packed UV islands, no missing corners or overlapping projections.
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.uv.smart_project(angle_limit=1.15192,island_margin=.035); bpy.ops.object.mode_set(mode='OBJECT')
mesh.uv_layers.active.name='UV0'
for p in mesh.polygons: p.use_smooth=True
mat=bpy.data.materials.get('Pebble') or bpy.data.materials.new('Pebble'); mat.use_nodes=True
mat.diffuse_color=(.24,.215,.185,1)
p=mat.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=mat.diffuse_color; p.inputs['Roughness'].default_value=.67; p.inputs['Metallic'].default_value=0; p.inputs['Alpha'].default_value=1
mesh.materials.clear(); mesh.materials.append(mat)
asset['review_only']=True; asset['issue']='D108 medium isolated pebble'; asset['replacement_reason']='Explicit request replaces previous joined mound'
finish([asset])
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'; scene.view_settings.exposure=0
# Keep presentation geometry separate from the single asset and its FBX.
for ob in list(scene.objects):
    if ob.type=='MESH' and ob!=asset: bpy.data.objects.remove(ob,do_unlink=True)
stage=bpy.data.materials.new('Review_Backdrop'); stage.use_nodes=True
stage.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.23,.23,.23,1)
stage.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.9
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.0003)); ground=bpy.context.object; ground.name='Presentation_only_ground'; ground.data.materials.append(stage); ground['presentation_only']=True
for ob in list(scene.objects):
    if ob.type=='LIGHT': bpy.data.objects.remove(ob,do_unlink=True)
scene.world.use_nodes=True
bg=scene.world.node_tree.nodes.get('Background'); bg.inputs['Color'].default_value=(.3,.3,.3,1); bg.inputs['Strength'].default_value=.5
def light(name,loc,power,size):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.shape='DISK'; d.size=size
    o=bpy.data.objects.new(name,d); scene.collection.objects.link(o); o.location=loc; o.rotation_euler=(Vector((0,0,.03))-o.location).to_track_quat('-Z','Y').to_euler()
light('Soft_key',(-.35,-.45,.65),16,.45); light('Soft_fill',(.45,.2,.4),6,.5)
cam=scene.camera; cam.data.type='ORTHO'; cam.data.clip_start=.001; cam.data.clip_end=100

def render(name,loc,target,width):
    cam.location=loc; cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.ortho_scale=width
    scene.render.filepath='/output/'+name; bpy.ops.render.render(write_still=True)
render('top.png',(0,0,.6),(0,0,0),.25)
render('side.png',(0,-.6,.035),(0,0,.035),.25)
render('scale_1m.png',(.45,-.65,.5),(0,0,.03),1.0)
render('preview.png',(.32,-.45,.32),(0,0,.032),.26)
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True); bpy.context.view_layer.objects.active=asset
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
mesh.calc_loop_triangles(); bm=bmesh.new(); bm.from_mesh(mesh)
nonmanifold=sum(not e.is_manifold for e in bm.edges); volume=bm.calc_volume(signed=True); bm.free()
assert len(mesh.loop_triangles)==60
assert nonmanifold==0 and volume>0
assert all(abs(a-b)<1e-6 for a,b in zip(asset.dimensions,(.18,.13,.07)))
assert len(mesh.materials)==1 and mesh.materials[0].name=='Pebble'
assert all(abs(x-1)<1e-7 for x in asset.scale)
assert min(v.co.z for v in mesh.vertices)==0
path=Path('/output/validation.json'); receipt=json.loads(path.read_text()) if path.exists() else {}
receipt['isolated_pebble_checks']={'triangles':60,'vertices':32,'connected_components':1,'nonmanifold_edges':nonmanifold,'positive_volume_m3':volume,'bounds_m':list(asset.dimensions),'uv0':mesh.uv_layers.active.name,'uv_corners':len(mesh.uv_layers.active.data),'material_slots':['Pebble'],'opaque':True,'transforms_applied':True,'pivot':'ground center','contact_vertices':8,'crown':'broad planar eight-sided cap with rounded shoulder; no polar apex','human_visual_review':'pending','scale_view_width_m':1.0}
path.write_text(json.dumps(receipt,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 medium rounded beach pebble','review_only':True,'source_previous':'/previous/asset.blend','change':'Explicit geometry replacement: joined mound replaced by exactly one isolated stone','dimensions_m':[.18,.13,.07],'triangles':60,'semantic_slot':'Pebble','outputs':['asset.blend','asset.fbx','preview.png','top.png','side.png','scale_1m.png','validation.json'],'scale_view':'Orthographic width exactly 1 meter; backdrop excluded from checked FBX','production_changes':False,'approval':'Pending human review; no Unreal import or promotion'},indent=2))

import bpy, sys, math, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output'); out.mkdir(exist_ok=True)
# Read-only approved concept payloads: validate and load before geometry authoring.
expected={123:['a4f1eadbcef4ce61879463b710bd54910f10864179e93a4eff69efec38d0a3b4','cd720b85c44386dec305e3110d7c8d1aa702dc62aa689b4375d88e8dba508fbf','5fba12a32587cb88e0a3791f19394d718ea4cbeca113d916e603916836ae3b9f'],124:['1ddcd5e5043988801680dcf070607df1f7411050c21d0d463f985b64b071f1ee','e9a5b23f9b0ce83d28d976158d7cfeeb5f262dbb283876909389dd15111f6a40','6924da5d2fb7a1cefc95c02b4dd1fd67197d12f26c10b178f161fade64b4d161']}
refs=[]
for issue in (123,124):
    item={'issue':issue,'version':1,'files':{}}
    for i,fn in enumerate(('asset.png','approval.json','unreal-handoff.json')):
        p=Path('/repo/ArtSource/Generated/comfy/issue-%d/v1'%issue)/fn
        raw=p.read_bytes(); h=hashlib.sha256(raw).hexdigest(); assert h==expected[issue][i],str(p)
        item['files'][fn]={'path':str(p),'sha256':h}
        if fn.endswith('.json'): item['files'][fn]['payload']=json.loads(raw)
        else:
            image=bpy.data.images.load(str(p),check_existing=True)
            assert image.size[0]>0 and image.size[1]>0
            item['image_loaded']=True;item['image_size']=list(image.size)
    refs.append(item)
# Seven intentionally sparse closed, triangular-section wedge blades, no cards or base.
verts=[];faces=[]
# tip X/Y, height, blade breadth, bend fraction
spec=[(-.225,-.035,.275,.043,.58),(.225,.015,.32,.047,.56),(-.065,-.175,.25,.041,.58),(.09,.175,.315,.046,.59),(-.04,.02,.45,.050,.51),(.115,-.08,.39,.043,.53),(-.135,.115,.36,.046,.56)]
for k,(x,y,h,w,bend) in enumerate(spec):
    d=Vector((x,y,0)).normalized(); side=Vector((-d.y,d.x,0))
    root=Vector((0,0,0)); mid=Vector((x*.39,y*.39,h*bend)); tip=Vector((x,y,h))
    local=[]
    for center,width,thick in ((root,w*.36,.005),(mid,w,.008)):
        local.extend([center-side*width/2-d*thick/2,center+side*width/2-d*thick/2,center+d*thick/2])
    local.append(tip); start=len(verts);verts.extend([tuple(v) for v in local])
    fs=[(0,2,1),(0,1,4,3),(1,2,5,4),(2,0,3,5),(3,4,6),(4,5,6),(5,3,6)]
    faces.extend([tuple(start+i for i in f) for f in fs])
# Exact metric bounds, with buried-root contact center retained at the origin.
lo=[min(v[a] for v in verts) for a in range(3)];hi=[max(v[a] for v in verts) for a in range(3)]
factors=[s/(hi[a]-lo[a]) for a,s in enumerate((.45,.35,.45))]
verts=[tuple(v[a]*factors[a] for a in range(3)) for v in verts]
mesh=bpy.data.meshes.new('DuneGrass_closed_wedges');mesh.from_pydata(verts,[],faces);mesh.update()
obj=bpy.data.objects.new('SM_Scenery_DuneGrass_A',mesh);bpy.context.collection.objects.link(obj)
mat=bpy.data.materials.new('DuneGrass');mat.diffuse_color=(.29,.355,.235,1);mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=mat.diffuse_color;bs.inputs['Roughness'].default_value=.88
mesh.materials.append(mat)
bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
# Consistent outward normals on each disconnected closed wedge.
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
# Per-face local planar UV0; disconnected islands are deliberate, no textures required.
uv=mesh.uv_layers.new(name='UV0')
for p in mesh.polygons:
    p.use_smooth=False
    points=[mesh.vertices[mesh.loops[i].vertex_index].co for i in p.loop_indices]
    origin=points[0];u=(points[1]-origin).normalized();v=p.normal.cross(u).normalized()
    for li,pt in zip(p.loop_indices,points):
        delta=pt-origin;uv.data[li].uv=(.05+delta.dot(u),.05+delta.dot(v))
finish([obj])
# Add issue-specific measured evidence to the helper's validation without discarding it.
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH' and ('DuneGrass' in o.name or o.data==mesh)]
asset=obj if obj.name in bpy.data.objects else bpy.context.view_layer.objects.active
assert asset and asset.type=='MESH'
asset.name='SM_Scenery_DuneGrass_A';asset.data.materials.clear();asset.data.materials.append(mat)
bpy.context.view_layer.update();asset.data.calc_loop_triangles()
tri=len(asset.data.loop_triangles);assert tri==70 and tri<=96
bounds=[asset.matrix_world@v.co for v in asset.data.vertices]
mins=[min(v[i] for v in bounds) for i in range(3)];maxs=[max(v[i] for v in bounds) for i in range(3)]
dims=[maxs[i]-mins[i] for i in range(3)]
assert all(abs(a-b)<=b*.05 for a,b in zip(dims,(.45,.35,.45)))
assert abs(mins[2])<1e-6
assert asset.location.length<1e-6 and all(abs(s-1)<1e-6 for s in asset.scale)
uv=asset.data.uv_layers.active;assert uv
areas=[]
for t in asset.data.loop_triangles:
    a,b,c=[Vector(uv.data[i].uv) for i in t.loops]
    areas.append(abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x))*.5)
assert min(areas)>1e-12
with checked_fbx(asset,out/'asset.fbx',['DuneGrass'],expected_triangles=tri,expected_sections=1) as check:
    rt={'pass':True,'dimensions_m':list(check.dimensions),'triangles':len(check.data.loop_triangles),'material_slots':[m.name.split('.')[0] for m in check.data.materials]}
p=out/'validation.json';report=json.loads(p.read_text()) if p.exists() else {}
report['D108_source_review']={'asset':'SM_Scenery_DuneGrass_A','review_only':True,'blade_count':7,'dimensions_m':dims,'bounds_m':[mins,maxs],'min_z':mins[2],'pivot':list(asset.location),'rotation':list(asset.rotation_euler),'scale':list(asset.scale),'triangles':tri,'material_count':len(asset.data.materials),'material':{'name':'DuneGrass','rgba':list(mat.diffuse_color),'roughness':.88,'opaque':True},'UV0':{'finite':all(math.isfinite(x) for d in uv.data for x in d.uv),'min_triangle_area':min(areas)},'normals':'flat; closed wedge normals recalculated outward','collision':'none','source_LODs':1,'fbx_roundtrip':rt,'approved_references':refs,'production_modified':False,'distance_readability':'not assessed; close-up source preview only'}
p.write_text(json.dumps(report,indent=2))
(out/'provenance.json').write_text(json.dumps({'issue':'D108 #134','asset':'SM_Scenery_DuneGrass_A','references':refs,'construction':'Seven closed low-poly triangular wedge blades; one opaque material; no base, rig or textures; reviewed concepts loaded read-only.','purpose':'initial review-only study; not production promotion'},indent=2))
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

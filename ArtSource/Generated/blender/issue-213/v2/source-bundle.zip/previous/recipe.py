import bpy, math, sys, json, bmesh
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import finish
from CityBuildingStudyIO import checked_fbx
# Isolated source study, not a production update.
verts=[]
N=10
for ring,(radius,z) in enumerate(((.43,0.0),(1.0,.043),(.67,.083))):
    for i in range(N):
        a=2*math.pi*i/N
        wobble=1+.045*math.sin(3*a+.4)+.025*math.cos(2*a-.7)
        x=.12*radius*wobble*math.cos(a)+(.003 if ring==2 else 0)
        y=.09*radius*(1+.035*math.sin(a+.7))*math.sin(a)
        zz=z if ring==0 else z+.002*math.sin(a+.3)
        verts.append((x,y,zz))
verts.append((.004,-.002,.100))
faces=[tuple(reversed(range(N)))]
for r in range(2):
    for i in range(N):
        j=(i+1)%N
        faces.append((r*N+i,r*N+j,(r+1)*N+j,(r+1)*N+i))
for i in range(N):faces.append((20+i,20+(i+1)%N,30))
# Exact intended envelope, ground-center origin, all authored in mesh coordinates.
for axis,target in ((0,.24),(1,.18)):
    lo=min(v[axis] for v in verts);hi=max(v[axis] for v in verts)
    verts=[tuple(((v[k]-(lo+hi)/2)*target/(hi-lo)) if k==axis else v[k] for k in range(3)) for v in verts]
mesh=bpy.data.meshes.new('LargerPebble_SourceMesh');mesh.from_pydata(verts,[],faces);mesh.update()
obj=bpy.data.objects.new('D108_LargerSmoothBeachPebble',mesh);bpy.context.collection.objects.link(obj)
bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
# Consistent closed-volume winding.
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
for p in mesh.polygons:p.use_smooth=True
mat=bpy.data.materials.new('Pebble');mat.diffuse_color=(.235,.215,.185,1);mat.use_nodes=True
p=mat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=mat.diffuse_color;p.inputs['Roughness'].default_value=.57
mesh.materials.append(mat)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15192,island_margin=.035);bpy.ops.object.mode_set(mode='OBJECT')
obj['review_status']='Review only; human approval pending'
obj['issue']='D108 larger smooth beach pebble'
finish([obj])
# Find the retained source after the preview helper's join.
assets=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.data.materials and any(m and m.name.split('.')[0]=='Pebble' for m in o.data.materials)]
assert len(assets)==1, [o.name for o in assets]
obj=assets[0];mesh=obj.data;mesh.calc_loop_triangles()
bm=bmesh.new();bm.from_mesh(mesh)
closed=all(e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);bm.free()
assert closed and volume>0
assert 40<=len(mesh.loop_triangles)<=72
assert len(mesh.materials)==1 and mesh.materials[0].name.split('.')[0]=='Pebble'
assert mesh.uv_layers.active is not None
assert all(abs(a-b)<.00001 for a,b in zip(obj.dimensions,(.24,.18,.10)))
assert obj.location.length<1e-6 and all(abs(s-1)<1e-6 for s in obj.scale)
assert min(v.co.z for v in mesh.vertices)>=-1e-6
with checked_fbx(obj,'/output/asset.fbx',['Pebble'],expected_triangles=58,expected_sections=1) as check:
    assert check.data.uv_layers.active is not None
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
# Retain helper's neutral three-quarter preview; add matched orthographic reviews.
def view(name,position,ortho):
    cam.location=position;cam.rotation_euler=(Vector((0,0,.045))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=ortho
    scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
orig=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.type,cam.data.ortho_scale)
view('top',(0,0,.6),.32)
view('side',(0,-.6,.045),.32)
view('scale_1m',(0,-1,.75),1.0)
cam.location=orig[0];cam.rotation_euler=orig[1];cam.data.type=orig[2];cam.data.ortho_scale=orig[3]
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
vp=Path('/output/validation.json')
validation=json.loads(vp.read_text()) if vp.exists() else {}
validation['pebble_contract']={'dimensions_m':list(obj.dimensions),'triangles':len(mesh.loop_triangles),'closed_manifold':closed,'positive_volume_m3':volume,'uv0':True,'semantic_slots':['Pebble'],'identity_transform':True,'ground_center_pivot':True,'contact_vertices':sum(abs(v.co.z)<1e-7 for v in mesh.vertices),'checked_fbx_readback':True,'human_visual_review':'pending','production_modified':False}
vp.write_text(json.dumps(validation,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 larger smooth beach pebble','source_commit':'322ad23f7d717783f6073245c579cc986721e9c7','study':'initial independent larger pebble','units':'meters','outputs':['asset.blend','asset.fbx','preview.png','top.png','side.png','scale_1m.png','validation.json'],'scale_view':'Orthographic frame width and height exactly 1 m; no extra mesh included','scope':'External source review only; no approval, promotion, integration or device claims','authoring':'Three asymmetric oval rings, rounded crown, stable small underside; one opaque Pebble slot'},indent=2))

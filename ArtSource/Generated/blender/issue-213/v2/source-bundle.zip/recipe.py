import bpy, sys, json, hashlib, bmesh
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous, finish
from CityBuildingStudyIO import snapshot, checked_fbx
objects=load_previous()
assert len(objects)==1
obj=objects[0]
before=snapshot(obj)
original_transform=[list(row) for row in obj.matrix_world]
mat=obj.data.materials[0]
assert len(obj.data.materials)==1 and mat.name.split('.')[0]=='Pebble'
mat.use_nodes=True
p=mat.node_tree.nodes.get('Principled BSDF')
p.inputs['Base Color'].default_value=(.19,.165,.135,1)
p.inputs['Roughness'].default_value=.53
p.inputs['Metallic'].default_value=0
mat.diffuse_color=(.19,.165,.135,1)
finish(objects)
assets=[o for o in bpy.context.scene.objects if o.type=='MESH' and any(m and m.name.split('.')[0]=='Pebble' for m in o.data.materials)]
assert len(assets)==1
obj=assets[0]
assert snapshot(obj)==before, 'Presentation revision must preserve mesh/UV data'
assert [list(row) for row in obj.matrix_world]==original_transform
scene=bpy.context.scene
# Replace presentation lighting only; source mesh, smooth normals, UV and pivot remain untouched.
for o in list(scene.objects):
    if o.type=='LIGHT' or (o.type=='MESH' and o!=obj):
        bpy.data.objects.remove(o,do_unlink=True)
scene.render.engine='CYCLES'
scene.cycles.device='CPU'
scene.cycles.samples=12
scene.render.resolution_x=512
scene.render.resolution_y=512
scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.view_settings.exposure=-.65
scene.view_settings.gamma=1
world=bpy.data.worlds.new('Neutral review world')
world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.28,.26,.24,1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45
scene.world=world
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.0005))
ground=bpy.context.object
ground.name='Review ground - presentation only'
gm=bpy.data.materials.new('Review warm gray')
gm.use_nodes=True
gp=gm.node_tree.nodes.get('Principled BSDF')
gp.inputs['Base Color'].default_value=(.25,.225,.20,1)
gp.inputs['Roughness'].default_value=.85
ground.data.materials.append(gm)
def area(name,loc,power,size):
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
    light=bpy.data.objects.new(name,data);scene.collection.objects.link(light)
    light.location=loc;light.rotation_euler=(Vector((0,0,.04))-light.location).to_track_quat('-Z','Y').to_euler()
area('Soft key',(-.4,-.45,.65),14,.5)
area('Soft fill',(.45,.15,.4),6,.55)
cam=scene.camera
cam.data.type='ORTHO'
cam.data.clip_start=.001
cam.data.clip_end=300
cam.data.lens=50
cam.data.dof.use_dof=False
def view(name,position,width,target=(0,0,.045)):
    cam.location=position
    cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.ortho_scale=width
    scene.render.filepath='/output/'+name+'.png'
    bpy.ops.render.render(write_still=True)
view('preview',(.36,-.48,.34),.34)
hero=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale)
view('top',(0,0,.7),.32)
view('side',(0,-.7,.045),.32)
view('scale_1m',(.45,-.7,.55),1.0)
cam.location=hero[0];cam.rotation_euler=hero[1];cam.data.ortho_scale=hero[2]
scene.render.filepath='/output/preview.png'
mesh=obj.data;mesh.calc_loop_triangles()
bm=bmesh.new();bm.from_mesh(mesh)
closed=all(e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);bm.free()
assert closed and volume>0 and 40<=len(mesh.loop_triangles)<=72
with checked_fbx(obj,'/output/asset.fbx',['Pebble'],expected_triangles=58,expected_sections=1) as check:
    assert check.data.uv_layers.active is not None
assert snapshot(obj)==before
bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
vp=Path('/output/validation.json')
v=json.loads(vp.read_text()) if vp.exists() else {}
v['presentation_revision']={'geometry_uv_face_assignments_unchanged':True,'transform_unchanged':True,'dimensions_m':list(obj.dimensions),'triangles':len(mesh.loop_triangles),'closed_manifold':closed,'volume_m3':volume,'slots':['Pebble'],'checked_fbx_readback':True,'contact_vertices':sum(abs(v.co.z)<1e-7 for v in mesh.vertices),'exposure':-.65,'human_visual_review':'pending','production_modified':False}
vp.write_text(json.dumps(v,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 larger smooth beach pebble','revision':'v2 presentation only','source':'/previous/asset.blend','source_sha256':hashlib.sha256(Path('/previous/asset.blend').read_bytes()).hexdigest(),'preservation':'Original mesh, UV, smoothing, slot, pivot and dimensions retained. Existing Pebble material adjusted; lighting and ground are review-only.','outputs':['asset.blend','asset.fbx','preview.png','top.png','side.png','scale_1m.png','validation.json'],'scale_view':'Orthographic square is exactly 1 m wide and high; only one stone, no scale geometry exported','scope':'Human review pending; no production promotion, Unreal import or build'},indent=2))

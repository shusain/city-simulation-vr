import bpy,sys,json,math,hashlib,shutil,itertools
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous,box,finish
from CityBuildingStudyIO import checked_fbx
objects=load_previous()
# Retain the v2 massing and all unchanged loose mesh islands. Replace only defective trim.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
def bounds(o):
 p=[o.matrix_world@v.co for v in o.data.vertices];return ([min(v[i] for v in p) for i in range(3)],[max(v[i] for v in p) for i in range(3)])
def near(a,b):return abs(a-b)<.015
removed=[]
for o in list(objects):
 lo,hi=bounds(o);d=[hi[i]-lo[i] for i in range(3)];c=[(hi[i]+lo[i])/2 for i in range(3)]
 defect=(near(d[0],.10) and (near(c[1],-5.91) or near(c[1],-2.50))) or (near(d[0],1.38) and near(c[1],-5.95)) or (near(c[2],6.78))
 if defect:
  removed.append({'bounds':[lo,hi]});objects.remove(o);bpy.data.objects.remove(o,do_unlink=True)
mats={}
for o in objects:
 for m in o.data.materials:
  if m:mats[m.name.split('.')[0]]=m
names=['OpaqueFacade','TechGlass','LightMetal','RoofService','DoorAccent']
for n in names:
 if n not in mats:
  mats[n]=bpy.data.materials.new(n);mats[n].use_nodes=True
frames=[]
def B(n,d,c,m='LightMetal',frame=False):
 o=box(n,d,c,tuple(mats[m].diffuse_color));o.data.materials.clear();o.data.materials.append(mats[m]);objects.append(o)
 if frame:frames.append(o);o['trim_component']=n
 return o
# Continuous outer posts, rails restricted to true clear spans.
def frontframe(tag,xs,y,z0,z1,t=.1,depth=.16):
 for i,x in enumerate(xs):B(tag+'_post_'+str(i),(t,depth,z1-z0),(x,y,(z0+z1)/2),frame=True)
 for i,(a,b) in enumerate(zip(xs,xs[1:])):
  for z in [z0+t/2,z1-t/2]:B(tag+'_rail_'+str(i),(b-a-t,depth,t),((a+b)/2,y,z),frame=True)
frontframe('Lobby',[-6.18,-4.45,-2.75,-1.05,.55,2.25,3.98],-5.91,.375,3.625)
frontframe('Ribbon',[-5.8,-3.85,-1.92,0,1.92,3.85,5.8],-2.50,4.265,5.695)
frontframe('Door',[-.81,.41],-6.0,.20,2.48,t=.12,depth=.18)
# Glazed return has one shared corner post (the lobby end), no second coincident post.
B('ReturnPane',(.08,1.6,2.55),(3.98,-4.95,1.95),'TechGlass')
B('Return_post',(.10,.16,3.25),(3.98,-4.0,2.0),frame=True)
for z in [.425,3.575]:B('Return_rail',(.10,1.75,.1),(3.98,-4.955,z),frame=True)
# Coping has uninterrupted side runs; front/back terminate at their inner faces.
for x in [-6.7,6.7]:B('CopingSide',(.26,8.9,.10),(x,1.8,6.78),frame=True)
for y in [-2.52,6.12]:B('CopingEnd',(13.14,.26,.10),(0,y,6.78),frame=True)
# Service access with visible handles, hinges, deep louver cheeks, and panel joints.
for y in [-.8,2.3,5.0]:
 for yy in [y-1.22,y+1.22]:B('LouverCheek',(.26,.10,3.05),(6.73,yy,2.7),'RoofService')
for x in [-4.4,0,4.4]:
 B('RearAccessPanel',(1.45,.10,1.0),(x,6.26,4.8),'DoorAccent')
 B('AccessHandle',(.065,.12,.30),(x+.48,6.36,4.8))
 for z in [4.5,5.1]:B('Hinge',(.12,.10,.12),(x-.60,6.34,z))
for x in [-3.4,2.5]:
 for y in [-1.12,4.52]:
  B('CoolingServiceHandle',(.48,.1,.075),(x+.7,y,7.04))
 for y in [.25,3.15]:
  for dx in [-.75,-.5,-.25,.25,.5,.75]:
   length=2*math.sqrt(.98**2-dx**2)
   B('FanGuardSupplement',(.035,length,.035),(x+dx,y,7.78))
for x in [-5.2,-2.6,0,2.6,5.2]:
 B('FrontPanelJoint',(.025,.025,.55),(x,-2.415,3.85),'RoofService')
 B('RearPanelJoint',(.025,.025,5.4),(x,6.015,3.05),'RoofService')
# Actual staged PBR images, copied unchanged and packed. No generated faux maps.
manifest={};refs={}
for region,folder,stem in [('OpaqueFacade','BuildingSurfaces','CityBrick'),('RoofService','CivicSurfaces','CivicAsphalt')]:
 m=mats[region];m.use_nodes=True;nt=m.node_tree;p=nt.nodes.get('Principled BSDF');tex={};records=[]
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{stem}_{suffix}.png';src=Path('/repo')/rel;dst=Path('/output')/src.name;shutil.copyfile(src,dst)
  refs[rel]=hashlib.sha256(src.read_bytes()).hexdigest();im=bpy.data.images.load(str(dst),check_existing=True)
  im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack();node=nt.nodes.new('ShaderNodeTexImage');node.image=im;tex[suffix]=node
  records.append({'source':rel,'image':im.name,'sha256':refs[rel],'dimensions':list(im.size),'color_space':im.colorspace_settings.name,'reuse':'unchanged original; packed and copied'})
 nt.links.new(tex['BaseColor'].outputs['Color'],p.inputs['Base Color'])
 normal=nt.nodes.new('ShaderNodeNormalMap');nt.links.new(tex['Normal'].outputs['Color'],normal.inputs['Color']);nt.links.new(normal.outputs['Normal'],p.inputs['Normal'])
 sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(tex['ORM'].outputs['Color'],sep.inputs['Color']);nt.links.new(sep.outputs['Green'],p.inputs['Roughness']);nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
 manifest[region]={'maps':records,'uv':'UV0 planar metric: 1 repeat per 2m','channels':'BaseColor sRGB, tangent normal RGB; ORM R=AO (native multiply pending), G=roughness B=metallic','native_binding':'existing civic brick family' if region=='OpaqueFacade' else 'MI_CivicAsphaltRoof'}
for n in ['TechGlass','LightMetal','DoorAccent']:
 m=mats[n];m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Metallic'].default_value=.65 if n=='LightMetal' else 0;p.inputs['Roughness'].default_value=.32 if n=='TechGlass' else .45
 manifest[n]={'maps':[],'native_binding':'explicit reusable opaque PBR region; native binding pending','room_color':'optional independent pane color UV; tint/day-night separate' if n=='TechGlass' else None}
# Metric planar UVs on opaque textured faces; glass islands normalized independently.
for o in objects:
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
 for poly in o.data.polygons:
  normal=poly.normal;axis=max(range(3),key=lambda i:abs(normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in poly.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]/2,v[axes[1]]/2)
# Geometry-derived trim report, including all generated axis-aligned frame/return/coping pairs.
tol=1e-5;components=[{'name':o.name,'bounds':bounds(o)} for o in frames];bad=[];joints=[];pairs=0
for a,b in itertools.combinations(components,2):
 pairs+=1;al,ah=a['bounds'];bl,bh=b['bounds'];over=[min(ah[i],bh[i])-max(al[i],bl[i]) for i in range(3)]
 if all(v>tol for v in over):bad.append({'a':a['name'],'b':b['name'],'volume_m3':math.prod(over)})
 elif all(v>=-tol for v in over) and sum(v>tol for v in over)==2:joints.append({'a':a['name'],'b':b['name'],'overlap_axes_m':over})
# Detect identical face vertex sets; internal butt caps are explicitly distinguished from exposed duplicates.
faces={};duplicates=[]
for o in frames:
 for f in o.data.polygons:
  key=tuple(sorted(tuple(round(x,5) for x in (o.matrix_world@o.data.vertices[i].co)) for i in f.vertices))
  if key in faces:duplicates.append([faces[key],o.name])
  else:faces[key]=o.name
trim={'tested_pairs':pairs,'tested_butt_joints':len(joints),'joints':joints,'components':components,'offending_pairs':bad,'tolerance_m':tol,'identical_trim_face_pairs':duplicates,'scope':'axis-aligned generated trim only; no angled frame bars. Identical butt caps internal, not exposed; no claim of global solid boolean validation.'}
Path('/output/frame_validation.json').write_text(json.dumps(trim,indent=2))
Path('/output/material-texture-manifest.json').write_text(json.dumps(manifest,indent=2))
finish(objects)
asset=max([o for o in bpy.context.scene.objects if o.type=='MESH'],key=lambda o:len(o.data.vertices));asset.name='ComputingCenter_v3_ReviewOnly'
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset;bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
asset['catalog_id']='ComputingCenter';asset['entrance_side']='-Y';asset['presentation_yaw_offset_quarter_turns']=2
asset.data.calc_loop_triangles();lo,hi=bounds(asset)
with checked_fbx(asset,Path('/output/asset.fbx')) as readback:
 rt={'triangles':len(readback.data.loop_triangles),'materials':[m.name for m in readback.data.materials],'uv_layers':[u.name for u in readback.data.uv_layers],'dimensions':list(readback.dimensions),'pass':True}
for rel in ['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Manifests/city_low_density_buildings.json']:
 refs[rel]=hashlib.sha256((Path('/repo')/rel).read_bytes()).hexdigest()
p=Path('/output/validation.json');r=json.loads(p.read_text()) if p.exists() else {};r.update({'issue':'D90.A4','version':3,'review_only':True,'bounds':[lo,hi],'triangles':len(asset.data.loop_triangles),'triangle_target_met':len(asset.data.loop_triangles)<=5000,'lot_contract_met':all(lo[i]>=-8.0001 and hi[i]<=8.0001 for i in [0,1]) and hi[2]<=9,'pivot':list(asset.location),'scale':list(asset.scale),'rotation':list(asset.rotation_euler),'regions':[m.name for m in asset.data.materials],'entrance':{'side':'-Y','door_m':[1.1,2.1],'yaw_quarter_turns':2,'native_reconciliation':'pending'},'trim_evidence':trim,'fbx_roundtrip':rt,'source_hashes':refs,'previous_sha256':hashlib.sha256(Path('/previous/asset.blend').read_bytes()).hexdigest(),'replaced_trim_islands':removed,'approval':'pending user review; no runtime or artistic pass claimed'})
p.write_text(json.dumps(r,indent=2));Path('/output/provenance.json').write_text(json.dumps({'method':'Edited v2 loose islands; massing retained. Trim replacement and requested detail additions only. Read-only original sources preserved.','references':refs},indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100;cam=scene.camera;cam.data.type='ORTHO'
def render(name,pos,target,scale):
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale;scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
render('preview',(21,-27,23),(0,0,3.2),23)
render('front',(0,-30,7),(0,0,3.7),18)
render('window-corner',(-4,-12,6),(-4.45,-5.91,3.35),2.3)
render('door-corner',(2,-12,4),(.41,-6,2.36),2.1)
render('facade-return',(10,-13,7),(3.98,-5.65,3.4),3.4)
cam.location=(21,-27,23);cam.rotation_euler=(Vector((0,0,3.2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=23;scene.render.filepath='/output/preview.png';bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
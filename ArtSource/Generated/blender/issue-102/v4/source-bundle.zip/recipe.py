import bpy,sys,json,math,itertools,hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous,finish
from CityBuildingStudyIO import checked_fbx
objects=load_previous()
out=Path('/output')
def bounds(o):
 p=[o.matrix_world@v.co for v in o.data.vertices]
 return [[min(v[i] for v in p) for i in range(3)],[max(v[i] for v in p) for i in range(3)]]
# Recover the original loose islands without changing coordinates, materials or UVs.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
expected=[]
def expect(n,d,c):expected.append((n,[[c[i]-d[i]/2 for i in range(3)],[c[i]+d[i]/2 for i in range(3)]]))
def frame(tag,xs,y,z0,z1,t=.1,depth=.16):
 for i,x in enumerate(xs):expect(tag+'_post_'+str(i),(t,depth,z1-z0),(x,y,(z0+z1)/2))
 for i,(a,b) in enumerate(zip(xs,xs[1:])):
  for j,z in enumerate([z0+t/2,z1-t/2]):expect(tag+'_rail_'+str(i)+'_'+('lower' if j==0 else 'upper'),(b-a-t,depth,t),((a+b)/2,y,z))
frame('Lobby',[-6.18,-4.45,-2.75,-1.05,.55,2.25,3.98],-5.91,.375,3.625)
frame('Ribbon',[-5.8,-3.85,-1.92,0,1.92,3.85,5.8],-2.50,4.265,5.695)
frame('Door',[-.81,.41],-6,.20,2.48,.12,.18)
expect('Return_post',(.10,.16,3.25),(3.98,-4,2))
for j,z in enumerate([.425,3.575]):expect('Return_rail_'+str(j),(.10,1.75,.1),(3.98,-4.955,z))
for j,x in enumerate([-6.7,6.7]):expect('CopingSide_'+str(j),(.26,8.9,.10),(x,1.8,6.78))
for j,y in enumerate([-2.52,6.12]):expect('CopingEnd_'+str(j),(13.14,.26,.1),(0,y,6.78))
frames=[];matches={}
for name,bb in expected:
 candidates=[o for o in objects if max(abs(bounds(o)[j][i]-bb[j][i]) for j in range(2) for i in range(3))<2e-5]
 assert len(candidates)==1,(name,len(candidates))
 o=candidates[0];o.name=name;o['trim_component']=name;frames.append(o);matches[name]=o
rail=matches['Lobby_rail_3_lower'];old_bounds=bounds(rail)
# Only this rail is clipped: the two full-height door stiles stay untouched.
cut_left=bounds(matches['Door_post_0'])[0][0];cut_right=bounds(matches['Door_post_1'])[1][0]
replacements=[]
for label,xmin,xmax in [('left',old_bounds[0][0],cut_left),('right',cut_right,old_bounds[1][0])]:
 assert xmax>xmin
 o=rail.copy();o.data=rail.data.copy();bpy.context.collection.objects.link(o);o.name='Lobby_rail_3_lower_'+label;o['trim_component']=o.name
 inv=o.matrix_world.inverted()
 original={v.index:o.matrix_world@v.co for v in o.data.vertices}
 for v in o.data.vertices:
  p=original[v.index].copy();p.x=xmin if abs(p.x-old_bounds[0][0])<abs(p.x-old_bounds[1][0]) else xmax;v.co=inv@p
 # Preserve existing metric planar projection on the edited faces, including end caps.
 for uv in o.data.uv_layers:
  for poly in o.data.polygons:
   axis=max(range(3),key=lambda i:abs(poly.normal[i]));axes=[i for i in range(3) if i!=axis]
   for li in poly.loop_indices:
    vi=o.data.loops[li].vertex_index;before=original[vi];after=o.matrix_world@o.data.vertices[vi].co
    uv.data[li].uv.x+=(after[axes[0]]-before[axes[0]])/2
    uv.data[li].uv.y+=(after[axes[1]]-before[axes[1]])/2
 o.data.update();objects.append(o);frames.append(o);replacements.append({'name':o.name,'bounds':bounds(o)})
objects.remove(rail);frames.remove(rail);bpy.data.objects.remove(rail,do_unlink=True)
tol=1e-5;components=[{'name':o.name,'bounds':bounds(o)} for o in frames];bad=[];joints=[];pairs=0
for a,b in itertools.combinations(components,2):
 pairs+=1;al,ah=a['bounds'];bl,bh=b['bounds'];over=[min(ah[i],bh[i])-max(al[i],bl[i]) for i in range(3)]
 if all(v>tol for v in over):bad.append({'a':a['name'],'b':b['name'],'volume_m3':math.prod(over)})
 elif all(v>=-tol for v in over) and sum(v>tol for v in over)==2:joints.append({'a':a['name'],'b':b['name'],'overlap_axes_m':over})
faces={};duplicates=[];exposed=[]
for o in frames:
 for f in o.data.polygons:
  key=tuple(sorted(tuple(round(x,5) for x in (o.matrix_world@o.data.vertices[i].co)) for i in f.vertices))
  normal=(o.matrix_world.to_3x3()@f.normal).normalized()
  for other,n in faces.get(key,[]):
   rec={'a':other,'b':o.name,'normal_dot':normal.dot(n)};duplicates.append(rec)
   if normal.dot(n)>-.999:exposed.append(rec)
  faces.setdefault(key,[]).append((o.name,normal))
trim={'tested_pairs':pairs,'tested_butt_joints':len(joints),'joints':joints,'components':components,'offending_pairs':bad,'tolerance_m':tol,'identical_trim_face_pairs':duplicates,'exposed_duplicate_trim_faces':exposed,'scope':'Same generated axis-aligned trim set as v3; exact world-space vertex bounds for solid boxes. No angled bars. Opposed identical caps are internal butt caps, retained; no global boolean claim.','correction':{'original_rail_bounds':old_bounds,'removed_x_interval':[cut_left,cut_right],'pieces':replacements}}
(out/'frame_validation.json').write_text(json.dumps(trim,indent=2))
assert pairs>0 and len(joints)>0
assert not bad,('Remaining positive-volume trim crossings',bad)
assert not exposed,('Duplicate exposed trim faces',exposed)
# Retain all packed texture bytes, not a renamed or newly generated substitute.
textures=[]
for im in bpy.data.images:
 if im.packed_file:
  filename=Path(im.filepath).name or im.name
  dest=out/filename;dest.write_bytes(bytes(im.packed_file.data));im.filepath=str(dest)
  textures.append({'image':im.name,'file':filename,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'dimensions':list(im.size),'color_space':im.colorspace_settings.name,'provenance':'unchanged packed v3 image bytes','newly_baked':False})
materials={m.name:m for o in objects for m in o.data.materials if m}
manifest={}
for name,m in materials.items():
 maps=[{'node':n.name,'image':n.image.name,'file':Path(n.image.filepath).name} for n in m.node_tree.nodes if n.type=='TEX_IMAGE' and n.image] if m.use_nodes else []
 manifest[name]={'source_material':m.name,'preserved_nodes':True,'maps':maps,'uv_density':'Preserved v3 UV0, 1 repeat per 2m; clipped rail UV interpolated metrically','native_binding':'existing civic brick family' if name.startswith('OpaqueFacade') else 'MI_CivicAsphaltRoof' if name.startswith('RoofService') else 'explicit reusable opaque PBR; native binding pending','native_channels':'Existing BaseColor, tangent Normal, ORM G roughness/B metallic; AO native multiply pending' if maps else 'Preserved explicit PBR values; no generated maps'}
(out/'material-texture-manifest.json').write_text(json.dumps({'regions':manifest,'textures':textures},indent=2))
finish(objects)
asset=max([o for o in bpy.context.scene.objects if o.type=='MESH'],key=lambda o:len(o.data.vertices));asset.name='ComputingCenter_v4_ReviewOnly'
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset;bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
asset['catalog_id']='ComputingCenter';asset['entrance_side']='-Y';asset['presentation_yaw_offset_quarter_turns']=2;asset['frame_validation']=json.dumps(trim)
asset.data.calc_loop_triangles();lo,hi=bounds(asset)
with checked_fbx(asset,out/'asset.fbx') as rb:
 rt={'pass':True,'triangles':len(rb.data.loop_triangles),'materials':[m.name for m in rb.data.materials],'uv_layers':[u.name for u in rb.data.uv_layers],'dimensions':list(rb.dimensions)}
refs={}
for rel in ['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Manifests/city_low_density_buildings.json']:
 refs[rel]=hashlib.sha256((Path('/repo')/rel).read_bytes()).hexdigest()
r=json.loads((out/'validation.json').read_text());r.update({'issue':'D90.A4','version':4,'review_only':True,'bounds':[lo,hi],'dimensions_m':list(asset.dimensions),'triangles':len(asset.data.loop_triangles),'triangle_target_met':len(asset.data.loop_triangles)<=5000,'lot_contract_met':all(lo[i]>=-8.0001 and hi[i]<=8.0001 for i in [0,1]) and hi[2]<=9,'pivot':list(asset.location),'rotation':list(asset.rotation_euler),'scale':list(asset.scale),'regions':[m.name for m in asset.data.materials],'uv_layers':[u.name for u in asset.data.uv_layers],'entrance':{'side':'-Y','door_m':[1.1,2.1],'yaw_quarter_turns':2,'native_reconciliation':'pending'},'trim_evidence':trim,'fbx_roundtrip':rt,'source_hashes':refs,'previous_sha256':hashlib.sha256(Path('/previous/asset.blend').read_bytes()).hexdigest(),'approval':'pending user review; no native/runtime assessment'})
(out/'validation.json').write_text(json.dumps(r,indent=2))
(out/'provenance.json').write_text(json.dumps({'method':'Loaded v3; split only Lobby lower rail at outer door-post faces. All other loose mesh islands, UVs, materials and packed image bytes retained. Original sources read-only.','references':refs,'textures':textures,'prior_sha256':r['previous_sha256']},indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100;cam=scene.camera;cam.data.type='ORTHO'
def render(name,pos,target,scale):
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale;scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
render('preview',(21,-27,23),(0,0,3.2),23)
render('front',(0,-30,7),(0,0,3.7),18)
render('window-corner',(-4,-12,6),(-4.45,-5.91,3.35),2.3)
render('door-corner',(2,-12,4),(.41,-6,2.36),2.1)
render('facade-return',(10,-13,7),(3.98,-5.65,3.4),3.4)
render('door-lower-rail',(1,-12,2),(-.20,-5.96,.6),2.4)
cam.location=(21,-27,23);cam.rotation_euler=(Vector((0,0,3.2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=23;scene.render.filepath=str(out/'preview.png');bpy.ops.wm.save_as_mainfile(filepath=str(out/'asset.blend'))
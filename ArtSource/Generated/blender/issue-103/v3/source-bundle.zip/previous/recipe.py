import bpy, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
from CityBuildingStudyIO import checked_fbx
# Original review-only ResearchCampus; no source objects are altered or promoted.
colors={'OpaqueFacade':(.57,.62,.60,1),'TechGlass':(.035,.29,.32,1),'LightMetal':(.72,.80,.81,1),'RoofService':(.095,.135,.15,1),'DoorAccent':(.17,.30,.32,1)}
objects=[]
def B(n,d,p,m):
    o=box(n,d,p,colors[m]);o['semantic_region']=m;objects.append(o);return o
B('Lot paving',(23.6,23.6,.12),(0,0,.06),'OpaqueFacade')
# Asymmetric paired laboratories frame an open public courtyard, not a glazed-roof institute.
for x,h in [(-7.2,5.5),(7.2,6.3)]:
    B('Lab wing',(6.4,16,h),(x,1,.12+h/2),'OpaqueFacade')
    B('Dark flat roof',(6.5,16.1,.20),(x,1,h+.22),'RoofService')
    for z in [1.95,4.25]:
        for y in [-5,-2,1,4,7]:
            for side in [-1,1]:
                xx=x+side*3.22
                B('Tinted laboratory bay',(.10,2.45,1.45),(xx,y,z),'TechGlass')
                B('Pale sill',(.18,2.6,.10),(xx,y,z-.78),'LightMetal')
        B('Front glazing',(5.5,.10,1.45),(x,-7.04,z),'TechGlass')
        for dx in [-2.8,0,2.8]:
            B('Front mullion',(.12,.16,1.6),(x+dx,-7.11,z),'LightMetal')
    for z in [.5,3.18,h+.25]:
        B('Wing edge trim',(6.65,16.25,.12),(x,1,z),'LightMetal')
    # Small opaque-capped clerestory, deliberately not a dominant glass roof.
    B('Clerestory curb',(3.1,8.3,.35),(x,2,h+.48),'RoofService')
    B('Clerestory tinted band',(2.8,8,.65),(x,2,h+.96),'TechGlass')
    B('Clerestory pale lid',(3.25,8.45,.16),(x,2,h+1.36),'LightMetal')
    for y in [-1,2,5]:
        B('Roof band frame',(2.9,.12,.72),(x,y,h+.96),'LightMetal')
# Low rear connection leaves courtyard open toward -Y.
B('Public connection',(8,4.2,3.3),(0,6.9,1.77),'OpaqueFacade')
B('Connection roof',(8.25,4.45,.20),(0,6.9,3.52),'RoofService')
B('Lobby glass',(7.7,.12,2.3),(0,4.75,1.7),'TechGlass')
B('Entrance door 1.1 x 2.1',(1.1,.16,2.1),(0,4.64,1.17),'DoorAccent')
for x in [-.62,.62]:B('Door jamb',(.12,.22,2.26),(x,4.57,1.25),'LightMetal')
B('Door head',(1.36,.22,.12),(0,4.57,2.39),'LightMetal')
B('Door pull',(.035,.07,.48),(.39,4.51,1.25),'LightMetal')
B('Public canopy',(5.4,2.3,.18),(0,3.9,2.85),'LightMetal')
for x in [-2.45,2.45]:B('Canopy pier',(.12,.12,2.7),(x,3,1.47),'LightMetal')
B('Entrance walk',(2.6,16.3,.06),(0,-3.45,.15),'LightMetal')
for x in [-2.75,2.75]:
    for y in [-5.5,-.6]:
        B('Courtyard seat',(1.3,2,.35),(x,y,.31),'RoofService')
        B('Seat cap',(1.4,2.1,.10),(x,y,.535),'LightMetal')
# Consolidate true semantic materials before helper joining/export.
mats={}
for name,c in colors.items():
    m=bpy.data.materials.new(name);m.diffuse_color=c;m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=c
    p.inputs['Roughness'].default_value=.32 if name=='TechGlass' else (.36 if name=='LightMetal' else .72)
    p.inputs['Metallic'].default_value=.55 if name=='LightMetal' else 0
    mats[name]=m
for o in objects:
    o.data.materials.clear();o.data.materials.append(mats[o['semantic_region']])
    if not o.data.uv_layers:o.data.uv_layers.new(name='UVMap')
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=1
finish(objects)
# Use resulting single static mesh; enforce ground-center identity transforms.
asset=max((o for o in bpy.context.scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices))
asset.name='ResearchCampus_ReviewOnly'
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
asset['catalog_id']='ResearchCampus';asset['entrance_local']='-Y';asset['presentation_yaw_offset_quarter_turns']=2
asset['review_only']=True
if not asset.data.uv_layers:asset.data.uv_layers.new(name='UVMap')
asset.data.calc_loop_triangles()
coords=[asset.matrix_world@v.co for v in asset.data.vertices]
lo=[min(v[i] for v in coords) for i in range(3)];hi=[max(v[i] for v in coords) for i in range(3)]
assert all(lo[i]>=-12.001 and hi[i]<=12.001 for i in [0,1]) and hi[2]<=9
assert len(asset.data.materials)<=5
with checked_fbx(asset,'/output/asset.fbx') as check:
    rt={'passed':True,'triangles':len(check.data.loop_triangles),'dimensions_m':list(check.dimensions),'UV0':bool(check.data.uv_layers)}
refs={}
for rel in ['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json','Tools/CityBuildingStudyIO.py']:
    refs[rel]=hashlib.sha256(Path('/repo',rel).read_bytes()).hexdigest()
vpath=Path('/output/validation.json')
try:validation=json.loads(vpath.read_text())
except Exception:validation={}
validation.update({'catalog_id':'ResearchCampus','review_only':True,'bounds_min_m':lo,'bounds_max_m':hi,'dimensions_m':list(asset.dimensions),'pivot_m':list(asset.location),'scale':list(asset.scale),'rotation_rad':list(asset.rotation_euler),'triangles':len(asset.data.loop_triangles),'triangle_target':5000,'material_regions':[m.name for m in asset.data.materials],'UV0':bool(asset.data.uv_layers),'fbx_roundtrip':rt,'door_width_height_m':[1.1,2.1],'entrance_local':'-Y','presentation_yaw_offset_quarter_turns':2,'import_mapping_status':'Reconcile established quarter-turn mapping at later integration; mesh not rotated','reference_sha256':refs,'native_integration':False,'shader_handoff':'Opaque constant colors only; map five semantic regions to existing native materials during separate integration. No procedural graph export claim.'})
vpath.write_text(json.dumps(validation,indent=2))
Path('/output/provenance.json').write_text(json.dumps({'issue':'D90.A5','source_sha':'88e57d79778d6a33f1bd25c5616a7a4d9a31f309','design':'Original two-wing courtyard research campus from corrected written brief. No approved source mesh modified.','references':refs,'approval':'Pending user source review'},indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
cam.location=(30,-38,29);cam.rotation_euler=(Vector((0,0,2.5))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=36
scene.render.filepath='/output/preview.png';bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend');bpy.ops.render.render(write_still=True)
cam.location=(0,-44,7);cam.rotation_euler=(Vector((0,0,3.4))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=28
scene.render.filepath='/output/front.png';bpy.ops.render.render(write_still=True)

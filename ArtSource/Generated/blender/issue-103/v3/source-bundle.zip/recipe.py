import bpy,sys,json,hashlib,itertools,shutil,bmesh
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box,finish,load_previous
from CityBuildingStudyIO import checked_fbx
objects=load_previous()
# Separate the existing joined v2 into its original disconnected primitive shells.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
parts=[o for o in bpy.context.scene.objects if o.type=='MESH']
colors={'OpaqueFacade':(.57,.62,.60,1),'TechGlass':(.035,.29,.32,1),'LightMetal':(.72,.80,.81,1),'RoofService':(.095,.135,.15,1),'DoorAccent':(.17,.30,.32,1)}
mats={}
for n,c in colors.items():
 m=bpy.data.materials.new(n+'_v3');m.use_nodes=True;m.diffuse_color=c
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=c;p.inputs['Roughness'].default_value=.32 if n=='TechGlass' else .65;p.inputs['Metallic'].default_value=.65 if n=='LightMetal' else 0;mats[n]=m
# Reference college facade selection is recorded, while original shipped PBR maps provide the portable shading.
with bpy.data.libraries.load('/repo/ArtSource/Blender/CityCivicSurfaces.blend',link=False) as (a,b):
 choices=[n for n in a.materials if 'Brick' in n and ('College' in n or 'School' in n)]
 selected=next((n for n in choices if 'College' in n),choices[0] if choices else next(n for n in a.materials if 'Brick' in n));b.materials=[selected]
source_mat=b.materials[0]
manifest={};refs={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for rel in ['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Manifests/city_low_density_buildings.json','Tools/CityBuildingStudyIO.py']:
 refs[rel]=sha('/repo/'+rel)
for region,folder,stem in [('OpaqueFacade','BuildingSurfaces','CityBrick'),('RoofService','CivicSurfaces','CivicAsphalt')]:
 m=mats[region];nt=m.node_tree;p=nt.nodes.get('Principled BSDF');images=[]
 for suffix in ['BaseColor','Normal','ORM']:
  rel='ArtSource/Textures/'+folder+'/'+stem+'_'+suffix+'.png';src='/repo/'+rel;dst='/output/'+stem+'_'+suffix+'.png';shutil.copyfile(src,dst)
  im=bpy.data.images.load(dst,check_existing=True);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack();tex=nt.nodes.new('ShaderNodeTexImage');tex.image=im
  if suffix=='BaseColor':nt.links.new(tex.outputs['Color'],p.inputs['Base Color'])
  elif suffix=='Normal':
   normal=nt.nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.35;nt.links.new(tex.outputs['Color'],normal.inputs['Color']);nt.links.new(normal.outputs['Normal'],p.inputs['Normal'])
  else:
   sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(tex.outputs['Color'],sep.inputs['Color']);nt.links.new(sep.outputs['Green'],p.inputs['Roughness']);nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
  images.append({'source':rel,'sha256':sha(src),'image':im.name,'size':list(im.size),'color_space':im.colorspace_settings.name,'channels':suffix,'reuse':'original unchanged; no new bake'})
 manifest[region]={'images':images,'uv_density':'1 UV repeat per 2 metres, dominant-axis metric projection','native_binding':'existing civic brick facade' if region=='OpaqueFacade' else 'MI_CivicAsphaltRoof','ORM':'R=AO (native hookup pending), G=roughness, B=metallic','source_material_reference':selected if region=='OpaqueFacade' else 'CivicAsphaltRoof','handoff':'image maps supplied; native hookup/appearance pending'}
for n in ['LightMetal','TechGlass','DoorAccent']:manifest[n]={'images':[],'native_binding':'reusable '+n+' PBR semantic; exact native instance pending','roughness':.32 if n=='TechGlass' else .65,'metallic':.65 if n=='LightMetal' else 0,'room_color':'TechGlass pane-local UV can be reassigned independently; no unapproved room pixels' if n=='TechGlass' else None}
objects=[];removed=[]
for o in parts:
 slot=o.data.materials[o.data.polygons[0].material_index].name.split('.')[0];region=next((n for n in colors if slot.startswith(n)),None)
 if not region:continue
 d=list(o.dimensions);c=o.matrix_world@sum((v.co for v in o.data.vertices),Vector())/len(o.data.vertices)
 # All obsolete window/door/roof crossing trim is replaced; canopy, piers, path and seats remain.
 remove=region=='LightMetal' and ((abs(d[0]-.18)<.02 and abs(d[1]-2.6)<.02) or (abs(d[0]-.12)<.02 and abs(d[2]-1.6)<.02) or d[1]>16.2 or (abs(d[0]-2.9)<.02 and abs(d[1]-.12)<.02) or (abs(c.x)<.8 and c.y>4.4))
 if remove:removed.append({'dimensions':d,'center':list(c)});bpy.data.objects.remove(o,do_unlink=True);continue
 o.data.materials.clear();o.data.materials.append(mats[region]);objects.append(o)
frames=[];rails=[]
def B(n,d,c,r='LightMetal',tag=None):
 o=box(n,d,c,colors[r]);o.data.materials.clear();o.data.materials.append(mats[r]);objects.append(o)
 if tag:o['frame_role']=tag;frames.append(o)
 return o
def frame(n,axis,center,w,h,t=.10,depth=.18):
 # axis is the horizontal clear-span direction. Vertical stiles run full height.
 a=axis;other=1-a;c=list(center)
 def make(s,along,z,role):
  d=[depth,depth,h if role=='post' else t];d[a]=t if role=='post' else s;d[other]=depth
  pos=list(c);pos[a]+=along;pos[2]+=z
  ob=B(n+'_'+role,d,pos,tag=role)
  if role=='rail':rails.append((ob,a))
 for sign in [-1,1]:make(t,sign*(w-t)/2,0,'post')
 for sign in [-1,1]:make(w-2*t,0,sign*(h-t)/2,'rail')
for x,h in [(-7.2,5.5),(7.2,6.3)]:
 for z in [1.95,4.25]:
  for y in [-5,-2,1,4,7]:
   for side in [-1,1]:frame('SideBay',1,(x+side*3.28,y,z),2.65,1.65)
  # Split front bay with continuous center post, rails ending at inner post faces.
  for cx in [x-1.4,x+1.4]:frame('FrontBay',0,(cx,-7.13,z),2.8,1.65)
 # Clerestory single shared corner posts. All four returns terminate inside posts.
 z=h+.96;lo=x-1.46;hi=x+1.46;ylo=-2.06;yhi=6.06;t=.12
 for xx in [lo,hi]:
  for yy in [ylo,yhi]:B('Clerestory_shared_corner',(t,t,.77),(xx,yy,z),tag='post')
 for zz in [z-.325,z+.325]:
  for yy in [ylo,yhi]:rails.append((B('Clerestory_front_return',(hi-lo-t,t,t),(x,yy,zz),tag='rail'),0))
  for xx in [lo,hi]:rails.append((B('Clerestory_side_return',(t,yhi-ylo-t,t),(xx,2,zz),tag='rail'),1))
 for xx in [lo,hi]:
  for yy in [-.7,2,4.7]:B('Clerestory_depth_mullion',(.12,.10,.53),(xx,yy,z),tag='post')
 # Roof service covers and drainage scuppers.
 for yy in [-4,7]:
  B('Service access cover',(1.3,1.1,.12),(x,yy,h+.38),'RoofService')
  B('Scupper',(.28,.35,.12),(x+3.1,yy,h+.29),'RoofService')
 for yy in [-3.5,2.5,5.5]:
  B('Panel reveal',(.018,.035,1.05),(x+3.207,yy,3.05),'RoofService')
frame('Door',0,(0,4.57,1.23),1.34,2.22,.12,.22)
B('Door threshold',(1.34,.4,.06),(0,4.53,.15))
for xx in [.39]:
 for zz in [1.04,1.46]:B('Pull fixing',(.065,.10,.045),(xx,4.48,zz))
for y in [-10,-7,-4,-1,2]:B('Courtyard paving joint',(2.6,.022,.009),(0,y,.185),'RoofService')
# Measure actual world vertex bounds before joining, not nominal box parameters.
bpy.context.view_layer.update()
def bounds(o):
 vs=[o.matrix_world@v.co for v in o.data.vertices];return ([min(v[i] for v in vs) for i in range(3)],[max(v[i] for v in vs) for i in range(3)])
spec=[{'name':o.name,'role':o['frame_role'],'min':bounds(o)[0],'max':bounds(o)[1]} for o in frames]
tol=2e-5;bad=[];joints=[];tested=0
for a,b in itertools.combinations(spec,2):
 tested+=1;span=[min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i]) for i in range(3)]
 if min(span)>tol:bad.append({'a':a['name'],'b':b['name'],'overlap_volume_m3':span[0]*span[1]*span[2]})
 if sum(s>tol for s in span)==2 and all(s>=-tol for s in span):joints.append({'a':a['name'],'b':b['name'],'intersection_spans_m':span})
# Remove rail end caps at butt joints; continuous stile surfaces remain. No angled members exist.
for ob,axis in rails:
 bm=bmesh.new();bm.from_mesh(ob.data);bm.normal_update();faces=[f for f in bm.faces if abs(f.normal[axis])>.99];bmesh.ops.delete(bm,geom=faces,context='FACES');bm.to_mesh(ob.data);bm.free()
faceset={};duplicates=[]
for ob in frames:
 for p in ob.data.polygons:
  key=tuple(sorted(tuple(round(q,5) for q in ob.matrix_world@ob.data.vertices[i].co) for i in p.vertices))
  if key in faceset:duplicates.append([faceset[key],ob.name])
  else:faceset[key]=ob.name
Path('/output/frame_components.json').write_text(json.dumps({'components':spec,'joints':joints,'removed_v2_components':removed},indent=2))
# Metric planar UV0 on opaque surfaces, pane-local coordinates retained for optional room images.
for ob in objects:
 uv=ob.data.uv_layers.active or ob.data.uv_layers.new(name='UVMap')
 reg=next(n for n,m in mats.items() if m==ob.data.materials[0]);lo,hi=bounds(ob)
 for p in ob.data.polygons:
  axes=[i for i in range(3) if i!=max(range(3),key=lambda i:abs(p.normal[i]))]
  for li in p.loop_indices:
   v=ob.matrix_world@ob.data.vertices[ob.data.loops[li].vertex_index].co
   uv.data[li].uv=tuple((v[i]-lo[i])/max(hi[i]-lo[i],.001) if reg=='TechGlass' else v[i]/2 for i in axes)
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=1
finish(objects)
asset=max((o for o in bpy.context.scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices));asset.name='ResearchCampus_v3_ReviewOnly'
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
asset['catalog_id']='ResearchCampus';asset['entrance_local']='-Y';asset['presentation_yaw_offset_quarter_turns']=2;asset['review_only']=True
asset.data.calc_loop_triangles();lo,hi=bounds(asset)
with checked_fbx(asset,'/output/asset.fbx') as check:rt={'passed':True,'triangles':len(check.data.loop_triangles),'UV0':bool(check.data.uv_layers),'material_names':[m.name for m in check.data.materials]}
p=Path('/output/validation.json');v=json.loads(p.read_text()) if p.exists() else {}
v.update({'bounds_min_m':lo,'bounds_max_m':hi,'dimensions_m':list(asset.dimensions),'pivot':list(asset.location),'rotation':list(asset.rotation_euler),'scale':list(asset.scale),'triangles':len(asset.data.loop_triangles),'triangle_target':5000,'triangle_target_met':len(asset.data.loop_triangles)<=5000,'regions':[m.name for m in asset.data.materials],'fbx_roundtrip':rt,'entrance':'-Y','yaw_quarter_turns':2,'door_clear_m':[1.1,2.1],'frame_checks':{'tolerance_m':tol,'tested_pairs':tested,'tested_joints':len(joints),'offending_pairs':bad,'duplicate_trim_faces':duplicates,'scope':'All generated axis-aligned frame components, windows, door, clerestory returns; no angled roof bars. Rail end caps removed. Shared adjacent front posts reported honestly if any.'},'reference_hashes':refs,'previous_blend_sha256':sha('/previous/asset.blend'),'review_only':True,'native_checks':'Pending separate approved-version integration; no runtime/visual acceptance claimed'})
p.write_text(json.dumps(v,indent=2));Path('/output/material_texture_manifest.json').write_text(json.dumps(manifest,indent=2));Path('/output/provenance.json').write_text(json.dumps({'revision':'v3','base':'read-only v2 loaded and separated; existing body, courtyard and roof silhouettes retained','source_material':selected,'references':refs,'approval':'pending'},indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
def render(name,loc,target,scale):
 cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
render('preview',(30,-38,29),(0,0,2.5),36)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
render('front',(0,-44,8),(0,0,3.3),28)
render('window_corner',(-3,-14,6),(-5.8,-7.13,4.9),3.6)
render('door_corner',(2,-1,3.5),(.45,4.57,2.17),2.5)
render('roof_return',(13,-7,12),(8.66,-2.06,7.26),3.8)

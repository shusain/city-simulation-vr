import bpy, sys, math, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
# A single continuous, solid, washed ribbon: broad body and a loose curled end.
# The approved reference PNG is identified by issue provenance, but is not staged.
pts=[(-.34,-.085,.016,.030),(-.29,-.065,.024,.085),(-.235,-.018,.055,.125),(-.175,.020,.075,.135),(-.105,.012,.048,.140),(-.035,-.025,.019,.130),(.035,-.060,.016,.115),(.105,-.065,.035,.105),(.175,-.040,.065,.095),(.230,.010,.082,.085),(.245,.075,.065,.077),(.220,.130,.038,.070),(.165,.150,.020,.060),(.110,.130,.028,.052),(.090,.085,.048,.040),(.125,.060,.057,.014)]
verts=[]
for i,(x,y,z,w) in enumerate(pts):
    a=Vector(pts[max(0,i-1)][:2]); b=Vector(pts[min(len(pts)-1,i+1)][:2]); d=(b-a).normalized(); n=Vector((-d.y,d.x))
    tilt=.20*math.sin(i*.9)+.13*math.cos(i*.43)
    for side,dz in [(-1,.004),(1,.004),(1,-.004),(-1,-.004)]:
        verts.append((x+n.x*w*.5*side,y+n.y*w*.5*side,z+tilt*w*side+dz))
faces=[]
for i in range(len(pts)-1):
    for j in range(4):
        a=4*i+j; b=4*i+(j+1)%4; c=4*(i+1)+(j+1)%4; d=4*(i+1)+j
        faces.append((a,b,c,d))
faces.extend([(3,2,1,0),(60,61,62,63)])
mins=[min(v[k] for v in verts) for k in range(3)]; maxs=[max(v[k] for v in verts) for k in range(3)]
target=(.70,.35,.10)
verts=[tuple((v[k]-(mins[k] if k==2 else (mins[k]+maxs[k])/2))*target[k]/(maxs[k]-mins[k]) for k in range(3)) for v in verts]
mesh=bpy.data.meshes.new('Kelp_SolidRibbon'); mesh.from_pydata(verts,[],faces); mesh.update()
obj=bpy.data.objects.new('Washed_Curled_Kelp_D108',mesh); bpy.context.collection.objects.link(obj)
bpy.context.view_layer.objects.active=obj; obj.select_set(True)
# Recalculate all solid shell normals and lay out nonoverlapping UV islands.
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.uv.smart_project(angle_limit=math.radians(55),island_margin=.025); bpy.ops.object.mode_set(mode='OBJECT')
mesh.uv_layers.active.name='UV0'
mat=bpy.data.materials.new('Kelp'); mat.diffuse_color=(.19,.175,.065,1); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=mat.diffuse_color; bs.inputs['Roughness'].default_value=.78; bs.inputs['Metallic'].default_value=0
mesh.materials.append(mat)
for p in mesh.polygons:p.use_smooth=False
obj['scope']='Review only; no production integration'; obj['reference']='199 v2 upper-left; reference image not included in staged bundle'
finish([obj])
# Keep helper output and checked FBX receipt, adding focused source checks and views.
scene=bpy.context.scene; scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
assets=[o for o in scene.objects if o.type=='MESH' and len(o.data.materials)==1 and o.data.materials[0].name.split('.')[0]=='Kelp']
asset=assets[0] if assets else obj
asset.data.calc_loop_triangles()
edge_counts={}
for p in asset.data.polygons:
    ids=list(p.vertices)
    for a,b in zip(ids,ids[1:]+ids[:1]):
        key=tuple(sorted((a,b))); edge_counts[key]=edge_counts.get(key,0)+1
tri=len(asset.data.loop_triangles)
assert tri==124,tri
assert all(v==2 for v in edge_counts.values())
assert asset.data.uv_layers.active is not None
cam=scene.camera
original_matrix=cam.matrix_world.copy(); original_type=cam.data.type; original_scale=cam.data.ortho_scale
cam.data.type='ORTHO'; cam.data.ortho_scale=.86; cam.location=(0,0,2); cam.rotation_euler=(0,0,0)
scene.render.filepath='/output/top.png'; bpy.ops.render.render(write_still=True)
cam.location=(.85,-1.15,1.05); cam.rotation_euler=(Vector((0,0,.035))-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.ortho_scale=1.0
scene.render.filepath='/output/scale_1m.png'; bpy.ops.render.render(write_still=True)
cam.matrix_world=original_matrix; cam.data.type=original_type; cam.data.ortho_scale=original_scale
scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json'); report=json.loads(p.read_text()) if p.exists() else {}
report['kelp_source_checks']={'triangles':tri,'closed_edge_incidence_two':all(v==2 for v in edge_counts.values()),'dimensions_m':list(asset.dimensions),'semantic_slots':[m.name for m in asset.data.materials],'UV0':bool(asset.data.uv_layers),'ground_center_pivot':list(asset.location),'review_only':True,'scale_view_orthographic_width_m':1.0,'reference_image_available':False}
p.write_text(json.dumps(report,indent=2))
manifest={'issue':'D108 washed curled kelp strand','status':'First source preview; human review pending','reference':'#199 v2 upper-left, approved comment 3379','reference_png_sha256':'515efb327e365a4b7cbac766503c9ddf263c06625fb2f19c6612c3d587005cbb','reference_limitation':'Reference image not staged; geometry follows written selected-study specification.','source_commit':'322ad23f7d717783f6073245c579cc986721e9c7','artifacts':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('/output').iterdir() if f.suffix in ('.blend','.fbx','.png')},'excluded':'No base, props, rig, collision, LOD, production edits or runtime material integration'}
Path('/output/manifest.json').write_text(json.dumps(manifest,indent=2))

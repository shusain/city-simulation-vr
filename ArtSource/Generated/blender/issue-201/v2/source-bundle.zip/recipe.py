import bpy, sys, json, hashlib, math
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
objects=load_previous()
def signature(o):
 return {'v':[list(v.co) for v in o.data.vertices],'f':[list(p.vertices) for p in o.data.polygons],'uv':[list(x.uv) for x in o.data.uv_layers.active.data]}
before=[signature(o) for o in objects]
finish(objects)
scene=bpy.context.scene
assets=[o for o in scene.objects if o.type=='MESH' and any(m and m.name.split('.')[0]=='Kelp' for m in o.data.materials)]
assert len(assets)==1
asset=assets[0]
assert signature(asset)==before[0], 'Geometry or UV changed'
# Presentation-only revision. Preserve the approved material and all source topology.
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=16
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'; scene.view_settings.exposure=-0.6
# Replace the review rig only; no presentation mesh is exported.
for o in list(scene.objects):
 if o.type=='LIGHT' or (o.type=='MESH' and o!=asset): bpy.data.objects.remove(o,do_unlink=True)
world=bpy.data.worlds.new('Neutral review world'); scene.world=world; world.use_nodes=True
world.node_tree.nodes.get('Background').inputs['Color'].default_value=(.28,.27,.24,1)
world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.45
mat=bpy.data.materials.new('Review ground only'); mat.use_nodes=True
p=mat.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(.27,.25,.21,1); p.inputs['Roughness'].default_value=.9
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.001))
ground=bpy.context.object; ground.name='Presentation ground - not asset'; ground.data.materials.append(mat)
def area(name,loc,power,size):
 data=bpy.data.lights.new(name,'AREA'); data.energy=power; data.shape='DISK'; data.size=size
 ob=bpy.data.objects.new(name,data); scene.collection.objects.link(ob); ob.location=loc; ob.rotation_euler=(Vector((0,0,.02))-ob.location).to_track_quat('-Z','Y').to_euler()
area('Soft key',(-.65,-.65,1.15),45, .85)
area('Soft fill',(.7,.35,.8),18,1.0)
cam=scene.camera; cam.data.type='ORTHO'
def view(loc,width,path):
 cam.location=loc; cam.rotation_euler=(Vector((0,0,.045))-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.ortho_scale=width
 scene.render.filepath=path; bpy.ops.render.render(write_still=True)
# Near-front three-quarter view retains the full long silhouette at ~70% width.
view((.12,-1.25,1.25),1.0,'/output/preview.png')
hero=cam.matrix_world.copy()
view((0,0,2),1.0,'/output/top.png')
# Exactly one metre orthographic field is the common physical scale reference.
view((.12,-1.25,1.25),1.0,'/output/scale_1m.png')
cam.matrix_world=hero; scene.render.filepath='/output/preview.png'
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True); bpy.context.view_layer.objects.active=asset
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
asset.data.calc_loop_triangles(); edges={}
for face in asset.data.polygons:
 ids=list(face.vertices)
 for a,b in zip(ids,ids[1:]+ids[:1]):
  k=tuple(sorted((a,b))); edges[k]=edges.get(k,0)+1
assert all(n==2 for n in edges.values())
assert 80<=len(asset.data.loop_triangles)<=140
assert len(asset.data.materials)==1
p=Path('/output/validation.json'); report=json.loads(p.read_text())
report['revision_checks']={'geometry_and_uv_unchanged':signature(asset)==before[0],'closed':all(n==2 for n in edges.values()),'triangles':len(asset.data.loop_triangles),'dimensions_m':list(asset.dimensions),'pivot':list(asset.location),'material_slots':[m.name for m in asset.data.materials],'presentation_ground_exported':False,'orthographic_view_width_m':1.0,'exposure':-.6,'human_review':'pending'}
p.write_text(json.dumps(report,indent=2))
manifest={'issue':'D108 washed curled kelp','revision':'v2 presentation-only; v1 geometry and material preserved','source':'/previous/asset.blend','reference':'#199 v2 upper-left approved direction','scope':'Review only; no production promotion or runtime changes','files':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('/output').iterdir() if f.suffix in ('.blend','.fbx','.png')}}
Path('/output/manifest.json').write_text(json.dumps(manifest,indent=2))
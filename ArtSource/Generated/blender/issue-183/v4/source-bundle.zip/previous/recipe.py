import bpy,sys,json,hashlib,shutil,math
from pathlib import Path
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
def write(n,x):(O/n).write_text(json.dumps(x,indent=2))
# Read retained metadata when available; pinned recipe provides exact fallback names.
prior={}
for n in ['window-mounts.json','validation.json','material-manifest.json','upgrade-plan.json','waste-contract.json','entrance-anchors.json','vehicle-bays.json']:
 p=Path('/previous')/n
 if p.exists():prior[n]=json.loads(p.read_text())
objects=load_previous();assert len(objects)==1
ob=objects[0];me=ob.data
assert len(me.materials)==6 and len(ob.vertex_groups)==216
assert all(abs(v)<1e-6 for v in ob.location) and all(abs(v-1)<1e-6 for v in ob.scale)
assert not ob.modifiers
members={g.name:[] for g in ob.vertex_groups}
for v in me.vertices:
 gs=[ob.vertex_groups[g.group].name for g in v.groups if g.weight>.5];assert len(gs)==1
 members[gs[0]].append(v.index)
assert all(members.values())
# Prove each retained group is exactly one connected solid.
adj={v.index:set() for v in me.vertices}
for e in me.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
for n,ids in members.items():
 pending={ids[0]};seen=set()
 while pending:
  v=pending.pop()
  if v in seen:continue
  seen.add(v);pending.update(adj[v]-seen)
 assert seen==set(ids),n
original=[tuple(v.co) for v in me.vertices]
uvs=[[tuple(d.uv) for d in layer.data] for layer in me.uv_layers]
polys=[(tuple(p.vertices),p.material_index) for p in me.polygons]
def bounds(n):
 vs=[ob.matrix_world@me.vertices[i].co for i in members[n]]
 return {'name':n,'min':[min(v[k] for v in vs) for k in range(3)],'max':[max(v[k] for v in vs) for k in range(3)]}
window_names=[n for n in members if n.startswith(('AdminFrontUpper_','AdminFrontLower_','AdminWest_','AdminRear_','HallEastClerestory_','HallFrontClerestory_')) and not n.endswith(('_L','_R','_H','_S'))]
windows=prior.get('window-mounts.json',{}).get('windows',[])
if not windows:
 for n in window_names:
  axis=0 if n.startswith(('AdminWest_','HallEast')) else 1
  sign=1 if n.startswith(('AdminRear_','HallEast')) else -1
  face=6 if n.startswith('HallEast') else -20 if n.startswith('AdminWest') else 5 if n.startswith('AdminRear') else -8
  windows.append(dict(pane=n,frame_parts=[n+s for s in ['_L','_R','_H','_S']],backing='ReceivingHall' if n.startswith('Hall') else 'AdminOccupied',axis=axis,sign=sign,wall_face=face))
assert {r['pane'] for r in windows}==set(window_names)
allowed=set();lifted=[];rear_changes=0
for r in windows:
 n=r['pane'];a=r['axis'];s=r['sign'];f=r['wall_face']
 ds=[s*(me.vertices[i].co[a]-f) for i in members[n]];rear=min(ds)
 assert abs(max(ds)-.035)<1e-5
 if abs(rear+.015)<1e-5:
  for i in members[n]:
   if abs(s*(me.vertices[i].co[a]-f)-rear)<1e-5:me.vertices[i].co[a]+=s*.01;allowed.add(i);rear_changes+=1
 else:assert abs(rear+.005)<1e-5
 if n.startswith('AdminFrontUpper_'):
  b=bounds(n);z=(b['min'][2]+b['max'][2])/2
  if abs(z-4.75)<1e-5:
   for part in [n]+r['frame_parts']:
    for i in members[part]:me.vertices[i].co.z+=.60;allowed.add(i)
   lifted.append(n)
  else:assert abs(z-5.35)<1e-5
me.update();bpy.context.view_layer.update()
assert all(tuple(v.co)==original[v.index] for v in me.vertices if v.index not in allowed)
assert uvs==[[tuple(d.uv) for d in layer.data] for layer in me.uv_layers]
assert polys==[(tuple(p.vertices),p.material_index) for p in me.polygons]
components=[bounds(n) for n in members];lookup={c['name']:c for c in components}
def overlap(a,b,axes=(0,1,2)):return all(min(a['max'][k],b['max'][k])-max(a['min'][k],b['min'][k])>1e-6 for k in axes)
for r in windows:
 p=lookup[r['pane']];fs=[lookup[n] for n in r['frame_parts']];w=lookup[r['backing']];a=r['axis'];u=1-a;s=r['sign'];face=r['wall_face']
 r['pane_bounds']={k:p[k] for k in ['min','max']};r['frame_bounds']=fs
 for q in [p]+fs:
  for k in [u,2]:assert q['min'][k]>=w['min'][k]+.12-1e-5 and q['max'][k]<=w['max'][k]-.12+1e-5
  d=sorted(s*(q[t][a]-face) for t in ['min','max']);assert -.021<=d[0]<=.001
 pd=sorted(s*(p[t][a]-face) for t in ['min','max'])
 assert abs(pd[0]+.005)<1e-5 and abs(pd[1]-.035)<1e-5
 for q in fs:
  fd=sorted(s*(q[t][a]-face) for t in ['min','max']);assert fd[0]<=pd[0] and fd[1]>=pd[1]
 assert p['min'][u]>=fs[0]['max'][u]-1e-5 and p['max'][u]<=fs[1]['min'][u]+1e-5
 assert p['min'][2]>=fs[3]['max'][2]-1e-5 and p['max'][2]<=fs[2]['min'][2]+1e-5
 for i,q in enumerate(fs):
  assert not overlap(p,q)
  for t in fs[i+1:]:assert not overlap(q,t)
 if r['pane'].startswith('AdminFront'):
  for q in [p]+fs:
   for name in members:
    if name.startswith(('IdentityBack','BinRelief')):assert not overlap(q,lookup[name],(0,2)),(r['pane'],name)
# Glass membership completeness.
glass={i for p in me.polygons if me.materials[p.material_index].name.split('.')[0]=='WindowGlass' for i in p.vertices}
assert glass=={i for r in windows for i in members[r['pane']]}
anchors=[]
for role,x,width,height,end,target in [('pedestrian',-15,1.8,2.4,-8.24,'PublicLeaf_-15.46'),('service',-2,4.5,4.2,-8.20,'ReceivingDoor')]:
 corridor={'min':[x-width/2,-20,0],'max':[x+width/2,end,height]}
 assert target in members
 for c in components:assert not overlap(c,corridor),(role,c['name'])
 anchors.append(dict(role=role,target=target,xyz_m=[x,end,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=corridor))
write('entrance-anchors.json',{'anchors':anchors})
bay=dict(anchors[1]);bay.pop('role');bay.update(id='receiving-01',height_m=4.5);write('vehicle-bays.json',{'bays':[bay]})
doors=prior.get('window-mounts.json',{}).get('doors',[dict(target=a['target'],wall='AdminOccupied' if a['role']=='pedestrian' else 'ReceivingHall',axis=1,sign=-1,wall_face=-8,clear_width_m=a['width_m'],height_m=2.5 if a['role']=='pedestrian' else 4.5) for a in anchors])
write('window-mounts.json',dict(windows=windows,doors=doors))
tex=O/'textures';tex.mkdir(exist_ok=True);textures={}
for stem,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for suffix in ['BaseColor','Normal','ORM']:
  name=stem+'_'+suffix+'.png';src=Path('/repo/ArtSource/Textures')/folder/name;dst=tex/name;shutil.copyfile(src,dst)
  ims=[im for im in bpy.data.images if Path(im.filepath).name==name or im.name==name];assert len(ims)==1,(name,[im.name for im in bpy.data.images])
  im=ims[0];assert im.packed_file
  cs='sRGB' if suffix=='BaseColor' else 'Non-Color';assert im.colorspace_settings.name==cs
  im.filepath=str(dst);textures[name]=dict(sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=cs)
matrec={}
for m in me.materials:
 ns=m.node_tree.nodes;p=next(n for n in ns if n.type=='BSDF_PRINCIPLED');mix=[n for n in ns if n.type=='MIX_RGB' and n.blend_type=='MULTIPLY'];tint=next((n for n in mix if not n.inputs[2].is_linked),None)
 matrec[m.name]=dict(tint_multiply=list(tint.inputs[2].default_value) if tint else list(p.inputs['Base Color'].default_value),roughness_constant=p.inputs['Roughness'].default_value,metallic_constant=p.inputs['Metallic'].default_value,normal_strength=.25 if mix else 0,transmission=0,images=[n.image.name for n in ns if n.type=='TEX_IMAGE'])
write('material-manifest.json',dict(materials=matrec,textures=textures,ORM={'R':'AO multiplied with BaseColor before tint','G':'roughness','B':'metallic'},UV0='Preserved finite dominant-face world planar coordinates metres / 2',opaque_glass=True))
occupied={k:[(min if k=='min' else max)(c[k][i] for c in components) for i in range(3)] for k in ['min','max']}
for c in components:
 assert c['min'][0]>=-23.5 and c['max'][0]<=23.5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5 and c['min'][2]>=-1e-5
upgrade=prior.get('upgrade-plan.json',dict(family='wastedepot',stage='base',stage_index=0,existing_stages=['base','medium'],existing_upgrade_count=1,gameplay_changes=False,source_site_m=[48,40],current_native_footprint=[4,3],retained_entrance_centres={'pedestrian':[-15,-8,0],'service':[-2,-8,0]},progression='Medium adds second bay and rear equipment groups; no high stage.',future_LOD='LOD1 simplify frames, ribs and equipment; original references retained.'))
upgrade['occupied_bounds']=occupied;write('upgrade-plan.json',upgrade)
contract=prior.get('waste-contract.json')
if not contract:
 groups={k:[] for k in ['admin','hall','entry','roof','identity','compactor','conveyor','bins']}
 for n in members:
  if n.startswith(('Identity','BinRelief')):g='identity'
  elif n.startswith(('Feed',)):g='conveyor'
  elif n.startswith(('Compactor','RamBox','Hydraulic','SkipLoading')):g='compactor'
  elif n.startswith(('Skip','ContainedWaste')):g='bins'
  elif n.startswith(('Extraction','Filter','Extractor','LowRoof','VentCap','HallRoof','HallSideParapet','HallEndParapet','AdminSlateRoof')):g='roof'
  elif n.startswith(('Public','EntryShelter','ReceivingDoor','DoorSection','Bay')):g='entry'
  elif n.startswith(('Hall','ReceivingHall')):g='hall'
  else:g='admin'
  groups[g].append(n)
 contract=dict(family='wastedepot',stage='base',sourceID='building.wastedepot.a',source_site_m=[48,40],components=groups,bales='not applicable: transfer depot',process='Hall feed bridge and hydraulic compactor discharge toward loaded open skip',review_only=True,integration='HELD')
for names in contract['components'].values():
 for n in names:assert n in members
write('waste-contract.json',contract)
me.calc_loop_triangles();assert len(me.loop_triangles)==2592
for mesh in list(bpy.data.meshes):
 if mesh.users==0:bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
 if mat.users==0:bpy.data.materials.remove(mat)
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
finish([ob])
p=O/'validation.json';receipt=json.loads(p.read_text())
receipt.update(components=components,connected_solids=216,window_count=len(windows),revision=dict(rear_vertices_moved=rear_changes,upper_front_lifted=lifted,topology_uv_materials_retained=True),window_mount_checks=dict(containment=True,wall_contact=True,pane_within_frame_depth=True,clear_opening=True,disjoint_frame_corners=True,projected_icon_front_window_separation=True),strict_corridors_clear=True,source_site_m=[48,40],triangle_ceiling=6500,semantic_region_ceiling=6,review_only=True,integration='HELD',no_artistic_approval_claim=True)
write('validation.json',receipt)

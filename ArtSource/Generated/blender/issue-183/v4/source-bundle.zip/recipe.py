import bpy,bmesh,sys,json,math,shutil,hashlib
from pathlib import Path
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
prior={}
for n in ['window-mounts.json','entrance-anchors.json','vehicle-bays.json','upgrade-plan.json','waste-contract.json','material-manifest.json']:
 p=Path('/previous')/n
 if p.exists():prior[n]=json.loads(p.read_text())
objects=load_previous();assert len(objects)==1
ob=objects[0];me=ob.data
assert len(me.materials)==6
mats={m.name:m for m in me.materials}
assert all(n in mats for n in ['CivicBrick','LightStone','RoofMembrane','EquipmentMetal','WindowGlass','ServiceAccent'])
def groups():
 d={g.name:[] for g in ob.vertex_groups}
 for v in ob.data.vertices:
  gs=[ob.vertex_groups[g.group].name for g in v.groups if g.weight>.5];assert len(gs)==1
  d[gs[0]].append(v.index)
 return {n:ids for n,ids in d.items() if ids}
def measure():
 d=groups();return {n:dict(name=n,min=[min(ob.data.vertices[i].co[k] for i in ids) for k in range(3)],max=[max(ob.data.vertices[i].co[k] for i in ids) for k in range(3)]) for n,ids in d.items()}
old=measure();original_groups=groups()
removed=['AdminBelt_0.18','AdminBelt_3.2','AdminBelt_6.25','AdminFrontPier_-19.86','AdminFrontPier_-10.14']
assert all(n in old for n in removed)
removed += [n for n in old if n.startswith('Hall') and 'parapet' in n.lower()]
roof_names=[n for n in old if n.startswith('HallRoof')];assert roof_names
roof_top=max(old[n]['max'][2] for n in roof_names)
retained_snapshot={n:[tuple(me.vertices[i].co) for i in ids] for n,ids in original_groups.items() if n not in removed}
kill={i for n in removed for i in original_groups[n]}
bm=bmesh.new();bm.from_mesh(me);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[bm.verts[i] for i in kill],context='VERTS');bm.to_mesh(me);bm.free();me.update()
for n in removed:ob.vertex_groups.remove(ob.vertex_groups[n])
# Only requested semantic recolouring; retain all six previous slots and names.
def constant(m,color,rough,metal):
 p=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 for key in ['Base Color','Roughness','Metallic','Normal','Transmission Weight']:
  if key in p.inputs:
   for l in list(p.inputs[key].links):m.node_tree.links.remove(l)
 p.inputs['Base Color'].default_value=color;p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;p.inputs['Transmission Weight'].default_value=0;m.diffuse_color=color
constant(mats['ServiceAccent'],(.035,.24,.075,1),.70,.10)
rubber=bpy.data.materials.new('ContainerLidRubber');rubber.use_nodes=True;constant(rubber,(.012,.015,.018,1),.85,0);mats[rubber.name]=rubber
# Existing relief keeps its exact geometry and placement.
for p in me.polygons:
 ns={ob.vertex_groups[g.group].name for i in p.vertices for g in me.vertices[i].groups if g.weight>.5}
 if any(n.startswith('BinRelief') for n in ns):
  if any('lid' in n.lower() for n in ns):
   if rubber.name not in [m.name for m in me.materials]:me.materials.append(rubber)
   p.material_index=list(me.materials).index(rubber)
  else:p.material_index=list(me.materials).index(mats['ServiceAccent'])
 if any(n.startswith('Skip') and any(s in n.lower() for s in ['side','end','bottom','body','plate']) for n in ns):p.material_index=list(me.materials).index(mats['ServiceAccent'])
added=[];newbounds={}
def solid(name,verts,faces,mat):
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.materials.append(mats[mat]);mesh.update()
 obj=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(obj);obj.vertex_groups.new(name=name).add(list(range(len(verts))),1,'REPLACE')
 uv=mesh.uv_layers.new(name='UVMap')
 for p in mesh.polygons:
  axis=max(range(3),key=lambda k:abs(p.normal[k]));a,b=[k for k in range(3) if k!=axis]
  for li in p.loop_indices:
   co=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=(co[a]/2,co[b]/2)
 added.append(obj);newbounds[name]=dict(name=name,min=[min(v[k] for v in verts) for k in range(3)],max=[max(v[k] for v in verts) for k in range(3)])
 return name
def box(name,lo,hi,mat='LightStone'):
 x,y,z=lo;X,Y,Z=hi
 return solid(name,[(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat)
trim=[];joints=[]
for z in [.22,3.20,6.30]:
 tag=str(z);names=[]
 specs=[('F',[-20.06,-8.06,z-.06],[-9.94,-7.99,z+.06]),('B',[-20.06,4.99,z-.06],[-9.94,5.06,z+.06]),('W',[-20.06,-7.99,z-.06],[-19.99,4.99,z+.06]),('E',[-10.01,-7.99,z-.06],[-9.94,.99 if z<4 else 4.99,z+.06])]
 for suffix,lo,hi in specs:names.append(box('TrimR2_'+tag+'_'+suffix,lo,hi));trim.append(names[-1])
 for a,b,plane in [(names[0],names[2],-7.99),(names[0],names[3],-7.99),(names[1],names[2],4.99)]+([(names[1],names[3],4.99)] if z>4 else []):joints.append(dict(parts=[a,b],axis=1,plane=plane))
par=[]
for n,lo,hi in [('W',[-8,-8,roof_top-.01],[-7.78,10,roof_top+.37]),('E',[5.78,-8,roof_top-.01],[6,10,roof_top+.37]),('F',[-7.78,-8,roof_top-.01],[5.78,-7.78,roof_top+.37]),('B',[-7.78,9.78,roof_top-.01],[5.78,10,roof_top+.37])]:par.append(box('ParapetR2_'+n,lo,hi))
for s,x in [('W',-7.78),('E',5.78)]:
 for t in ['F','B']:joints.append(dict(parts=['ParapetR2_'+s,'ParapetR2_'+t],axis=0,plane=x))
annex=[]
annex.append(box('FurnaceR2_Occupied',[-19,8,0],[-10.5,16,5.5],'CivicBrick'))
annex.append(box('FurnaceR2_Roof',[-19,8,5.5],[-10.5,16,5.7],'RoofMembrane'))
annex.append(box('FurnaceR2_FeedDuct',[-10.5,8.5,2.6],[-7.95,9.7,3.6],'EquipmentMetal'))
for x in [-17,-13]:
 annex.append(box('FurnaceR2_Hatch_'+str(x),[x-1.25,15.995,1.2],[x+1.25,16.10,3.8],'ContainerLidRubber'))
 for s,lo,hi in [('L',[x-1.39,15.99,1.06],[x-1.25,16.16,3.94]),('R',[x+1.25,15.99,1.06],[x+1.39,16.16,3.94]),('H',[x-1.25,15.99,3.8],[x+1.25,16.16,3.94]),('S',[x-1.25,15.99,1.06],[x+1.25,16.16,1.2])]:annex.append(box('FurnaceR2_HatchFrame_'+str(x)+s,lo,hi,'EquipmentMetal'))
annex.append(box('FurnaceR2_AshDrawer',[-16.8,15.995,.2],[-12.8,16.15,.8],'ContainerLidRubber'))
annex.append(box('FurnaceR2_AshHandle',[-15.5,16.14,.48],[-14.1,16.24,.60],'EquipmentMetal'))
# Continuous 12-sided thick-walled open tube, with annular root and rim but no throat cap.
cx,cy=-16.5,12;verts=[]
for z,r in [(5.7,.70),(14.2,.70),(5.7,.56),(14.2,.56)]:
 for i in range(12):a=2*math.pi*i/12;verts.append((cx+r*math.cos(a),cy+r*math.sin(a),z))
faces=[]
for i in range(12):
 j=(i+1)%12;faces.extend([(i,j,12+j,12+i),(24+j,24+i,36+i,36+j),(12+i,12+j,36+j,36+i),(j,i,24+i,24+j)])
flue=solid('FurnaceR2_OpenFlue',verts,faces,'EquipmentMetal');annex.append(flue)
# Commercial dumpster plates and two opaque black lids; no solid filled body.
dump=[]
for n,lo,hi,mat in [('Bottom',[19,-7,.20],[23,-3.5,.34],'ServiceAccent'),('Front',[19,-7,.34],[23,-6.86,2.60],'ServiceAccent'),('Rear',[19,-3.64,.34],[23,-3.5,2.60],'ServiceAccent'),('West',[19,-6.86,.34],[19.14,-3.64,2.60],'ServiceAccent'),('East',[22.86,-6.86,.34],[23,-3.64,2.60],'ServiceAccent'),('LidA',[19,-7,2.60],[20.985,-3.5,2.82],'ContainerLidRubber'),('LidB',[21.015,-7,2.60],[23,-3.5,2.82],'ContainerLidRubber'),('Hinge',[19.12,-3.60,2.52],[22.88,-3.50,2.66],'ContainerLidRubber')]:dump.append(box('DumpsterR2_01_'+n,lo,hi,mat))
for i,(x,y) in enumerate([(19.25,-6.7),(22.4,-6.7),(19.25,-4.1),(22.4,-4.1)]):dump.append(box('DumpsterR2_01_Foot'+str(i),[x,y,0],[x+.35,y+.35,.20],'ContainerLidRubber'))
for i,x in enumerate([19.6,20.5,21.4,22.3]):dump.append(box('DumpsterR2_01_Rib'+str(i),[x,-7.06,.5],[x+.13,-6.99,2.35],'ServiceAccent'))
# Join only newly requested solids to original joined source, preserving original mesh/group memberships.
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True)
for o in added:o.select_set(True)
bpy.context.view_layer.objects.active=ob;bpy.ops.object.join();me=ob.data;me.update();bpy.context.view_layer.update()
lookup=measure();members=groups();components=list(lookup.values())
for n,coords in retained_snapshot.items():assert coords==[tuple(me.vertices[i].co) for i in members[n]],n
# Connected-solid audit: each group is exactly one connected mesh island, no duplicates or omissions.
adj=[set() for v in me.vertices]
for e in me.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
for n,ids in members.items():
 todo=[ids[0]];seen=set()
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 assert seen==set(ids),n
assert sum(map(len,members.values()))==len(me.vertices)
def overlap(a,b,axes=(0,1,2)):
 return all(min(a['max'][k],b['max'][k])-max(a['min'][k],b['min'][k])>1e-5 for k in axes)
strips=trim+par
for i,n in enumerate(strips):
 for m in strips[i+1:]:assert not overlap(lookup[n],lookup[m]),(n,m)
for j in joints:
 a,b=[lookup[n] for n in j['parts']];k=j['axis'];assert min(abs(a['max'][k]-b['min'][k]),abs(b['max'][k]-a['min'][k]))<.001
for n in par:
 assert abs(lookup[n]['min'][2]-(roof_top-.01))<1e-5 and abs(lookup[n]['max'][2]-(roof_top+.37))<1e-5
 assert any(overlap(lookup[n],lookup[r]) for r in roof_names)
windows=prior.get('window-mounts.json',{}).get('windows',[])
if not windows:
 for n in members:
  if not n.startswith(('AdminFrontUpper_','AdminFrontLower_','AdminWest_','AdminRear_','HallEastClerestory_','HallFrontClerestory_')) or n.endswith(('_L','_R','_H','_S')):continue
  axis=0 if n.startswith(('AdminWest_','HallEast')) else 1;sign=1 if n.startswith(('AdminRear_','HallEast')) else -1
  face=6 if n.startswith('HallEast') else -20 if n.startswith('AdminWest') else 5 if n.startswith('AdminRear') else -8
  windows.append(dict(pane=n,frame_parts=[n+s for s in ['_L','_R','_H','_S']],backing='ReceivingHall' if n.startswith('Hall') else 'AdminOccupied',axis=axis,sign=sign,wall_face=face))
for r in windows:
 p=lookup[r['pane']];fs=[lookup[n] for n in r['frame_parts']];w=lookup[r['backing']];a=r['axis'];u=1-a;s=r['sign'];face=r['wall_face']
 r['pane_bounds']={k:p[k] for k in ['min','max']};r['frame_bounds']=fs
 for q in [p]+fs:
  for k in [u,2]:assert q['min'][k]>=w['min'][k]+.12-1e-5 and q['max'][k]<=w['max'][k]-.12+1e-5
  d=sorted(s*(q[t][a]-face) for t in ['min','max']);assert -.021<=d[0]<=.001
  for n in strips:assert not overlap(q,lookup[n]),(r['pane'],n)
 pd=sorted(s*(p[t][a]-face) for t in ['min','max']);assert abs(pd[0]+.005)<1e-5 and abs(pd[1]-.035)<1e-5
 for q in fs:
  fd=sorted(s*(q[t][a]-face) for t in ['min','max']);assert fd[0]<=pd[0]+1e-6 and fd[1]>=pd[1]-1e-6
 assert p['min'][u]>=fs[0]['max'][u]-1e-5 and p['max'][u]<=fs[1]['min'][u]+1e-5
 assert p['min'][2]>=fs[3]['max'][2]-1e-5 and p['max'][2]<=fs[2]['min'][2]+1e-5
 for i,q in enumerate(fs):
  assert not overlap(p,q)
  for t in fs[i+1:]:assert not overlap(q,t)
glass={i for p in me.polygons if me.materials[p.material_index].name=='WindowGlass' for i in p.vertices}
assert glass=={i for r in windows for i in members[r['pane']]}
anchors=[]
for role,x,width,height,end,target in [('pedestrian',-15,1.8,2.4,-8.24,'PublicLeaf_-15.46'),('service',-2,4.5,4.2,-8.20,'ReceivingDoor')]:
 corridor=dict(min=[x-width/2,-20,0],max=[x+width/2,end,height]);assert target in members
 for c in components:assert not overlap(c,corridor),(role,c['name'])
 leaf=lookup[target];assert leaf['min'][1]<-8 and leaf['max'][2]>=height
 if role=='service':assert leaf['max'][0]-leaf['min'][0]>=4.5-1e-5
 anchors.append(dict(role=role,target=target,xyz_m=[x,end,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=corridor))
write('entrance-anchors.json',dict(anchors=anchors));bay=dict(anchors[1]);bay.pop('role');bay.update(id='receiving-01',height_m=4.5);write('vehicle-bays.json',dict(bays=[bay]))
write('window-mounts.json',dict(windows=windows,doors=prior.get('window-mounts.json',{}).get('doors',[dict(target=a['target'],axis=1,sign=-1,wall_face=-8,clear_width_m=a['width_m']) for a in anchors])))
for c in components:assert c['min'][0]>=-23.5-1e-5 and c['max'][0]<=23.5+1e-5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5 and c['min'][2]>=-1e-5
occupied={k:[(min if k=='min' else max)(c[k][i] for c in components) for i in range(3)] for k in ['min','max']}
write('corner-contract.json',dict(removed=removed,new_strips=[lookup[n] for n in strips],joints=joints,roof_components=roof_names,roof_top=roof_top,positive_strip_intersections=False,unchanged_window_geometry=True))
write('incinerator-contract.json',dict(furnace=annex,annex_bounds=lookup['FurnaceR2_Occupied'],roof=lookup['FurnaceR2_Roof'],duct=lookup['FurnaceR2_FeedDuct'],flues=[dict(component=flue,centre_m=[cx,cy],outer_radius_m=.70,inner_radius_m=.56,sides=12,root_z=5.70,top_z=14.20,air_opening=True,throat_uncapped=True)],source_only=True))
write('dumpster-contract.json',dict(dumpsters=[dict(id='01',components=[lookup[n] for n in dump],body=[n for n in dump if any(s in n for s in ['Bottom','Front','Rear','West','East'])],lids=[n for n in dump if 'Lid' in n],hinge=[n for n in dump if 'Hinge' in n],feet=[n for n in dump if 'Foot' in n],overall_bounds=dict(min=[19,-7.06,0],max=[23,-3.5,2.82]))]))
upgrade=prior.get('upgrade-plan.json',dict(family='wastedepot',stage='base',stage_index=0,existing_stages=['base','medium'],existing_upgrade_count=1,gameplay_changes=False,source_site_m=[48,40],current_native_footprint=[4,3],retained_entrance_centres={'pedestrian':[-15,-8,0],'service':[-2,-8,0]}));upgrade.update(occupied_bounds=occupied,progression='Existing medium adds second receiving bay, rear process group, second furnace flue and second dumpster. No additional gameplay tier.');write('upgrade-plan.json',upgrade)
grp={k:[] for k in ['admin','hall','entry','roof','identity','compactor','conveyor','bins','incinerator','dumpster']}
for n in members:
 if n in annex:g='incinerator'
 elif n in dump:g='dumpster'
 elif n.startswith(('Identity','BinRelief')):g='identity'
 elif n.startswith('Feed'):g='conveyor'
 elif n.startswith(('Compactor','RamBox','Hydraulic','SkipLoading')):g='compactor'
 elif n.startswith(('Skip','ContainedWaste')):g='bins'
 elif n.startswith(('Extraction','Filter','Extractor','LowRoof','VentCap','HallRoof','ParapetR2','AdminSlateRoof')):g='roof'
 elif n.startswith(('Public','EntryShelter','ReceivingDoor','DoorSection','Bay')):g='entry'
 elif n.startswith(('Hall','ReceivingHall')):g='hall'
 else:g='admin'
 grp[g].append(n)
assert all(grp[k] for k in ['compactor','conveyor','bins','identity'])
write('waste-contract.json',dict(family='wastedepot',stage='base',sourceID='building.wastedepot.a',source_site_m=[48,40],components=grp,review_only=True,integration='HELD'))
tex=O/'textures';tex.mkdir(exist_ok=True);textures={}
for stem,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for suffix in ['BaseColor','Normal','ORM']:
  name=stem+'_'+suffix+'.png';src=Path('/repo/ArtSource/Textures')/folder/name;dst=tex/name;shutil.copyfile(src,dst)
  ims=[im for im in bpy.data.images if Path(im.filepath).name==name or im.name==name];assert len(ims)==1
  im=ims[0];im.filepath=str(dst);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack();textures[name]=dict(sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name)
matrec={}
for m in me.materials:
 ns=m.node_tree.nodes;p=next(n for n in ns if n.type=='BSDF_PRINCIPLED');mix=[n for n in ns if n.type=='MIX_RGB' and n.blend_type=='MULTIPLY'];tint=next((n for n in mix if not n.inputs[2].is_linked),None)
 matrec[m.name]=dict(base_color_constant=list(p.inputs['Base Color'].default_value),base_color_linked=p.inputs['Base Color'].is_linked,tint_multiply=list(tint.inputs[2].default_value) if tint else None,roughness_constant=p.inputs['Roughness'].default_value,metallic_constant=p.inputs['Metallic'].default_value,transmission=p.inputs['Transmission Weight'].default_value,images=[n.image.name for n in ns if n.type=='TEX_IMAGE'],normal_strengths=[n.inputs['Strength'].default_value for n in ns if n.type=='NORMAL_MAP'])
write('material-manifest.json',dict(materials=matrec,textures=textures,ORM={'R':'AO multiplied before tint','G':'roughness','B':'metallic'},UV0='Finite dominant-face world planar coordinates metres / 2; retained UVs unchanged',opaque_glass=True))
assert len(me.materials)==7
for uv in me.uv_layers:
 assert all(math.isfinite(x) for d in uv.data for x in d.uv)
me.calc_loop_triangles();assert len(me.loop_triangles)<=6500
for mesh in list(bpy.data.meshes):
 if mesh.users==0:bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
 if mat.users==0:bpy.data.materials.remove(mat)
bpy.context.scene.cursor.location=(0,0,0)
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
finish([ob])
receipt=json.loads((O/'validation.json').read_text());receipt.update(components=components,connected_solids=len(components),window_count=len(windows),revision=dict(removed=removed,retained_geometry_exact=True,new_solids=len(newbounds)),window_mount_checks=dict(containment=True,wall_contact=True,pane_frame_depth=True,clear_opening=True,disjoint_rim=True,new_trim_clear=True),strict_corridors_clear=True,corner_checks=True,source_site_m=[48,40],triangle_ceiling=6500,semantic_region_ceiling=7,review_only=True,integration='HELD',no_artistic_approval_claim=True);write('validation.json',receipt)

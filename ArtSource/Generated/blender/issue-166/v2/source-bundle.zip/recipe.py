import bpy, sys, math, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box,cylinder,finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output');out.mkdir(exist_ok=True)
# Fresh study: no completed parent is staged in this packet.
for o in list(bpy.data.objects):
 if o.type=='MESH': bpy.data.objects.remove(o,do_unlink=True)
for m in list(bpy.data.meshes):
 if m.users==0:bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
 if m.users==0:bpy.data.materials.remove(m)
colors={'Concrete':(.43,.45,.43,1),'BuildingFacade':(.39,.46,.44,1),'RoofService':(.095,.115,.13,1),'EquipmentMetal':(.26,.31,.32,1),'WindowAccent':(.075,.16,.21,1)}
mats={};manifest={'regions':{},'textures':[],'normal_strength':.3,'metric_uv_scale':.5}
for name,col in colors.items():
 m=bpy.data.materials.new(name);m.diffuse_color=col;m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.65
 mats[name]=m;manifest['regions'][name]=list(col)
for region,folder,stem in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
 m=mats[region];nodes=m.node_tree.nodes;links=m.node_tree.links;p=nodes.get('Principled BSDF')
 tex={}
 for suffix in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+suffix+'.png');dst=out/'textures'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst),check_existing=False);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  n=nodes.new('ShaderNodeTexImage');n.image=im;tex[suffix]=n
  manifest['textures'].append({'region':region,'source':str(src),'copy':str(dst),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'dimensions':list(im.size),'colorspace':im.colorspace_settings.name})
 links.new(tex['BaseColor'].outputs['Color'],p.inputs['Base Color'])
 sep=nodes.new('ShaderNodeSeparateColor');links.new(tex['ORM'].outputs['Color'],sep.inputs['Color']);links.new(sep.outputs['Green'],p.inputs['Roughness']);links.new(sep.outputs['Blue'],p.inputs['Metallic'])
 normal=nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.3;links.new(tex['Normal'].outputs['Color'],normal.inputs['Color']);links.new(normal.outputs['Normal'],p.inputs['Normal'])
objects=[]
def use(o,mat):
 o.data.materials.clear();o.data.materials.append(mats[mat]);objects.append(o);return o
def B(name,d,loc,mat='EquipmentMetal'):return use(box(name,d,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',seg=16):return use(cylinder(name,r,h,loc,colors[mat],vertices=seg),mat)
def pipe(name,a,b,r=.28,seg=12):
 a,b=Vector(a),Vector(b);o=C(name,r,(b-a).length,(a+b)/2,seg=seg);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def ring(name,x,y,ro,ri,z0,z1,mat,seg=32):
 verts=[(x+r*math.cos(2*math.pi*i/seg),y+r*math.sin(2*math.pi*i/seg),z) for r,z in [(ro,z0),(ro,z1),(ri,z1),(ri,z0)] for i in range(seg)]
 faces=[(j*seg+i,j*seg+(i+1)%seg,((j+1)%4)*seg+(i+1)%seg,((j+1)%4)*seg+i) for j in range(4) for i in range(seg)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return use(o,mat)
for i,x in enumerate([-16.2,-5.4,5.4,16.2]):
 y=8;tag=f'Clarifier_{i+1}'
 ring(tag+'_structural_vessel',x,y,4.35,4.03,0,2.25,'Concrete');ring(tag+'_coping_rim',x,y,4.43,3.98,2.25,2.4,'Concrete')
 C(tag+'_recessed_calm_water',4.02,.08,(x,y,1.32),'WindowAccent',32);C(tag+'_spindle',.21,1.3,(x,y,1.99));B(tag+'_diameter_service_bridge',(8.55,.48,.18),(x,y,2.55));C(tag+'_drive',.37,.4,(x,y,2.84))
 for side in [-1,1]:
  for dx in [-4,-2,0,2,4]:B(tag+f'_post_{side}_{dx}',(.055,.055,1),(x+dx,y+side*.27,3.08))
  for z in [3.08,3.58]:B(tag+f'_handrail_{side}_{z}',(8.2,.06,.06),(x,y+side*.27,z))
 # End rails close bridge perimeter without a forest of fittings.
 for dx in [-4.1,4.1]:B(tag+f'_endrail_{dx}',(.06,.48,.06),(x+dx,y,3.58))
B('Worker_control_two_storey_block',(9,7,6.3),(-7.5,-7,3.15),'BuildingFacade')
B('Worker_control_flat_roof',(9.35,7.35,.22),(-7.5,-7,6.41),'RoofService');B('Control_floor_band',(9.08,7.08,.16),(-7.5,-7,3.2),'Concrete')
B('Filter_pump_hall',(10,7,4.6),(6.5,-6.5,2.3),'BuildingFacade');B('Filter_hall_service_roof',(10.35,7.35,.22),(6.5,-6.5,4.71),'RoofService')
B('Personnel_door_leaf',(1.2,.12,2.2),(-9.5,-10.56,1.1));B('Personnel_door_glass',(.84,.035,1.1),(-9.5,-10.64,1.42),'WindowAccent');B('Personnel_handle',(.05,.11,.35),(-9.06,-10.72,1.02));B('Personnel_canopy',(2.1,1,.14),(-9.5,-10.8,2.65),'RoofService')
B('Service_vehicle_shutter',(4,.14,3.5),(7.5,-10.07,1.75))
for z in [.45,.95,1.45,1.95,2.45,2.95,3.45]:B('Shutter_seam_'+str(z),(3.92,.035,.035),(7.5,-10.16,z),'RoofService')
for x in [5.43,9.57]:B('Bay_jamb_'+str(x),(.13,.2,3.62),(x,-10.08,1.81),'Concrete')
B('Bay_header',(4.27,.2,.16),(7.5,-10.08,3.7),'Concrete')
windows=[]
def window(name,wall,axis,sign,t,z,w,h):
 # Complete hollow rim; jambs span full height, head/sill fit between jambs.
 face=wall.location[axis]+sign*wall.dimensions[axis]/2
 tangent=1-axis;th=.11;depth=.16;center=face+sign*.07
 def part(n,tw,hh,tt,zz,dd=depth,cc=center,mat='EquipmentMetal'):
  d=[0,0,hh];loc=[0,0,zz];d[axis]=dd;d[tangent]=tw;loc[axis]=cc;loc[tangent]=tt
  return B(n,d,loc,mat)
 frame=[part(name+'_jamb_L',th,h,t-w/2+th/2,z),part(name+'_jamb_R',th,h,t+w/2-th/2,z),part(name+'_head',w-2*th,th,t,z+h/2-th/2),part(name+'_sill',w-2*th,th,t,z-h/2+th/2)]
 pane=part(name,w-2*th,h-2*th,t,z,.04,face+sign*.08,'WindowAccent')
 windows.append({'pane':pane.name,'frame_parts':[o.name for o in frame],'backing':wall.name,'axis':axis,'sign':sign,'wall_normal':[sign if axis==0 else 0,sign if axis==1 else 0,0]})
control=bpy.data.objects['Worker_control_two_storey_block'];hall=bpy.data.objects['Filter_pump_hall']
for level in [1.65,4.65]:
 for x in [-6.9,-4.5]:window(f'Control_front_window_{x}_{level}',control,1,-1,x,level,1.85,1.45)
for y in [-8.9,-6.5,-4.55]:
 for z in [1.65,4.65]:window(f'Control_side_glazing_{y}_{z}',control,0,-1,y,z,1.8,1.45)
for x in [2.8,4.5]:window('Hall_window_'+str(x),hall,1,-1,x,3.7,1.57,1.02)
for x in [3.2,7.8]:
 B('Hall_roof_vent_'+str(x),(1.4,1.5,.6),(x,-5.8,5.11));B('Hall_vent_cap_'+str(x),(1.6,1.7,.12),(x,-5.8,5.47),'RoofService')
for j,x in enumerate([-10.8,0,10.8]):
 pipe(f'Main_{j}_horizontal',(x,-1.8,.85),(x,2.7,.85),.3);pipe(f'Main_{j}_riser',(x,2.7,.85),(x,2.7,1.9),.3)
 for y in [-.9,1.5]:pipe(f'Main_{j}_flange_{y}',(x,y-.07,.85),(x,y+.07,.85),.43,16)
 pipe(f'Valve_{j}_stem',(x,.2,.9),(x,.2,1.55),.065,8);C(f'Valve_{j}_handwheel',.31,.07,(x,.2,1.58))
 for y in [-1.2,1.8]:B(f'Pipe_{j}_foot_{y}',(.18,.25,.55),(x,y,.275))
# Retain the original pair and add four vessels to the same process yard.
for x,y in [(-1.1,-4.1),(1.1,-4.1),(-1.1,-7),(1.1,-7),(-1.1,-9.9),(1.1,-9.9)]:
 tag=f'{x}_{y}';C('Upright_process_vessel_'+tag,.62,2.65,(x,y,1.675),seg=24);C('Vessel_cap_'+tag,.65,.16,(x,y,3.08),seg=24)
 for dx in [-.4,.4]:B('Vessel_leg_'+tag+str(dx),(.12,.5,.45),(x+dx,y,.225))
# Additional full pump/filter train front-right, well outside the service corridor.
extra=B('Additional_filter_pump_hall',(8,10,4.6),(17.2,-7.4,2.3),'BuildingFacade');B('Additional_filter_roof',(8.35,10.35,.22),(17.2,-7.4,4.71),'RoofService')
for x in [14.7,17.2,19.7]:window('Train2_front_'+str(x),extra,1,-1,x,3.25,1.6,1.3)
for y in [-10,-7.4,-4.8]:window('Train2_side_'+str(y),extra,0,1,y,2.9,1.8,1.45)
for x in [15.3,19.1]:
 B('Train2_roof_vent_'+str(x),(1.5,2,.7),(x,-7.4,5.17));B('Train2_vent_cap_'+str(x),(1.7,2.2,.12),(x,-7.4,5.58),'RoofService')
# Broad two-storey control wing, same height rather than an empty extra floor.
wing=B('Expanded_control_wing',(7,7,6.3),(-15.5,-7,3.15),'BuildingFacade');B('Expanded_control_roof',(7.35,7.35,.22),(-15.5,-7,6.41),'RoofService')
for x in [-17.8,-15.5,-13.2]:
 for z in [1.65,4.65]:window(f'Wing_front_{x}_{z}',wing,1,-1,x,z,1.8,1.45)
for y in [-8.7,-5.3]:
 for z in [1.65,4.65]:window(f'Wing_side_{y}_{z}',wing,0,-1,y,z,1.8,1.45)
# Large rear distribution header with four branches; raised on equipment saddles.
pipe('Expanded_distribution_header',(-20.6,2.7,1.9),(20.6,2.7,1.9),.36,16)
for i,x in enumerate([-16.2,-5.4,5.4,16.2]):
 pipe(f'Basin_feed_{i}',(x,2.7,1.9),(x,3.8,1.9),.3)
 B(f'Header_saddle_{i}',(.35,.8,1.5),(x,2.7,.75),'Concrete')
pipe('Train2_main',(20.8,-2,1),(20.8,2.7,1),.3);pipe('Train2_riser',(20.8,2.7,1),(20.8,2.7,1.9),.3)
# Actual vertex-based component measurements and metric planar UV0.
bpy.context.view_layer.update()
def bounds(o):
 v=[o.matrix_world@p.co for p in o.data.vertices];return ([min(p[i] for p in v) for i in range(3)],[max(p[i] for p in v) for i in range(3)])
components=[];lookup={}
for o in objects:
 lo,hi=bounds(o);lookup[o.name]=(lo,hi);components.append({'name':o.name,'min':lo,'max':hi})
 assert lo[0]>=-23.5-1e-5 and hi[0]<=23.5+1e-5 and lo[1]>=-15.5-1e-5 and hi[1]<=15.5+1e-5 and lo[2]>=-1e-5,(o.name,lo,hi)
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
 for p in o.data.polygons:
  n=o.matrix_world.to_3x3()@p.normal;drop=max(range(3),key=lambda i:abs(n[i]));axes=[i for i in range(3) if i!=drop]
  for li in p.loop_indices:
   co=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]*.5,co[axes[1]]*.5)
for w in windows:
 a=w['axis'];t=1-a;s=w['sign'];wl,wh=lookup[w['backing']];pl,ph=lookup[w['pane']];face=wh[a] if s==1 else wl[a]
 for name in w['frame_parts']:
  lo,hi=lookup[name];rear=lo[a] if s==1 else hi[a];assert -.02001<=(rear-face)*s<=.00001
  assert lo[t]>=wl[t]+.12-1e-5 and hi[t]<=wh[t]-.12+1e-5 and lo[2]>=wl[2]+.12 and hi[2]<=wh[2]-.12
  assert pl[a]>=lo[a]-1e-5 and ph[a]<=hi[a]+1e-5
 # Pane lies strictly within the assembled hollow rim.
 fl=[lookup[n] for n in w['frame_parts']];assert pl[t]>=min(v[0][t] for v in fl) and ph[t]<=max(v[1][t] for v in fl)
anchors=[]
for role,target,x,width,clear,height,prefixes in [('pedestrian','Personnel_door_leaf',-9.5,1.2,1.8,2.4,['Personnel_door','Personnel_handle']),('vehicle_service','Service_vehicle_shutter',7.5,4,4,3.5,['Service_vehicle_shutter','Shutter_seam'])]:
 fixtures=[c for c in components if any(c['name'].startswith(p) for p in prefixes)];end=min(c['min'][1] for c in fixtures)-.02
 lo=[x-clear/2,-16,0];hi=[x+clear/2,end,height]
 for c in components:assert not all(min(hi[i],c['max'][i])-max(lo[i],c['min'][i])>1e-6 for i in range(3)),('approach obstruction',c['name'])
 anchors.append({'role':role,'target':target,'xyz_m':[x,lookup[target][0][1],0],'outward':[0,-1,0],'width_m':width,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':clear,'grade_m':0},'reserved_free_corridor':{'min':lo,'max':hi}})
triangles=0
for o in objects:o.data.calc_loop_triangles();triangles+=len(o.data.loop_triangles)
assert triangles<=10000,triangles
# Applied source transforms; preserve first origin at the reservation origin.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
for fn,data in [('material-manifest.json',manifest),('window-mounts.json',{'windows':windows}),('entrance-anchors.json',{'anchors':anchors})]:(out/fn).write_text(json.dumps(data,indent=2))
envelope={'min':[min(c['min'][i] for c in components) for i in range(3)],'max':[max(c['max'][i] for c in components) for i in range(3)]}
(out/'upgrade-stage.json').write_text(json.dumps({'asset_id':'building.service.high.a','stage':'water_high','capacity_percent_reference':300,'module_counts':{'clarifiers':4,'filter_pump_trains':2,'upright_process_vessels':6,'control_wings':2},'occupied_envelope_m':envelope,'base_identity':'parent #157 reviewed worker/control and primary pump-house; original doors retained','review_only':True,'lower_LOD_plan':'Preserve masses, portals, major manifolds; reduce secondary rings, frames and fixtures. No mobile performance claim.'},indent=2))
finish(objects)
# Retain the helper actual checked readback/report, then append focused study validation.
p=out/'validation.json';report=json.loads(p.read_text()) if p.exists() else {}
report.update({'components':components,'source_triangles':triangles,'triangle_ceiling':10000,'semantic_region_count':5,'region_ceiling':5,'window_mount_contact_containment_pass':True,'approach_aabb_pass':True,'plot_inset_pass':True,'units':'metres Z-up','grade_m':0,'review_only':True})
p.write_text(json.dumps(report,indent=2))
# Ensure editable delivered file retains packed maps and CPU settings.
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

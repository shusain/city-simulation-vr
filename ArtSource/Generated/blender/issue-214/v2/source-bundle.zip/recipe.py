import bpy, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import snapshot, digest
objects=load_previous()
# Render-only revision: the completed source is the only geometry input.
def signature(obs):
    records=[]
    for o in obs:
        records.append({'mesh':snapshot(o),'matrix':[list(row) for row in o.matrix_world],'materials':[{'name':m.name,'diffuse':list(m.diffuse_color),'nodes':[(n.name,[(i.name,list(i.default_value) if hasattr(i.default_value,'__len__') else i.default_value) for i in n.inputs if hasattr(i,'default_value') and isinstance(i.default_value,(int,float,bool,str)) or hasattr(i,'default_value') and hasattr(i.default_value,'__len__')]) for n in m.node_tree.nodes] if m.use_nodes else []} for m in o.data.materials]})
    return hashlib.sha256(json.dumps(records,sort_keys=True).encode()).hexdigest()
before=signature(objects)
# Uses the worker's shared scale-normalized preview setup, not the old recipe's lighting.
finish(objects)
assert signature(objects)==before, 'Render-only source preservation failed'
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
camera=scene.camera
original_matrix=camera.matrix_world.copy(); original_type=camera.data.type; original_scale=camera.data.ortho_scale
# All views retain the same shared lighting and exposure from finish().
scene.render.filepath='/output/preview.png';bpy.ops.render.render(write_still=True)
def view(name,position,target,scale):
    camera.data.type='ORTHO';camera.location=position
    camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.ortho_scale=scale
    scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
view('top',(0,0,2),(0,0,0),1.06)
view('side',(0,-2,.18),(0,0,.06),1.06)
# Camera framing covers a common 1 m reference span without adding any mesh.
view('scale_1m',(1.05,-1.6,1.55),(0,0,.03),1.0)
camera.matrix_world=original_matrix;camera.data.type=original_type;camera.data.ortho_scale=original_scale
assert signature(objects)==before
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json'); report=json.loads(p.read_text()) if p.exists() else {}
report['render_only_revision']={'source':'/previous/asset.blend','source_sha256':digest('/previous/asset.blend'),'unchanged_geometry_uv_material_transform_signature':before,'preservation_pass':True,'lighting':'Shared CityRunnerPreview scale-normalized setup used unchanged for all views','samples':12,'device':'CPU','scale_view_vertical_span_m':1.0,'no_mesh_added':True}
p.write_text(json.dumps(report,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 curved washed-up seaweed strands lying in a loose pile','revision':'Render-only lighting review','status':'Unapproved external source review only; no production integration','source_sha256':digest('/previous/asset.blend'),'preserved':'v1 geometry, dimensions, topology, UVs, pivot, transforms and Kelp material values','lighting':'Shared scale-normalized CityRunnerPreview lighting','outputs':['asset.blend','asset.fbx','preview.png','top.png','side.png','scale_1m.png','validation.json'],'scale_reference':'scale_1m is an orthographic view with precisely 1 m vertical span; no calibration geometry added','fbx_sha256':digest('/output/asset.fbx')},indent=2))

import bpy, sys, math, json
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx, digest
# Fresh independent curved-ribbon study, not derived from rejected geometry.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
mat=bpy.data.materials.new('Kelp'); mat.diffuse_color=(.205,.225,.115,1); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=mat.diffuse_color; bs.inputs['Roughness'].default_value=.79
paths=[
[(-.40,-.08,.008),(-.30,-.18,.012),(-.12,-.19,.018),(.04,-.12,.030),(.12,.015,.015)],
[(-.25,.15,.014),(-.12,.205,.018),(.07,.16,.045),(.17,.045,.067),(.35,.015,.012)],
[(-.37,.045,.007),(-.23,.09,.027),(-.08,.025,.067),(.06,-.065,.045),(.25,-.045,.014)],
[(-.10,-.135,.008),(.08,-.17,.016),(.28,-.12,.032),(.39,-.015,.026),(.36,.12,.010)],
[(-.30,.12,.012),(-.24,.015,.046),(-.11,-.045,.078),(.045,.01,.091),(.10,.135,.014)],
[(.00,.19,.012),(.17,.205,.018),(.30,.13,.045),(.24,.015,.060),(.13,-.07,.018)]
]
widths=[.052,.047,.060,.046,.049,.043]
objects=[]
for k,points in enumerate(paths):
    verts=[]; faces=[]
    for i,p in enumerate(points):
        t=Vector(points[min(4,i+1)])-Vector(points[max(0,i-1)]); t.z=0; t.normalize(); n=Vector((-t.y,t.x,0))
        w=widths[k]*[.24,.94,1,.82,.18][i]
        for zoff in (0,.004):
            for side in (-1,1):
                v=Vector(p)+n*(w*.5*side); v.z+=zoff; verts.append(tuple(v))
    for i in range(4):
        a=4*i;b=a+4
        faces.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
    faces.extend([(0,1,3,2),(16,18,19,17)])
    mesh=bpy.data.meshes.new('CurvedRibbon_%02d'%k); mesh.from_pydata(verts,[],faces); mesh.update()
    ob=bpy.data.objects.new('Strand_%02d'%k,mesh); scene.collection.objects.link(ob); mesh.materials.append(mat)
    uv=mesh.uv_layers.new(name='UV0')
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            co=mesh.vertices[mesh.loops[li].vertex_index].co
            uv.data[li].uv=((co.x+.5),co.y+.5)
    objects.append(ob)
# Exact review envelope; ground-center pivot, identity object transforms.
allv=[v for ob in objects for v in ob.data.vertices]
mins=[min(v.co[j] for v in allv) for j in range(3)]; maxs=[max(v.co[j] for v in allv) for j in range(3)]
for v in allv:
    v.co.x=(v.co.x-(mins[0]+maxs[0])/2)*.85/(maxs[0]-mins[0])
    v.co.y=(v.co.y-(mins[1]+maxs[1])/2)*.45/(maxs[1]-mins[1])
    v.co.z=(v.co.z-mins[2])*.12/(maxs[2]-mins[2])
for ob in objects:
    ob.data.update()
finish(objects)
# Preserve the tested scene, add focused multi-view evidence and explicit contract checks.
asset=max((o for o in scene.objects if o.type=='MESH' and any(m and m.name.split('.')[0]=='Kelp' for m in o.data.materials)),key=lambda o:len(o.data.vertices))
asset.name='D108_CurvedSeaweed_ReviewOnly'
asset.data.calc_loop_triangles()
import bmesh
bm=bmesh.new(); bm.from_mesh(asset.data)
boundary=sum(not e.is_manifold for e in bm.edges); bm.free()
assert len(asset.data.loop_triangles)==216
assert boundary==0
assert len(asset.data.materials)==1
assert asset.data.uv_layers.active
with checked_fbx(asset,Path('/output/asset.fbx'),['Kelp'],expected_triangles=216,expected_sections=1) as readback:
    roundtrip={'triangles':len(readback.data.loop_triangles),'dimensions_m':list(readback.dimensions),'passed':True}
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
camera=scene.camera
original_matrix=camera.matrix_world.copy(); original_type=camera.data.type; original_scale=camera.data.ortho_scale
camera.data.type='ORTHO'
def view(name,position,target,scale):
    camera.location=position; camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler(); camera.data.ortho_scale=scale
    scene.render.filepath='/output/'+name+'.png'; bpy.ops.render.render(write_still=True)
view('top',(0,0,2),(0,0,0),1.06)
view('side',(0,-2,.18),(0,0,.06),1.06)
# Temporary real 1 m calibration bar, separate from asset and excluded from source/export.
bpy.ops.mesh.primitive_cube_add(size=1,location=(0,-.37,.012))
bar=bpy.context.object;bar.name='Temporary_1m_scale_bar';bar.dimensions=(1,.012,.012)
view('scale_1m',(1.05,-1.6,1.55),(0,-.06,.03),1.38)
bpy.data.objects.remove(bar,do_unlink=True)
camera.matrix_world=original_matrix;camera.data.type=original_type;camera.data.ortho_scale=original_scale
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json'); prior=json.loads(p.read_text()) if p.exists() else {}
prior['focused_seaweed']={'review_only':True,'strand_count':6,'centerline_points_per_strand':5,'triangles':216,'closed_manifold_components':6,'nonmanifold_edges':boundary,'bounds_m':list(asset.dimensions),'material_slots':[m.name for m in asset.data.materials],'uv0':True,'ground_contact_min_z':min((asset.matrix_world@v.co).z for v in asset.data.vertices),'identity_scale':list(asset.scale),'fbx_readback':roundtrip}
p.write_text(json.dumps(prior,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 curved washed-up seaweed source review','status':'review only; no production promotion','construction':'Six individually authored closed curved ribbons joined for static export; five plan-view stations each; tapered end sections; solid thickness and crossing lifts.','source':'Fresh procedural geometry; no prior rejected mesh reused','centerlines_before_envelope_fit':paths,'material':'Kelp','outputs':['asset.blend','asset.fbx','preview.png','top.png','side.png','scale_1m.png'],'scale_reference':'1 metre temporary bar in scale_1m only; not part of asset','fbx_sha256':digest('/output/asset.fbx')},indent=2))

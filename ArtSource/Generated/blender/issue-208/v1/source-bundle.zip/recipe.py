import bpy, sys, math, json
from mathutils import Vector
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
wood=(0.38,0.20,0.095,1)
cream=(0.88,0.81,0.65,1)
parts=[]
def block(name,dims,loc,fabric=False):
    o=box(name,dims,loc,cream if fabric else wood);parts.append(o);return o
def beam(name,a,b,width,depth=None):
    a,b=Vector(a),Vector(b)
    o=block(name,(width,depth or width,(b-a).length),(a+b)/2)
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
# Long, taut cream sling, with a clearly separated reclining back.
block('Cream foot and seat sling',(.535,1.18,.025),(0,-.43,.375),True)
a=Vector((0,.18,.39));b=Vector((0,.80,.81))
o=block('Cream raised back sling',(.535,(b-a).length,.025),(a+b)/2,True)
o.rotation_euler[0]=math.atan2(b.z-a.z,b.y-a.y)
for x in [-.30,.30]:
    beam('Long side rail',(x,-1.045,.35),(x,.20,.35),.05)
    beam('Back side rail',(x,.16,.365),(x,.83,.82),.05)
    beam('Front splayed leg',(x,-.83,.025),(x,-.65,.35),.05)
    beam('Rear splayed leg',(x,.53,.025),(x,.12,.35),.05)
    beam('Back adjustment prop',(x,.53,.14),(x,.61,.66),.037)
    # Three fixed stops make the static adjustment mechanism legible.
    for y in [.30,.40,.50]:
        block('Adjustment stop',(.065,.035,.035),(x,y,.14))
    h=cylinder('Hinge pin',.047,.074,(x,.18,.36),wood,vertices=8)
    h.rotation_euler[1]=math.pi/2;parts.append(h)
for y,z in [(-.83,.033),(.53,.033),(-1.02,.35),(.18,.35),(.81,.805)]:
    block('Transverse frame tie',(.60,.045,.045),(0,y,z))
# Exactly two shared semantic materials, no separate hardware slot.
materials=[]
for name,color in [('Frame',wood),('Fabric',cream)]:
    m=bpy.data.materials.new(name);m.diffuse_color=color;m.use_nodes=True
    m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=color
    m.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.78
    materials.append(m)
for o in parts:
    is_fabric='sling' in o.name
    o.data.materials.clear();o.data.materials.append(materials[1 if is_fabric else 0])
finish(parts)
# Normalize the delivered study to a ground-contact origin under the seat.
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH' and any(m and m.name in ['Frame','Fabric'] for m in o.data.materials)]
assert len(meshes)==1,[(o.name,o.type) for o in meshes]
asset=meshes[0];asset.name='D108_RecliningBeachLounger_ReviewOnly'
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
asset.data.calc_loop_triangles();tris=len(asset.data.loop_triangles)
assert 220<=tris<=420,tris
assert len(asset.data.materials)==2
# Stable canonical slot order independent of join ordering.
old=list(asset.data.materials);indices=[0 if old[p.material_index].name=='Frame' else 1 for p in asset.data.polygons]
asset.data.materials.clear()
for m in materials:asset.data.materials.append(m)
for p,i in zip(asset.data.polygons,indices):p.material_index=i
with checked_fbx(asset,'/output/asset.fbx',['Frame','Fabric'],expected_triangles=tris,expected_sections=2):pass
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
camera=scene.camera
assert camera is not None
# Additional orthographic inspections use the same neutral studio lighting.
def view(path,position,target,scale):
    camera.location=position;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.type='ORTHO';camera.data.ortho_scale=scale
    scene.render.filepath=path;bpy.ops.render.render(write_still=True)
# Main hero view includes the hinge side and long reclining silhouette.
view('/output/preview.png',(2.6,-3.3,2.2),(0,-.1,.38),2.65)
hero_loc=camera.location.copy();hero_rot=camera.rotation_euler.copy()
view('/output/top.png',(0,-.10,4),(0,-.10,0),2.35)
# Render-only one-metre ruler, deliberately excluded from the asset export.
ruler=box('Review_only_1m_scale',(.012,1,.012),(0,-.40,-.10),(.12,.20,.22,1))
markers=[ruler]
for y in [-.9,-.4,.1]:
    markers.append(box('Scale_tick',(.012,.012,.075),(0,y,-.10),(.12,.20,.22,1)))
view('/output/side_1m_scale.png',(3,-.10,.5),(0,-.10,.34),2.35)
for ob in markers:bpy.data.objects.remove(ob,do_unlink=True)
camera.location=hero_loc;camera.rotation_euler=hero_rot;camera.data.ortho_scale=2.65
scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
validation_path=Path('/output/validation.json')
v=json.loads(validation_path.read_text()) if validation_path.exists() else {}
v['lounger_review']={'triangles':tris,'target_triangles':[220,420],'dimensions_m':list(asset.dimensions),'origin_m':list(asset.location),'materials':['Frame','Fabric'],'fbx_roundtrip_pass':True,'static_only':True,'ground_base':False,'review_only':True,'views':['preview.png','top.png','side_1m_scale.png'],'scale_bar_length_m':1.0,'note':'Scale ruler is review-only and excluded from blend and FBX. No Unreal or device validation performed.'}
validation_path.write_text(json.dumps(v,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 Resident reclining beach lounger','status':'review-only; no production approval','units':'meters','up':'Z','origin':'ground contact centered below seat','asset':'asset.blend','export':'asset.fbx','validation':'validation.json','views':['preview.png','side_1m_scale.png','top.png'],'construction':'Warm wood frame, cream taut sling, fixed raised back, visible hinge pins and adjustment stops; no rig'},indent=2))

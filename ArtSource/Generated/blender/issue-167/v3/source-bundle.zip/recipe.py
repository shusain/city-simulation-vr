import bpy, sys, math, json, shutil, hashlib
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
O=Path('/output'); O.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
objects=[]; groups={}; contacts=[]
def mat(n,c,r,m):
 a=bpy.data.materials.new(n); a.diffuse_color=(*c,1); a.use_nodes=True
 p=a.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1); p.inputs['Roughness'].default_value=r; p.inputs['Metallic'].default_value=m
 return a
blue=mat('Paint_BlueGrey',(.23,.37,.43),.48,.12)
grey=mat('Paint_LightGrey',(.57,.61,.61),.55,.12)
hard=mat('Mechanical',(.12,.14,.15),.55,.7)
tex=[]; (O/'textures').mkdir(exist_ok=True)
nt=hard.node_tree; p=nt.nodes.get('Principled BSDF')
for kind in ['BaseColor','Normal','ORM']:
 src=Path('/repo/ArtSource/Textures/BuildingSurfaces/CityMechanical_'+kind+'.png'); dst=O/'textures'/src.name; shutil.copyfile(src,dst)
 im=bpy.data.images.load(str(dst)); im.colorspace_settings.name='sRGB' if kind=='BaseColor' else 'Non-Color'; im.pack()
 node=nt.nodes.new('ShaderNodeTexImage'); node.image=im
 if kind=='BaseColor': nt.links.new(node.outputs['Color'],p.inputs['Base Color'])
 elif kind=='Normal':
  normal=nt.nodes.new('ShaderNodeNormalMap'); normal.inputs['Strength'].default_value=.35; nt.links.new(node.outputs['Color'],normal.inputs['Color']); nt.links.new(normal.outputs['Normal'],p.inputs['Normal'])
 else:
  sep=nt.nodes.new('ShaderNodeSeparateColor'); nt.links.new(node.outputs['Color'],sep.inputs['Color']); nt.links.new(sep.outputs['Green'],p.inputs['Roughness']); nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
 tex.append(dict(path='textures/'+src.name,sha256=hashlib.sha256(src.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
def keep(o,m,g):
 o.data.materials.clear(); o.data.materials.append(m); objects.append(o); groups.setdefault(g,[]).append(o.name); return o
def bx(n,d,l,m=grey,g='structure'): return keep(box(n,d,l,(*m.diffuse_color,)),m,g)
def cy(n,r,h,l,m=hard,g='riser',v=12): return keep(cylinder(n,r,h,l,(*m.diffuse_color,),vertices=v),m,g)
def beam(n,a,b,w=.15,m=grey,g='braces'):
 a,b=Vector(a),Vector(b); o=bx(n,(w,w,(b-a).length),(a+b)/2,m,g); o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler(); return o
def lathe(n,profile,m,g,N=28):
 vs=[(r*math.cos(2*math.pi*i/N),r*math.sin(2*math.pi*i/N),z) for r,z in profile for i in range(N)]
 fs=[]
 for j in range(len(profile)-1):
  for i in range(N): fs.append((j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i))
 fs.extend([tuple(range(N-1,-1,-1)),tuple((len(profile)-1)*N+i for i in range(N))])
 me=bpy.data.meshes.new(n); me.from_pydata(vs,[],fs); me.update(); ob=bpy.data.objects.new(n,me); bpy.context.collection.objects.link(ob)
 for poly in me.polygons: poly.use_smooth=len(poly.vertices)==4
 return keep(ob,m,g)
def ring(n,r,w,z,h,m=grey,g='bands'):
 return lathe(n,[(r-w,z-h/2),(r,z-h/2),(r,z+h/2),(r-w,z+h/2),(r-w,z-h/2)],m,g)
shell=lathe('Tank_shell',[(3.8,10.2),(3.8,14.5)],blue,'tank_shell')
bottom=lathe('Tank_shallow_conical_bottom',[(.32,8.4),(1.35,8.65),(2.8,9.4),(3.8,10.2)],blue,'tank_bottom')
roof=lathe('Tank_roof',[(3.8,14.5),(2.5,15.0),(.5,15.42),(.0,15.45)],blue,'tank_roof')
support=ring('Load_bearing_support_ring',3.91,.62,10.15,.38,grey,'support_ring')
for z in [10.4,12.35,14.48]: ring('Restrained_seam_'+str(z),3.835,.07,z,.065,blue)
legs=[]
for i,(x,y) in enumerate([(-2.45,-2.45),(2.45,-2.45),(2.45,2.45),(-2.45,2.45)]):
 leg=bx('Leg_'+str(i+1),(.46,.46,10.28),(x,y,5.14),grey,'leg_'+str(i+1)); legs.append(leg)
 bx('Steel_foot_'+str(i+1),(.72,.72,.12),(x,y,.06),hard,'leg_'+str(i+1))
for side in range(4):
 a=legs[side].location; b=legs[(side+1)%4].location
 for lo,hi in [(.7,5.1),(5.1,9.9)]:
  for flip in [False,True]:
   aa=(a.x,a.y,hi if flip else lo); bb=(b.x,b.y,lo if flip else hi)
   br=beam('Crossbrace_%s_%s_%s'%(side,lo,flip),aa,bb,.16)
   contacts.append((br.name,legs[side].name)); contacts.append((br.name,legs[(side+1)%4].name))
 for z in [5.1,9.95]: beam('Tie_%s_%s'%(side,z),(a.x,a.y,z),(b.x,b.y,z),.22)
for leg in legs: contacts.append((leg.name,support.name))
contacts.append((support.name,bottom.name))
cy('Central_riser',.22,8.7,(0,0,4.35))
cy('Valve_body',.36,.6,(0,0,1.15))
for z in [.82,1.48,8.4]: cy('Riser_flange_'+str(z),.36,.09,(0,0,z))
beam('Valve_stem',(0,-.2,1.2),(0,-.68,1.2),.09,hard,'valves')
wheel=ring('Valve_handwheel',.31,.055,0,.06,hard,'valves'); wheel.rotation_euler[0]=math.pi/2; wheel.location=(0,-.7,1.2)
for x in [-.2,.2]: beam('Riser_clamp_support',(x,0,4.8),(x,2.45,5.1),.09,hard,'riser')
bx('Under_tank_service_landing',(1.65,1.1,.16),(0,-3.75,9.0),grey,'landing')
for x in [-.7,.7]:
 beam('Landing_cantilever',(x,-4.3,8.87),(x,-2.45,8.87),.18,grey,'landing')
 beam('Landing_knee',(x,-4.1,8.85),(x,-2.45,7.7),.13,grey,'landing')
 beam('Landing_connection',(x,-2.45,8.87),(-2.45 if x<0 else 2.45,-2.45,8.87),.18,grey,'landing')
 for y in [-4.25,-3.25]: beam('Landing_guard_post',(x,y,9.08),(x,y,10.12),.065,grey,'landing')
 beam('Landing_side_guard',(x,-4.25,10.12),(x,-3.25,10.12),.065,grey,'landing')
beam('Landing_rear_guard',(-.7,-3.25,10.12),(.7,-3.25,10.12),.065,grey,'landing')
for x in [-.4,.4]: bx('Front_ladder_rail_'+str(x),(.085,.085,15.65),(x,-4.62,7.825),grey,'ladder')
for j in range(51): bx('Ladder_rung_%02d'%j,(.87,.075,.065),(0,-4.62,.26+j*.3),hard,'ladder')
for z in [2.7,5.2,7.7,10.2,12.6,14.5]:
 for x in [-.4,.4]: beam('Ladder_standoff',(x,-4.62,z),(x,-2.45 if z<10 else -3.78,z),.075,grey,'ladder')
for z in [3,5,7,11,13,14.8]:
 pts=[(.65*math.cos(math.pi*i/8),-4.62-.65*math.sin(math.pi*i/8),z) for i in range(9)]
 for i in range(8): beam('Cage_hoop',pts[i],pts[i+1],.045,grey,'ladder_cage')
for x in [-.46,.46]: beam('Roof_access_handrail',(x,-4.62,15.65),(x,-2.8,15.65),.065,grey,'roof_access')
bx('Roof_access_walk',(.92,1.85,.12),(0,-3.7,15.05),grey,'roof_access')
for x in [-.35,.35]: beam('Roof_walk_support',(x,-4.45,14.99),(x,-3.45,14.65),.12,grey,'roof_access')
cy('Roof_hatch',.5,.18,(0,-2.5,15.12),hard,'hatch',16)
bx('Hatch_handle',(.36,.075,.08),(0,-2.5,15.25),grey,'hatch')
bpy.ops.object.select_all(action='DESELECT')
for ob in objects:
 ob.select_set(True); bpy.context.view_layer.objects.active=ob; bpy.ops.object.transform_apply(location=False,rotation=True,scale=True); ob.select_set(False)
bpy.context.view_layer.update()
components=[]; trees={}
for ob in objects:
 pts=[ob.matrix_world@v.co for v in ob.data.vertices]
 components.append(dict(name=ob.name,min=[min(v[k] for v in pts) for k in range(3)],max=[max(v[k] for v in pts) for k in range(3)]))
 trees[ob.name]=BVHTree.FromPolygons(pts,[tuple(p.vertices) for p in ob.data.polygons])
 uv=ob.data.uv_layers.active or ob.data.uv_layers.new(name='UVMap')
 for face in ob.data.polygons:
  axis=max(range(3),key=lambda k:abs(face.normal[k])); axes=[k for k in range(3) if k!=axis]
  for li in face.loop_indices:
   v=pts[ob.data.loops[li].vertex_index]; uv.data[li].uv=(v[axes[0]]/2,v[axes[1]]/2)
contact_report=[dict(a=a,b=b,surface_triangle_intersections=len(trees[a].overlap(trees[b]))) for a,b in contacts]
assert all(c['surface_triangle_intersections']>0 for c in contact_report),contact_report
corr={'min':[-.6,-8,0],'max':[.6,-4.72,2.2]}
hits=[c['name'] for c in components if all(c['max'][k]>corr['min'][k] and c['min'][k]<corr['max'][k] for k in range(3))]
assert not hits,hits
assert all(max(abs(c['min'][k]),abs(c['max'][k]))<=7.5 for c in components for k in [0,1])
tri=sum(sum(len(p.vertices)-2 for p in ob.data.polygons) for ob in objects); assert tri<=4500,tri
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
write('entrance-anchors.json',{'anchors':[{'role':'maintenance','target':'Front_ladder_rail_-0.4','xyz_m':[0,-4.72,0],'outward':[0,-1,0],'width_m':1.2,'grade_m':0,'boundary_connector':{'xyz_m':[0,-8,0],'outward':[0,-1,0],'width_m':1.2,'grade_m':0},'reserved_free_corridor':corr}],'all_component_AABB_intersections':hits,'future_connection':'Future service sidewalk reaches the front ladder from the south site boundary; no path geometry authored.'})
write('material-manifest.json',{'maps':tex,'regions':[{'name':'Paint_BlueGrey','base_color':[.23,.37,.43],'roughness':.48,'metallic':.12},{'name':'Paint_LightGrey','base_color':[.57,.61,.61],'roughness':.55,'metallic':.12},{'name':'Mechanical','base_color':'mapped sRGB','roughness':'ORM.G','metallic':'ORM.B','normal_strength':.35,'occlusion':'ORM.R retained, not multiplied into lighting'}],'UV':'face-normal dominant planar projection, 2 metres per repeat','native_reconstruction':'FBX does not preserve node graphs: reconstruct Mechanical with BaseColor sRGB, Normal via tangent Normal Map, ORM linear G roughness B metallic. Painted surfaces use the listed constant Principled parameters.'})
write('landmark-contract.json',{'units':'metres','up':'Z','front':'-Y','site_proposal_m':[16,16],'groups':groups,'components':components,'support_contact_measurement':contact_report,'contact_method':'Applied world-space mesh triangle BVH surface overlap, actual intersecting triangle-pair counts; no contact flags substituted.','access_positions':{'grade':[0,-4.72,0],'landing_side_step':[0,-4.25,9.08],'external_roof_ladder_top':[0,-4.62,15.05],'roof_hatch':[0,-2.5,15.21]},'ladder_opening':'Landing begins at Y -4.30; ladder centre Y -4.62 has no landing floor across climb. Side-step inward onto deck.','lod_plan':{'LOD1':'Remove cage, alternate ladder rungs, wheel and hatch handle; tank 16 sides, omit middle seam, retain all four legs and diagonal silhouette.','LOD2':'Use preserved original low-poly tower as historical starting point, retaining new bracing silhouette and proposed scale; separate future reviewed work.'},'review_status':'SOURCE REVIEW ONLY; no production or catalog changes'})
bpy.context.scene.cursor.location=(0,0,0)
bpy.context.view_layer.objects.active=objects[0]; objects[0].select_set(True); bpy.ops.object.origin_set(type='ORIGIN_CURSOR'); objects[0].select_set(False)
finish(objects)
p=O/'validation.json'; data=json.loads(p.read_text()) if p.exists() else {}
data.update({'components':components,'authored_triangles':tri,'semantic_regions':3,'site_proposal_m':[16,16],'source_identity':{'sha':'2b0beb7e2b38627804aabcac6e6b50bcf4dc54d4','context':'ArtSource/Blender/CityParkIntegration.blend:SM_Building_WaterTower_A.001','new_original_geometry':True},'support_contacts':contact_report,'approach_intersections':hits,'UV0_finite':all(math.isfinite(t) for ob in bpy.data.objects if ob.type=='MESH' for uv in ob.data.uv_layers for v in uv.data for t in v.uv),'review_only':True})
write('validation.json',data)

import sys, math, json
sys.path.insert(0,'/worker')
import bpy
from mathutils import Vector
from CityRunnerPreview import load_previous, box, cylinder, finish
objects=load_previous()
# Preserve approved v1 assembly. Add only a visible, mounted water-delivery system.
original_counts={o.name:len(o.data.vertices) for o in objects if o.type=='MESH'}
mats={m.name.split('.')[0]:m for o in objects for m in o.data.materials if m}
def material(name,col,rough,metal):
 m=bpy.data.materials.new(name);m.diffuse_color=col;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 mats[name]=m;return m
material('HoseJacket',(.105,.12,.105,1),.72,0)
material('CouplingBrass',(.48,.30,.095,1),.32,.7)
added=[]
def style(o,mat):
 o.data.materials.clear();o.data.materials.append(mats[mat]);added.append(o);return o
def B(name,d,p,mat):
 o=style(box(name,d,p,(.3,.3,.3,1)),mat)
 mod=o.modifiers.new('Small edge bevel','BEVEL');mod.width=.015;mod.segments=2
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 return o
def tube(name,a,b,r,mat,verts=20):
 a,b=Vector(a),Vector(b)
 o=cylinder(name,r,(b-a).length,(a+b)/2,(.3,.3,.3,1),vertices=verts)
 o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
 style(o,mat)
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 return o
def hose(name,coords,r,mat):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=12;c.bevel_depth=r;c.bevel_resolution=2
 s=c.splines.new('BEZIER');s.bezier_points.add(len(coords)-1)
 for p,co in zip(s.bezier_points,coords):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o)
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');style(o,mat)
 return o
# Monitor occupies front-left equipment-roof corner, clear of secured center ladder.
B('MonitorMountingPlate',(.53,.49,.08),(.35,-.84,2.94),'MetalTrim')
tube('MonitorSwivelPedestal',(.35,-.84,2.97),(.35,-.84,3.22),.145,'BodyPaint')
tube('MonitorSwivelCollar',(.35,-.84,3.10),(.35,-.84,3.17),.18,'MetalTrim')
hose('MonitorElbow',[(.35,-.84,3.17),(.35,-.84,3.40),(.51,-.84,3.51),(.72,-.84,3.57)],.102,'BodyPaint')
tube('WaterCannonBarrel',(.67,-.84,3.55),(1.05,-.84,3.68),.103,'MetalTrim')
tube('NozzleGrip',(.84,-.84,3.61),(1.03,-.84,3.68),.116,'Rubber')
tube('NozzleTip', (1.03,-.84,3.68),(1.23,-.84,3.75),.084,'CouplingBrass')
# Dark inset aperture gives the forward nozzle an unmistakably open-mouth read.
tube('NozzleMouth', (1.231,-.84,3.750),(1.237,-.84,3.752),.061,'PumpPanel')
hose('MonitorControlHandle',[(.48,-.84,3.42),(.45,-1.04,3.43),(.11,-1.04,3.31)],.026,'MetalTrim')
tube('ControlGrip',(.12,-1.04,3.32),(-.02,-1.04,3.27),.039,'Rubber')
# Connected supply hose from visible pump outlet up to monitor; clipped, not floating.
hose('ConnectedSupplyHose',[(-.13,-1.39,1.83),(.12,-1.47,1.80),(.52,-1.45,1.94),(.61,-1.38,2.43),(.59,-1.26,2.88),(.49,-1.06,3.05),(.35,-.87,3.08)],.065,'HoseJacket')
tube('SupplyOutletCollar',(-.13,-1.32,1.83),(-.13,-1.45,1.83),.096,'CouplingBrass')
for z in (2.18,2.62):
 B('HoseRetentionBracket',(.22,.13,.065),(.59,-1.35,z),'MetalTrim')
# New UV0 only; leave all original v1 vertices, UVs and materials untouched.
bpy.ops.object.select_all(action='DESELECT')
for o in added:o.select_set(True)
bpy.context.view_layer.objects.active=added[0]
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.025);bpy.ops.object.mode_set(mode='OBJECT')
finish(objects+added)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=8
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera;target=Vector((0,0,1.8));cam.data.type='ORTHO';cam.data.ortho_scale=9.6
for label,pos in [('side',(0,-14,1.8)),('front',(14,0,1.8)),('rear',(-14,0,1.8))]:
 cam.location=pos;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath='/output/'+label+'.png';bpy.ops.render.render(write_still=True)
cam.location=(11,-14,10);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=10
scene.render.filepath='/output/preview.png';bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p='/output/validation.json'
with open(p) as f:report=json.load(f)
report['revision']='Preserved v1 fire engine; added mounted forward water monitor, open nozzle, control handle and connected clipped supply hose. Review only; no water effect or runtime behavior.'
report['preserved_source_vertex_counts_before_join']=original_counts
report['material_semantics']={'Glass':'Unchanged opaque glossy blue-gray windows','HoseJacket':'Opaque rubberized supply hose','CouplingBrass':'Metal nozzle and pump coupling','Taillight':'Unchanged red lenses; no animation'}
report['additional_views']=['side.png','front.png','rear.png']
report['coordinate_contract']='+X nose, +Z up, ground z=0, metric; original assembly preserved'
with open(p,'w') as f:json.dump(report,f,indent=2)

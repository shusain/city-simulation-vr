import sys, math, json
sys.path.insert(0,'/worker')
import bpy
from mathutils import Vector
from CityRunnerPreview import box, cylinder, finish
# Isolated issue-owned v1 study; no production sources are executed or changed.
parts=[]
palette={
'BodyPaint':((.65,.025,.018,1),.32,.0),
'Glass':((.027,.075,.105,1),.18,.15),
'Rubber':((.018,.022,.027,1),.74,0),
'MetalTrim':((.48,.55,.59,1),.3,.75),
'LockerMetal':((.30,.36,.39,1),.48,.55),
'WarmWhite':((.85,.86,.76,1),.35,0),
'Headlight':((1,.86,.57,1),.22,.1),
'Taillight':((.85,.012,.008,1),.23,.1),
'PumpPanel':((.065,.085,.095,1),.46,.25)}
mats={}
for name,(color,rough,metal) in palette.items():
 m=bpy.data.materials.new(name);m.diffuse_color=color;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=color;p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 mats[name]=m

def style(o,mat,bevel=0):
 o.data.materials.clear();o.data.materials.append(mats[mat]);parts.append(o)
 if bevel:
  mod=o.modifiers.new('Restrained edge chamfer','BEVEL');mod.width=bevel;mod.segments=2
  bpy.context.view_layer.objects.active=o
  bpy.ops.object.modifier_apply(modifier=mod.name)
 return o

def B(n,d,l,m='BodyPaint',b=.025):return style(box(n,d,l,palette[m][0]),m,b)
def C(n,r,dep,l,m='MetalTrim',axis='Y',v=24):
 o=cylinder(n,r,dep,l,palette[m][0],vertices=v)
 if axis=='Y':o.rotation_euler.x=math.pi/2
 elif axis=='X':o.rotation_euler.y=math.pi/2
 bpy.context.view_layer.objects.active=o;o.select_set(True)
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 style(o,m)
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 return o
# Chassis and distinct crew cab / equipment body.
B('Frame',(7.0,1.65,.25),(0,0,.79),'PumpPanel')
B('CrewCabLower',(2.65,2.38,.72),(2.12,0,1.43))
B('CrewCabGlazingCore',(2.57,2.32,1.13),(2.13,0,2.33))
B('CabRoof',(2.78,2.44,.16),(2.12,0,2.94),'WarmWhite',.055)
B('EquipmentBody',(4.48,2.36,1.56),(-1.49,0,2.00),b=.045)
B('EquipmentRoof',(4.53,2.4,.12),(-1.49,0,2.83),'BodyPaint')
# Windows remain opaque, glossy, distinctly framed.
for y in (-.575,.575):
 B('DividedWindshield',(.035,1.075,.91),(3.432,y,2.35),'Glass',.025)
for s in (-1,1):
 for x,w in ((2.66,1.04),(1.47,.91)):
  B('CrewSideWindow',(w,.035,.82),(x,s*1.172,2.36),'Glass',.035)
 B('DoorSplit',(.025,.025,.73),(2.10,s*1.202,1.43),'PumpPanel',.002)
 for x in (1.40,2.63):B('DoorHandle',(.23,.055,.055),(x,s*1.23,1.86),'MetalTrim',.014)
 B('CabStripe',(2.55,.035,.16),(2.10,s*1.204,1.64),'WarmWhite',.005)
 B('MirrorStem',(.14,.24,.05),(3.20,s*1.29,2.14),'MetalTrim',.008)
 B('Mirror',(.13,.12,.30),(3.20,s*1.43,2.29),'PumpPanel',.025)
# Fender bands and wheels, lower body deliberately avoids tire volume.
for x in (-2.43,2.30):
 for s in (-1,1):
  C('Tire',.57,.31,(x,s*1.09,.57),'Rubber',v=32)
  C('Sidewall',.47,.028,(x,s*1.258,.57),'Rubber',v=32)
  C('WheelRim',.315,.045,(x,s*1.28,.57),'MetalTrim')
  C('Hub',.14,.075,(x,s*1.31,.57),'LockerMetal')
  for a in range(6):
   t=a*math.tau/6;C('Lug',.026,.025,(x+.225*math.sin(t),s*1.313,.57+.225*math.cos(t)),'PumpPanel',v=8)
  B('FenderTop',(1.35,.17,.11),(x,s*1.20,1.20),'BodyPaint',.035)
for s in (-1,1):
 B('CrewStep',(1.07,.27,.13),(1.16,s*1.15,.71),'MetalTrim')
 B('RearSkirt',(.53,.13,.39),(-3.44,s*1.14,1.01))
 B('CenterSkirt',(2.85,.13,.38),(-.46,s*1.14,1.02))
 # Locker frames, recessed roll-up faces and readable slat cues.
 for x,w in ((-2.88,1.21),(-1.48,1.24)):
  B('LockerFrame',(w+.09,.065,1.24),(x,s*1.195,2.02),'WarmWhite',.018)
  B('RollUpLocker',(w,.045,1.15),(x,s*1.238,2.02),'LockerMetal',.01)
  for z in (1.60,1.83,2.06,2.29,2.52):B('LockerSlat',(w-.03,.018,.017),(x,s*1.268,z),'MetalTrim',.002)
  B('LockerHandle',(.31,.065,.045),(x,s*1.28,1.57),'MetalTrim',.008)
 B('PumpRecess',(.83,.06,1.18),(-.30,s*1.21,2.01),'PumpPanel',.018)
 for x,z in ((-.53,2.34),(-.12,2.34)):
  C('GaugeBezel',.103,.035,(x,s*1.26,z),'MetalTrim',v=16)
  C('GaugeFace',.077,.042,(x,s*1.28,z),'WarmWhite',v=16)
 for x in (-.55,-.13):
  C('HoseCoupling',.11,.13,(x,s*1.29,1.83),'MetalTrim',v=12)
  B('ValveLever',(.17,.04,.045),(x,s*1.38,2.05),'Taillight',.008)
# Front grille and lens clusters.
B('FrontBumper',(.28,2.48,.25),(3.61,0,.88),'MetalTrim',.035)
B('Grille',(.05,1.28,.51),(3.46,0,1.43),'PumpPanel',.015)
for z in (1.24,1.35,1.46,1.57,1.68):B('GrilleBar',(.065,1.22,.035),(3.50,0,z),'MetalTrim',.006)
for s in (-1,1):
 B('HeadlightBezel',(.07,.41,.31),(3.47,s*.94,1.40),'MetalTrim',.025)
 B('HeadlightLens',(.085,.33,.23),(3.51,s*.94,1.42),'Headlight',.025)
 B('FrontMarker',(.07,.25,.08),(3.51,s*.94,1.69),'Taillight',.015)
B('RearBumper',(.22,2.49,.22),(-3.75,0,.72),'MetalTrim')
B('RearLocker',(.055,1.65,1.25),(-3.757,0,2.01),'LockerMetal')
for s in (-1,1):
 B('RearLampHousing',(.07,.25,.56),(-3.76,s*.99,1.34),'PumpPanel')
 B('RearRedLens',(.09,.20,.28),(-3.80,s*.99,1.46),'Taillight',.025)
 B('ReverseLens',(.09,.20,.13),(-3.80,s*.99,1.20),'Headlight',.015)
# Modest roof lamps, not giant cubes.
B('LightbarBase',(.34,1.66,.08),(2.35,0,3.065),'PumpPanel')
for y,m in ((-.60,'Taillight'),(0,'Headlight'),(.60,'Taillight')):
 B('RoofEmergencyLens',(.29,.44,.19),(2.35,y,3.19),m,.055)
# Secured ladder on raised saddles above rear roof.
for x in (-2.93,-.12):
 B('LadderSaddle',(.17,1.05,.16),(x,0,2.97),'PumpPanel')
 for y in (-.46,.46):B('RetentionClamp',(.14,.16,.18),(x,y,3.14),'BodyPaint',.018)
for y in (-.40,.40):B('LadderRail',(4.05,.09,.13),(-1.60,y,3.14),'MetalTrim',.012)
for i in range(12):B('LadderRung',(.065,.78,.07),(-3.47+i*.34,0,3.14),'MetalTrim',.01)
# Applied transforms and clean nonoverlapping UV0 on the entire mesh assembly.
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.025);bpy.ops.object.mode_set(mode='OBJECT')
finish(parts)
# Additional uncropped orthographic review angles using runner's studio scene.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=8
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera;target=Vector((0,0,1.6));cam.data.type='ORTHO';cam.data.ortho_scale=9.3
for label,pos in [('side',(0,-14,3.0)),('front',(14,0,3.0)),('rear',(-14,0,3.0))]:
 cam.location=pos;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath='/output/'+label+'.png';bpy.ops.render.render(write_still=True)
# Keep the editable source camera on the primary isometric presentation.
cam.location=(11,-14,10);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=10
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p='/output/validation.json'
with open(p) as f:report=json.load(f)
report['review_scope']='Fire engine v1 source study only; no production promotion or native acceptance.'
report['material_semantics']={'Glass':'Opaque dark blue-gray glossy glass; remap to native vehicle glass later.','Taillight':'Red emergency and rear lenses; no flashing or animation in study.','Headlight':'Warm-white front and central roof lenses; no runtime light claim.'}
report['coordinate_contract']='+X nose; +Z up; ground z=0; metric applied transforms'
report['additional_views']=['side.png','front.png','rear.png']
with open(p,'w') as f:json.dump(report,f,indent=2)

import sys, math, json
from pathlib import Path
import bpy
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
objects=load_previous()
originals=list(objects)
materials={m.name.split('.')[0]:m for o in objects for m in o.data.materials if m}
# Additive revision only: preserve the complete approved-for-review v2 assembly.
mat=bpy.data.materials.new('ProtectiveBar_DarkSteel'); mat.diffuse_color=(.065,.082,.10,1); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=mat.diffuse_color; bs.inputs['Metallic'].default_value=.65; bs.inputs['Roughness'].default_value=.33
added=[]
def tube(name,a,b,r=.034):
 a,b=Vector(a),Vector(b); d=b-a
 bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r,depth=d.length,end_fill_type='NGON',location=(a+b)*.5)
 o=bpy.context.object; o.name=name; o.rotation_euler=d.to_track_quat('Z','Y').to_euler(); o.data.materials.append(mat)
 for p in o.data.polygons: p.use_smooth=len(p.vertices)==4
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 added.append(o); return o
# Twin upright push bars and crossrails, low enough to leave lamps visible.
# Angled returns tie the guards back to the existing bumper rather than floating.
for label,sgn,bumper,outer in [('Front',1,2.49,2.67),('Rear',-1,-2.37,-2.54)]:
 top=.94 if sgn==1 else .88
 for y in (-.48,.48):
  pts=[(bumper,y,.40),(outer,y,.46),(outer,y,top-.06),(outer-sgn*.06,y,top),(bumper,y,top)]
  for i in range(len(pts)-1): tube(label+'_PushUpright_'+str(y)+'_'+str(i),pts[i],pts[i+1],.039)
 for z in (.49,.73):
  # Full-width but restrained: rear/front lenses at outer corners stay exposed.
  pts=[(bumper,-.78,z),(outer,-.67,z),(outer,.67,z),(bumper,.78,z)]
  for i in range(3): tube(label+'_CrossRail_'+str(z)+'_'+str(i),pts[i],pts[i+1],.032)
 # Compact bumper brackets, clearly separate from lens geometry.
 for y in (-.48,.48):
  tube(label+'_Mount', (bumper-sgn*.055,y,.51),(outer,y,.51),.046)
# UV only new geometry: existing source topology, normals and UVs are unchanged.
bpy.ops.object.select_all(action='DESELECT')
for o in added: o.select_set(True)
bpy.context.view_layer.objects.active=added[0]
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.uv.smart_project(island_margin=.025); bpy.ops.object.mode_set(mode='OBJECT')
objects.extend(added)
finish(objects)
scene=bpy.context.scene; scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=8
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
cam=scene.camera
for name,pos,scale in [('side',(0,-8,.9),6.1),('front',(8,0,.90),3.3),('rear',(-8,0,.90),3.3),('rear_isometric',(-7,-8,5),6.1)]:
 cam.location=pos; cam.rotation_euler=(Vector((0,0,.87))-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.type='ORTHO'; cam.data.ortho_scale=scale
 scene.render.filepath='/output/'+name+'.png'; bpy.ops.render.render(write_still=True)
p=Path('/output/validation.json'); facts=json.loads(p.read_text())
facts['revision']={'source':'/previous/asset.blend','scope':'Review-only v3, additive front and rear protective bars; no production changes or approval handoff','preservation':'Loaded v2 unchanged; added guard geometry only, original materials and UVs retained','bars':'Dark steel tubular push guards, paired uprights, twin crossrails and bumper returns at each end','guard_tube_radius_m':[.032,.039,.046],'glass':'Original opaque glossy blue-gray retained; native remapping pending','emergency_lenses':'Original red/blue semantic lenses retained; native remapping pending','views':['preview.png','side.png','front.png','rear.png','rear_isometric.png'],'acceptance':'Human source review pending; no game rendering or headset acceptance claimed'}
p.write_text(json.dumps(facts,indent=2))

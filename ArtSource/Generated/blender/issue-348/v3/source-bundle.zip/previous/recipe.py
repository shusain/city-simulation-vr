import sys, math, json
from pathlib import Path
import bpy
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, box, finish
objects=load_previous()
# Edit the reviewed mesh in place, preserving cabin, livery and lighting assembly.
wheel_components=0
for obj in objects:
 if obj.type!='MESH': continue
 me=obj.data
 adjacency=[[] for v in me.vertices]
 for e in me.edges:
  a,b=e.vertices; adjacency[a].append(b); adjacency[b].append(a)
 remaining=set(range(len(me.vertices)))
 while remaining:
  seed=remaining.pop(); group=[seed]; todo=[seed]
  while todo:
   for j in adjacency[todo.pop()]:
    if j in remaining: remaining.remove(j); group.append(j); todo.append(j)
  coords=[obj.matrix_world @ me.vertices[i].co for i in group]
  lo=Vector(tuple(min(v[k] for v in coords) for k in range(3))); hi=Vector(tuple(max(v[k] for v in coords) for k in range(3)))
  center=(lo+hi)*.5
  wheel=(min(abs(center.x+1.47),abs(center.x-1.43))<.39 and abs(center.y)>.72 and hi.z<.73 and lo.z<.70)
  if wheel:
   wheel_components+=1
   shift=Vector((0,-math.copysign(.085,center.y),0))
   for i in group: me.vertices[i].co += obj.matrix_world.inverted().to_3x3() @ shift
  else:
   # Extend only the existing nose/hood surfaces and front fascia, not cabin.
   for i in group:
    v=me.vertices[i]; w=obj.matrix_world @ v.co
    if w.x>1.10 and w.z<1.045:
     w.x+=.13*min(1.05,(w.x-1.10)/1.25)
     v.co=obj.matrix_world.inverted() @ w
 me.update()
materials={m.name.split('.')[0]:m for o in objects for m in o.data.materials if m}
navy=materials['BodyPaint_Navy']; metal=materials['MetalTrim']; dark=materials['Grille']; red=materials['Taillight']
def mesh(name,verts,faces,mat):
 data=bpy.data.meshes.new(name); data.from_pydata(verts,[],faces); data.update()
 o=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(o); data.materials.append(mat); objects.append(o); return o
def cube(name,dims,loc,mat,bevel=.012):
 o=box(name,dims,loc,tuple(mat.diffuse_color)); o.data.materials.clear(); o.data.materials.append(mat); objects.append(o)
 if bevel:
  mod=o.modifiers.new('Restrained creases','BEVEL'); mod.width=bevel; mod.segments=2
  bpy.context.view_layer.objects.active=o; bpy.ops.object.modifier_apply(modifier=mod.name)
 return o
# Four substantial painted wheel-arch lips bridge the body sides to inset tires.
for x in (-1.47,1.43):
 for s in (-1,1):
  verts=[]; count=21
  for y,r in [(s*.875,.425),(s*.965,.425),(s*.965,.487),(s*.875,.487)]:
   for j in range(count):
    a=math.pi*j/(count-1)
    verts.append((x+r*math.cos(a),y,.355+r*math.sin(a)))
  faces=[]
  for k in range(4):
   for j in range(count-1): faces.append((k*count+j,k*count+j+1,((k+1)%4)*count+j+1,((k+1)%4)*count+j))
  faces.extend([(0,count,2*count,3*count),(count-1,4*count-1,3*count-1,2*count-1)])
  mesh('IntegratedPaintedFender',verts,faces,navy)
# Broad lower front intake and a restrained rear deck edge give the ends distinct readings.
cube('FrontLowerAirDam',(.075,1.30,.09),(2.49,0,.385),dark,.018)
cube('RearDeckLip',(.16,1.59,.045),(-2.13,0,.94),navy,.016)
cube('RearRecess',(.025,.68,.135),(-2.337,0,.697),dark,.009)
cube('RearReflectorLeft',(.027,.20,.04),(-2.372,-.65,.485),red,.007)
cube('RearReflectorRight',(.027,.20,.04),(-2.372,.65,.485),red,.007)
# UV0 is regenerated on the edited assembly; all original semantic materials retained.
bpy.ops.object.select_all(action='DESELECT')
for o in objects: o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.object.join(); asset=bpy.context.object; asset.name='PolicePatrolCar_Study_v2'
bpy.context.scene.cursor.location=(0,0,0); bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.uv.smart_project(island_margin=.025); bpy.ops.object.mode_set(mode='OBJECT')
finish([asset])
scene=bpy.context.scene; scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=8
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
cam=scene.camera
for name,pos,scale in [('side',(0,-8,.88),5.7),('front',(8,0,.87),3.2),('rear',(-8,0,.87),3.2)]:
 cam.location=pos; cam.rotation_euler=(Vector((0,0,.87))-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.type='ORTHO'; cam.data.ortho_scale=scale
 scene.render.filepath='/output/'+name+'.png'; bpy.ops.render.render(write_still=True)
p=Path('/output/validation.json'); facts=json.loads(p.read_text())
asset.data.calc_loop_triangles()
facts['revision']={'source':'/previous/asset.blend','scope':'Review-only v2; original assembly edited, no production updates or approval.','changes':['Wheel assemblies inset 0.085 m per side','Four painted arch lips added','Existing hood/nose extended 0.13 m with broad lower intake','Rear deck lip, recessed rear fascia and red bumper reflectors added'],'wheel_components_adjusted':wheel_components,'triangles':len(asset.data.loop_triangles),'dimensions_m':list(asset.dimensions),'uv0':bool(asset.data.uv_layers),'materials':[m.name for m in asset.data.materials],'glass':'Opaque glossy blue-gray; native remapping pending','emergency_lenses':'Separate red/blue opaque glossy lenses; native remapping pending','views':['preview.png','side.png','front.png','rear.png'],'acceptance':'Human source review pending; no game or headset claims'}
p.write_text(json.dumps(facts,indent=2))

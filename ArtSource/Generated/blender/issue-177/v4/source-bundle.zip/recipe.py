import bpy,sys,json,hashlib,shutil,math
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
objects=load_previous()
D=Vector((-1.8,0,.12));targets={'AttachedCivicShield','ShieldCentralRelief'}
components=[];before={};members={};changed=set();allnames=set()
for ob in objects:
 assert ob.type=='MESH' and not ob.modifiers
 assert all(abs(ob.matrix_world[i][j]-(1 if i==j else 0))<1e-6 for i in range(4)for j in range(4))
 before[ob.name]=[tuple(v.co)for v in ob.data.vertices]
 groups={g.index:g.name for g in ob.vertex_groups}
 for v in ob.data.vertices:
  names=[groups[g.group]for g in v.groups if g.weight>.5]
  assert len(names)==1,(v.index,names)
  name=names[0];allnames.add(name);members.setdefault(name,[]).append((ob,v.index))
  if name in targets:v.co+=D;changed.add(name)
 ob.data.update()
assert changed==targets and len(allnames)==217
for name,items in members.items():
 pts=[ob.matrix_world@ob.data.vertices[i].co for ob,i in items]
 components.append(dict(name=name,min=[min(p[j]for p in pts)for j in range(3)],max=[max(p[j]for p in pts)for j in range(3)]))
 ob=items[0][0];inds={i for x,i in items};adj={i:set()for i in inds}
 for e in ob.data.edges:
  a,b=e.vertices
  if a in inds and b in inds:adj[a].add(b);adj[b].add(a)
 seen=set();todo=[next(iter(inds))]
 while todo:
  i=todo.pop()
  if i not in seen:seen.add(i);todo.extend(adj[i]-seen)
 assert seen==inds,name
for ob in objects:
 for v,old in zip(ob.data.vertices,before[ob.name]):
  name=next(ob.vertex_groups[g.group].name for g in v.groups if g.weight>.5)
  expected=Vector(old)+(D if name in targets else Vector((0,0,0)))
  assert(v.co-expected).length<1e-6
 assert ob.data.uv_layers.active
 assert all(math.isfinite(x)for uv in ob.data.uv_layers.active.data for x in uv.uv)
C={c['name']:c for c in components}
bpy.ops.mesh.primitive_cube_add(size=1,location=(-11.8,-5.025,3.8))
mount=bpy.context.object;mount.name='BadgeMountSpacer';mount.dimensions=(.2,.07,.4)
bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
mount.data.materials.append(bpy.data.materials['ServiceAccent'])
uv=mount.data.uv_layers.active or mount.data.uv_layers.new(name='UV0')
vg=mount.vertex_groups.new(name=mount.name);vg.add(list(range(len(mount.data.vertices))),1,'REPLACE')
bpy.context.view_layer.update();points=[mount.matrix_world@v.co for v in mount.data.vertices]
part=dict(name=mount.name,min=[min(v[k]for v in points)for k in range(3)],max=[max(v[k]for v in points)for k in range(3)])
objects.append(mount);components.append(part);C[mount.name]=part
def bb(n):return[C[n]['min'],C[n]['max']]
occupied={k:[f(c[k][j]for c in components)for j in range(3)]for k,f in[('min',min),('max',max)]}
assert abs(occupied['min'][2])<1e-6
for c in components:assert c['min'][0]>=-19.5 and c['max'][0]<=19.5 and c['min'][1]>=-15.5 and c['max'][1]<=15.5
windows=[];doors=[]
for name in sorted(C):
 if not(name.endswith('Pane')or name.endswith('Leaf')):continue
 glass=name.endswith('Pane');stem=name[:-4];parts=[stem+s for s in['JambL','JambR','Head']+(['Sill']if glass else[])]
 assert all(n in C for n in parts)
 wall='HighThirdFloor' if stem.startswith('Third')else 'ResponseGarage' if stem.startswith(('Bay','Garage'))else 'AdminTwoFloors'
 axis=0 if('West' in stem or 'East' in stem)else 1
 sign=1 if('Rear' in stem or 'East' in stem)else-1
 face=C[wall]['max' if sign>0 else 'min'][axis]
 r=dict(pane=name,frame_parts=parts,backing=wall,axis=axis,sign=sign,wall_face=face,pane_bounds=bb(name),frame_bounds=[bb(n)for n in parts])
 (windows if glass else doors).append(r)
assert len(windows)==30
separations=[]
for n in targets:
 a=bb(n)
 assert a[0][1]<-5 and a[1][1]>=-5.16
 for w in windows:
  if w['axis']!=1 or w['sign']!=-1:continue
  for q in[w['pane']]+w['frame_parts']:
   b=bb(q)
   if abs(w['wall_face']+5)>.02:continue
   gap=max(b[0][0]-a[1][0],a[0][0]-b[1][0],b[0][2]-a[1][2],a[0][2]-b[1][2])
   assert gap>0,(n,q,gap)
   separations.append(dict(badge=n,window_part=q,projected_axis_separation_m=gap))
assert C['AttachedCivicShield']['min'][2]>C['EntryCanopy']['max'][2]
anchors=[];bays=[]
for i,x in enumerate([2,8,14]):
 bays.append(dict(id='bay'+str(i+1),target='Bay'+str(i+1)+'Leaf',xyz_m=[x,-5.15,0],outward=[0,-1,0],width_m=4.5,height_m=3.6,boundary_connector={'xyz_m':[x,-16,0]},reserved_free_corridor={'min':[x-2.25,-16,0],'max':[x+2.25,-5.15,3.6]}))
for role,x,width,height,target in[('pedestrian',-10,1.9,2.4,'PublicDoubleDoorLeaf'),('service',2,4.5,3.6,'Bay1Leaf')]:
 anchors.append(dict(role=role,target=target,xyz_m=[x,-5.15,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-16,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor={'min':[x-width/2,-16,0],'max':[x+width/2,-5.15,height]}))
for r in anchors+bays:
 a=r['reserved_free_corridor']
 for c in components:assert not all(min(a['max'][j],c['max'][j])-max(a['min'][j],c['min'][j])>1e-6 for j in range(3))
tex=O/'textures';tex.mkdir(exist_ok=True);maps=[]
for folder,stem in[('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for ch in['BaseColor','Normal','ORM']:
  p=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+ch+'.png');q=tex/p.name;shutil.copyfile(p,q)
  imgs=[im for im in bpy.data.images if Path(im.filepath).name==p.name or im.name.split('.')[0]==p.stem]
  if not imgs:imgs=[im for im in bpy.data.images if im.name.startswith(p.name)]
  assert imgs,p.name
  for im in imgs:
   im.filepath=str(q);assert im.colorspace_settings.name==('sRGB' if ch=='BaseColor' else 'Non-Color');im.pack()
  maps.append(dict(file='textures/'+p.name,sha256=hashlib.sha256(q.read_bytes()).hexdigest(),dimensions=list(imgs[0].size),colorspace=imgs[0].colorspace_settings.name))
def preserve(n,fallback):
 p=Path('/previous')/n
 if p.exists():shutil.copyfile(p,O/n)
 else:write(n,fallback)
preserve('window-mounts.json',dict(windows=windows,doors=doors));preserve('entrance-anchors.json',dict(anchors=anchors));preserve('vehicle-bays.json',dict(bays=bays))
recipes=[]
for name,stem,tint,rough,metal in[('CivicBrick','CityBrick',[.57,.43,.33,1],.78,0),('LightStone',None,[.78,.71,.56,1],.8,0),('RoofMembrane','RoofMembrane',[.16,.20,.25,1],.85,0),('EquipmentMetal','CityMechanical',[.48,.52,.56,1],.5,.65),('WindowGlass',None,[.15,.25,.31,1],.32,0),('ServiceAccent',None,[.065,.13,.22,1],.6,0)]:
 recipes.append(dict(region=name,texture_family=stem,tint_multiply=tint,roughness_constant=rough,metallic_constant=metal,orm={'R':'AO multiplied before tint','G':'roughness','B':'metallic'},normal_strength=.25,transmission=0,uv='UV0 world planar dominant face projection / 2m'))
preserve('material-manifest.json',dict(maps=maps,materials=recipes,semantic_region_count=6))
preserve('upgrade-plan.json',dict(family='police',stage='high',stage_index=2,existing_stages=['base','medium','high'],existing_upgrade_count=2,gameplay_changes=False,source_site_m=[40,32],current_native_footprint=[3,2],retained_entrance_centres=[[-10,-5],[2,-5]],progression='Third compact office floor and three functional response bays; no vehicles or future stages.',occupied_bounds=occupied,LOD1='Simplify four-bar rims and relief and remove section ribs.',LOD2='Collapse roof equipment and emblem; retain entrances and massing.'))
source=Path('/previous/recipe.py').read_text();groups={k:[]for k in['admin','garage','body','roof','entry','windows','emblem','equipment']}
for n in C:
 if n in targets or n=='BadgeMountSpacer':k='emblem'
 elif any(n==w['pane']or n in w['frame_parts']for w in windows):k='windows'
 elif n.startswith(('Radio','GarageVent')):k='equipment'
 elif 'Roof' in n or 'Coping' in n:k='roof'
 elif n=='EnclosedConnector':k='body'
 elif n.startswith(('Bay','ResponseGarage')):k='entry' if any(n==w['pane']or n in w['frame_parts']for w in doors)else 'garage'
 elif n.startswith(('Public','Door','Entry','Canopy')):k='entry'
 else:k='admin'
 groups[k].append(n)
preserve('civic-contract.json',dict(family='police',stage='high',sourceID='building.police_high.a',role='welcoming public police reception and response station',groups=groups,proposed_site_m=[40,32],integration='HELD; human source review only'))
cc=json.loads((O/'civic-contract.json').read_text());cc['groups'].setdefault('emblem',[]).append('BadgeMountSpacer');write('civic-contract.json',cc)
write('design-response.json',dict(mount_spacer=C['BadgeMountSpacer'],revision='civic177-badge-window-clearance-v3',delta_m=list(D),corrected_components=[C[n]for n in sorted(targets)],unchanged_connected_parts=215,geometry_preservation_checked=True,wall_contact='Original shield rear has 0.04m gap; concealed BadgeMountSpacer bridges wall and shield with embedded contacts',positive_projected_separations=separations,canopy_vertical_gap_m=C['AttachedCivicShield']['min'][2]-C['EntryCanopy']['max'][2],integration='HELD'))
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
p=O/'validation.json';v=json.loads(p.read_text());v.update(components=components,occupied_bounds=occupied,window_count=30,vehicle_bay_count=3,connected_parts=218,unchanged_parts=215,badge_occlusion_correction=True,corridor_checks=True,finiteUV0=True,sourceID='building.police_high.a',integration_held=True,review_only=True)
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH' and not o.name.startswith('ReviewGround')];tri=0
for ob in meshes:ob.data.calc_loop_triangles();tri+=len(ob.data.loop_triangles)
assert tri==2620,tri
assert len(meshes)==1 and len(meshes[0].data.materials)==6
v['measured_scene_triangles']=tri;write('validation.json',v)

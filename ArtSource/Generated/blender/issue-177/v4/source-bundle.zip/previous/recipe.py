import bpy,sys,json,hashlib,shutil,math
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box,cylinder,finish
OUT=Path('/output');OUT.mkdir(exist_ok=True)
def write(n,d):(OUT/n).write_text(json.dumps(d,indent=2))
for o in list(bpy.data.objects):
 if o.type=='MESH':bpy.data.objects.remove(o,do_unlink=True)
for m in list(bpy.data.meshes):
 if not m.users:bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
 if not m.users:bpy.data.materials.remove(m)
texdir=OUT/'textures';texdir.mkdir(exist_ok=True)
images={};maps=[]
for folder,stem in[('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for channel in['BaseColor','Normal','ORM']:
  p=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+channel+'.png');q=texdir/p.name;shutil.copyfile(p,q)
  im=bpy.data.images.load(str(q),check_existing=True);im.colorspace_settings.name='sRGB' if channel=='BaseColor' else 'Non-Color';im.pack();images[stem,channel]=im
  maps.append(dict(file='textures/'+p.name,sha256=hashlib.sha256(q.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
materials={};recipes=[]
for name,stem,tint,rough,metal in[('CivicBrick','CityBrick',(.57,.43,.33,1),.78,0),('LightStone',None,(.78,.71,.56,1),.8,0),('RoofMembrane','RoofMembrane',(.16,.20,.25,1),.85,0),('EquipmentMetal','CityMechanical',(.48,.52,.56,1),.5,.65),('WindowGlass',None,(.15,.25,.31,1),.32,0),('ServiceAccent',None,(.065,.13,.22,1),.6,0)]:
 m=bpy.data.materials.new(name);m.diffuse_color=tint;m.use_nodes=True;nt=m.node_tree;p=nt.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=tint;p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 if stem:
  ts={}
  for channel in['BaseColor','Normal','ORM']:
   t=nt.nodes.new('ShaderNodeTexImage');t.image=images[stem,channel];ts[channel]=t
  sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(ts['ORM'].outputs['Color'],sep.inputs[0])
  ao=nt.nodes.new('ShaderNodeMixRGB');ao.blend_type='MULTIPLY';ao.inputs[0].default_value=1;nt.links.new(ts['BaseColor'].outputs['Color'],ao.inputs[1]);nt.links.new(sep.outputs['Red'],ao.inputs[2])
  mul=nt.nodes.new('ShaderNodeMixRGB');mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1;mul.inputs[2].default_value=tint;nt.links.new(ao.outputs[0],mul.inputs[1]);nt.links.new(mul.outputs[0],p.inputs['Base Color'])
  nt.links.new(sep.outputs['Green'],p.inputs['Roughness']);nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
  norm=nt.nodes.new('ShaderNodeNormalMap');norm.inputs['Strength'].default_value=.25;nt.links.new(ts['Normal'].outputs['Color'],norm.inputs['Color']);nt.links.new(norm.outputs[0],p.inputs['Normal'])
 materials[name]=m;recipes.append(dict(region=name,texture_family=stem,tint_multiply=list(tint),roughness_constant=rough,metallic_constant=metal,orm={'R':'AO multiplied before tint','G':'roughness','B':'metallic'},normal_strength=.25,transmission=0,uv='UV0 world planar dominant face projection / 2m'))
objects=[];groups={};windows=[];doors=[]
def add(name,lo,hi,mat,group):
 assert name not in[o.name for o in objects]
 o=box(name,tuple(hi[i]-lo[i]for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),materials[mat].diffuse_color)
 o.data.materials.clear();o.data.materials.append(materials[mat]);objects.append(o);groups.setdefault(group,[]).append(name);return o
def bounds(o):
 pts=[o.matrix_world@Vector(v)for v in o.bound_box];return[[min(v[i]for v in pts)for i in range(3)],[max(v[i]for v in pts)for i in range(3)]]
admin=add('AdminTwoFloors',(-16,-5,0),(-4,8,6.5),'CivicBrick','admin')
garage=add('ResponseGarage',(-2,-5,0),(18,8,5.3),'CivicBrick','garage')
connector=add('EnclosedConnector',(-4,2,0),(-2,6,3.5),'CivicBrick','body')
upper=add('HighThirdFloor',(-15,-3,6.5),(-5,7,10.8),'CivicBrick','admin')
for n,lo,hi in[('Admin',(-16,-5,6.5),(-4,8,6.65)),('Garage',(-2,-5,5.3),(18,8,5.45)),('Connector',(-4,2,3.5),(-2,6,3.65)),('Third',(-15,-3,10.8),(-5,7,10.95))]:
 add(n+'Roof',lo,hi,'RoofMembrane','roof')
 x0,y0,z=lo;x1,y1,t=hi
 for suffix,a,b in[('Front',(x0-.12,y0-.12,z),(x1+.12,y0+.10,z+.26)),('Back',(x0-.12,y1-.10,z),(x1+.12,y1+.12,z+.26)),('Left',(x0-.12,y0+.10,z),(x0+.10,y1-.10,z+.26)),('Right',(x1-.10,y0+.10,z),(x1+.12,y1-.10,z+.26))]:add(n+suffix+'Coping',a,b,'LightStone','roof')
add('AdminFloorString',(-16.06,-5.07,3.12),(-3.94,8.06,3.25),'LightStone','admin')
for x in[-15.85,-4.15]:add('AdminPier'+str(x),(x-.13,-5.12,0),(x+.13,-4.98,6.45),'LightStone','admin')
def opening(name,wall,axis,sign,u,z,w,h,glass=True):
 lo,hi=bounds(wall);face=(hi if sign>0 else lo)[axis];other=1-axis
 def rect(suffix,a,b,c,d,near,far,mat):
  l=[0,0,c];r=[0,0,d];l[other]=a;r[other]=b
  vals=[face+sign*near,face+sign*far];l[axis]=min(vals);r[axis]=max(vals)
  return add(name+suffix,l,r,mat,'entry' if not glass else 'windows')
 pane=rect('Pane' if glass else 'Leaf',u-w/2,u+w/2,z,z+h,.008,.038,'WindowGlass' if glass else 'ServiceAccent')
 t=.11;parts=[]
 parts.append(rect('JambL',u-w/2-t,u-w/2,z-t if glass else z,z+h+t,-.01,.11,'LightStone'))
 parts.append(rect('JambR',u+w/2,u+w/2+t,z-t if glass else z,z+h+t,-.01,.11,'LightStone'))
 parts.append(rect('Head',u-w/2+.001,u+w/2-.001,z+h,z+h+t,-.01,.11,'LightStone'))
 if glass:parts.append(rect('Sill',u-w/2+.001,u+w/2-.001,z-t,z,-.01,.11,'LightStone'))
 rec=dict(pane=pane.name,frame_parts=[a.name for a in parts],backing=wall.name,axis=axis,sign=sign,wall_face=face,pane_bounds=bounds(pane),frame_bounds=[bounds(a)for a in parts])
 (windows if glass else doors).append(rec);return pane
for x in[-13.6,-6.4]:opening('Reception'+str(x),admin,1,-1,x,.85,1.5,1.7)
for x in[-13.6,-10,-6.4]:opening('OfficeFront'+str(x),admin,1,-1,x,4.0,1.65,1.7)
for z in[.9,4.0]:
 for x in[-13.5,-10,-6.5]:opening('AdminRear'+str((x,z)),admin,1,1,x,z,1.6,1.65)
 for y in[-2,2,5.5]:opening('AdminWest'+str((y,z)),admin,0,-1,y,z,1.6,1.65)
for x in[-12.8,-10,-7.2]:
 opening('ThirdFront'+str(x),upper,1,-1,x,8,1.5,1.65)
 opening('ThirdRear'+str(x),upper,1,1,x,8,1.5,1.65)
for y in[-.5,3.5]:opening('ThirdWest'+str(y),upper,0,-1,y,8,1.6,1.65)
for x in[2,8,14]:opening('BayClerestory'+str(x),garage,1,-1,x,4.13,2.8,.65)
for y in[-1,3.5]:opening('GarageEast'+str(y),garage,0,1,y,2.2,2.0,1.4)
public=opening('PublicDoubleDoor',admin,1,-1,-10,0,1.9,2.65,False)
add('DoorMeetingStile',(-10.025,-5.065,0),(-9.975,-5.04,2.65),'EquipmentMetal','entry')
add('EntryCanopy',(-12,-6.8,2.95),(-8,-4.96,3.12),'ServiceAccent','entry')
for x in[-11.85,-8.15]:add('CanopySupport'+str(x),(x-.07,-6.6,0),(x+.07,-6.46,2.95),'EquipmentMetal','entry')
bays=[]
for i,x in enumerate([2,8,14]):
 leaf=opening('Bay'+str(i+1),garage,1,-1,x,0,4.5,3.6,False)
 for z in[.6,1.2,1.8,2.4,3.0]:add('Bay%dSection%.1f'%(i+1,z),(x-2.23,-5.065,z-.018),(x+2.23,-5.039,z+.018),'EquipmentMetal','garage')
 bays.append(dict(id='bay'+str(i+1),target=leaf.name,xyz_m=[x,-5.15,0],outward=[0,-1,0],width_m=4.5,height_m=3.6,boundary_connector={'xyz_m':[x,-16,0]},reserved_free_corridor={'min':[x-2.25,-16,0],'max':[x+2.25,-5.15,3.6]}))
verts2=[(-.56,.48),(.56,.48),(.50,-.10),(0,-.58),(-.50,-.10)]
verts=[(-10+x,y,3.65+z)for y in[-5.04,-5.16]for x,z in verts2];faces=[tuple(range(4,-1,-1)),tuple(range(5,10))]+[(i,(i+1)%5,(i+1)%5+5,i+5)for i in range(5)]
me=bpy.data.meshes.new('ShieldMesh');me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new('AttachedCivicShield',me);bpy.context.collection.objects.link(o);o.data.materials.append(materials['ServiceAccent']);objects.append(o);groups['emblem']=[o.name]
add('ShieldCentralRelief',(-10.12,-5.19,3.49),(-9.88,-5.15,3.91),'LightStone','emblem')
add('RadioRoofUnit',(-12,2,10.95),(-10.3,3.3,11.55),'EquipmentMetal','equipment')
add('RadioMount',(-11.35,2.45,11.55),(-11.15,2.65,12.65),'EquipmentMetal','equipment')
add('GarageVent',(12,4,5.45),(14,5.4,6.15),'EquipmentMetal','equipment')
components=[]
for o in objects:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);bpy.context.view_layer.update()
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
 for p in o.data.polygons:
  ax=max(range(3),key=lambda a:abs(p.normal[a]));ij=[a for a in range(3)if a!=ax]
  for li in p.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(co[ij[0]]/2,co[ij[1]]/2)
 vg=o.vertex_groups.new(name=o.name);vg.add(list(range(len(o.data.vertices))),1,'REPLACE')
 a,b=bounds(o);components.append(dict(name=o.name,min=a,max=b));assert a[0]>=-19.5 and b[0]<=19.5 and a[1]>=-15.5 and b[1]<=15.5 and a[2]>=-1e-5
lookup={o.name:o for o in objects}
def overlap(a,b):return all(min(a[1][j],b[1][j])-max(a[0][j],b[0][j])>1e-6 for j in range(3))
for w in windows:
 ax=w['axis'];u=1-ax;lo,hi=bounds(lookup[w['backing']]);pb=w['pane_bounds'];fb=w['frame_bounds'];face=w['wall_face'];sg=w['sign']
 for b in[pb]+fb:
  assert b[0][u]>=lo[u]+.12 and b[1][u]<=hi[u]-.12 and b[0][2]>=lo[2]+.12 and b[1][2]<=hi[2]-.12
 for i,a in enumerate(fb):
  assert min(sg*(a[0][ax]-face),sg*(a[1][ax]-face))<=0
  assert not overlap(a,pb)
  for b in fb[i+1:]:assert not overlap(a,b)
 assert min(sg*(pb[0][ax]-face),sg*(pb[1][ax]-face))<=.02
anchors=[]
for role,x,width,height,target in[('pedestrian',-10,1.9,2.4,public.name),('service',2,4.5,3.6,bays[0]['target'])]:
 anchors.append(dict(role=role,target=target,xyz_m=[x,-5.15,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-16,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor={'min':[x-width/2,-16,0],'max':[x+width/2,-5.15,height]}))
for r in anchors+bays:
 c=r['reserved_free_corridor'];ab=[c['min'],c['max']]
 for comp in components:assert not overlap(ab,[comp['min'],comp['max']]),('corridor',r,comp)
occupied={'min':[min(c['min'][j]for c in components)for j in range(3)],'max':[max(c['max'][j]for c in components)for j in range(3)]}
write('window-mounts.json',dict(windows=windows,doors=doors));write('entrance-anchors.json',dict(anchors=anchors));write('vehicle-bays.json',dict(bays=bays))
write('material-manifest.json',dict(maps=maps,materials=recipes,semantic_region_count=6))
write('upgrade-plan.json',dict(family='police',stage='high',stage_index=2,existing_stages=['base','medium','high'],existing_upgrade_count=2,gameplay_changes=False,source_site_m=[40,32],current_native_footprint=[3,2],retained_entrance_centres=[[-10,-5],[2,-5]],progression='Third compact office floor and three functional response bays; no vehicles or future stages.',occupied_bounds=occupied,LOD1='Simplify four-bar rims and relief and remove section ribs.',LOD2='Collapse roof equipment and emblem; retain entrances and massing.'))
write('civic-contract.json',dict(family='police',stage='high',sourceID='building.police_high.a',role='welcoming public police reception and response station',groups=groups,proposed_site_m=[40,32],integration='HELD; human source review only'))
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
p=OUT/'validation.json';v=json.loads(p.read_text())if p.exists()else{};v.update(components=components,occupied_bounds=occupied,window_count=len(windows),window_mount_checks=True,corridor_checks=True,review_only=True,source_triangle_cap=8000,sourceID='building.police_high.a',integration_held=True)
mesh=[o for o in bpy.context.scene.objects if o.type=='MESH'];tri=0
for o in mesh:o.data.calc_loop_triangles();tri+=len(o.data.loop_triangles)
assert tri<=8000
v['measured_scene_triangles']=tri;write('validation.json',v)

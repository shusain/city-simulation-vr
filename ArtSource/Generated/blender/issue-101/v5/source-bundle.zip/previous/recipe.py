import bpy, sys, os, json, math, hashlib, itertools
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous, box, finish
# Read the actual contracts and previous authoring context without executing an older generator.
contracts={}
for p in ['/repo/Tools/CityBuildingStudyIO.py','/previous/recipe.py']:
    with open(p) as f: contracts[p]=f.read()
objects=load_previous()
os.makedirs('/output',exist_ok=True)
with open('/output/previous_recipe_reference.py','w') as f:f.write(contracts['/previous/recipe.py'])
with open('/output/study_io_contract_reference.py','w') as f:f.write(contracts['/repo/Tools/CityBuildingStudyIO.py'])
# Retain all existing surfaces and texture nodes. Inspect disconnected source components
# so trim edits do not replace the approved overall design or cabinet details.
components=[]
for ob in objects:
    if ob.type!='MESH':continue
    me=ob.data
    adj=[[] for v in me.vertices]
    for e in me.edges:
        a,b=e.vertices;adj[a].append(b);adj[b].append(a)
    seen=set()
    for v in me.vertices:
        if v.index in seen:continue
        stack=[v.index];seen.add(v.index);ids=[]
        while stack:
            a=stack.pop();ids.append(a)
            for b in adj[a]:
                if b not in seen:seen.add(b);stack.append(b)
        idsset=set(ids)
        faces=[p for p in me.polygons if all(i in idsset for i in p.vertices)]
        mats=set(me.materials[p.material_index].name if p.material_index<len(me.materials) and me.materials[p.material_index] else '' for p in faces)
        pts=[ob.matrix_world@me.vertices[i].co for i in ids]
        lo=Vector(tuple(min(p[k] for p in pts) for k in range(3)));hi=Vector(tuple(max(p[k] for p in pts) for k in range(3)))
        d=hi-lo
        metal=any(('metal' in n.lower() or 'frame' in n.lower() or 'chrome' in n.lower()) for n in mats)
        # Axis-aligned cuboids only: do not assert AABB proof for angled roof elements.
        axisbox=all(all(abs(p[k]-lo[k])<1e-5 or abs(p[k]-hi[k])<1e-5 for k in range(3)) for p in pts)
        c={'ob':ob,'ids':ids,'lo':lo,'hi':hi,'mats':list(mats),'axisbox':axisbox,'name':ob.name+':'+str(min(ids))}
        c['vertical']=metal and axisbox and d.z>0.55 and d.x<0.5 and d.y<0.5
        c['horizontal']=metal and axisbox and max(d.x,d.y)>0.55 and d.z<0.5 and min(d.x,d.y)<0.5
        components.append(c)
verts=[c for c in components if c['vertical']]
rails=[c for c in components if c['horizontal']]
tol=1e-6
edits=[]
for r in rails:
    axis=0 if (r['hi'].x-r['lo'].x)>(r['hi'].y-r['lo'].y) else 1
    other=1-axis
    newlo=r['lo'][axis];newhi=r['hi'][axis]
    for v in verts:
        if min(r['hi'].z,v['hi'].z)-max(r['lo'].z,v['lo'].z)<=tol:continue
        if min(r['hi'][other],v['hi'][other])-max(r['lo'][other],v['lo'][other])<=tol:continue
        a,b=v['lo'][axis],v['hi'][axis]
        if a-tol<=newlo<b-tol:newlo=max(newlo,b)
        if a+tol<newhi<=b+tol:newhi=min(newhi,a)
    if newhi-newlo>tol and (abs(newlo-r['lo'][axis])>tol or abs(newhi-r['hi'][axis])>tol):
        oldlo=r['lo'][axis];oldhi=r['hi'][axis];inv=r['ob'].matrix_world.inverted()
        for i in r['ids']:
            p=r['ob'].matrix_world@r['ob'].data.vertices[i].co
            p[axis]=newlo+(p[axis]-oldlo)*(newhi-newlo)/(oldhi-oldlo)
            r['ob'].data.vertices[i].co=inv@p
        edits.append({'component':r['name'],'axis':axis,'old':[oldlo,oldhi],'new':[newlo,newhi]})
        r['lo'][axis]=newlo;r['hi'][axis]=newhi
# Preserve component identifiers in a sidecar because the delivery helper joins static geometry.
pairs=[];joints=[]
for r,v in itertools.product(rails,verts):
    ext=[min(r['hi'][k],v['hi'][k])-max(r['lo'][k],v['lo'][k]) for k in range(3)]
    volume=math.prod(max(0,x) for x in ext)
    pairs.append({'rail':r['name'],'post':v['name'],'overlap_m3':volume})
    if sum(x>tol for x in ext)==2 and any(abs(x)<=tol for x in ext):joints.append({'rail':r['name'],'post':v['name'],'intersection_extents':ext})
# Exact coplanar polygon duplicates among identified trim components, including boundary caps.
facekeys={};duplicates=[]
for c in rails+verts:
    ids=set(c['ids']);ob=c['ob']
    for p in ob.data.polygons:
        if all(i in ids for i in p.vertices):
            key=tuple(sorted(tuple(round(t,6) for t in (ob.matrix_world@ob.data.vertices[i].co)) for i in p.vertices))
            if key in facekeys:duplicates.append([facekeys[key],c['name']])
            else:facekeys[key]=c['name']
# Add only missing human-scale door hardware; locate existing door slab by semantic material.
doors=[]
for c in components:
    d=c['hi']-c['lo']
    if any('door' in m.lower() for m in c['mats']) and 0.8<d.x<1.6 and 1.7<d.z<2.5:doors.append(c)
materials={m.name:m for ob in objects if ob.type=='MESH' for m in ob.data.materials if m}
metal=next((m for n,m in materials.items() if 'metal' in n.lower()),None)
added=[]
if doors:
    door=min(doors,key=lambda c:c['lo'].y);lo=door['lo'];hi=door['hi'];cx=(lo.x+hi.x)/2
    # Existing fixing hardware is retained. New pull/threshold remain inside the original lot.
    specs=[('DoorPull_Detail',(0.055,0.09,0.32),(hi.x-0.18,lo.y-0.055,lo.z+1.05)),('DoorThreshold_Detail',(hi.x-lo.x,0.20,0.045),(cx,lo.y-0.04,max(0.025,lo.z+0.0225)))]
    for name,dim,loc in specs:
        if not any(name.lower() in o.name.lower() for o in objects):
            o=box(name,dim,loc,(0.64,0.7,0.73,1))
            if metal:o.data.materials.clear();o.data.materials.append(metal)
            objects.append(o);added.append(name)
# Pack and export every image actually used by the retained source; no invented replacement maps.
texture_manifest=[]
for im in bpy.data.images:
    if im.source!='FILE':continue
    src=bpy.path.abspath(im.filepath)
    item={'image':im.name,'source':src,'colorspace':im.colorspace_settings.name,'dimensions':list(im.size),'reuse':True}
    if os.path.isfile(src):item['sha256']=hashlib.sha256(open(src,'rb').read()).hexdigest()
    try:
        im.pack()
        out='/output/'+os.path.basename(src)
        if im.packed_file:
            with open(out,'wb') as f:f.write(im.packed_file.data)
            item['export']=out
    except Exception as e:item['packing_note']=str(e)
    texture_manifest.append(item)
region_manifest=[]
for name,m in materials.items():
    nodes=[]
    if m.use_nodes:
        for n in m.node_tree.nodes:
            if n.type=='TEX_IMAGE' and n.image:nodes.append(n.image.name)
    region_manifest.append({'region':name,'retained_v3_nodes':True,'images':nodes,'native_binding':'existing semantic region; native material assignment and appearance require later integration','pending':'No claim that procedural Blender shading transfers via FBX. Existing packed maps retained; native ORM/normal hookup must be verified at integration.'})
report={'revision':'v4 bounded trim/detail verification of v3','contracts_read':list(contracts),'frame_scope':'Axis-aligned metal cuboid components only; angled roof intersections NOT certified by AABB. Full source retained.','tolerance_m':tol,'tested_pair_count':len(pairs),'joint_count':len(joints),'joints':joints,'offending_pairs':[p for p in pairs if p['overlap_m3']>tol**3],'tested_pairs':pairs,'trim_edits':edits,'duplicate_trim_faces':duplicates,'duplicate_check_scope':'exact vertex-matched coplanar trim polygons; boundary internal caps included, not a universal exposed partial-face proof','added_details':added,'entrance':'negative Y','native_yaw':'established quarter-turn mapping; reconcile on import','components':[{'name':c['name'],'lo':list(c['lo']),'hi':list(c['hi']),'materials':c['mats'],'axis_aligned':c['axisbox'],'vertical':c['vertical'],'horizontal':c['horizontal']} for c in components],'review_status':'Review only; not approved. Unmeasured angled/partial coplanar intersections remain explicit.'}
with open('/output/frame_validation.json','w') as f:json.dump(report,f,indent=2)
with open('/output/material_texture_manifest.json','w') as f:json.dump({'regions':region_manifest,'images':texture_manifest,'uv':'Retained v3 UV0 and source metric mapping; no UV regeneration or density change.'},f,indent=2)
finish(objects)
# Append focused evidence to the helper's measured export/readback receipt.
p='/output/validation.json'
with open(p) as f:validation=json.load(f)
validation['framing_revision']=report
with open(p,'w') as f:json.dump(validation,f,indent=2)
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=8;scene.cycles.device='CPU'
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
mesh=[o for o in scene.objects if o.type=='MESH']
pts=[o.matrix_world@Vector(c) for o in mesh for c in o.bound_box]
lo=Vector(tuple(min(p[k] for p in pts) for k in range(3)));hi=Vector(tuple(max(p[k] for p in pts) for k in range(3)))
center=(lo+hi)/2
cam.data.type='ORTHO'
def view(name,target,offset,scale):
    target=Vector(target);cam.location=target+Vector(offset);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale
    scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
view('front',center,(0,-35,0),max(hi.x-lo.x,hi.z-lo.z)*1.18)
if rails:
    r=min(rails,key=lambda c:c['lo'].y)
    t=Vector((r['hi'].x,r['lo'].y,r['hi'].z))
    view('window_corner',t,(1.8,-6,1.5),2.8)
if doors:
    d=doors[0];t=Vector((d['hi'].x,d['lo'].y,d['hi'].z))
    view('door_corner',t,(1,-6,0.8),2.5)
else:
    view('door_detail_context',(center.x,lo.y,1.8),(0,-8,0.5),5)
view('facade_roof_return',(hi.x,lo.y,hi.z-1),(6,-8,4),6)
# Leave the full isometric preview from finish unchanged; save updated editable review scene.
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

import bpy,sys,os,json,math,hashlib,itertools
from pathlib import Path
from mathutils import Vector
sys.path[:0]=['/worker','/repo/Tools']
from CityRunnerPreview import load_previous,finish
from CityBuildingStudyIO import checked_fbx
objects=[o for o in load_previous() if o.type=='MESH']
os.makedirs('/output',exist_ok=True)
def dump(n,x):Path('/output/'+n+'.json').write_text(json.dumps(x,indent=2))
def fingerprint(obs,uv=False):
 rows=[]
 for o in obs:
  m=o.data;m.calc_loop_triangles()
  for t in m.loop_triangles:
   pts=[]
   for vi,li in zip(t.vertices,t.loops):
    p=list(o.matrix_world@m.vertices[vi].co)
    if uv:p+=list(m.uv_layers.active.data[li].uv)
    pts.append(tuple(round(x,5) for x in p))
   rows.append((t.material_index,sorted(pts)))
 return hashlib.sha256(repr(sorted(rows)).encode()).hexdigest()
before=fingerprint(objects)
audit=[]
for o in objects:
 for m in o.data.materials:
  audit.append({'material':m.name,'uv_layers':[u.name for u in o.data.uv_layers],'images':[{'node':n.name,'image':n.image.name,'size':list(n.image.size),'vector_links':[l.from_node.name for l in n.inputs['Vector'].links]} for n in m.node_tree.nodes if n.type=='TEX_IMAGE' and n.image] if m.use_nodes else []})
dump('before_graph_audit',audit)
source='/repo/ArtSource/Blender/CityCivicSurfaces.blend'
with bpy.data.libraries.load(source,link=False) as (a,b):
 names=list(a.materials)
 brick=next((n for n in names if 'CivicBrick' in n and ('School' in n or 'College' in n)),next(n for n in names if 'CivicBrick' in n))
 roof=next(n for n in names if 'CivicAsphalt' in n)
 b.materials=[brick,roof]
brickmat,roofmat=b.materials
manifest=[];image_records=[]
# Recover original PNG bytes from packed source where the bounded bundle omits loose maps.
for mat in [brickmat,roofmat]:
 for n in mat.node_tree.nodes:
  if n.type!='TEX_IMAGE' or not n.image:continue
  im=n.image;fn=os.path.basename(im.filepath.replace('\\','/'))
  candidates=list(Path('/repo/ArtSource/Textures').rglob(fn)) if Path('/repo/ArtSource/Textures').exists() else []
  raw=None
  if candidates:raw=candidates[0].read_bytes();im.filepath=str(candidates[0]);im.reload()
  elif im.packed_file:raw=bytes(im.packed_file.data)
  if raw:
   out='/output/'+fn;Path(out).write_bytes(raw);im.filepath=out;im.pack()
  image_records.append({'source_material':mat.name,'image':im.name,'filename':fn,'sha256':hashlib.sha256(raw).hexdigest() if raw else None,'bytes':len(raw) if raw else 0,'reused_original':True})
# Keep original civic graphs, removing only the stale per-asset atlas overlay by replacement.
seen={}
for o in objects:
 for i,old in enumerate(list(o.data.materials)):
  if old in seen:o.data.materials[i]=seen[old];continue
  low=old.name.lower();kind='OpaqueFacade' if ('opaque' in low or 'facade' in low) else 'RoofService' if ('roof' in low or 'service' in low) else 'LightMetal' if ('metal' in low or 'frame' in low) else 'TechGlass' if 'glass' in low else 'DoorAccent'
  src=brickmat if kind=='OpaqueFacade' else roofmat if kind=='RoofService' else None
  new=src.copy() if src else old.copy();new.name=old.name+'_MetricRepair';new.use_nodes=True
  if not src:
   nt=new.node_tree;p=next((n for n in nt.nodes if n.type=='BSDF_PRINCIPLED'),None)
   if p:
    for n in list(nt.nodes):
     if n.type=='TEX_IMAGE':nt.nodes.remove(n)
    vals={'LightMetal':((.63,.71,.74,1),.75,.29),'TechGlass':((.035,.26,.29,1),.25,.25),'DoorAccent':((.085,.14,.16,1),.25,.43)}
    col,met,rough=vals.get(kind,vals['DoorAccent']);p.inputs['Base Color'].default_value=col;p.inputs['Metallic'].default_value=met;p.inputs['Roughness'].default_value=rough
  nt=new.node_tree;uv=nt.nodes.new('ShaderNodeUVMap');uv.uv_map='UV0';uv.label='Metric planar UV0: one repeat per metre'
  for n in nt.nodes:
   if n.type=='TEX_IMAGE' and n.image:nt.links.new(uv.outputs['UV'],n.inputs['Vector']);n.extension='REPEAT'
  seen[old]=new;o.data.materials[i]=new
  manifest.append({'region':kind,'material':new.name,'original_source_material':src.name if src else None,'source_graph_reused':bool(src),'uv':'UV0; explicit one repeat/metre; source mapping nodes bypassed for image coordinates','native_binding':'MI_CivicBrick school-family / MI_CivicAsphaltRoof' if src else kind+' constant PBR','native_pending':'Original normal/ORM and color space hookup, tint and tangent basis require later native verification; shader graph is not FBX handoff.','images':[n.image.name for n in nt.nodes if n.type=='TEX_IMAGE' and n.image]})
# Planar mapping uses horizontal run vs world Z on walls, XY on roofs.
metrics={};scales={}
for o in objects:
 me=o.data
 for u in list(me.uv_layers):me.uv_layers.remove(u)
 uv=me.uv_layers.new(name='UV0')
 for p in me.polygons:
  normal=o.matrix_world.to_3x3()@p.normal;axis=max(range(3),key=lambda k:abs(normal[k]));coords=[]
  for li in p.loop_indices:
   pt=o.matrix_world@me.vertices[me.loops[li].vertex_index].co
   q=(pt.x,pt.y) if axis==2 else ((pt.x,pt.z) if axis==1 else (pt.y,pt.z))
   uv.data[li].uv=q;coords.append(q)
  area=abs(sum(coords[j][0]*coords[(j+1)%len(coords)][1]-coords[(j+1)%len(coords)][0]*coords[j][1] for j in range(len(coords)))/2)
  reg=me.materials[p.material_index].name;s=metrics.setdefault(reg,{'faces':0,'collapsed':0,'nonfinite':0,'min_area':1e30});s['faces']+=1;s['collapsed']+=area<1e-12;s['nonfinite']+=not all(math.isfinite(v) for q in coords for v in q);s['min_area']=min(s['min_area'],area)
  if 'facade' in reg.lower() and axis in (0,1):
   key='east_west' if axis==0 else 'front_rear';r=scales.setdefault(key,[])
   for j,li in enumerate(p.loop_indices):
    lj=p.loop_indices[(j+1)%len(coords)];a=o.matrix_world@me.vertices[me.loops[li].vertex_index].co;b=o.matrix_world@me.vertices[me.loops[lj].vertex_index].co;d=b-a;du=Vector(coords[(j+1)%len(coords)])-Vector(coords[j])
    if d.length>1e-7:r.append(du.length/d.length)
assert fingerprint(objects)==before
# Recompute retained trim evidence from actual disconnected components; never edit geometry.
comps=[];facekeys={};duplicates=[]
for o in objects:
 me=o.data;adj=[[] for v in me.vertices]
 for e in me.edges:
  a,b=e.vertices;adj[a].append(b);adj[b].append(a)
 visited=set()
 for v in me.vertices:
  if v.index in visited:continue
  todo=[v.index];visited.add(v.index);ids=[]
  while todo:
   i=todo.pop();ids.append(i)
   for j in adj[i]:
    if j not in visited:visited.add(j);todo.append(j)
  ids=set(ids);faces=[p for p in me.polygons if all(i in ids for i in p.vertices)]
  if not any('metal' in me.materials[p.material_index].name.lower() for p in faces):continue
  pts=[o.matrix_world@me.vertices[i].co for i in ids];lo=Vector([min(p[k] for p in pts) for k in range(3)]);hi=Vector([max(p[k] for p in pts) for k in range(3)]);d=hi-lo
  axisbox=all(all(abs(p[k]-lo[k])<1e-5 or abs(p[k]-hi[k])<1e-5 for k in range(3)) for p in pts)
  typ='post' if d.z>.55 and d.x<.5 and d.y<.5 else 'rail' if max(d.x,d.y)>.55 and d.z<.5 and min(d.x,d.y)<.5 else 'other'
  if not axisbox or typ=='other':continue
  tag=o.name+':'+str(min(ids));comps.append({'tag':tag,'type':typ,'lo':list(lo),'hi':list(hi)})
  for p in faces:
   key=tuple(sorted(tuple(round(x,6) for x in o.matrix_world@me.vertices[i].co) for i in p.vertices))
   if key in facekeys:duplicates.append([tag,facekeys[key]])
   facekeys[key]=tag
pairs=0;joints=[];bad=[];tol=1e-6
for a,b in itertools.product([c for c in comps if c['type']=='post'],[c for c in comps if c['type']=='rail']):
 pairs+=1;e=[min(a['hi'][k],b['hi'][k])-max(a['lo'][k],b['lo'][k]) for k in range(3)]
 if all(x>tol for x in e):bad.append([a['tag'],b['tag'],math.prod(e)])
 if sum(x>tol for x in e)==2 and any(abs(x)<=tol for x in e):joints.append([a['tag'],b['tag']])
frame={'components':comps,'tested_pair_count':pairs,'touching_joint_count':len(joints),'joints':joints,'offending_pairs':bad,'duplicate_trim_faces':duplicates,'tolerance_m':tol,'scope':'Axis-aligned disconnected metal cuboids; exact duplicate polygons only. Angled bars and partial coplanar faces not certified.'}
dump('frame_validation',frame)
finish(objects)
asset=next(o for o in bpy.context.scene.objects if o.type=='MESH' and o.data.uv_layers and o.data.uv_layers.get('UV0'))
rt={}
with checked_fbx(asset,'/output/asset.fbx') as check:
 rt={'uv_layers':[u.name for u in check.data.uv_layers],'uv_triangle_corner_fingerprint_match':fingerprint([asset],True)==fingerprint([check],True),'material_count':len(check.data.materials),'uv_present':bool(check.data.uv_layers)}
after=fingerprint([asset]);report={'review_only':True,'before_geometry_sha256':before,'after_geometry_sha256':after,'unchanged_geometry':before==after,'cause':'Actual prior node/image/UV bindings recorded in before_graph_audit.json. Prior recipe retained atlas and source nodes on one UV0; stale atlas overrides removed; original civic graphs restored with explicitly shared metric UV0.','uv_metrics':metrics,'tiled_overlap':'Expected across faces; not a bake atlas. Every face projected including hardware.','perpendicular_facade_uv_units_per_m':{k:{'samples':len(v),'min':min(v),'max':max(v)} for k,v in scales.items()},'fbx':rt,'entrance':'-Y','presentation_yaw_offset_quarter_turns':2,'frame':frame,'source_blend_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest()}
dump('material_texture_manifest',{'regions':manifest,'images':image_records,'new_maps':False})
p=Path('/output/validation.json');v=json.loads(p.read_text());v['uv_material_repair']=report;p.write_text(json.dumps(v,indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=8;scene.cycles.device='CPU';scene.render.resolution_x=scene.render.resolution_y=512;scene.render.resolution_percentage=100
pts=[asset.matrix_world@v.co for v in asset.data.vertices];lo=Vector([min(p[k] for p in pts) for k in range(3)]);hi=Vector([max(p[k] for p in pts) for k in range(3)]);center=(lo+hi)/2;cam=scene.camera;cam.data.type='ORTHO'
def view(name,t,offset,size):
 t=Vector(t);cam.location=t+Vector(offset);cam.rotation_euler=(t-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=size;scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
view('preview',center,(26,-34,24),max(hi.x-lo.x,hi.y-lo.y)*1.5)
view('front',center,(0,-35,0),max(hi.x-lo.x,hi.z-lo.z)*1.12)
view('east_facade', (hi.x,center.y,2.3),(20,-5,4),9)
frontfaces=[p for p in asset.data.polygons if 'facade' in asset.data.materials[p.material_index].name.lower() and p.normal.y<-.8]
t=asset.matrix_world@max(frontfaces,key=lambda p:p.area).center if frontfaces else Vector((center.x,lo.y,2))
view('brick_window_detail',t,(1,-10,1),4)
doors=[p for p in asset.data.polygons if 'door' in asset.data.materials[p.material_index].name.lower() and p.normal.y<-.8]
t=asset.matrix_world@max(doors,key=lambda p:p.area).center if doors else Vector((0,lo.y,1.5))
view('door_detail',t,(0,-10,1),3.8)
view('roof_return',(hi.x-2,lo.y+2,hi.z-1),(10,-13,12),11)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

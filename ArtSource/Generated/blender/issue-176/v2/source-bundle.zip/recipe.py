import bpy, sys, json, math, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
out=Path('/output');out.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for m in list(bpy.data.meshes):
    if not m.users:bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
    if not m.users:bpy.data.materials.remove(m)
def write(n,v): (out/n).write_text(json.dumps(v,indent=2))
# Exact repository maps, copied and packed; no generated texture substitutes.
tex={}; receipts=[]
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
    tex[family]={}
    for channel in ['BaseColor','Normal','ORM']:
        name=family+'_'+channel+'.png';src=Path('/repo/ArtSource/Textures')/folder/name
        dest=out/'textures'/name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(src,dest)
        im=bpy.data.images.load(str(dest));im.colorspace_settings.name='sRGB' if channel=='BaseColor' else 'Non-Color';im.pack()
        tex[family][channel]=im
        receipts.append(dict(path='textures/'+name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
mats={};spec=[]
def material(name,color,family=None,rough=.65,metal=0):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
    if family:
        nodes={}
        uv=n.new('ShaderNodeTexCoord')
        for c,im in tex[family].items():
            t=n.new('ShaderNodeTexImage');t.image=im;t.extension='REPEAT';l.new(uv.outputs['UV'],t.inputs['Vector']);nodes[c]=t
        sep=n.new('ShaderNodeSeparateColor');l.new(nodes['ORM'].outputs['Color'],sep.inputs['Color'])
        ao=n.new('ShaderNodeMixRGB');ao.blend_type='MULTIPLY';ao.inputs[0].default_value=1;l.new(nodes['BaseColor'].outputs['Color'],ao.inputs[1]);l.new(sep.outputs['Red'],ao.inputs[2])
        tint=n.new('ShaderNodeMixRGB');tint.blend_type='MULTIPLY';tint.inputs[0].default_value=1;tint.inputs[2].default_value=(*color,1);l.new(ao.outputs[0],tint.inputs[1]);l.new(tint.outputs[0],p.inputs['Base Color'])
        l.new(sep.outputs['Green'],p.inputs['Roughness']);l.new(sep.outputs['Blue'],p.inputs['Metallic'])
        normal=n.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.25;l.new(nodes['Normal'].outputs['Color'],normal.inputs['Color']);l.new(normal.outputs['Normal'],p.inputs['Normal'])
    mats[name]=m;spec.append(dict(region=name,family=family,tint_multiply=list(color),roughness=rough,metallic=metal,transmission=0,normal_strength=.25 if family else 0,channels={'R':'AO multiply before tint','G':'roughness','B':'metallic'} if family else {},UV='UV0 planar face projection in metres divided by 2; shared 2m repeat'))
material('CivicBrick',(.58,.43,.32),'CityBrick')
material('LightStone',(.77,.72,.60))
material('RoofMembrane',(.12,.16,.20),'RoofMembrane')
material('EquipmentMetal',(.48,.53,.57),'CityMechanical')
material('WindowGlass',(.085,.17,.23),rough=.28)
material('ServiceAccent',(.035,.085,.16),rough=.48)
objects=[];groups={};components=[]
def register(o,region,group):
    o.data.materials.clear();o.data.materials.append(mats[region]);bpy.context.view_layer.objects.active=o;o.select_set(True)
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
    bpy.context.view_layer.update()
    uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
    for p in o.data.polygons:
        axis=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=axis]
        for li in p.loop_indices:
            co=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]/2,co[axes[1]]/2)
    vg=o.vertex_groups.new(name=o.name);vg.add(list(range(len(o.data.vertices))),1,'REPLACE')
    coords=[o.matrix_world@v.co for v in o.data.vertices];lo=[min(v[i] for v in coords) for i in range(3)];hi=[max(v[i] for v in coords) for i in range(3)]
    assert lo[0]>=-19.5 and hi[0]<=19.5 and lo[1]>=-15.5 and hi[1]<=15.5 and lo[2]>=-1e-5
    components.append(dict(name=o.name,min=lo,max=hi));groups.setdefault(group,[]).append(o.name);objects.append(o);o.select_set(False);return o

def B(name,lo,hi,mat='LightStone',group='detail'):
    assert all(hi[i]>lo[i] for i in range(3))
    return register(box(name,tuple(hi[i]-lo[i] for i in range(3)),tuple((lo[i]+hi[i])/2 for i in range(3)),(1,1,1,1)),mat,group)
admin=B('AdminOccupied',(-16,-5,0),(-4,8,6.5),'CivicBrick','admin')
garage=B('GarageOccupied',(-2,-5,0),(12,8,5.3),'CivicBrick','garage')
connector=B('EnclosedConnector',(-4,2,0),(-2,6,3.5),'CivicBrick','body')
for name,lo,hi,z in [('Admin',(-16,-5),(-4,8),6.5),('Garage',(-2,-5),(12,8),5.3),('Connector',(-4,2),(-2,6),3.5)]:
    B(name+'Roof',(lo[0]-.18,lo[1]-.18,z),(hi[0]+.18,hi[1]+.18,z+.18),'RoofMembrane','roof')
    for suffix,a,b in [('Front',(lo[0]-.2,lo[1]-.2,z+.16),(hi[0]+.2,lo[1]-.06,z+.39)),('Rear',(lo[0]-.2,hi[1]+.06,z+.16),(hi[0]+.2,hi[1]+.2,z+.39)),('West',(lo[0]-.2,lo[1]-.06,z+.16),(lo[0]-.06,hi[1]+.06,z+.39)),('East',(hi[0]+.06,lo[1]-.06,z+.16),(hi[0]+.2,hi[1]+.06,z+.39))]:B(name+'Coping'+suffix,a,b,'LightStone','roof')
# Four independent bars, hollow centre, 1mm rail/jamb separation.
mounts=[]
def window(name,wall,axis,sign,u,z,w=1.65,h=1.45):
    vs=[v.co for v in wall.data.vertices];face=(max if sign==1 else min)(v[axis] for v in vs);tang=1-axis
    def part(n,umin,umax,zmin,zmax,d0,d1,mat):
        lo=[0,0,zmin];hi=[0,0,zmax];lo[tang]=umin;hi[tang]=umax;ds=sorted([face+sign*d0,face+sign*d1]);lo[axis]=ds[0];hi[axis]=ds[1];return B(n,lo,hi,mat,'glazing')
    a=u-w/2;b=u+w/2;c=z-h/2;d=z+h/2;r=.11
    pane=part(name+'Pane',a+r+.006,b-r-.006,c+r+.006,d-r-.006,.015,.045,'WindowGlass')
    bars=[part(name+'JambL',a,a+r,c,d,-.01,.13,'LightStone'),part(name+'JambR',b-r,b,c,d,-.01,.13,'LightStone'),part(name+'Head',a+r+.001,b-r-.001,d-r,d,-.01,.13,'LightStone'),part(name+'Sill',a+r+.001,b-r-.001,c,c+r,-.01,.13,'LightStone')]
    byname={v['name']:v for v in components};pb=byname[pane.name];fb=[byname[v.name] for v in bars];wb=byname[wall.name]
    assert a>=wb['min'][tang]+.12 and b<=wb['max'][tang]-.12 and c>=wb['min'][2]+.12 and d<=wb['max'][2]-.12
    assert .015<=.02 and .045<.13
    def intersects(a,b):return all(min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i])>1e-6 for i in range(3))
    for i,f in enumerate(fb):
        assert f['min'][axis]<=face<=f['max'][axis]
        assert not intersects(f,pb)
        for other in fb[i+1:]:assert not intersects(f,other)
    mounts.append(dict(pane=pane.name,frame_parts=[v.name for v in bars],backing=wall.name,axis=axis,sign=sign,wall_face=face,pane_bounds=pb,frame_bounds=fb))
for x in [-14,-6]:window('AdminFrontLow'+str(x),admin,1,-1,x,1.8)
for x in [-14,-11.3,-8.6,-6]:window('AdminFrontUpper'+str(x),admin,1,-1,x,5.1,h=1.35)
for z in [1.8,4.95]:
    for x in [-14,-10.5,-7]:window('AdminRear'+str(x)+str(z),admin,1,1,x,z)
    for y in [-2,1.8,5.5]:window('AdminSide'+str(y)+str(z),admin,0,-1,y,z)
for y in [-2,1.5,5.2]:window('ServiceSide'+str(y),garage,0,1,y,2.5,w=1.85)
for x in [0,4.5,9]:window('ServiceRear'+str(x),garage,1,1,x,2.5,w=2)
# Public entry: closed double leaves and outboard trim, canopy above clear volume.
doors=[]
for side,a,b in [('L',-11,-10.015),('R',-9.985,-9)]:
    leaf=B('PublicLeaf'+side,(a,-5.08,0),(b,-4.99,2.6),'ServiceAccent','entry');doors.append(leaf.name)
for x in [-11.18,-9]:B('PublicJamb'+str(x),(x,-5.15,0),(x+.18,-4.99,2.82),'LightStone','entry')
B('PublicHead',(-11,-5.15,2.6),(-9,-4.99,2.82),'LightStone','entry')
B('PublicCanopy',(-12,-6.6,3.05),(-8,-4.95,3.28),'ServiceAccent','entry')
for x in [-11.8,-8.35]:B('CanopyBracket'+str(x),(x,-5.7,2.84),(x+.15,-4.98,3.05),'EquipmentMetal','entry')
# Modest attached shield relief, original outline, extruded along Y.
verts2=[(-.52,.42),(.52,.42),(.48,-.12),(0,-.65),(-.48,-.12)]
verts=[(-10+x,y,4.12+z) for y in [-5.04,-5.18] for x,z in verts2]
faces=[(4,3,2,1,0),(5,6,7,8,9)]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)]
mesh=bpy.data.meshes.new('ShieldMesh');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new('ReceptionShield',mesh);bpy.context.collection.objects.link(o);register(o,'LightStone','emblem')
B('ShieldCentre',(-10.13,-5.23,3.91),(-9.87,-5.175,4.38),'ServiceAccent','emblem')
bays=[]
for k,x in enumerate([2,8]):
    target=B('Bay%dSectionalLeaf'%(k+1),(x-2.25,-5.08,0),(x+2.25,-4.98,3.6),'EquipmentMetal','garage').name
    for side,xx in [('L',x-2.45),('R',x+2.25)]:B('Bay%dJamb%s'%(k+1,side),(xx,-5.2,0),(xx+.2,-4.98,3.85),'LightStone','garage')
    B('Bay%dHead'%(k+1),(x-2.25,-5.2,3.6),(x+2.25,-4.98,3.85),'LightStone','garage')
    for j,z in enumerate([.72,1.44,2.16,2.88]):B('Bay%dSectionRail%d'%(k+1,j),(x-2.24,-5.12,z),(x+2.24,-5.075,z+.045),'ServiceAccent','garage')
    window('Bay%dUpperLight'%(k+1),garage,1,-1,x,4.52,w=2.8,h=.65)
    bays.append(dict(id='bay-'+str(k+1),target=target,xyz_m=[x,-5.22,0],outward=[0,-1,0],width_m=4.5,height_m=3.6,boundary_connector={'xyz_m':[x,-16,0]},reserved_free_corridor={'min':[x-2.25,-16,0],'max':[x+2.25,-5.221,3.6]}))
# Equipment feet and cabinets touch real roof; no freestanding ground objects.
for i,x in enumerate([-13,-7]):
    B('HVACBase'+str(i),(x-.85,3,6.68),(x+.85,4.5,6.85),'EquipmentMetal','equipment')
    B('HVACCabinet'+str(i),(x-.75,3.1,6.85),(x+.75,4.4,7.55),'EquipmentMetal','equipment')
    for j in range(4):B('HVACSlat%d_%d'%(i,j),(x-.65,3.085,6.98+j*.12),(x+.65,3.105,7.02+j*.12),'ServiceAccent','equipment')
B('AerialFoot',(-5.5,5.4,6.68),(-5,5.9,6.85),'EquipmentMetal','equipment')
register(cylinder('RadioMast',.065,1.7,(-5.25,5.65,7.7),(1,1,1,1),vertices=8),'EquipmentMetal','equipment')
anchors=[dict(role='pedestrian',target='PublicLeafL',xyz_m=[-10,-6.62,0],outward=[0,-1,0],width_m=2,grade_m=0,boundary_connector=dict(xyz_m=[-10,-16,0],outward=[0,-1,0],width_m=2,grade_m=0),reserved_free_corridor={'min':[-11,-16,0],'max':[-9,-5.221,2.4]}),dict(role='service',target=bays[0]['target'],xyz_m=[2,-5.22,0],outward=[0,-1,0],width_m=4.5,grade_m=0,boundary_connector=dict(xyz_m=[2,-16,0],outward=[0,-1,0],width_m=4.5,grade_m=0),reserved_free_corridor=bays[0]['reserved_free_corridor'])]
# Every solid is included, without exemptions, in positive-volume corridor testing.
for lane in [a['reserved_free_corridor'] for a in anchors]+[b['reserved_free_corridor'] for b in bays]:
    for c in components:
        assert not all(min(c['max'][i],lane['max'][i])-max(c['min'][i],lane['min'][i])>1e-6 for i in range(3)),('Corridor obstruction',c['name'])
assert len({c['name'] for c in components})==len(components)
assert len(mounts)==len([o for o in objects if o.data.materials[0].name=='WindowGlass'])
for o in objects:
    assert all(abs(v)<1e-6 for v in o.location) and all(abs(v-1)<1e-6 for v in o.scale)
    assert all(math.isfinite(x) for u in o.data.uv_layers.active.data for x in u.uv)
    # Each authored object is one connected solid.
    adj={v.index:set() for v in o.data.vertices}
    for e in o.data.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
    seen={0};stack=[0]
    while stack:
        for v in adj[stack.pop()]-seen:seen.add(v);stack.append(v)
    assert len(seen)==len(adj),o.name
bounds={'min':[min(c['min'][i] for c in components) for i in range(3)],'max':[max(c['max'][i] for c in components) for i in range(3)]}
write('material-manifest.json',dict(regions=spec,textures=receipts,FBX_note='Graphs require native reconstruction from this manifest.'))
write('window-mounts.json',dict(windows=mounts,doors=[dict(target=n,backing='AdminOccupied',axis=1,sign=-1,wall_face=-5) for n in doors]+[dict(target=b['target'],backing='GarageOccupied',axis=1,sign=-1,wall_face=-5) for b in bays]))
write('entrance-anchors.json',dict(anchors=anchors));write('vehicle-bays.json',dict(bays=bays))
write('upgrade-plan.json',dict(family='police',stage='medium',stage_index=1,existing_stages=['base','medium','high'],existing_upgrade_count=2,gameplay_changes=False,source_site_m=[40,32],current_native_footprint=[3,2],retained_entrance_centres=[[-10,-5],[2,-5]],progression='Second apparatus bay and useful side offices; two storey public reception/admin, enclosed connector.',occupied_bounds=bounds,LOD_policy='Future LOD1/LOD2 simplify rims, emblem and roof gear; no production adoption.'))
write('civic-contract.json',dict(family='police',stage='medium',sourceID='building.police_medium.a',role='review-only civic station',groups=groups,proposed_site_m=[40,32],integration='HELD',source_preserved=True))
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
tri=sum(len(o.data.polygons)*2 for o in objects)
for o in objects:o.data.calc_loop_triangles()
tri=sum(len(o.data.loop_triangles) for o in objects);assert tri<=6500
# Tested runner performs the actual export/import triangle, region and dimension checks.
finish(objects)
p=out/'validation.json';v=json.loads(p.read_text()) if p.exists() else {}
v.update(components=components,sourceID='building.police_medium.a',triangle_cap=6500,authored_triangles=tri,semantic_regions=list(mats),occupied_bounds=bounds,window_count=len(mounts),assertions=dict(connected_solids=True,identity_transforms=True,finite_UV0=True,wall_containment=True,frame_contact=True,frame_depth=True,clear_openings=True,rim_disjointness=True,all_corridors_unobstructed=True,site_bounds=True),review_only=True,integration='HELD',textures=receipts)
write('validation.json',v)
assert (out/'asset.fbx').is_file() and (out/'asset.blend').is_file() and (out/'preview.png').is_file()

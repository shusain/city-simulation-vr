import bpy, sys, math, json
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
# Previous recipe was not staged: reconstruct only the requested review source.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
fabric=bpy.data.materials.new('Fabric'); fabric.use_nodes=True
p=fabric.node_tree.nodes.get('Principled BSDF'); p.inputs['Roughness'].default_value=.88
attr=fabric.node_tree.nodes.new('ShaderNodeVertexColor'); attr.layer_name='PanelColor'
fabric.node_tree.links.new(attr.outputs['Color'],p.inputs['Base Color'])
fabric.diffuse_color=(.73,.38,.30,1)
frame=bpy.data.materials.new('Frame'); frame.diffuse_color=(.46,.28,.14,1); frame.use_nodes=True
p=frame.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=frame.diffuse_color; p.inputs['Roughness'].default_value=.65
verts=[]; faces=[]; slots=[]; cols=[]; groups={}
palette=[(.70,.31,.25,1),(.88,.80,.63,1),(.19,.44,.43,1),(.88,.80,.63,1)]
def face(v,slot,col): faces.append(v); slots.append(slot); cols.append(col)
n=32
for underside in (False,True):
    start=len(verts); dz=-.012 if underside else 0
    verts.append((0,0,2.19+dz))
    for r,z in ((.38,2.14),(.78,2.02),(1.1,1.86)):
        for i in range(n):
            a=2*math.pi*i/n; verts.append((r*math.cos(a),r*math.sin(a),z+dz))
    groups['Canopy_Lining' if underside else 'Canopy_Panels']=list(range(start,len(verts)))
    for i in range(n):
        j=(i+1)%n; color=palette[(i//2)%4]
        f=[start,start+1+i,start+1+j]
        face(list(reversed(f)) if underside else f,0,color)
        for ring in range(2):
            a=start+1+ring*n; b=a+n
            f=[a+i,b+i,b+j,a+j]
            face(list(reversed(f)) if underside else f,0,color)
# Closed thin fabric edge, no alpha surfaces.
for i in range(n):
    j=(i+1)%n
    face([65+i,162+i,162+j,65+j],0,palette[(i//2)%4])
def spindle(name,rings,count):
    start=len(verts)
    for r,z in rings:
        for i in range(count):
            a=2*math.pi*i/count; verts.append((r*math.cos(a),r*math.sin(a),z))
    face([start+i for i in reversed(range(count))],1,frame.diffuse_color)
    for ring in range(len(rings)-1):
        a=start+ring*count; b=a+count
        for i in range(count):
            j=(i+1)%count; face([a+i,a+j,b+j,b+i],1,frame.diffuse_color)
    last=start+(len(rings)-1)*count
    face([last+i for i in range(count)],1,frame.diffuse_color)
    groups[name]=list(range(start,len(verts)))
# Small tapered ground end integrated in shaft; no redundant buried cap.
spindle('Pole_and_ground_tip',[(.006,0),(.022,.10),(.022,2.17)],10)
spindle('Crown_cap',[(.033,2.175),(.018,2.20)],8)
mesh=bpy.data.meshes.new('Umbrella_SourceMesh'); mesh.from_pydata(verts,[],faces); mesh.materials.append(fabric); mesh.materials.append(frame); mesh.update()
obj=bpy.data.objects.new('Resident_Beach_Umbrella',mesh); scene.collection.objects.link(obj)
color=mesh.color_attributes.new(name='PanelColor',type='FLOAT_COLOR',domain='CORNER')
for poly,slot,col in zip(mesh.polygons,slots,cols):
    poly.material_index=slot
    for li in poly.loop_indices: color.data[li].color=col
for name,indices in groups.items(): obj.vertex_groups.new(name=name).add(indices,1,'REPLACE')
obj['review_only']=True; obj['source_note']='Prior v1 recipe not included in pinned inputs; reconstructed restrained source study, not a verified exact v1 edit.'
mesh.calc_loop_triangles(); assert 250<=len(mesh.loop_triangles)<=500
finish([obj])
# Locate the joined export mesh after the tested helper has established its studio.
asset=max((o for o in scene.objects if o.type=='MESH'),key=lambda o:len(o.data.polygons))
bpy.context.view_layer.objects.active=asset
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True)
# Preserve ground-tip pivot independent of helper join behavior.
scene.cursor.location=(0,0,0); bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
asset.data.calc_loop_triangles(); tris=len(asset.data.loop_triangles)
assert 250<=tris<=500
assert [m.name for m in asset.data.materials]==['Fabric','Frame']
with checked_fbx(asset,'/output/asset.fbx',['Fabric','Frame'],expected_triangles=tris,expected_sections=2) as imported:
    roundtrip={'triangles':len(imported.data.loop_triangles),'dimensions_m':list(imported.dimensions),'passed':True}
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
cam=scene.camera
original=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.type,cam.data.ortho_scale)
def view(path,location,target,scale):
    cam.location=location; cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.type='ORTHO'; cam.data.ortho_scale=scale
    scene.render.filepath=path; bpy.ops.render.render(write_still=True)
view('/output/preview.png',(3.6,-5,3.1),(0,0,1.1),3.1)
view('/output/top.png',(0,0,7),(0,0,0),2.8)
# Non-export annotation: 1 m scale marker in front elevation.
curve=bpy.data.curves.new('One_metre_scale','CURVE'); curve.dimensions='3D'; curve.bevel_depth=.007; curve.bevel_resolution=0
for points in [[(-1.35,0,.1),(-1.35,0,1.1)],[(-1.41,0,.1),(-1.29,0,.1)],[(-1.41,0,1.1),(-1.29,0,1.1)]]:
    sp=curve.splines.new('POLY'); sp.points.add(len(points)-1)
    for p,co in zip(sp.points,points): p.co=(*co,1)
ruler=bpy.data.objects.new('Review_only_1m_marker',curve); scene.collection.objects.link(ruler); curve.materials.append(frame)
text=bpy.data.curves.new('Scale_label','FONT'); text.body='1 m'; text.size=.11
label=bpy.data.objects.new('Review_only_scale_label',text); scene.collection.objects.link(label); label.location=(-1.62,-.01,.58); label.rotation_euler=(math.pi/2,0,0); text.materials.append(frame)
view('/output/front_1m.png',(0,-6,1.1),(-.1,0,1.1),3.3)
ruler.hide_render=True; label.hide_render=True; ruler.hide_set(True); label.hide_set(True)
cam.location,cam.rotation_euler,cam.data.type,cam.data.ortho_scale=original
scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
validation_path=Path('/output/validation.json')
try: report=json.loads(validation_path.read_text())
except Exception: report={}
report.update({'triangles':tris,'within_250_500':True,'materials':['Fabric','Frame'],'dimensions_m':list(asset.dimensions),'origin':list(asset.location),'fbx_roundtrip':roundtrip,'review_only':True,'previous_source_available':False,'exact_v1_preservation_verified':False,'views':['preview.png','front_1m.png','top.png']})
validation_path.write_text(json.dumps(report,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'asset':'D108 Resident beach umbrella','status':'Review only; no production approval','blend':'asset.blend','fbx':'asset.fbx','validation':report,'construction':'Closed double-sided 32-segment canopy, integrated tapered pole tip; two semantic slots, per-corner fabric palette; readable vertex groups','revision_limitation':'Previous recipe and blend were not staged; exact prior appearance cannot be verified.'},indent=2))

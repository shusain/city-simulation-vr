import bpy,sys,json,math,shutil,hashlib
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
objects=load_previous();assert len(objects)==1
ob=objects[0];me=ob.data
assert not ob.modifiers and all(abs(x)<1e-6 for x in ob.location) and all(abs(x-1)<1e-6 for x in ob.scale)
parts={g.name:[] for g in ob.vertex_groups};names={g.index:g.name for g in ob.vertex_groups}
for v in me.vertices:
 gs=[g for g in v.groups if g.weight>.5];assert len(gs)==1
 parts[names[gs[0].group]].append(v.index)
def bounds(n):
 vs=[me.vertices[i].co for i in parts[n]]
 return [[min(v[a] for v in vs) for a in range(3)],[max(v[a] for v in vs) for a in range(3)]]
B={n:bounds(n) for n in parts}
def snap(n):
 ix=parts[n];ss=set(ix)
 return dict(vertices=[tuple(me.vertices[i].co) for i in ix],faces=[(tuple(p.vertices),p.material_index,tuple(tuple(me.uv_layers.active.data[j].uv) for j in p.loop_indices)) for p in me.polygons if p.vertices[0] in ss])
old={n:snap(n) for n in parts};changed=set()
def edit(n,x=None,z=None,top=None):
 assert n in parts;nlo,nhi=B[n];changed.add(n)
 for i in parts[n]:
  v=me.vertices[i]
  if x is not None:v.co.x=x[0]+(v.co.x-nlo[0])/(nhi[0]-nlo[0])*(x[1]-x[0])
  if z is not None:v.co.z=z[0]+(v.co.z-nlo[2])/(nhi[2]-nlo[2])*(z[1]-z[0])
  if top is not None and abs(v.co.z-nhi[2])<1e-5:v.co.z=top
for n in ['Front_Pilaster_-7.7','Front_Pilaster_4','Front_Pilaster_17.7']:edit(n,top=7.95)
edit('PublicDoor_-15.51',x=[-16.057,-15.003],z=[.003,2.707])
edit('PublicDoor_-14.49',x=[-14.997,-13.943],z=[.003,2.707])
for n in ['EntryJamb_-16.15','EntryJamb_-13.85']:edit(n,top=2.71)
edit('ReceivingDoor_-2',x=[-4.437,.437],z=[.003,4.722])
edit('ReceivingDoor_10',x=[7.563,12.437],z=[.003,4.722])
jambs=[n for n in parts if n.startswith('BayJamb_')];assert len(jambs)==4
for n in jambs:edit(n,top=4.725)
assert len(changed)==13 and len(parts)==254
me.update()
# Reproject only changed component face loops, preserving the source's 2m planar repeat.
changedids=set(i for n in changed for i in parts[n])
for p in me.polygons:
 if p.vertices[0] in changedids:
  ax=max(range(3),key=lambda a:abs(p.normal[a]));axes=[a for a in range(3) if a!=ax]
  for j in p.loop_indices:
   co=me.vertices[me.loops[j].vertex_index].co;me.uv_layers.active.data[j].uv=(co[axes[0]]/2,co[axes[1]]/2)
C={n:bounds(n) for n in parts}
for n in parts:
 if n not in changed:assert snap(n)==old[n],('unexpected change',n)
 else:
  assert C[n][0][1]==B[n][0][1] and C[n][1][1]==B[n][1][1]
  assert [(x[0],x[1]) for x in snap(n)['faces']]==[(x[0],x[1]) for x in old[n]['faces']]
def positive(a,b):return all(min(a[1][i],b[1][i])-max(a[0][i],b[0][i])>1e-6 for i in range(3))
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
for name in ['entrance-anchors.json','vehicle-bays.json','window-mounts.json','upgrade-plan.json','material-manifest.json','waste-contract.json','corner-contract.json']:
 shutil.copyfile(Path('/previous')/name,O/name)
roofsupports=[]
for n in ['Front_Pilaster_-7.7','Front_Pilaster_4','Front_Pilaster_17.7']:
 assert abs(C[n][1][2]-C['Hall_SlateRoof'][0][2]-.01)<1e-5
 assert positive(C[n],C['Hall_SlateRoof'])
 roofsupports.append(dict(part=n,roof='Hall_SlateRoof',contact_axis=2,embed_m=.01))
assemblies=[]
publicj=['EntryJamb_-16.15','EntryJamb_-13.85']
for id,leaves,js,header in [('public',['PublicDoor_-15.51','PublicDoor_-14.49'],publicj,'EntryHeader'),('receiving_1',['ReceivingDoor_-2'],sorted(jambs,key=lambda n:C[n][0][0])[:2],'BayHeader_-2'),('receiving_2',['ReceivingDoor_10'],sorted(jambs,key=lambda n:C[n][0][0])[2:],'BayHeader_10')]:
 js=sorted(js,key=lambda n:C[n][0][0]);l,r=js;h=C[header][0][2];xmin=C[l][1][0];xmax=C[r][0][0]
 for j in js:
  assert abs(C[j][1][2]-h)<1e-5 and not positive(C[j],C[header])
 leaves=sorted(leaves,key=lambda n:C[n][0][0])
 assert abs(C[leaves[0]][0][0]-xmin-.003)<1e-5
 assert abs(xmax-C[leaves[-1]][1][0]-.003)<1e-5
 for a,b in zip(leaves,leaves[1:]):assert abs(C[b][0][0]-C[a][1][0]-.006)<1e-5
 for n in leaves:
  assert abs(C[n][0][2]-.003)<1e-5 and abs(h-C[n][1][2]-.003)<1e-5
  assert xmin<C[n][0][0]<C[n][1][0]<xmax
 assemblies.append(dict(id=id,leaves=leaves,left_jamb=l,right_jamb=r,header=header,axis=1,sign=-1,inner_opening=dict(min=[xmin,-8.4,0],max=[xmax,-7.9,h]),edge_reveal_m=.003,centre_or_panel_seam_m=.006))
# Actual polygon ray tests from the public side. Use several near-edge points per leaf.
bvh=BVHTree.FromPolygons([v.co.copy() for v in me.vertices],[list(p.vertices) for p in me.polygons],all_triangles=False)
owner={i:n for n,ix in parts.items() for i in ix};rays=[]
for a in assemblies:
 for n in a['leaves']:
  lo,hi=C[n]
  for x,z in [(lo[0]+.012,lo[2]+.012),(hi[0]-.012,lo[2]+.012),(lo[0]+.012,hi[2]-.012),(hi[0]-.012,hi[2]-.012),((lo[0]+hi[0])/2,(lo[2]+hi[2])/2)]:
   hit,normal,idx,dist=bvh.ray_cast(Vector((x,-20,z)),Vector((0,1,0)),30)
   assert idx is not None and owner[me.polygons[idx].vertices[0]]==n,('door ray',n,x,z,idx)
   rays.append(dict(part=n,point=[x,z],first_hit=n))
write('assembly-fit-contract.json',dict(family='recycling',stage='medium',roof_supports=roofsupports,doors=assemblies,ray_checks=rays))
mount=json.loads((O/'window-mounts.json').read_text());assert len(mount['windows'])==25
for w in mount['windows']:
 assert C[w['pane']]==B[w['pane']]
 for n in w['frame_parts']+[w['backing']]:assert snap(n)==old[n]
# Refresh any explicitly named door component bounds while keeping all window records untouched.
def refresh(node):
 if isinstance(node,list):
  for v in node:refresh(v)
 elif isinstance(node,dict):
  refs=[v for v in node.values() if isinstance(v,str) and v in changed]
  for n in refs:
   for k in ['bounds','pane_bounds','leaf_bounds','door_bounds']:
    if k in node:node[k]=C[n]
  for k,v in list(node.items()):
   if k in changed and isinstance(v,dict):
    for field in ['bounds','pane_bounds','leaf_bounds','door_bounds']:
     if field in v:v[field]=C[k]
   refresh(v)
refresh(mount.get('doors',[]));write('window-mounts.json',mount)
for file,key in [('entrance-anchors.json','anchors'),('vehicle-bays.json','bays')]:
 data=json.loads((O/file).read_text())
 if key=='anchors':assert len(data[key])==2
 for a in data[key]:
  corridor=a['reserved_free_corridor'];bb=[corridor['min'],corridor['max']]
  for n,c in C.items():assert not positive(c,bb),('approach obstructed',file,n)
contract=json.loads((O/'waste-contract.json').read_text());assert isinstance(contract['groups'],dict) and contract['stage']=='medium'
upgrade=json.loads((O/'upgrade-plan.json').read_text());upgrade['technical_fit_note']='13 existing solids adjusted in place: continuous pilaster roof contact and 3mm door reveals / 6mm public seam; no gameplay, stage or footprint change.';write('upgrade-plan.json',upgrade)
tex=[];(O/'textures').mkdir(exist_ok=True)
for folder,stem in [('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for typ in ['BaseColor','Normal','ORM']:
  p=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+typ+'.png');dst=O/'textures'/p.name;shutil.copyfile(p,dst)
  ims=[im for im in bpy.data.images if Path(im.filepath).name==p.name or im.name.split('.png')[0]==p.stem];assert ims
  im=ims[0];im.filepath=str(dst);assert im.colorspace_settings.name==('sRGB' if typ=='BaseColor' else 'Non-Color');im.pack()
  tex.append(dict(path='textures/'+p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
me.calc_loop_triangles();assert len(me.loop_triangles)==3084 and len(me.materials)==6
assert all(math.isfinite(x) for u in me.uv_layers.active.data for x in u.uv)
# Connected-component uniqueness and closed-solid checks on actual post-edit mesh.
for n,ix in parts.items():
 ss=set(ix);adj={i:set() for i in ix};edges={}
 for p in me.polygons:
  if p.vertices[0] not in ss:continue
  assert set(p.vertices)<=ss
  vs=list(p.vertices)
  for a,b in zip(vs,vs[1:]+vs[:1]):
   e=tuple(sorted((a,b)));edges[e]=edges.get(e,0)+1;adj[a].add(b);adj[b].add(a)
 seen=set();todo=[ix[0]]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 assert seen==ss and all(v==2 for v in edges.values()),n
 assert all(C[n][0][i]>=[-23.5,-19.5,0][i]-1e-5 and C[n][1][i]<=[23.5,19.5,20][i]+1e-5 for i in range(3))
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
finish(objects)
r=json.loads((O/'validation.json').read_text());r.update(review_only=True,integration='HELD',sourceID='building.recycling_medium.a',components=[dict(name=n,min=c[0],max=c[1]) for n,c in C.items()],changed_components=sorted(changed),unchanged_components=241,preserved_component_geometry_uv_materials=True,window_count=25,window_mount_checks=True,empty_corridor_checks=True,assembly_fit_checks=True,door_ray_count=len(rays),texture_records=tex,source_site_m=[48,40]);write('validation.json',r)

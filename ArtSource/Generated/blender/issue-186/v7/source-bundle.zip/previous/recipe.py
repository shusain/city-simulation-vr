import bpy,sys,json,math,shutil,hashlib,bmesh
from pathlib import Path
sys.path.insert(0,'/worker');sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous,box,finish
O=Path('/output');O.mkdir(exist_ok=True)
objects=load_previous();assert len(objects)==1
ob=objects[0];bpy.context.view_layer.update()
assert not ob.modifiers
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
def parts_of():
 me=ob.data; ids={g.index:g.name for g in ob.vertex_groups};parts={g.name:[] for g in ob.vertex_groups}
 for v in me.vertices:
  gs=[g for g in v.groups if g.weight>.5];assert len(gs)==1
  parts[ids[gs[0].group]].append(v.index)
 return parts
def bounds(ix):
 vs=[ob.data.vertices[i].co for i in ix]
 return [[min(v[a] for v in vs) for a in range(3)],[max(v[a] for v in vs) for a in range(3)]]
parts=parts_of();before={n:bounds(ix) for n,ix in parts.items()}
removed=['Admin_Belt_0.22','Admin_Belt_3.2','Admin_Belt_6.28']+[n for n in parts if n.startswith(('Hall_ParapetSide','Hall_ParapetEnd'))]
assert len(removed)==7 and all(n in parts for n in removed),removed
# Preserve an exact per-component snapshot, including UVs and region assignments.
def snap(n,ps):
 ix=ps[n];ss=set(ix);me=ob.data
 return dict(vertices=[tuple(me.vertices[i].co) for i in ix],faces=[([ix.index(i) for i in p.vertices],p.material_index,[tuple(me.uv_layers.active.data[j].uv) for j in p.loop_indices]) for p in me.polygons if p.vertices[0] in ss])
saved={n:snap(n,parts) for n in parts if n not in removed}
roof_top=before['Hall_SlateRoof'][1][2];assert abs(roof_top-8.16)<.001
bm=bmesh.new();bm.from_mesh(ob.data);bm.verts.ensure_lookup_table()
kill=set(i for n in removed for i in parts[n]);bmesh.ops.delete(bm,geom=[bm.verts[i] for i in kill],context='VERTS');bm.to_mesh(ob.data);bm.free()
for n in removed:ob.vertex_groups.remove(ob.vertex_groups[n])
stone=next(m for m in ob.data.materials if m.name=='LightStone')
new={};add=[]
def strip(n,lo,hi):
 new[n]=[lo,hi];obj=box(n,tuple(hi[a]-lo[a] for a in range(3)),tuple((lo[a]+hi[a])/2 for a in range(3)),(.9,.85,.7,1));obj.data.materials.clear();obj.data.materials.append(stone)
 bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 uv=obj.data.uv_layers.active or obj.data.uv_layers.new(name='UVMap')
 for p in obj.data.polygons:
  ax=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=ax]
  for j in p.loop_indices:
   co=obj.data.vertices[obj.data.loops[j].vertex_index].co;uv.data[j].uv=(co[axes[0]]/2,co[axes[1]]/2)
 g=obj.vertex_groups.new(name=n);g.add(list(range(len(obj.data.vertices))),1,'REPLACE');add.append(obj)
for label,z in [('Lower',.22),('Middle',3.20),('Upper',6.30)]:
 pref='TrimR2_'+label+'_'
 strip(pref+'F',[-20.06,-8.06,z-.06],[-9.94,-7.99,z+.06])
 strip(pref+'B',[-20.06,4.99,z-.06],[-9.94,5.06,z+.06])
 strip(pref+'W',[-20.06,-7.99,z-.06],[-19.99,4.99,z+.06])
 strip(pref+'E',[-10.01,-7.99,z-.06],[-9.94,4.99 if label=='Upper' else .99,z+.06])
for side,lo,hi in [('W',[-8,-8],[-7.78,10]),('E',[17.78,-8],[18,10]),('F',[-7.78,-8],[17.78,-7.78]),('B',[-7.78,9.78],[17.78,10])]:strip('ParapetR2_'+side,lo+[roof_top-.01],hi+[roof_top+.37])
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True)
for obj in add:obj.select_set(True)
bpy.context.view_layer.objects.active=ob;bpy.ops.object.join();objects=[ob]
parts=parts_of();C={n:bounds(ix) for n,ix in parts.items()}
for n,s in saved.items():assert snap(n,parts)==s,('changed untouched component',n)
def positive(a,b,axes=(0,1,2)):
 return all(min(a[1][i],b[1][i])-max(a[0][i],b[0][i])>1e-6 for i in axes)
joints=[]
def contact(a,b):
 aa=C[a];bb=C[b];assert not positive(aa,bb),(a,b)
 gaps=[max(aa[0][i]-bb[1][i],bb[0][i]-aa[1][i],0) for i in range(3)];assert max(gaps)<=.001,(a,b,gaps)
 plane=[dict(axis=i,coordinate=(aa[1][i]+bb[0][i])/2) for i in range(3) if abs(aa[1][i]-bb[0][i])<.001]
 plane += [dict(axis=i,coordinate=(bb[1][i]+aa[0][i])/2) for i in range(3) if abs(bb[1][i]-aa[0][i])<.001]
 assert plane;joints.append(dict(a=a,b=b,contact_planes=plane,gaps=gaps))
for label in ['Lower','Middle','Upper']:
 p='TrimR2_'+label+'_'
 for a,b in [('F','W'),('F','E'),('B','W')]+([('B','E')] if label=='Upper' else []):contact(p+a,p+b)
for a,b in [('F','W'),('F','E'),('B','W'),('B','E')]:contact('ParapetR2_'+a,'ParapetR2_'+b)
assert len(joints)==14
for i,a in enumerate(new):
 for b in list(new)[:i]:assert not positive(C[a],C[b]),(a,b)
for n in new:
 if n.startswith('Parapet'):
  assert abs(C[n][0][2]-(roof_top-.01))<1e-5 and abs(C[n][1][2]-(roof_top+.37))<1e-5
 for w in C:
  if w.startswith(('OfficeFront_','OfficeWest_','OfficeRear_','HallFrontClerestory_','HallEastClerestory_')):assert not positive(C[n],C[w]),(n,w)
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
# Spatial contracts are copied byte-for-byte from the checked source, not regenerated.
for name in ['entrance-anchors.json','vehicle-bays.json','window-mounts.json','upgrade-plan.json','material-manifest.json','waste-contract.json']:
 src=Path('/previous')/name
 assert src.exists(),('missing source contract',name)
 shutil.copyfile(src,O/name)
mount=json.loads((O/'window-mounts.json').read_text());assert len(mount['windows'])==25
for w in mount['windows']:
 pane=w['pane'];axis=w['axis'];sign=w['sign'];face=w['wall_face'];wall=C[w['backing']];tang=[i for i in range(3) if i!=axis]
 assert all(abs(C[pane][k][i]-w['pane_bounds'][k][i])<1e-5 for k in range(2) for i in range(3))
 rims=[C[n] for n in w['frame_parts']]
 for r in [C[pane]]+rims:assert all(r[0][i]>=wall[0][i]+.12-1e-5 and r[1][i]<=wall[1][i]-.12+1e-5 for i in tang)
 for j,r in enumerate(rims):
  assert abs((r[1][axis] if sign<0 else r[0][axis])-face+sign*.01)<1e-4
  assert not positive(r,C[pane],tang)
  for rr in rims[:j]:assert not positive(r,rr)
covered=set(i for w in mount['windows'] for i in parts[w['pane']]);glass={i for i,m in enumerate(ob.data.materials) if m.name=='WindowGlass'}
assert all(set(p.vertices)<=covered for p in ob.data.polygons if p.material_index in glass)
for file,key in [('entrance-anchors.json','anchors'),('vehicle-bays.json','bays')]:
 data=json.loads((O/file).read_text())
 if key=='anchors':assert len(data[key])==2 and {a['role'] for a in data[key]}=={'pedestrian','service'}
 for a in data[key]:
  corridor=a['reserved_free_corridor'];b=[corridor['min'],corridor['max']]
  assert a['target'] in C
  for n,c in C.items():assert not positive(c,b),('corridor obstruction',file,n)
contract=json.loads((O/'waste-contract.json').read_text());assert isinstance(contract['groups'],dict)
contract.update(family='recycling',stage='medium',sourceID='building.recycling_medium.a',source_site_m=[48,40])
contract['groups']={k:[n for n in v if n in C] for k,v in contract['groups'].items()}
contract['groups']['TrimR2admin']=[n for n in new if n.startswith('TrimR2')];contract['groups']['ParapetR2roof']=[n for n in new if n.startswith('ParapetR2')];write('waste-contract.json',contract)
occupied=[[min(c[k][i] for c in C.values()) if k==0 else max(c[k][i] for c in C.values()) for i in range(3)] for k in range(2)]
upgrade=json.loads((O/'upgrade-plan.json').read_text());upgrade['occupied_bounds']=occupied;write('upgrade-plan.json',upgrade)
tex=[];(O/'textures').mkdir(exist_ok=True)
for folder,stem in [('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for typ in ['BaseColor','Normal','ORM']:
  p=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+typ+'.png');dst=O/'textures'/p.name;shutil.copyfile(p,dst)
  ims=[im for im in bpy.data.images if Path(im.filepath).name==p.name or im.name.split('.png')[0]==p.stem];assert ims,p.name
  im=ims[0];im.filepath=str(dst);im.colorspace_settings.name='sRGB' if typ=='BaseColor' else 'Non-Color';im.pack()
  tex.append(dict(path='textures/'+p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
me=ob.data;me.calc_loop_triangles();assert len(me.loop_triangles)<=8500 and len(me.materials)==6
assert me.uv_layers.active and all(math.isfinite(x) for u in me.uv_layers.active.data for x in u.uv)
# Verify each named group is exactly one closed connected solid.
for n,ix in parts.items():
 ss=set(ix);edges={};adj={i:set() for i in ix};vol=0
 for p in me.polygons:
  if p.vertices[0] not in ss:continue
  assert set(p.vertices)<=ss
  vs=list(p.vertices)
  for a,b in zip(vs,vs[1:]+vs[:1]):
   key=tuple(sorted((a,b)));edges[key]=edges.get(key,0)+1;adj[a].add(b);adj[b].add(a)
 seen=set();todo=[ix[0]]
 while todo:
  a=todo.pop()
  if a in seen:continue
  seen.add(a);todo.extend(adj[a]-seen)
 assert seen==ss and all(v==2 for v in edges.values()),n
 for t in me.loop_triangles:
  if t.vertices[0] in ss:
   a,b,c=[me.vertices[i].co for i in t.vertices];vol+=a.dot(b.cross(c))/6
 assert abs(vol)>1e-7,n
 assert all(C[n][0][i]>=[-23.5,-19.5,0][i]-1e-5 and C[n][1][i]<=[23.5,19.5,20][i]+1e-5 for i in range(3))
write('corner-contract.json',dict(removed=removed,strips={n:C[n] for n in new},joints=joints,required_joint_count=14,roof_top_m=roof_top,preserved_components=list(saved),all_unchanged_component_snapshots_pass=True))
for mesh in list(bpy.data.meshes):
 if mesh.users==0:bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
 if mat.users==0:bpy.data.materials.remove(mat)
bpy.context.scene.cursor.location=(0,0,0);bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
finish(objects)
r=json.loads((O/'validation.json').read_text());r.update(components=[dict(name=n,min=c[0],max=c[1]) for n,c in C.items()],sourceID='building.recycling_medium.a',review_only=True,integration='HELD',source_site_m=[48,40],occupied_bounds=occupied,corner_joint_count=14,window_count=25,window_mount_checks=True,empty_corridor_checks=True,texture_records=tex,preserved_component_geometry_uv_materials=True);write('validation.json',r)

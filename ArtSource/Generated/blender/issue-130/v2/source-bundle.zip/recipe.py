import bpy, math, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
out=Path('/output');out.mkdir(exist_ok=True)
expected={123:['a4f1eadbcef4ce61879463b710bd54910f10864179e93a4eff69efec38d0a3b4','cd720b85c44386dec305e3110d7c8d1aa702dc62aa689b4375d88e8dba508fbf','5fba12a32587cb88e0a3791f19394d718ea4cbeca113d916e603916836ae3b9f'],124:['1ddcd5e5043988801680dcf070607df1f7411050c21d0d463f985b64b071f1ee','e9a5b23f9b0ce83d28d976158d7cfeeb5f262dbb283876909389dd15111f6a40','6924da5d2fb7a1cefc95c02b4dd1fd67197d12f26c10b178f161fade64b4d161']}
refs=[]
for issue,hashes in expected.items():
    for name,want in zip(['asset.png','approval.json','unreal-handoff.json'],hashes):
        p=Path('/repo/ArtSource/Generated/comfy')/('issue-'+str(issue))/'v1'/name
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        assert actual==want,(str(p),actual)
        r={'path':str(p),'sha256':actual,'matches_pinned':True}
        if name.endswith('.png'):
            image=bpy.data.images.load(str(p),check_existing=False)
            size=list(image.size)
            pixel=float(image.pixels[0])
            r.update(size=list(image.size),has_data=bool(image.has_data),first_pixel=pixel)
            assert r['has_data'] and min(r['size'])>0
        else:
            json.loads(p.read_text())
        refs.append(r)
# Reference verification must finish before any modeling.
for ob in list(bpy.data.objects):
    bpy.data.objects.remove(ob,do_unlink=True)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1.0
# Seven broad raised rays alternating with shallow valleys; no miniature ornament.
v=[(0,-.09,.012)]
angles=[math.radians(-85+170*i/14) for i in range(15)]
for i,t in enumerate(angles):
    v.append((.11*math.sin(t)*.53,-.09+.18*math.cos(t)*.53,.045 if i%2==0 else .032))
for i,t in enumerate(angles):
    v.append((.11*math.sin(t),-.09+.18*math.cos(t),.012 if i%2==0 else .009))
f=[]
# Top winding points upward.
for i in range(14):
    f.append((0,1+i,2+i))
    f.append((1+i,16+i,17+i,2+i))
# Boundary follows the top surface counterclockwise.
boundary=[0]+list(range(1,16))
# Actual outline goes hinge, outer left to right; mid endpoints lie on side edges.
boundary=[0,1]+list(range(16,31))+[15]
# 18 perimeter vertices => top42 + bottom16 + sides36 =94 triangles.
bottom=[]
for idx in boundary:
    bottom.append(len(v));v.append((v[idx][0],v[idx][1],0))
f.append(tuple(reversed(bottom)))
for i in range(len(boundary)):
    j=(i+1)%len(boundary)
    f.append((boundary[j],boundary[i],bottom[i],bottom[j]))
mesh=bpy.data.meshes.new('FanShell_closed_lowpoly');mesh.from_pydata(v,[],f);mesh.update()
obj=bpy.data.objects.new('SM_Scenery_FanShell_A',mesh);scene.collection.objects.link(obj)
bpy.context.view_layer.objects.active=obj;obj.select_set(True)
# Recalculate consistently outward; preserve all broad flat regions.
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
mins=[min(v.co[k] for v in mesh.vertices) for k in range(3)];maxs=[max(v.co[k] for v in mesh.vertices) for k in range(3)]
for vert in mesh.vertices:
    for k,target in enumerate([.22,.18,.045]):
        vert.co[k]=(vert.co[k]-(0 if k==2 else (mins[k]+maxs[k])/2))*target/(maxs[k]-mins[k])
uv=mesh.uv_layers.new(name='UV0')
for poly in mesh.polygons:
    poly.use_smooth=False
    normal=poly.normal
    # Per-face orthonormal mapping ensures even vertical edges have nondegenerate UVs.
    a=Vector((1,0,0)) if abs(normal.x)<.8 else Vector((0,1,0))
    u=normal.cross(a).normalized();w=normal.cross(u).normalized()
    for li in poly.loop_indices:
        co=mesh.vertices[mesh.loops[li].vertex_index].co
        uv.data[li].uv=(.5+co.dot(u)*2,.5+co.dot(w)*2)
mat=bpy.data.materials.new('Shell');mat.diffuse_color=(.83,.76,.62,1);mat.use_nodes=True
bsdf=mat.node_tree.nodes.get('Principled BSDF');bsdf.inputs['Base Color'].default_value=mat.diffuse_color;bsdf.inputs['Roughness'].default_value=.72
mesh.materials.append(mat);mesh.update();bpy.context.view_layer.update();mesh.calc_loop_triangles()
tri=len(mesh.loop_triangles);assert tri<=96,tri
# Topological, normal and UV checks on actual authored mesh.
import bmesh
bm=bmesh.new();bm.from_mesh(mesh);closed=all(e.is_manifold for e in bm.edges);bm.free();assert closed
uv_ok=True
for t in mesh.loop_triangles:
    a,b,c=[Vector(uv.data[i].uv) for i in t.loops]
    area=abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x))
    uv_ok &= area>1e-12 and all(math.isfinite(x) for p in (a,b,c) for x in p)
assert uv_ok
with checked_fbx(obj,out/'asset.fbx',['Shell'],expected_triangles=tri,expected_sections=1) as check:
    roundtrip={'pass':True,'dimensions_m':list(check.dimensions),'triangles':len(check.data.loop_triangles),'materials':[m.name.split('.')[0] for m in check.data.materials]}
# Review-only lighting and camera: scale the camera, never the shell.
world=bpy.data.worlds.new('Neutral_review');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.25,.27,.30,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4;scene.world=world
for name,loc,power,size in [('Key',(-.18,-.12,.35),8,.25),('Fill',(.2,.12,.25),4,.22)]:
    light=bpy.data.lights.new(name,'AREA');light.energy=power;light.shape='DISK';light.size=size
    ob=bpy.data.objects.new(name,light);scene.collection.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,0,.015))-ob.location).to_track_quat('-Z','Y').to_euler()
camdata=bpy.data.cameras.new('ReviewCamera');cam=bpy.data.objects.new('ReviewCamera',camdata);scene.collection.objects.link(cam);scene.camera=cam;camdata.type='ORTHO';camdata.ortho_scale=.29;camdata.clip_start=.001;camdata.clip_end=10
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=16;scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
def render(loc,path):
    cam.location=loc;cam.rotation_euler=(Vector((0,0,.018))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
render((.25,-.34,.29),out/'preview.png')
render((0,0,.5),out/'preview_top.png')
cam.location=(.25,-.34,.29);cam.rotation_euler=(Vector((0,0,.018))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/'preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(out/'asset.blend'))
validation={'asset_name':obj.name,'review_only':True,'recovery':'Force pixel decode before has_data check; previous failure history preserved, no parent blend available','dimensions_m':list(obj.dimensions),'bounds_m':[[min(v.co[k] for v in mesh.vertices) for k in range(3)],[max(v.co[k] for v in mesh.vertices) for k in range(3)]],'minZ':min(v.co.z for v in mesh.vertices),'pivot':list(obj.location),'rotation':list(obj.rotation_euler),'scale':list(obj.scale),'triangles':tri,'materials':['Shell'],'material_count':1,'material_color':list(mat.diffuse_color),'roughness':.72,'closed_manifold':closed,'flat_shaded':True,'normals_finite':all(math.isfinite(c) for p in mesh.polygons for c in p.normal),'UV0_finite_nondegenerate':uv_ok,'collision':'none','source_LODs':1,'orientation':'hinge -Y, fan +Y, Z up','references':refs,'fbx_roundtrip':roundtrip,'fbx_sha256':hashlib.sha256((out/'asset.fbx').read_bytes()).hexdigest(),'production_changes':False,'approval':'pending human source review','preview_only_objects':['ReviewCamera','Key','Fill'],'scale_note':'Actual dimensions retained; close camera is not city-distance readability evidence.'}
(out/'validation.json').write_text(json.dumps(validation,indent=2))
(out/'provenance.json').write_text(json.dumps({'issue':'D108 fan shell #130','references':refs,'design':'One closed pale ivory seven-rib fan shell; technical recovery only','previous_recipe':'Not staged; reconstructed requested intended geometry','no_runtime_integration':True},indent=2))

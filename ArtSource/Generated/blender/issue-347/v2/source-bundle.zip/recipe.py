import bpy, sys, math, json
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
parts=[]
palette={}
for name,col,rough,metal in [('BodyPaint',(.115,.27,.40,1),.34,0),('CargoWhite',(.82,.84,.82,1),.53,0),('Glass',(.025,.065,.095,1),.19,0),('Rubber',(.018,.023,.027,1),.8,0),('MetalTrim',(.33,.39,.43,1),.32,.65),('Headlight',(.92,.92,.72,1),.23,0),('Taillight',(.62,.018,.012,1),.26,0),('AmberLens',(.95,.29,.025,1),.3,0)]:
 m=bpy.data.materials.new(name);m.diffuse_color=col;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 palette[name]=m

def materialize(o,mat):
 o.data.materials.clear();o.data.materials.append(palette[mat]);parts.append(o);return o

def B(n,d,l,m,bevel=0):
 o=materialize(box(n,d,l,palette[m].diffuse_color),m)
 if bevel:
  bpy.context.view_layer.objects.active=o
  mod=o.modifiers.new('Restrained edge bevel','BEVEL');mod.width=bevel;mod.segments=2
  bpy.ops.object.modifier_apply(modifier=mod.name)
 return o

def mesh(n,v,f,m):
 me=bpy.data.meshes.new(n);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);return materialize(o,m)

def panel(n,v,m):return mesh(n,v,[tuple(range(len(v)))],m)
# Metric rigid chassis; forward +X, ground contact at zero.
B('Ladder chassis',(5.9,1.28,.22),(-.04,0,.73),'Rubber',.035)
B('Cargo box',(4.05,2.22,1.92),(-1.095,0,2.04),'CargoWhite',.035)
for y in [-1.12,1.12]:
 B('Cargo lower edge rail',(4.06,.045,.10),(-1.095,y,1.12),'MetalTrim',.012)
 B('Cargo roof edge',(4.06,.045,.065),(-1.095,y,2.965),'MetalTrim',.01)
# Cab leaves a clear gap to the independent freight body.
B('Cab lower shell',(1.98,2.02,.48),(2.02,0,1.28),'BodyPaint',.065)
# Raked windscreen face x=2.97 at belt, x=2.63 at roof.
profile=[(1.05,1.50),(3.01,1.50),(2.62,2.48),(1.05,2.48)]
v=[(x,y,z) for y in [-1.01,1.01] for x,z in profile]
mesh('Raked cab upper shell',v,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],'BodyPaint')
B('Cab roof',(1.66,2.08,.095),(1.84,0,2.51),'BodyPaint',.035)
# Opaque glossy panes on the raked surface, with blue body pillars all around.
def wx(z):return 3.01-(z-1.5)*(.39/.98)+.012
panel('Broad raked windshield',[(wx(1.65),-.88,1.65),(wx(1.65),.88,1.65),(wx(2.36),.88,2.36),(wx(2.36),-.88,2.36)],'Glass')
for s in [-1,1]:
 y=s*1.022
 panel('Side cab glass',[(1.19,y,1.65),(2.82,y,1.65),(2.54,y,2.36),(1.19,y,2.36)],'Glass')
 B('Rear window pillar',(.075,.035,.72),(1.60,s*1.033,2.0),'BodyPaint',.006)
 B('Door handle',(.23,.055,.06),(1.34,s*1.045,1.47),'MetalTrim',.015)
 B('Entry step',(.62,.22,.13),(1.20,s*.99,.87),'MetalTrim',.02)
 B('Mirror arm',(.11,.29,.065),(2.48,s*1.13,1.90),'MetalTrim',.012)
 B('Mirror housing',(.18,.14,.35),(2.48,s*1.32,2.0),'Rubber',.035)
 B('Mirror glass',(.135,.015,.26),(2.48,s*1.397,2.0),'MetalTrim',.015)
# Nose and readable front lighting.
B('Front bumper',(.17,2.08,.19),(3.065,0,.91),'MetalTrim',.035)
B('Grille recess',(.035,.92,.27),(3.02,0,1.25),'Rubber',.025)
for z in [1.17,1.25,1.33]:B('Grille slat',(.045,.84,.025),(3.047,0,z),'MetalTrim',.006)
for s in [-1,1]:
 B('Headlight dark surround',(.055,.43,.25),(3.026,s*.76,1.26),'Rubber',.025)
 B('Paired headlamp',(.065,.32,.17),(3.06,s*.73,1.28),'Headlight',.022)
 B('Front indicator',(.066,.085,.17),(3.061,s*.945,1.28),'AmberLens',.012)
# Four full tires, rounded shoulder bevels and independently readable hubs.
for x in [-1.95,2.16]:
 for s in [-1,1]:
  o=materialize(cylinder('Tire',.50,.30,(x,s*.96,.50),palette['Rubber'].diffuse_color,vertices=24),'Rubber');o.rotation_euler.x=math.pi/2
  bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
  mod=o.modifiers.new('Rounded tire shoulders','BEVEL');mod.width=.065;mod.segments=3;bpy.ops.object.modifier_apply(modifier=mod.name)
  for p in o.data.polygons:p.use_smooth=True
  for n,r,dep,y,mat in [('Wheel rim',.295,.032,s*1.115,'MetalTrim'),('Hub center',.135,.055,s*1.14,'MetalTrim')]:
   o=materialize(cylinder(n,r,dep,(x,y,.5),palette[mat].diffuse_color,vertices=24),mat);o.rotation_euler.x=math.pi/2
   bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
  B('Rear mud flap' if x<0 else 'Cab mud flap',(.08,.32,.38),(x-.58,s*.96,.48),'Rubber',.01)
# Rear door frame, two leaves, visible center gap, hinges and locking rods.
B('Rear frame',(.06,2.17,1.87),(-3.137,0,2.03),'MetalTrim',.012)
for s in [-1,1]:
 B('Rear cargo door',(.055,1.015,1.72),(-3.18,s*.529,2.035),'CargoWhite',.018)
 B('Door locking bar',(.045,.038,1.47),(-3.221,s*.30,2.04),'MetalTrim',.008)
 B('Latch handle',(.06,.21,.045),(-3.24,s*.37,1.64),'MetalTrim',.009)
 for z in [1.44,2.55]:B('Door hinge',(.08,.16,.075),(-3.225,s*.97,z),'MetalTrim',.01)
 B('Tail lamp housing',(.10,.39,.23),(-3.14,s*.81,.92),'Rubber',.02)
 B('Red tail lamp',(.12,.23,.16),(-3.19,s*.86,.94),'Taillight',.015)
 B('Rear amber indicator',(.12,.10,.16),(-3.19,s*.675,.94),'AmberLens',.012)
B('Rear underride guard',(.13,2.02,.14),(-3.15,0,.48),'MetalTrim',.02)
# Apply all transforms and give each semantic part deterministic usable UV0.
for o in parts:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.025);bpy.ops.object.mode_set(mode='OBJECT')
bpy.context.scene.unit_settings.system='METRIC'
finish(parts)
# Additional review views use the runner's existing studio lighting and camera.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera;cam.data.type='ORTHO';cam.data.ortho_scale=7.7
for label,pos in [('side',(0,-12,1.5)),('front',(12,0,1.5)),('rear',(-12,0,1.5))]:
 cam.location=pos;cam.rotation_euler=(Vector((0,0,1.5))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath='/output/'+label+'.png';bpy.ops.render.render(write_still=True)
p='/output/validation.json'
with open(p) as f:facts=json.load(f)
facts['review_scope']='Fresh freight source preview only; no production changes or approval. Glass is opaque blue-gray glossy; headlights, red tail and amber indicator lenses are separate semantic materials; no emergency lights.'
facts['additional_views']=['side.png','front.png','rear.png']
with open(p,'w') as f:json.dump(facts,f,indent=2)

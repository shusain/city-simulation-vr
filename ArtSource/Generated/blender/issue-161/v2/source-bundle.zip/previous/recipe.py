import bpy, sys, math, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box,cylinder,finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
O=Path('/output'); O.mkdir(exist_ok=True)
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
refs=['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json','Tools/CityBuildingStudyIO.py']
provenance={p:hashlib.sha256((Path('/repo')/p).read_bytes()).hexdigest() for p in refs}
# Bounded read-only reference inspection, without loading production objects.
reference_summary={}
for p in refs[:4]:
 if p.endswith('.blend'):
  with bpy.data.libraries.load('/repo/'+p,link=False) as (src,dst): reference_summary[p]={'objects':list(src.objects)[:24],'materials':list(src.materials)[:24]}
 else:
  d=json.loads((Path('/repo')/p).read_text()); reference_summary[p]={'task':d.get('task'),'asset_count':len(d.get('assets',[]))}
colors={'Concrete':(.48,.49,.46,1),'BuildingFacade':(.62,.64,.59,1),'RoofService':(.12,.15,.16,1),'EquipmentMetal':(.28,.35,.34,1),'WindowAccent':(.105,.24,.29,1)}
mats={}
for name,col in colors.items():
 m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.72 if name!='WindowAccent' else .28
 mats[name]=m
n=mats['Concrete'].node_tree; p=n.nodes.get('Principled BSDF');noise=n.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=5; bump=n.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.035;n.links.new(noise.outputs['Fac'],bump.inputs['Height']);n.links.new(bump.outputs['Normal'],p.inputs['Normal'])
textures=[]
(O/'textures').mkdir(exist_ok=True)
for region,folder,stem in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
 m=mats[region]; nt=m.node_tree;p=nt.nodes.get('Principled BSDF'); nodes={}
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{stem}_{suffix}.png';src=Path('/repo')/rel;dst=O/'textures'/src.name;shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst));im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  t=nt.nodes.new('ShaderNodeTexImage');t.image=im;nodes[suffix]=t
  textures.append({'source':rel,'copy':str(dst),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'dimensions':list(im.size),'channels':im.channels,'colorspace':im.colorspace_settings.name,'packed':True,'semantic':region})
 # UV0 is already 0.5 * metre projection.
 split=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(nodes['ORM'].outputs['Color'],split.inputs[0])
 mix=nt.nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;nt.links.new(nodes['BaseColor'].outputs['Color'],mix.inputs[1]);nt.links.new(split.outputs['Red'],mix.inputs[2]);nt.links.new(mix.outputs[0],p.inputs['Base Color'])
 nt.links.new(split.outputs['Green'],p.inputs['Roughness']);nt.links.new(split.outputs['Blue'],p.inputs['Metallic'])
 normal=nt.nodes.new('ShaderNodeNormalMap');normal.space='TANGENT';nt.links.new(nodes['Normal'].outputs['Color'],normal.inputs['Color']);nt.links.new(normal.outputs['Normal'],p.inputs['Normal'])
objects=[]
def use(o,mat):
 o.data.materials.clear();o.data.materials.append(mats[mat]);objects.append(o);return o
def B(name,d,loc,mat='EquipmentMetal'):return use(box(name,d,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',seg=16):return use(cylinder(name,r,h,loc,colors[mat],vertices=seg),mat)
def pipe(name,a,b,r=.28,seg=12):
 a,b=Vector(a),Vector(b);o=C(name,r,(b-a).length,(a+b)/2,seg=seg);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def ring(name,x,y,ro,ri,z0,z1,mat,seg=48):
 verts=[(x+r*math.cos(2*math.pi*i/seg),y+r*math.sin(2*math.pi*i/seg),z) for r,z in [(ro,z0),(ro,z1),(ri,z1),(ri,z0)] for i in range(seg)]
 faces=[]
 for j in range(4):
  for i in range(seg): faces.append((j*seg+i,j*seg+(i+1)%seg,((j+1)%4)*seg+(i+1)%seg,((j+1)%4)*seg+i))
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return use(o,mat)
for i,x in enumerate([-6.8,6.8]):
 y=7.2;tag=f'Clarifier_{i+1}'
 ring(tag+'_structural_vessel',x,y,4.35,4.03,0,2.25,'Concrete')
 ring(tag+'_coping_rim',x,y,4.43,3.98,2.25,2.4,'Concrete')
 C(tag+'_recessed_calm_water',4.02,.08,(x,y,1.32),'WindowAccent',48)
 C(tag+'_spindle',.21,1.3,(x,y,1.99),seg=16)
 B(tag+'_diameter_service_bridge',(8.55,.48,.18),(x,y,2.55))
 C(tag+'_drive',.37,.4,(x,y,2.84),seg=16)
 # Sparse bridge-edge handrails, no dense ring of bars.
 for side in [-1,1]:
  for dx in [-4,-2,0,2,4]:B(tag+f'_post_{side}_{dx}',(.055,.055,1),(x+dx,y+side*.27,3.08))
  B(tag+f'_handrail_{side}',(8.2,.06,.06),(x,y+side*.27,3.58))
# Front occupied volumes. No shared foundation, slab or site surface.
B('Worker_control_two_storey_block',(9,7,6.3),(-7.5,-7,3.15),'BuildingFacade')
B('Worker_control_flat_roof',(9.35,7.35,.22),(-7.5,-7,6.41),'RoofService')
B('Control_floor_band',(9.08,7.08,.16),(-7.5,-7,3.2),'Concrete')
B('Filter_pump_hall',(10,7,4.6),(6.5,-6.5,2.3),'BuildingFacade')
B('Filter_hall_service_roof',(10.35,7.35,.22),(6.5,-6.5,4.71),'RoofService')
# front doors are distinct fixtures ahead of facade, both at grade.
B('Personnel_door_leaf',(1.2,.12,2.2),(-9.5,-10.56,1.1),'EquipmentMetal')
B('Personnel_door_glass',(.84,.035,1.1),(-9.5,-10.64,1.42),'WindowAccent')
B('Personnel_handle',(.05,.11,.35),(-9.06,-10.72,1.02))
B('Personnel_canopy',(2.1,1.0,.14),(-9.5,-10.8,2.65),'RoofService')
B('Service_vehicle_shutter',(4,.14,3.5),(7.5,-10.07,1.75),'EquipmentMetal')
for z in [.45,.95,1.45,1.95,2.45,2.95,3.45]:B('Shutter_seam_'+str(z),(3.92,.035,.035),(7.5,-10.16,z),'RoofService')
for x in [5.43,9.57]:B('Bay_jamb_'+str(x),(.13,.2,3.62),(x,-10.08,1.81),'Concrete')
B('Bay_header',(4.27,.2,.16),(7.5,-10.08,3.7),'Concrete')
# Opaque glazing: shallow surrounds behind blue-grey inset panes.
for level in [1.65,4.65]:
 for x in [-6.9,-4.5]:
  B(f'Control_front_frame_{x}_{level}',(1.85,.12,1.45),(x,-10.54,level),'EquipmentMetal')
  B(f'Control_front_window_{x}_{level}',(1.63,.04,1.23),(x,-10.62,level),'WindowAccent')
for y in [-8.9,-6.5,-4.2]:
 for z in [1.65,4.65]:
  B(f'Control_side_frame_{y}_{z}',(.12,1.8,1.45),(-12.04,y,z))
  B(f'Control_side_glazing_{y}_{z}',(.04,1.58,1.23),(-12.12,y,z),'WindowAccent')
# Hall clerestory and roof ventilation; all independent of entrance corridors.
for x in [2.8,4.5]:B('Hall_window_'+str(x),(1.35,.05,.8),(x,-10.05,3.7),'WindowAccent')
for x in [3.2,7.8]:
 B('Hall_roof_vent_'+str(x),(1.4,1.5,.6),(x,-5.8,5.11))
 B('Hall_vent_cap_'+str(x),(1.6,1.7,.12),(x,-5.8,5.47),'RoofService')
# Three major pipe runs with flanges and valve actuators in the service gap.
for j,x in enumerate([-10.8,0,10.8]):
 pipe(f'Main_{j}_horizontal',(x,-1.8,.85),(x,2.7,.85),.3)
 pipe(f'Main_{j}_riser',(x,2.7,.85),(x,2.7,1.9),.3)
 for y in [-.9,1.5]:pipe(f'Main_{j}_flange_{y}',(x,y-.07,.85),(x,y+.07,.85),.43,16)
 pipe(f'Valve_{j}_stem',(x,.2,.9),(x,.2,1.55),.065,8)
 C(f'Valve_{j}_handwheel',.31,.07,(x,.2,1.58),seg=16)
 for y in [-1.2,1.8]:B(f'Pipe_{j}_foot_{y}',(.18,.25,.55),(x,y,.275))
for x in [-1.1,1.1]:
 C('Upright_process_vessel_'+str(x),.62,2.65,(x,-4.1,1.675),seg=24)
 C('Vessel_cap_'+str(x),.65,.16,(x,-4.1,3.08),seg=24)
 for dx in [-.4,.4]:B('Vessel_leg_'+str(x)+str(dx),(.12,.5,.45),(x+dx,-4.1,.225))
# Apply transforms and build metric UV0 per dominant face axis.
components=[]
for o in objects:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
 for f in o.data.polygons:
  axis=max(range(3),key=lambda a:abs(f.normal[a]));axes=[a for a in range(3) if a!=axis]
  for li in f.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]*.5,v[axes[1]]*.5)
 bpy.context.view_layer.update();vs=[o.matrix_world@v.co for v in o.data.vertices];lo=[min(v[a] for v in vs) for a in range(3)];hi=[max(v[a] for v in vs) for a in range(3)]
 o.data.calc_loop_triangles();components.append({'name':o.name,'min':lo,'max':hi,'triangles':len(o.data.loop_triangles),'material':o.data.materials[0].name})
 assert all(lo[a]>=-15.5 and hi[a]<=15.5 for a in [0,1]),o.name
 assert lo[2]>=-0.00001,o.name
anchors=[]
for role,target,x,y,w,clear,h,prefix in [('pedestrian','Personnel_door_leaf',-9.5,-10.56,1.2,1.8,2.4,'Personnel_'),('vehicle_service','Service_vehicle_shutter',7.5,-10.07,4,4,4.0,'Service_vehicle_')]:
 portal=[c for c in components if c['name']==target or (role=='pedestrian' and c['name'] in ['Personnel_door_glass','Personnel_handle']) or (role=='vehicle_service' and c['name'].startswith('Shutter_seam'))]
 end=min(y-.02,min(c['min'][1] for c in portal)-.02)
 corridor={'min':[x-clear/2,-16,0],'max':[x+clear/2,end,h]}
 collisions=[c['name'] for c in components if all(c['max'][a]>corridor['min'][a]+1e-6 and c['min'][a]<corridor['max'][a]-1e-6 for a in range(3))]
 assert not collisions,(role,collisions)
 anchors.append({'role':role,'target':target,'xyz_m':[x,y,0],'outward':[0,-1,0],'width_m':w,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':clear,'grade_m':0},'reserved_free_corridor':corridor,'portal_components':portal,'aabb_collisions':collisions})
write('entrance-anchors.json',{'anchors':anchors})
tri=sum(c['triangles'] for c in components);assert tri<=5000,tri
manifest={'textures':textures,'materials':{name:{'color':list(m.diffuse_color),'links':[{'from_node':l.from_node.bl_idname,'from_socket':l.from_socket.name,'to_node':l.to_node.bl_idname,'to_socket':l.to_socket.name} for l in m.node_tree.links]} for name,m in mats.items()},'uv':'UV0 dominant-axis metric projection, 0.5 repeats/metre','fbx_shader_transfer':False}
write('material-manifest.json',manifest)
write('provenance.json',{'references':provenance,'reference_summary':reference_summary,'review_only':True,'asset':'building.service.a BASE','new_geometry':True,'production_inputs_unchanged':True})
write('recipe.json',{'design':'Pathless municipal treatment plant; two recessed 8.7 m clarifiers, staffed two-storey controls and filter hall','units':'metres Z up, front -Y','plot_proposal_cells':[4,4],'catalog_modified':False,'lod_plan':'Future simplification preserves basin/roof silhouettes, entrances and major routing. Reduce radial segments; remove handles, flanges, tiny ventilation and rails; merge secondary machines. LOD0 only, no measured platform performance claim.'})
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=12;bpy.context.scene.cycles.device='CPU'
finish(objects)
# Retain runner validation and append focused checks, with explicit actual reimport.
report_path=O/'validation.json';report=json.loads(report_path.read_text())
asset=bpy.context.view_layer.objects.active
if asset is None or asset.type!='MESH':
 asset=max([o for o in bpy.context.scene.objects if o.type=='MESH'],key=lambda o:len(o.data.polygons))
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');asset.name='WaterTreatment_BASE_Review'
asset.data.calc_loop_triangles();assert len(asset.data.loop_triangles)==tri
with checked_fbx(asset,O/'asset.fbx',slots=[m.name for m in asset.data.materials]) as check:
 measured={'triangles':len(check.data.loop_triangles),'slots':[m.name.split('.')[0] for m in check.data.materials],'dimensions_m':list(check.dimensions),'roundtrip_pass':True}
assert len(asset.data.materials)==5
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
report['water_treatment_contract']={'components_before_join':components,'triangles':tri,'target_triangles':[3000,4800],'hard_cap_pass':tri<=5000,'target_met':3000<=tri<=4800,'checked_export':measured,'bounds_min':[min(c['min'][a] for c in components) for a in range(3)],'bounds_max':[max(c['max'][a] for c in components) for a in range(3)],'origin_m':list(asset.location),'finite_geometry':all(math.isfinite(v) for c in components for k in ['min','max'] for v in c[k]),'uv0':asset.data.uv_layers.active.name,'corridors_clear':True,'ground_contract':'No terrain, paths, parcel slab, plinth or foundation meshes; basin walls belong to vessels. Runner studio floor is staging only.','review_only':True,'integration_deferred':True,'production_inputs_unchanged':all(hashlib.sha256((Path('/repo')/p).read_bytes()).hexdigest()==v for p,v in provenance.items())}
write('validation.json',report)

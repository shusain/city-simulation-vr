import bpy, sys, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
# New, isolated review study. Approved source libraries remain untouched.
for o in list(bpy.data.objects):
    if o.type=='MESH': bpy.data.objects.remove(o,do_unlink=True)
for m in list(bpy.data.meshes):
    if m.users==0: bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
    if m.users==0: bpy.data.materials.remove(m)
materials={}; texture_records=[]
texdir=OUT/'textures'; texdir.mkdir(exist_ok=True)
sets={}
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
    sets[family]={}
    for kind in ['BaseColor','Normal','ORM']:
        src=Path('/repo/ArtSource/Textures')/folder/(family+'_'+kind+'.png')
        dst=texdir/src.name; shutil.copyfile(src,dst)
        im=bpy.data.images.load(str(dst),check_existing=True)
        im.colorspace_settings.name='sRGB' if kind=='BaseColor' else 'Non-Color'
        texture_records.append(dict(path='textures/'+dst.name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
        im.pack(); sets[family][kind]=im
specs={'CivicBrick':('CityBrick',(0.72,0.37,0.23,1)), 'LightStone':(None,(0.83,0.81,0.70,1)), 'RoofMembrane':('RoofMembrane',(0.15,0.19,0.23,1)), 'EquipmentMetal':('CityMechanical',(0.47,0.52,0.53,1)), 'WindowGlass':(None,(0.105,0.22,0.29,1)), 'ServiceAccent':(None,(0.075,0.34,0.38,1))}
for name,(family,tint) in specs.items():
    mat=bpy.data.materials.new(name); mat.diffuse_color=tint; mat.use_nodes=True
    n=mat.node_tree.nodes; l=mat.node_tree.links; p=n.get('Principled BSDF'); p.inputs['Base Color'].default_value=tint; p.inputs['Roughness'].default_value=.68; p.inputs['Metallic'].default_value=0; p.inputs['Transmission Weight'].default_value=0
    if family:
        nodes={}
        for kind,im in sets[family].items():
            t=n.new('ShaderNodeTexImage'); t.image=im; t.extension='REPEAT'; nodes[kind]=t
        sep=n.new('ShaderNodeSeparateColor'); l.new(nodes['ORM'].outputs['Color'],sep.inputs['Color'])
        ao=n.new('ShaderNodeMixRGB'); ao.blend_type='MULTIPLY'; ao.inputs[0].default_value=1
        l.new(nodes['BaseColor'].outputs['Color'],ao.inputs[1]); l.new(sep.outputs['Red'],ao.inputs[2])
        mul=n.new('ShaderNodeMixRGB'); mul.name='Restrained tint AFTER BaseColor and AO'; mul.blend_type='MULTIPLY'; mul.inputs[0].default_value=1; mul.inputs[2].default_value=tint
        l.new(ao.outputs[0],mul.inputs[1]); l.new(mul.outputs[0],p.inputs['Base Color'])
        l.new(sep.outputs['Green'],p.inputs['Roughness']); l.new(sep.outputs['Blue'],p.inputs['Metallic'])
        norm=n.new('ShaderNodeNormalMap'); norm.inputs['Strength'].default_value=.25; l.new(nodes['Normal'].outputs['Color'],norm.inputs['Color']); l.new(norm.outputs['Normal'],p.inputs['Normal'])
    materials[name]=mat
objects=[]; groups={}; bounds={}
def add(name,lo,hi,material,group):
    assert name not in bounds
    obj=box(name,tuple(hi[i]-lo[i] for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),specs[material][1])
    obj.data.materials.clear(); obj.data.materials.append(materials[material])
    bpy.context.view_layer.objects.active=obj; obj.select_set(True)
    bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
    bpy.context.view_layer.update()
    # Planar metre-based UV0, shared two metre repeat on each face.
    uv=obj.data.uv_layers.active or obj.data.uv_layers.new(name='UV0'); uv.name='UV0'
    for poly in obj.data.polygons:
        axis=max(range(3),key=lambda a:abs(poly.normal[a])); axes=[a for a in range(3) if a!=axis]
        for li in poly.loop_indices:
            co=obj.matrix_world@obj.data.vertices[obj.data.loops[li].vertex_index].co
            uv.data[li].uv=(co[axes[0]]/2,co[axes[1]]/2)
    vg=obj.vertex_groups.new(name=name); vg.add(list(range(len(obj.data.vertices))),1,'REPLACE')
    measured=[obj.matrix_world@Vector(c) for c in obj.bound_box]
    mn=[min(v[i] for v in measured) for i in range(3)]; mx=[max(v[i] for v in measured) for i in range(3)]
    bounds[name]=(mn,mx); groups.setdefault(group,[]).append(name); objects.append(obj)
    return obj
main=add('WardBlock',[-17,-7,0],[3,8,10.2],'LightStone','body')
add('EmergencyWing',[5,-7,0],[18,8,5.2],'LightStone','garage')
add('EnclosedClinicalLink',[3,2,0],[5,6,3.5],'LightStone','body')
add('RearClinicalWing',[-17,8,0],[18,14,10.2],'LightStone','body')
# Brick plinth is wall cladding, not a foundation or ground pad.
add('WardFrontBrick',[-17,-7.045,0],[3,-7,.82],'CivicBrick','body')
add('WardWestBrick',[-17.045,-7,0],[-17,14,.82],'CivicBrick','body')
add('RearBrick',[-17,14,0],[18,14.045,.82],'CivicBrick','body')
add('EmergencyEastBrick',[18,-7,0],[18.045,14,.82],'CivicBrick','garage')
for name,lo,hi,z in [('Ward',[-17,-7],[3,8],10.2),('Rear',[-17,8],[18,14],10.2),('Emergency',[5,-7],[18,8],5.2),('Link',[3,2],[5,6],3.5)]:
    add(name+'Roof',[lo[0]-.10,lo[1]-.10,z],[hi[0]+.10,hi[1]+.10,z+.13],'RoofMembrane','roof')
# Exterior parapet rails, with no covered-wall windows.
for name,x1,x2,y,z in [('WardFront',-17,3,-7,10.33),('RearBack',-17,18,14,10.33),('EmergencyFront',5,18,-7,5.33)]:
    add(name+'Coping',[x1-.15,y-.15,z],[x2+.15,y+.15,z+.23],'LightStone','roof')
for name,x,y1,y2,z in [('West',-17,-7,14,10.33),('EastRear',18,8,14,10.33),('EastEmergency',18,-7,8,5.33)]:
    add(name+'Coping',[x-.15,y1,z],[x+.15,y2,z+.23],'LightStone','roof')
windows=[]; doors=[]
def window(name,back,axis,sign,u,z,w=1.6,h=1.65):
    mn,mx=bounds[back]; face=mx[axis] if sign==1 else mn[axis]; tangent=1-axis
    def piece(label,a,b,z1,z2,d1,d2,mat):
        lo=[0,0,z1]; hi=[0,0,z2]; lo[tangent]=a; hi[tangent]=b
        vals=sorted([face+sign*d1,face+sign*d2]); lo[axis]=vals[0]; hi[axis]=vals[1]
        return add(name+label,lo,hi,mat,'windows')
    t=.10
    pane=piece('Pane',u-w/2+t,u+w/2-t,z-h/2+t,z+h/2-t,.005,.025,'WindowGlass')
    parts=[piece('JambL',u-w/2,u-w/2+t,z-h/2,z+h/2,-.01,.10,'LightStone'),piece('JambR',u+w/2-t,u+w/2,z-h/2,z+h/2,-.01,.10,'LightStone'),piece('Sill',u-w/2+t+.001,u+w/2-t-.001,z-h/2,z-h/2+t,-.01,.10,'LightStone'),piece('Head',u-w/2+t+.001,u+w/2-t-.001,z+h/2-t,z+h/2,-.01,.10,'LightStone')]
    rec=dict(pane=pane.name,frame_parts=[p.name for p in parts],backing=back,axis=axis,sign=sign,wall_face=face,pane_bounds=dict(min=bounds[pane.name][0],max=bounds[pane.name][1]),frame_bounds=[dict(name=p.name,min=bounds[p.name][0],max=bounds[p.name][1]) for p in parts])
    windows.append(rec)
for row,z in enumerate([2.0,5.3,8.6]):
    for i,x in enumerate([-14,-10,-3,0]):
        window('Front%d_%d'%(row,i),'WardBlock',1,-1,x,z)
    for i,y in enumerate([-3,2,6]): window('West%d_%d'%(row,i),'WardBlock',0,-1,y,z)
    for i,x in enumerate([-14,-7,0,7,14]): window('Rear%d_%d'%(row,i),'RearClinicalWing',1,1,x,z)
    for i,y in enumerate([10,12.5]): window('ClinicalEast%d_%d'%(row,i),'RearClinicalWing',0,1,y,z,w=1.5)
for i,y in enumerate([-3,2,6]): window('EmergencyEast%d'%i,'EmergencyWing',0,1,y,2.4)
for i,x in enumerate([6.7,16.4]): window('EmergencyFront%d'%i,'EmergencyWing',1,-1,x,2.3,w=1.25)
# 47 useful panes; no glazing on touching internal wall faces.
# Public entrance: two actual leaves; separate support-free canopy.
for name,x1,x2 in [('PublicDoorLeft',-8,-7.01),('PublicDoorRight',-6.99,-6)]:
    add(name,[x1,-7.08,0],[x2,-7.015,2.55],'ServiceAccent','entry')
    doors.append(dict(target=name,backing='WardBlock',axis=1,sign=-1,wall_face=-7,min=bounds[name][0],max=bounds[name][1]))
for name,x in [('PublicJambL',-8.16),('PublicJambR',-6.0)]: add(name,[x,-7.14,0],[x+.16,-6.99,2.75],'LightStone','entry')
add('PublicDoorHeader',[-8.16,-7.14,2.55],[-5.84,-6.99,2.75],'LightStone','entry')
add('PublicShelter',[-9,-9,3.0],[-5,-6.95,3.22],'ServiceAccent','entry')
add('PublicShelterCap',[-9.06,-9.06,3.22],[-4.94,-6.94,3.32],'LightStone','entry')
# A single 4.6 x 3.7 m closed emergency vehicle door.
add('AmbulanceDoor',[9.2,-7.08,0],[13.8,-7.015,3.7],'ServiceAccent','garage')
doors.append(dict(target='AmbulanceDoor',backing='EmergencyWing',axis=1,sign=-1,wall_face=-7,min=bounds['AmbulanceDoor'][0],max=bounds['AmbulanceDoor'][1]))
add('BayJambL',[9.0,-7.17,0],[9.2,-6.99,3.95],'LightStone','garage')
add('BayJambR',[13.8,-7.17,0],[14,-6.99,3.95],'LightStone','garage')
add('BayLintel',[9,-7.17,3.7],[14,-6.99,3.95],'LightStone','garage')
add('AmbulanceShelter',[8.7,-10,4.12],[14.3,-6.95,4.34],'ServiceAccent','garage')
add('AmbulanceShelterRim',[8.65,-10.05,4.34],[14.35,-6.95,4.44],'LightStone','garage')
# Attached medical H relief: three disjoint connected solids against teal fascia.
add('MedicalFascia',[-8.5,-7.18,3.55],[-5.5,-7,4.85],'ServiceAccent','emblem')
add('HLeft',[-7.65,-7.25,3.75],[-7.43,-7.17,4.65],'LightStone','emblem')
add('HRight',[-6.57,-7.25,3.75],[-6.35,-7.17,4.65],'LightStone','emblem')
add('HCross',[-7.43,-7.25,4.08],[-6.57,-7.17,4.30],'LightStone','emblem')
# Modest mounted rooftop plant. All bases contact real roof.
for i,x in enumerate([-10,-5]):
    add('PlantBase%d'%i,[x,9.2,10.33],[x+2.3,11.8,10.5],'EquipmentMetal','equipment')
    add('PlantCase%d'%i,[x+.1,9.3,10.5],[x+2.2,11.7,11.3],'EquipmentMetal','equipment')
    for j in range(3): add('PlantLouvre%d_%d'%(i,j),[x+.24,9.26,10.65+j*.18],[x+2.06,9.31,10.71+j*.18],'RoofMembrane','equipment')
# Measured independent mounting and corridor checks.
def overlap(a,b): return all(min(a[1][i],b[1][i])-max(a[0][i],b[0][i])>1e-6 for i in range(3))
for r in windows:
    a=r['axis']; t=1-a; mn,mx=bounds[r['backing']]; f=r['wall_face']; sg=r['sign']; pane=bounds[r['pane']]; frames=[bounds[n] for n in r['frame_parts']]
    for bb in [pane]+frames:
        assert bb[0][t]>=mn[t]+.12 and bb[1][t]<=mx[t]-.12
        assert bb[0][2]>=mn[2]+.12 and bb[1][2]<=mx[2]-.12
    def depths(bb): return sorted([sg*(bb[0][a]-f),sg*(bb[1][a]-f)])
    assert abs(depths(pane)[0]-.005)<1e-5 and depths(pane)[1]<.03
    for bb in frames: assert abs(depths(bb)[0]+.01)<1e-5 and abs(depths(bb)[1]-.1)<1e-5
    for i,bb in enumerate(frames):
        assert not overlap(bb,pane)
        for cc in frames[i+1:]: assert not overlap(bb,cc)
    assert pane[0][t]>=frames[0][1][t]-1e-5 and pane[1][t]<=frames[1][0][t]+1e-5
anchors=[]; bays=[]
for role,x,width,height,target,end in [('pedestrian',-7,2,2.4,'PublicDoorLeft',-7.20),('service',11.5,4.6,3.6,'AmbulanceDoor',-7.20)]:
    corridor=dict(min=[x-width/2,-20,0],max=[x+width/2,end,height])
    for name,bb in bounds.items(): assert not overlap(bb,(corridor['min'],corridor['max'])),('corridor',role,name)
    anchor=dict(role=role,target=target,xyz_m=[x,-10.15 if role=='service' else -9.15,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=corridor)
    anchors.append(anchor)
    if role=='service': bays.append(dict(id='ambulance-primary',target=target,xyz_m=anchor['xyz_m'],outward=[0,-1,0],width_m=width,height_m=height,boundary_connector=dict(xyz_m=[x,-20,0]),reserved_free_corridor=corridor))
for name,(lo,hi) in bounds.items():
    assert lo[0]>=-23.5 and hi[0]<=23.5 and lo[1]>=-19.5 and hi[1]<=19.5 and lo[2]>=-1e-6
assert len(windows)<=50
triangles=sum(len(o.data.polygons)*2 for o in objects); assert triangles<=10500
components=[dict(name=n,min=bb[0],max=bb[1]) for n,bb in bounds.items()]
occupied=dict(min=[min(bb[0][i] for bb in bounds.values()) for i in range(3)],max=[max(bb[1][i] for bb in bounds.values()) for i in range(3)])
def write(name,data): (OUT/name).write_text(json.dumps(data,indent=2))
write('window-mounts.json',dict(windows=windows,doors=doors))
write('entrance-anchors.json',dict(anchors=anchors)); write('vehicle-bays.json',dict(bays=bays))
write('upgrade-plan.json',dict(family='hospital',stage='medium',stage_index=1,existing_stages=['base','medium'],existing_upgrade_count=1,gameplay_changes=False,source_site_m=[48,40],current_native_footprint=[4,3],retained_entrance_centres=[[-7,-7],[11.5,-7]],progression='Third ward floor plus real full-width rear clinical wing. Separate emergency wing and enclosed link retained.',occupied_bounds=occupied,LOD_notes='Future LOD1/LOD2 simplify rims, medical relief and roof equipment; no production replacement in this review.'))
write('civic-contract.json',dict(family='hospital',stage='medium',sourceID='building.hospital_medium.a',role='outpatient wards and emergency',proposed_site_m=[48,40],groups=groups,admin=groups['body'],entry=groups['entry'],garage=groups['garage'],roof=groups['roof'],emblem=groups['emblem'],integration='HELD'))
write('material-manifest.json',dict(regions={n:dict(texture_family=f,tint_rgba=c,roughness_constant=.68,metallic_constant=0,transmission=0,basecolor_recipe='BaseColor * ORM.R AO then MULTIPLY tint' if f else 'constant',ORM_channels=dict(R='AO',G='roughness',B='metallic'),normal_strength=.25,uv_recipe='UV0 world planar dominant face projection metres / 2; finite repeat') for n,(f,c) in specs.items()},textures=texture_records))
# Establish ground-centred source origin on the first selected source mesh.
bpy.ops.object.select_all(action='DESELECT'); objects[0].select_set(True); bpy.context.view_layer.objects.active=objects[0]; bpy.context.scene.cursor.location=(0,0,0); bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.context.scene.render.engine='CYCLES'; bpy.context.scene.cycles.device='CPU'; bpy.context.scene.cycles.samples=12
finish(objects)
# Preserve tested finish measurements and real checked FBX receipt, augment rather than replace.
vp=OUT/'validation.json'; val=json.loads(vp.read_text())
val.update(dict(components=components,sourceID='building.hospital_medium.a',stage='medium',triangle_cap=10500,authored_triangles=triangles,semantic_regions=list(specs),occupied_bounds=occupied,window_count=len(windows),mount_checks=dict(containment=True,contact=True,pane_inset=True,open_frames=True,disjoint_rims=True),corridor_checks=True,source_site_m=[48,40],production_integration='HELD',human_art_review='pending',source_inputs_preserved=True))
write('validation.json',val)

import bpy, sys, json, math, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2))
# New review geometry only; approved libraries are never opened for writing.
materials={}; texmeta=[]
colors={'CivicBrick':(.48,.22,.14,1),'LightStone':(.74,.69,.55,1),'RoofMembrane':(.12,.15,.18,1),'EquipmentMetal':(.26,.29,.30,1),'WindowGlass':(.12,.23,.30,1),'ServiceAccent':(.48,.045,.035,1)}
for name,col in colors.items():
 m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.72
 if name=='WindowGlass':p.inputs['Roughness'].default_value=.32;p.inputs['Transmission Weight'].default_value=0
 materials[name]=m
for sem,folder,prefix,tint in [('CivicBrick','BuildingSurfaces','CityBrick',(.62,.32,.21,1)),('EquipmentMetal','BuildingSurfaces','CityMechanical',(.48,.5,.52,1)),('RoofMembrane','RoofsSigns','RoofMembrane',(.14,.18,.23,1))]:
 m=materials[sem]; ns=m.node_tree.nodes;lk=m.node_tree.links;p=ns.get('Principled BSDF');nodes={}
 for suffix in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(prefix+'_'+suffix+'.png'); dst=OUT/'textures'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst),check_existing=False);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  t=ns.new('ShaderNodeTexImage');t.image=im;t.extension='REPEAT';nodes[suffix]=t
  texmeta.append(dict(path='textures/'+src.name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
 sep=ns.new('ShaderNodeSeparateColor');lk.new(nodes['ORM'].outputs['Color'],sep.inputs['Color'])
 ao=ns.new('ShaderNodeMixRGB');ao.blend_type='MULTIPLY';ao.inputs[0].default_value=1;lk.new(nodes['BaseColor'].outputs['Color'],ao.inputs[1]);lk.new(sep.outputs[0],ao.inputs[2])
 mul=ns.new('ShaderNodeMixRGB');mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1;mul.inputs[2].default_value=tint;lk.new(ao.outputs[0],mul.inputs[1]);lk.new(mul.outputs[0],p.inputs['Base Color'])
 lk.new(sep.outputs[1],p.inputs['Roughness']);lk.new(sep.outputs[2],p.inputs['Metallic'])
 norm=ns.new('ShaderNodeNormalMap');norm.inputs['Strength'].default_value=.25;lk.new(nodes['Normal'].outputs['Color'],norm.inputs['Color']);lk.new(norm.outputs[0],p.inputs['Normal'])
write('material-manifest.json',dict(regions=list(materials),textures=texmeta,constants=colors,tints={'CivicBrick':[.62,.32,.21,1],'EquipmentMetal':[.48,.5,.52,1],'RoofMembrane':[.14,.18,.23,1]},channels={'R':'AO multiplied before tint','G':'roughness','B':'metallic'},normal_strength=.25,uv_recipe='UV0 planar per face, metres divided by 2; repeat',glass='opaque bluegrey, transmission 0'))
objects=[]; components=[]; bounds={}; groups={}
def add(name,lo,hi,mat,group='body'):
 assert name not in bounds
 o=box(name,tuple(hi[i]-lo[i] for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),colors[mat]);o.data.materials.clear();o.data.materials.append(materials[mat]);objects.append(o);groups.setdefault(group,[]).append(name)
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o.select_set(False);bpy.context.view_layer.update()
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
 for f in o.data.polygons:
  ax=max(range(3),key=lambda a:abs(f.normal[a]));axes=[a for a in range(3) if a!=ax]
  for li in f.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]/2,v[axes[1]]/2)
 vg=o.vertex_groups.new(name=name);vg.add(list(range(len(o.data.vertices))),1,'REPLACE')
 b=[o.matrix_world@Vector(c) for c in o.bound_box];mn=[min(v[i] for v in b) for i in range(3)];mx=[max(v[i] for v in b) for i in range(3)];bounds[name]=(mn,mx);components.append(dict(name=name,min=mn,max=mx));return o
add('Admin',[-17,-5,0],[-7,8,6.4],'CivicBrick','admin')
add('CrewTrainingUpper',[-17,-3,6.4],[-7,3,9.6],'CivicBrick','admin')
add('EnclosedLink',[-7,2,0],[-5,6,3.5],'CivicBrick')
add('TrainingTower',[-16,4,0],[-12,8,10.8],'CivicBrick','admin')
# Apparatus hall is built as walls and lintel, not a filled box.
add('HallRear',[-5,7.65,0],[17,8,6.4],'CivicBrick','garage')
add('HallWest',[-5,-5,0],[-4.65,8,6.4],'CivicBrick','garage')
add('HallEast',[16.65,-5,0],[17,8,6.4],'CivicBrick','garage')
add('HallFrontLintel',[-5,-5,3.95],[17,-4.6,6.4],'CivicBrick','garage')
for j,(a,b) in enumerate([(-5,-3.35),(1.35,3.65),(8.35,10.65),(15.35,17)]):add('HallPier'+str(j),[a,-5,0],[b,-4.6,3.95],'CivicBrick','garage')
# Clear bay openings width 4.5, headroom 3.6; thin complete sectional leaves.
windows=[];doors=[];bays=[]
for i,x in enumerate([-1,6,13]):
 name='BayDoor'+str(i+1);add(name,[x-2.25,-5.065,0],[x+2.25,-4.965,3.6],'ServiceAccent','entry')
 for side in [-1,1]:add(name+'Jamb'+str(side),[x+side*2.34-.09,-5.16,0],[x+side*2.34+.09,-4.99,3.78],'LightStone','entry')
 add(name+'Head',[x-2.249,-5.16,3.6],[x+2.249,-4.99,3.78],'LightStone','entry')
 for z in [.6,1.2,1.8,2.4,3.0]:add(name+'Rail'+str(z),[x-2.23,-5.085,z],[x+2.23,-5.066,z+.035],'EquipmentMetal','entry')
 corridor={'min':[x-2.25,-16,0],'max':[x+2.25,-5.20,3.6]}
 bays.append(dict(id=name,target=name,xyz_m=[x,-5.20,0],outward=[0,-1,0],width_m=4.5,height_m=3.6,boundary_connector={'xyz_m':[x,-16,0]},reserved_free_corridor=corridor));doors.append(dict(target=name,width_m=4.5,height_m=3.6))
for i,(a,b) in enumerate([(-12.95,-12),(-12,-11.05)]):add('PublicLeaf'+str(i),[a,-5.07,0],[b,-4.97,2.5],'ServiceAccent','entry')
for i,x in enumerate([-13.06,-10.94]):add('PublicJamb'+str(i),[x-.06,-5.17,0],[x+.06,-4.99,2.65],'LightStone','entry')
add('PublicHead',[-12.999,-5.17,2.5],[-11.001,-4.99,2.65],'LightStone','entry')
add('EntryCanopy',[-13.6,-6.1,2.85],[-10.4,-4.9,3.05],'LightStone','entry')
for x in [-12.1,-11.9]:add('Handle'+str(x),[x-.025,-5.13,1],[x+.025,-5.07,1.45],'EquipmentMetal','entry')
doors.append(dict(target='PublicLeaf0',other_leaf='PublicLeaf1',width_m=1.9,height_m=2.5))
# Attached four-piece rims: jambs occupy full height; rails stop 1mm short of jambs.
def window(name,back,axis,sign,u,z,w=1.4,h=1.6):
 mn,mx=bounds[back];face=(mx if sign>0 else mn)[axis];t=1-axis
 def coords(ua,ub,za,zb,outer,inner):
  a=[0,0,za];b=[0,0,zb];a[t]=ua;b[t]=ub;a[axis]=min(outer,inner);b[axis]=max(outer,inner);return a,b
 p=coords(u-w/2,u+w/2,z,z+h,face+sign*.045,face-sign*.005);add(name,*p,'WindowGlass','windows');parts=[]
 for tag,ua,ub,za,zb in [('L',u-w/2-.09,u-w/2,z-.09,z+h+.09),('R',u+w/2,u+w/2+.09,z-.09,z+h+.09),('S',u-w/2+.001,u+w/2-.001,z-.09,z),('H',u-w/2+.001,u+w/2-.001,z+h,z+h+.09)]:
  q=coords(ua,ub,za,zb,face+sign*.13,face-sign*.01);n=name+tag;add(n,*q,'LightStone','windows');parts.append(n)
 rec=dict(pane=name,frame_parts=parts,backing=back,axis=axis,sign=sign,wall_face=face,pane_bounds={'min':bounds[name][0],'max':bounds[name][1]},frame_bounds=[{'min':bounds[n][0],'max':bounds[n][1]} for n in parts]);windows.append(rec)
 # Independent mount checks against actual backing wall AABB.
 for n in [name]+parts:
  a,b=bounds[n]
  for k in [t,2]:assert a[k]>=mn[k]+.12-1e-6 and b[k]<=mx[k]-.12+1e-6,(name,'containment')
  assert a[axis]<=face+.02 and b[axis]>=face-.02
 assert bounds[name][1][axis]-bounds[name][0][axis]<.06
 def overlap(a,b):return all(min(a[1][k],b[1][k])-max(a[0][k],b[0][k])>1e-6 for k in range(3))
 for j,n in enumerate(parts):
  for other in parts[j+1:]:assert not overlap(bounds[n],bounds[other]),'rim overlap'
for x in [-15.3,-8.7]:window('AdminFrontLower'+str(x),'Admin',1,-1,x,.9)
for x in [-15.3,-12,-8.7]:window('AdminFrontUpper'+str(x),'Admin',1,-1,x,4.1)
for y in [-2.6,.7,5.3]:
 for z in [1,4.1]:window('AdminWest'+str(y)+str(z),'Admin',0,-1,y,z)
for x in [-15.3,-12,-8.7]:
 window('CrewFront'+str(x),'CrewTrainingUpper',1,-1,x,7.25)
 window('CrewRear'+str(x),'CrewTrainingUpper',1,1,x,7.25)
for y in [-1.5,1.5]:window('CrewWest'+str(y),'CrewTrainingUpper',0,-1,y,7.25,w=1.2)
for x in [-3,1,5,9,13,15.6]:window('HallClerestory'+str(x),'HallFrontLintel',1,-1,x,4.65,w=1.45,h=.85)
for y in [-2,2,6]:window('HallEastPane'+str(y),'HallEast',0,1,y,2.8,w=1.6,h=1.6)
for x in [-14.8,-13.2]:window('TowerFront'+str(x),'TrainingTower',1,-1,x,8.8,w=.85,h=1.25)
for y in [5.2,6.8]:window('TowerWest'+str(y),'TrainingTower',0,-1,y,8.8,w=.85,h=1.25)
# Restrained roof coping and inset membrane; all equipment contacts roofs.
for label,x0,x1,y0,y1,z in [('Admin',-17,-7,-5,8,6.4),('Crew',-17,-7,-3,3,9.6),('Tower',-16,-12,4,8,10.8),('Hall',-5,17,-5,8,6.4),('Link',-7,-5,2,6,3.5)]:
 add(label+'Roof',[x0,y0,z],[x1,y1,z+.12],'RoofMembrane','roof')
 for side,y in [('Front',y0),('Rear',y1-.13)]:add(label+side+'Coping',[x0-.08,y-.04,z+.12],[x1+.08,y+.13,z+.32],'LightStone','roof')
 for side,x in [('West',x0),('East',x1-.13)]:add(label+side+'Coping',[x-.04,y0+.131,z+.12],[x+.13,y1-.171,z+.32],'LightStone','roof')
for i,x in enumerate([4,10]):
 add('RoofVent'+str(i),[x,3,6.52],[x+1.4,4.3,7.15],'EquipmentMetal','roof')
 for k in range(4):add('VentLouvre'+str(i)+'_'+str(k),[x+.1,2.97,6.62+k*.11],[x+1.3,3.005,6.66+k*.11],'RoofMembrane','roof')
# Original compact attached shield/flame relief, each separate closed connected solid.
def prism(name,points,y0,y1,mat):
 verts=[(x,y,z) for y in [y0,y1] for x,z in points];n=len(points);faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(materials[mat]);objects.append(o);vg=o.vertex_groups.new(name=name);vg.add(list(range(len(verts))),1,'REPLACE');a=[min(v[k] for v in verts) for k in range(3)];b=[max(v[k] for v in verts) for k in range(3)];bounds[name]=(a,b);components.append(dict(name=name,min=a,max=b));groups.setdefault('emblem',[]).append(name)
prism('FireShield',[(-12.65,3.45),(-12,3.18),(-11.35,3.45),(-11.35,4.15),(-12.65,4.15)],-5.12,-4.99,'LightStone')
prism('FlameRelief',[(-12.35,3.52),(-12.38,3.77),(-12.08,4.05),(-12.05,3.78),(-11.86,3.94),(-11.65,3.66),(-11.83,3.45),(-12.1,3.4)],-5.18,-5.115,'ServiceAccent')
write('window-mounts.json',dict(windows=windows,doors=doors))
anchors=[]
for role,target,x,width,height,end in [('pedestrian','PublicLeaf0',-12,1.9,2.5,-5.22),('service','BayDoor1',-1,4.5,3.6,-5.20)]:
 anchors.append(dict(role=role,target=target,xyz_m=[x,end,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-16,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor={'min':[x-width/2,-16,0],'max':[x+width/2,end,height]}))
for lane in [a['reserved_free_corridor'] for a in anchors]+[b['reserved_free_corridor'] for b in bays]:
 for c in components:assert not all(min(c['max'][k],lane['max'][k])-max(c['min'][k],lane['min'][k])>1e-6 for k in range(3)),('corridor obstruction',c['name'])
for c in components:assert c['min'][0]>=-19.5 and c['max'][0]<=19.5 and c['min'][1]>=-15.5 and c['max'][1]<=15.5 and c['min'][2]>=0
write('entrance-anchors.json',dict(anchors=anchors));write('vehicle-bays.json',dict(bays=bays))
occupied={'min':[min(c['min'][i] for c in components) for i in range(3)],'max':[max(c['max'][i] for c in components) for i in range(3)]}
write('upgrade-plan.json',dict(family='fire',stage='high',stage_index=2,existing_stages=['base','medium','high'],existing_upgrade_count=2,gameplay_changes=False,source_site_m=[40,32],current_native_footprint=[3,2],retained_entrance_centres={'pedestrian':[-12,-5],'service':[-1,-5]},progression='Third apparatus bay plus compact crew/training upper floor; same family entrance centres and architectural module',occupied_bounds=occupied,integration='HELD',future_LODs='LOD1 simplify rims, flame and roof louvres; LOD2 collapse roof equipment and minor trim; original lowpoly sources retained'))
write('civic-contract.json',dict(family='fire',stage='high',sourceID='building.fire_high.a',role='Fire station HIGH stage 2/2',groups=groups,proposed_site_m=[40,32],review_only=True))
# Preserve individual solid metadata and groups through the tested join/export.
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR');objects[0].select_set(False)
tri=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in objects);assert tri<=8500
finish(objects)
p=OUT/'validation.json';v=json.loads(p.read_text());v.update(components=components,sourceID='building.fire_high.a',source_triangle_cap=8500,authored_triangles=tri,semantic_regions=list(materials),window_count=len(windows),window_mount_assertions=True,corridor_nonintersection=True,site_containment=True,occupied_bounds=occupied,review_only=True,integration='HELD',visual_assessment='Pending human review',no_grounds=True);write('validation.json',v)

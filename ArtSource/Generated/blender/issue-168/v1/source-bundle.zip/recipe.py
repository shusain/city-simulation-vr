import bpy, math, sys, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
bpy.context.scene.unit_settings.system='METRIC'; bpy.context.scene.unit_settings.scale_length=1
parts=[]; body=[]; rotor=[]; blades=[]
def material(name,color,rough,metal=0):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1); p.inputs['Roughness'].default_value=rough; p.inputs['Metallic'].default_value=metal
 return m
paint=material('OffWhite_PaintedSteel',(.73,.77,.77),.43)
accent=material('BlueGrey_Machinery',(.18,.26,.30),.48)
hardware=material('Mechanical_Mapped',(.30,.34,.36),.48,.65)
texdir=OUT/'textures'; texdir.mkdir(exist_ok=True); maps=[]
nt=hardware.node_tree; p=nt.nodes.get('Principled BSDF')
for suffix,cs in [('BaseColor','sRGB'),('Normal','Non-Color'),('ORM','Non-Color')]:
 src=Path('/repo/ArtSource/Textures/BuildingSurfaces/CityMechanical_'+suffix+'.png'); dst=texdir/src.name; shutil.copyfile(src,dst)
 im=bpy.data.images.load(str(dst)); im.colorspace_settings.name=cs; im.pack()
 n=nt.nodes.new('ShaderNodeTexImage'); n.image=im
 if suffix=='BaseColor': nt.links.new(n.outputs['Color'],p.inputs['Base Color'])
 elif suffix=='Normal':
  normal=nt.nodes.new('ShaderNodeNormalMap'); normal.inputs['Strength'].default_value=.3; nt.links.new(n.outputs['Color'],normal.inputs['Color']); nt.links.new(normal.outputs['Normal'],p.inputs['Normal'])
 else:
  sep=nt.nodes.new('ShaderNodeSeparateColor'); nt.links.new(n.outputs['Color'],sep.inputs['Color']); nt.links.new(sep.outputs['Green'],p.inputs['Roughness']); nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
 maps.append(dict(path='textures/'+dst.name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=cs))
def mesh(name,vs,fs,mat,group='body',smooth=False):
 me=bpy.data.meshes.new(name); me.from_pydata(vs,[],fs); me.update(); ob=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(ob); me.materials.append(mat)
 uv=me.uv_layers.new(name='UVMap')
 for poly in me.polygons:
  poly.use_smooth=smooth
  for li in poly.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co; uv.data[li].uv=(v.x*.5+v.y*.25,v.z*.5+v.y*.25)
 vg=ob.vertex_groups.new(name=name); vg.add(list(range(len(vs))),1,'REPLACE'); parts.append(ob)
 (body if group=='body' else rotor).append(name)
 return ob
# Closed ring loft, caps are intentionally planar and remain hard.
def loft(name,rings,mat,group='body'):
 n=len(rings[0]); vs=[v for ring in rings for v in ring]; fs=[]
 fs.append(tuple(reversed(range(n))))
 for j in range(len(rings)-1):
  for i in range(n): fs.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
 fs.append(tuple((len(rings)-1)*n+i for i in range(n)))
 ob=mesh(name,vs,fs,mat,group,True); ob.data.polygons[0].use_smooth=False; ob.data.polygons[-1].use_smooth=False
 return ob
def tower(name,zs,rs,mat):
 return loft(name,[[(r*math.cos(i*2*math.pi/32),r*math.sin(i*2*math.pi/32),z) for i in range(32)] for z,r in zip(zs,rs)],mat)
def radius(z):return 1.05-(1.05-.57)*z/21.5
tower('Mast_Tapered_Shell',[0,5.8,11.5,17.2,21.5],[radius(z) for z in [0,5.8,11.5,17.2,21.5]],paint)
for j,z in enumerate([5.8,11.5,17.2]):tower('Mast_Assembly_Seam_%02d'%j,[z-.025,z+.025],[radius(z)+.014,radius(z)+.014],accent)
tower('Yaw_Bearing_Collar',[20.95,21.22,21.38],[.62,.75,.75],hardware)
# Rounded elongated housing, front is -Y; every corner is a true profile.
nrings=[]
for y,w,h,zc in [(-1.55,.62,.56,22),(-1.30,.90,.79,22),(.8,.94,.80,22),(2.25,.78,.64,22),(2.55,.60,.47,22)]:
 nrings.append([(w*math.copysign(abs(math.cos(t))**.5,math.cos(t)),y,zc+h*math.copysign(abs(math.sin(t))**.5,math.sin(t))) for t in [2*math.pi*i/16 for i in range(16)]])
loft('Nacelle_Contoured_Housing',nrings,paint)
def cube(name,dims,loc,mat,group='body'):
 x,y,z=[v/2 for v in dims]; a,b,c=loc
 vs=[(a+sx*x,b+sy*y,c+sz*z) for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 return mesh(name,vs,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat,group)
cube('Roof_Service_Hatch',(.92,1.2,.065),(0,.48,22.805),accent)
for i in range(5):cube('Roof_Vent_Louvre_%02d'%i,(.62,.045,.045),(0,.12+i*.16,22.86),hardware)
# A slender rear band, rather than redundant bolt decoration.
loft('Nacelle_Rear_Assembly_Seam', [[( .79*math.copysign(abs(math.cos(t))**.5,math.cos(t)),y,22+.65*math.copysign(abs(math.sin(t))**.5,math.sin(t))) for t in [2*math.pi*i/16 for i in range(16)]] for y in [2.20,2.245]],accent)
# Door follows the taper: its backing is attached over the entire face.
def doorpatch(name,width,z0,z1,offset,thickness,mat):
 rings=[]
 # ring perimeter in the tangent x/z plane, sampled curved across both horizontal edges
 perimeter=[(-width/2+width*i/8,z0) for i in range(9)]+[(width/2-width*i/8,z1) for i in range(9)]
 for depth in [offset,offset+thickness]:
  rings.append([(x,-math.sqrt(radius(z)**2-x*x)-depth,z) for x,z in perimeter])
 return loft(name,rings,mat)
doorpatch('Door_Metal_Rim',.94,.12,2.22,.006,.035,hardware)
doorpatch('Door_Flush_Panel',.80,.20,2.14,.042,.018,accent)
cube('Door_Latch',(.045,.055,.16),(.28,-1.075,1.15),hardware)
AX=(0,-2.9,22)
def axial(name,ys,rs,mat,group):
 return loft(name,[[(r*math.cos(2*math.pi*i/24),y,22+r*math.sin(2*math.pi*i/24)) for i in range(24)] for y,r in zip(ys,rs)],mat,group)
axial('Spindle_Intentional_Connection',[-2.95,-1.40],[.29,.29],hardware,'body')
axial('Rotor_Hub',[-3.15,-2.66],[.70,.70],accent,'rotor')
axial('Spinner_Rounded_Cone',[-3.98,-3.89,-3.55,-3.15],[.035,.21,.52,.70],paint,'rotor')
# Each blade is one closed continuous mesh. Elliptical airfoil-like sections twist from a thick root into a very fine tip.
stations=[(.56,.36,.23,24),(.95,.48,.20,20),(1.65,.94,.16,15),(2.8,1.04,.13,10),(4.2,.88,.105,6),(5.8,.66,.08,3),(7.2,.43,.06,1),(8.35,.23,.038,0),(9.0,.035,.016,0)]
for bi,angle in enumerate([0,120,240]):
 a=math.radians(angle); rings=[]
 for rad,chord,thick,twist in stations:
  ring=[]; tw=math.radians(twist); sweep=.13*(rad/9)**2
  for i in range(12):
   t=2*math.pi*i/12; tang=chord*.5*math.cos(t); dep=thick*.5*math.sin(t)
   tx=tang*math.cos(tw)-dep*math.sin(tw)+sweep; yy=tang*math.sin(tw)+dep*math.cos(tw)
   ring.append((rad*math.sin(a)+tx*math.cos(a),AX[1]+yy,22+rad*math.cos(a)-tx*math.sin(a)))
  rings.append(ring)
 ob=loft('Blade_%02d_Continuous'%(bi+1),rings,paint,'rotor'); blades.append(ob.name)
# Normalize transforms before physical measurements; retain named disconnected solids as vertex groups.
bpy.context.view_layer.update(); components=[]; geometry={}
for ob in parts:
 bpy.context.view_layer.objects.active=ob; ob.select_set(True); bpy.ops.object.transform_apply(location=True,rotation=True,scale=True); ob.select_set(False)
 coords=[tuple(ob.matrix_world@v.co) for v in ob.data.vertices]; ob.data.calc_loop_triangles()
 components.append(dict(name=ob.name,min=[min(v[i] for v in coords) for i in range(3)],max=[max(v[i] for v in coords) for i in range(3)]))
 geometry[ob.name]=dict(vertices_m=coords,triangles=[list(t.vertices) for t in ob.data.loop_triangles])
# Full-angle sweep samples: all actual blade vertices, and therefore extrema of each rotated triangle.
swept=[]; radial=0
for name in blades:
 for x,y,z in geometry[name]['vertices_m']:
  dx=x; dz=z-22; radial=max(radial,math.hypot(dx,dz))
  for k in range(180):
   a=2*math.pi*k/180; swept.append((dx*math.cos(a)+dz*math.sin(a),y,22+dz*math.cos(a)-dx*math.sin(a)))
mins=[min(v[i] for v in swept) for i in range(3)]; maxs=[max(v[i] for v in swept) for i in range(3)]
body_no_spindle=[c for c in components if c['name'] in body and c['name']!='Spindle_Intentional_Connection']
ygap=min(c['min'][1] for c in body_no_spindle)-maxs[1]
assert ygap>0 and 22-radial>0 and radial<11.5
corrmin=[-.6,-12,0]; corrmax=[.6,-1.14,2.2]
hits=[]
for c in components:
 if all(c['max'][i]>corrmin[i]+1e-6 and c['min'][i]<corrmax[i]-1e-6 for i in range(3)):hits.append(c['name'])
assert not hits,hits
tri=sum(len(g['triangles']) for g in geometry.values()); assert tri<=4000
contract=dict(source_sha='2b0beb7e2b38627804aabcac6e6b50bcf4dc54d4',review_only=True,units='metres',up='Z',front='-Y',origin=[0,0,0],proposed_site_m=[24,24],body_component_names=body,rotor_component_names=rotor,blade_component_names=blades,hub_spinner_groups=['Rotor_Hub','Spinner_Rounded_Cone'],axle_xyz_m=list(AX),axis=[0,1,0],actual_blade_radial_extent_m=radial,sweep_ground_clearance_m=22-radial,swept_blade_envelope=dict(min=mins,max=maxs),analytic_full_rotor_envelope=dict(min=[-radial,-3.98,22-radial],max=[radial,max(c['max'][1] for c in components if c['name'] in rotor),22+radial]),mast_nacelle_clearance_lower_bound_m=ygap,clearance_method='All blade vertices rotated in 180 samples at 2 degree steps; triangles are convex combinations of measured vertices. Axle parallel Y makes separating-Y clearance valid for all angles, not only samples. Analytic radial envelope bounds continuous sweep.',excluded_intentional_connection=['Spindle_Intentional_Connection'],geometry=geometry,component_vertex_groups='Exact component names preserved in joined mesh',integration='HELD; static review only. Existing runtime split body / axle-centred rotor is preserved conceptually; no exported animation.',lod_plan='Retain old production low-poly sources. Future distant LOD: 12-sided three-span mast, 6 profile stations x 6 vertices per blade, 8-sided nacelle, omit seam bands/louvres/latch; retain three separately connected blades and original Y axle. Deliberate split and native integration require separate review.')
(OUT/'landmark-contract.json').write_text(json.dumps(contract,indent=2))
entrance=dict(anchors=[dict(role='maintenance',target='Door_Flush_Panel',xyz_m=[0,-1.14,0],outward=[0,-1,0],width_m=1.2,grade_m=0,boundary_connector=dict(xyz_m=[0,-12,0],outward=[0,-1,0],width_m=1.2,grade_m=0),reserved_free_corridor=dict(min=corrmin,max=corrmax))],all_component_aabb_intersections=hits,approach='Future service pedestrian connection reaches the actual mast door from south boundary; no path geometry is authored.')
(OUT/'entrance-anchors.json').write_text(json.dumps(entrance,indent=2))
(OUT/'material-manifest.json').write_text(json.dumps(dict(maps=maps,regions=3,recipes={'OffWhite_PaintedSteel':{'base_color':[.73,.77,.77],'roughness':.43,'metallic':0},'BlueGrey_Machinery':{'base_color':[.18,.26,.30],'roughness':.48,'metallic':0},'Mechanical_Mapped':{'base_color':'BaseColor sRGB','roughness':'ORM G','metallic':'ORM B','normal':'Normal Map tangent, strength 0.3','occlusion':'ORM R retained for native reconstruction; not multiplied in preview'}},uv='Finite UV0 projected at nominal 2m repeat; packed original maps.',native_reconstruction='FBX does not transfer shader graphs. Rebuild semantic materials and channel bindings explicitly; do not treat preview as native material approval.'),indent=2))
bpy.context.scene.cursor.location=(0,0,0)
bpy.context.view_layer.objects.active=parts[0]; parts[0].select_set(True); bpy.ops.object.origin_set(type='ORIGIN_CURSOR'); parts[0].select_set(False)
bpy.context.scene.render.engine='CYCLES'; bpy.context.scene.cycles.device='CPU'; bpy.context.scene.cycles.samples=12
finish(parts)
pth=OUT/'validation.json'; v=json.loads(pth.read_text()) if pth.exists() else {}
v.update(components=components,prejoin_triangles=tri,proposed_site_m=[24,24],source_identity=contract['source_sha'],full_sweep_clearance_m=22-radial,blade_body_separating_y_gap_m=ygap,entrance_corridor_all_component_nonintersection=not hits,semantic_material_regions=3,review_only=True)
joined=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name not in ['Ground','PreviewGround']]
# Helper validation remains authoritative for checked FBX readback.
v['component_metadata_file']='landmark-contract.json'; v['source_contract']='metres, Z-up, negative-Y front; ground centre; identity transform; no parcel ground geometry'
pth.write_text(json.dumps(v,indent=2))

import bpy, sys, json, math, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
O=Path('/output'); O.mkdir(exist_ok=True)
# Independent review study: no production inputs are modified.
objs=[]; components=[]; groups={}; windows=[]; doors=[]; mats={}; texture_records=[]
colors={'CivicBrick':(.48,.23,.14,1),'LightStone':(.78,.70,.54,1),'RoofMembrane':(.075,.095,.11,1),'EquipmentMetal':(.22,.25,.27,1),'WindowGlass':(.14,.24,.29,1),'ServiceAccent':(.48,.045,.035,1)}
for name,col in colors.items():
 m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=col; p.inputs['Roughness'].default_value=.72
 mats[name]=m
texdir=O/'textures'; texdir.mkdir(exist_ok=True)
sets={}
for stem,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 sets[stem]={}
 for suffix in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+suffix+'.png'); dest=texdir/src.name; shutil.copyfile(src,dest)
  im=bpy.data.images.load(str(dest),check_existing=False); im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'; im.pack(); sets[stem][suffix]=im
  texture_records.append({'path':'textures/'+dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'dimensions':list(im.size),'colorspace':im.colorspace_settings.name})
for name,stem,tint in [('CivicBrick','CityBrick',(.66,.34,.22,1)),('EquipmentMetal','CityMechanical',(.48,.52,.55,1)),('RoofMembrane','RoofMembrane',(.12,.16,.20,1))]:
 m=mats[name]; n=m.node_tree.nodes; l=m.node_tree.links; p=n.get('Principled BSDF')
 ts={}
 for key,im in sets[stem].items():
  t=n.new('ShaderNodeTexImage'); t.image=im; t.extension='REPEAT'; ts[key]=t
 sep=n.new('ShaderNodeSeparateColor'); l.new(ts['ORM'].outputs['Color'],sep.inputs['Color'])
 ao=n.new('ShaderNodeMixRGB'); ao.blend_type='MULTIPLY'; ao.inputs[0].default_value=1; l.new(ts['BaseColor'].outputs['Color'],ao.inputs[1]); l.new(sep.outputs['Red'],ao.inputs[2])
 mul=n.new('ShaderNodeMixRGB'); mul.name='Actual restrained tint MULTIPLY'; mul.blend_type='MULTIPLY'; mul.inputs[0].default_value=1; mul.inputs[2].default_value=tint; l.new(ao.outputs[0],mul.inputs[1]); l.new(mul.outputs[0],p.inputs['Base Color'])
 l.new(sep.outputs['Green'],p.inputs['Roughness']); l.new(sep.outputs['Blue'],p.inputs['Metallic'])
 normal=n.new('ShaderNodeNormalMap'); normal.inputs['Strength'].default_value=.25; l.new(ts['Normal'].outputs['Color'],normal.inputs['Color']); l.new(normal.outputs['Normal'],p.inputs['Normal'])
def bounds(o):
 pts=[o.matrix_world@Vector(v) for v in o.bound_box]
 return [[min(p[i] for p in pts) for i in range(3)],[max(p[i] for p in pts) for i in range(3)]]
def register(o,mat,group):
 o.data.materials.clear(); o.data.materials.append(mats[mat]); bpy.context.view_layer.objects.active=o; o.select_set(True)
 bpy.ops.object.transform_apply(location=True,rotation=True,scale=True); o.select_set(False); bpy.context.view_layer.update()
 vg=o.vertex_groups.new(name=o.name); vg.add(list(range(len(o.data.vertices))),1,'REPLACE')
 uv=o.data.uv_layers.new(name='UV0') if not o.data.uv_layers else o.data.uv_layers[0]
 for p in o.data.polygons:
  axis=max(range(3),key=lambda i:abs(p.normal[i])); axes=[i for i in range(3) if i!=axis]
  for li in p.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co; uv.data[li].uv=(co[axes[0]]/2,co[axes[1]]/2)
 lo,hi=bounds(o); components.append({'name':o.name,'min':lo,'max':hi}); objs.append(o); groups.setdefault(group,[]).append(o.name); return o
 def_unused=0
def B(name,lo,hi,mat='CivicBrick',group='body'):
 return register(box(name,tuple(hi[i]-lo[i] for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),colors[mat]),mat,group)
admin=B('Admin_actual_wall',(-17,-5,0),(-7,8,6.4),group='admin')
# Hall has actual framed aperture rather than a painted oversized wall.
B('Hall_west_pier',(-5,-5,0),(-3.4,8,6.4),group='garage')
B('Hall_east_pier',(1.4,-5,0),(3,8,6.4),group='garage')
B('Hall_rear',(-3.4,7.65,0),(1.4,8,6.4),group='garage')
B('Hall_header',(-3.4,-5,3.95),(1.4,7.65,6.4),group='garage')
B('Enclosed_link',(-7,2,0),(-5,6,3.5),group='body')
tower=B('Tower_actual_wall',(-16,4,6.4),(-12,8,10.8),group='tower')
# Flat roofs, shallow cream cornices and dark coping, supported on each occupied mass.
for name,lo,hi,z in [('Admin',(-17,-5),(-7,8),6.4),('Hall',(-5,-5),(3,8),6.4),('Link',(-7,2),(-5,6),3.5),('Tower',(-16,4),(-12,8),10.8)]:
 B(name+'_roof',(lo[0],lo[1],z),(hi[0],hi[1],z+.15),'RoofMembrane','roof')
 # Tower roof is the only roof detailing over its footprint.
 for side,a,b in [('front',(lo[0]-.08,lo[1]-.08,z-.16),(hi[0]+.08,lo[1]+.12,z+.06)),('back',(lo[0]-.08,hi[1]-.12,z-.16),(hi[0]+.08,hi[1]+.08,z+.06)),('left',(lo[0]-.08,lo[1]+.12,z-.16),(lo[0]+.12,hi[1]-.12,z+.06)),('right',(hi[0]-.12,lo[1]+.12,z-.16),(hi[0]+.08,hi[1]-.12,z+.06))]: B(name+'_coping_'+side,a,b,'LightStone','roof')
# Narrow corner articulation does not cross window openings.
for x in [-16.9,-7.25]: B('Admin_corner_'+str(x),(x,-5.07,0),(x+.15,-4.98,6.18),'LightStone','admin')
# Four discrete frame bars. Their backs embed 1cm into the backing face.
def window(name,back,axis,sign,u,z,w=1.35,h=1.45):
 lo,hi=bounds(back); face=hi[axis] if sign>0 else lo[axis]; ua=1-axis; t=.10
 def make(s,ul,uh,zl,zh,dl,dh,material):
  a=[0,0,zl]; b=[0,0,zh]; a[ua]=ul; b[ua]=uh
  ds=[face+sign*dl,face+sign*dh]; a[axis]=min(ds); b[axis]=max(ds)
  return B(name+s,a,b,material,'windows')
 pane=make('_pane',u-w/2,u+w/2,z-h/2,z+h/2,.012,.035,'WindowGlass')
 parts=[make('_jambL',u-w/2-t,u-w/2,z-h/2-t,z+h/2+t,-.01,.09,'LightStone'),make('_jambR',u+w/2,u+w/2+t,z-h/2-t,z+h/2+t,-.01,.09,'LightStone'),make('_head',u-w/2+.001,u+w/2-.001,z+h/2,z+h/2+t,-.01,.09,'LightStone'),make('_sill',u-w/2+.001,u+w/2-.001,z-h/2-t,z-h/2,-.01,.09,'LightStone')]
 for o in [pane]+parts:
  a,b=bounds(o)
  for k in [ua,2]: assert a[k]>=lo[k]+.12-1e-5 and b[k]<=hi[k]-.12+1e-5,(name,'containment')
 for i,a in enumerate(parts):
  al,ah=bounds(a)
  for b in parts[i+1:]:
   bl,bh=bounds(b); assert not all(min(ah[k],bh[k])-max(al[k],bl[k])>1e-6 for k in range(3))
 windows.append({'pane':pane.name,'frame_parts':[p.name for p in parts],'backing':back.name,'axis':axis,'sign':sign,'wall_face':face,'pane_bounds':bounds(pane),'frame_bounds':[bounds(p) for p in parts],'checks':{'contained':True,'rear_embed_m':.01,'pane_inset_m':.055,'clear_opening':True,'rim_disjoint':True}})
# Reception frontage retains generous clear space for doors and badge.
for x in [-15.3,-8.7]: window('Admin_ground_front_'+str(x),admin,1,-1,x,1.9)
for x in [-15.3,-12,-8.7]: window('Admin_upper_front_'+str(x),admin,1,-1,x,4.85,1.65,1.5)
for y in [-2.8,.5,3.6,6.5]:
 for z in [1.9,4.85]: window('Admin_west_'+str(y)+'_'+str(z),admin,0,-1,y,z,1.5,1.5)
for x in [-10,-7.95]:
 for z in [1.9,4.85]: window('Admin_rear_'+str(x)+'_'+str(z),admin,1,1,x,z,1.2,1.5)
for y in [-2.5,1,4.5]: window('Hall_east_'+str(y),next(o for o in objs if o.name=='Hall_east_pier'),0,1,y,4.95,1.75,1.3)
for x in [-14]:
 for z in [8.0,9.65]: window('Tower_front_'+str(z),tower,1,-1,x,z,1.3,.85)
for y in [6]:
 for z in [8,9.65]: window('Tower_west_'+str(z),tower,0,-1,y,z,1.2,.85)
# Public double leaves: opaque doors, not architectural glass panes.
for i,x in enumerate([-12.5,-11.5]):
 d=B('Public_leaf_'+str(i),(x-.495,-5.08,0),(x+.495,-4.99,2.65),'ServiceAccent','entry'); doors.append({'leaf':d.name,'type':'public double leaf'})
 B('Public_handle_'+str(i),(x+(.32 if i==0 else -.35),-5.14,1.03),(x+(.35 if i==0 else -.32),-5.07,1.45),'EquipmentMetal','entry')
for x in [-13.14,-10.98]: B('Entry_jamb_'+str(x),(x,-5.14,0),(x+.12,-4.99,2.85),'LightStone','entry')
B('Entry_lintel',(-13.14,-5.14,2.72),(-10.86,-4.99,2.88),'LightStone','entry')
B('Entry_canopy',(-13.55,-6.15,2.95),(-10.45,-4.95,3.15),'EquipmentMetal','entry')
# Bay clear width 4.5, height 3.6. Leaves sit behind all empty approach space.
bay=B('Bay01_closed_sectional_leaf',(-3.25,-5.06,0),(1.25,-4.96,3.65),'ServiceAccent','garage')
for x in [-3.4,1.25]: B('Bay_jamb_'+str(x),(x,-5.14,0),(x+.15,-4.97,3.85),'LightStone','garage')
B('Bay_lintel',(-3.4,-5.14,3.7),(1.4,-4.97,3.88),'LightStone','garage')
for z in [.6,1.2,1.8,2.4,3,3.6]: B('Bay_section_rail_'+str(z),(-3.245,-5.085,z-.015),(1.245,-5.06,z+.015),'EquipmentMetal','garage')
doors.append({'leaf':bay.name,'type':'sectional apparatus','width_m':4.5,'height_m':3.65})
# Original geometric shield and compact flame in shallow mounted relief beside reception.
def relief(name,points,yfront,yback,mat):
 verts=[(x,y,z) for y in [yfront,yback] for x,z in points]; n=len(points); faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 mesh=bpy.data.meshes.new(name); mesh.from_pydata(verts,[],faces); mesh.update(); o=bpy.data.objects.new(name,mesh); bpy.context.collection.objects.link(o); return register(o,mat,'emblem')
relief('Attached_fire_shield',[(-14.3,2.75),(-13.55,2.75),(-13.55,2.2),(-13.93,1.85),(-14.3,2.2)],-5.13,-4.99,'LightStone')
relief('Original_flame_relief',[(-14.15,2.18),(-14.19,2.37),(-13.96,2.66),(-13.99,2.4),(-13.80,2.52),(-13.72,2.30),(-13.84,2.13)],-5.18,-5.12,'ServiceAccent')
# Restrained mounted roof equipment, no poles or decorative pipework.
B('Hall_roof_vent_curb',(.5,5,6.55),(1.7,6.2,6.75),'EquipmentMetal','equipment')
B('Hall_roof_vent',(.6,5.1,6.75),(1.6,6.1,7.12),'EquipmentMetal','equipment')
for i in range(4): B('Vent_louvre_'+str(i),(.59,5.08,6.80+i*.07),(1.61,5.12,6.83+i*.07),'RoofMembrane','equipment')
# Exact proposed source site and strict positive corridor intersections over every component.
def corridor(x,w,end,height): return {'min':[x-w/2,-16,0],'max':[x+w/2,end,height]}
anchors=[]
for role,target,x,w,h,end in [('pedestrian','Public_leaf_0',-12,2,2.7,-6.2),('service',bay.name,-1,4.5,3.6,-5.2)]:
 c=corridor(x,w,end,h)
 for comp in components:
  assert not all(min(comp['max'][k],c['max'][k])-max(comp['min'][k],c['min'][k])>1e-6 for k in range(3)),('corridor obstructed',comp['name'])
 anchors.append({'role':role,'target':target,'xyz_m':[x,end,0],'outward':[0,-1,0],'width_m':w,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':w,'grade_m':0},'reserved_free_corridor':c})
for c in components:
 assert c['min'][0]>=-19.5 and c['max'][0]<=19.5 and c['min'][1]>=-15.5 and c['max'][1]<=15.5 and c['min'][2]>=-1e-6
tris=sum(len(o.data.polygons)*2 for o in objs if all(len(p.vertices)==4 for p in o.data.polygons))
for o in objs: o.data.calc_loop_triangles()
triangles=sum(len(o.data.loop_triangles) for o in objs); assert triangles<=5500,triangles
assert len(windows)>=20
occupied={'min':[min(c['min'][k] for c in components) for k in range(3)],'max':[max(c['max'][k] for c in components) for k in range(3)]}
def write(name,data): (O/name).write_text(json.dumps(data,indent=2))
write('window-mounts.json',{'windows':windows,'doors':doors})
write('entrance-anchors.json',{'anchors':anchors})
write('vehicle-bays.json',{'bays':[{'id':'bay01','target':bay.name,'xyz_m':[-1,-5.2,0],'outward':[0,-1,0],'width_m':4.5,'height_m':3.65,'boundary_connector':{'xyz_m':[-1,-16,0]},'reserved_free_corridor':anchors[1]['reserved_free_corridor']}]})
write('upgrade-plan.json',{'family':'fire','stage':'base','stage_index':0,'existing_stages':['base','medium','high'],'existing_upgrade_count':2,'gameplay_changes':False,'source_site_m':[40,32],'current_native_footprint':[3,2],'retained_entrance_centres':{'pedestrian':[-12,-5],'service':[-1,-5]},'progression':'Base: two-storey crew/admin, single generous apparatus bay, enclosed link and supported hose tower. Medium/high remain separately authored real family stages; no stage added here.','actual_occupied_bounds':occupied,'future_LOD':'LOD1 simplify rims, emblem and vent; LOD2 merge frames and remove small roof details. Approved originals retained.'})
write('civic-contract.json',{'family':'fire','stage':'base','sourceID':'building.fire.a','role':'fire station','proposed_site_m':[40,32],'groups':groups,'integration':'HELD; human source review only'})
write('material-manifest.json',{'textures':texture_records,'regions':list(mats),'UV0':'world planar face projection, 2 metres per repeat, finite','textured_regions':{'CivicBrick':{'set':'CityBrick','multiply':[.66,.34,.22,1]},'EquipmentMetal':{'set':'CityMechanical','multiply':[.48,.52,.55,1]},'RoofMembrane':{'set':'RoofMembrane','multiply':[.12,.16,.20,1]}},'shader_recipe':'BaseColor(sRGB) * ORM.R AO * tint -> base color; ORM.G roughness, ORM.B metallic; tangent normal Non-Color strength .25','constants':{k:list(v) for k,v in colors.items()},'opaque_glass':{'transmission':0,'roughness':.72},'native_reconstruction':'FBX does not transfer node graphs; reconstruct from this manifest.'})
# Finish is the tested worker implementation including strict checked FBX roundtrip.
bpy.context.scene.cursor.location=(0,0,0); bpy.ops.object.select_all(action='DESELECT'); objs[0].select_set(True); bpy.context.view_layer.objects.active=objs[0]; bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objs)
p=O/'validation.json'; result=json.loads(p.read_text()) if p.exists() else {}
result.update({'components':components,'sourceID':'building.fire.a','stage':'base','source_triangles':triangles,'triangle_cap':5500,'semantic_regions':list(mats),'window_count':len(windows),'occupied_bounds':occupied,'checks':{'all_components_measured_after_apply':True,'every_component_vertex_group':True,'site_containment':True,'strict_corridor_nonintersection_all_solids':True,'window_wall_containment':True,'frame_corner_disjointness':True,'window_contact_and_depth':True,'six_semantic_regions':True,'no_ground_geometry':True},'review_only':True,'integration':'HELD','visual_assessment':'Not claimed; preview supplied for human review.'})
write('validation.json',result)

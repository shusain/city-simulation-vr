import bpy, sys, math, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output'); out.mkdir(exist_ok=True)
# Inspect the exact pinned dependencies without changing any source files.
refs=[]
for issue in (123,124):
    base=Path('/repo/ArtSource/Generated/comfy')/('issue-'+str(issue))/'v1'
    record={'issue':issue,'version':1,'files':{}}
    for filename in ('asset.png','approval.json','unreal-handoff.json'):
        p=base/filename
        raw=p.read_bytes()
        record['files'][filename]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
        if filename.endswith('.json'):
            record['files'][filename]['content']=json.loads(raw)
    image=bpy.data.images.load(str(base/'asset.png'),check_existing=True)
    record['image_loaded']=bool(image.size[0] and image.size[1])
    record['image_dimensions']=list(image.size)
    assert record['image_loaded']
    refs.append(record)
kit=Path('/repo/ArtSource/Manifests/city_environment_kit.json')
kit_hash=hashlib.sha256(kit.read_bytes()).hexdigest()
# One continuous, capped low-sided coil. The increasing body volume forms
# broad whorls, not fine ridges or an elongated pointed horn.
verts=[]; faces=[]
n=15; sides=4
for i in range(n):
    t=i/(n-1)
    a=2*math.pi*1.65*t + .4
    radius=.004+.046*t
    thick=.0035+.0185*t
    center=Vector((radius*math.cos(a),radius*math.sin(a),.044-.015*t))
    radial=Vector((math.cos(a),math.sin(a),0))
    for j in range(sides):
        b=2*math.pi*j/sides+math.pi/4
        v=center + radial*(thick*math.cos(b)) + Vector((0,0,thick*1.55*math.sin(b)))
        verts.append(tuple(v))
for i in range(n-1):
    for j in range(sides):
        faces.append((i*sides+j,i*sides+(j+1)%sides,(i+1)*sides+(j+1)%sides,(i+1)*sides+j))
faces.append(tuple(reversed(range(sides))))
faces.append(tuple((n-1)*sides+j for j in range(sides)))
# Bake exact requested metric dimensions and ground-centered origin into vertices.
lo=[min(v[k] for v in verts) for k in range(3)]
hi=[max(v[k] for v in verts) for k in range(3)]
target=(.16,.12,.11)
verts=[tuple((v[k]-(lo[k] if k==2 else (lo[k]+hi[k])/2))*target[k]/(hi[k]-lo[k]) for k in range(3)) for v in verts]
mesh=bpy.data.meshes.new('SpiralShell_closed_coil'); mesh.from_pydata(verts,[],faces); mesh.update()
obj=bpy.data.objects.new('SM_Scenery_SpiralShell_A',mesh); bpy.context.collection.objects.link(obj)
bpy.context.view_layer.objects.active=obj; obj.select_set(True)
# Consistent outward normals on a closed surface.
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.object.mode_set(mode='OBJECT')
mat=bpy.data.materials.new('Shell'); mat.diffuse_color=(.72,.67,.57,1); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=mat.diffuse_color; bs.inputs['Roughness'].default_value=.78
mesh.materials.append(mat)
for p in mesh.polygons:p.use_smooth=False
# Independent face islands: finite, non-degenerate UV0 with no texture dependency.
uv=mesh.uv_layers.new(name='UV0')
for p in mesh.polygons:
    normal=p.normal
    axis=max(range(3),key=lambda k:abs(normal[k]))
    axes=[k for k in range(3) if k!=axis]
    coords=[(mesh.vertices[mesh.loops[l].vertex_index].co[axes[0]],mesh.vertices[mesh.loops[l].vertex_index].co[axes[1]]) for l in p.loop_indices]
    mins=[min(c[k] for c in coords) for k in range(2)]; maxs=[max(c[k] for c in coords) for k in range(2)]
    for l,c in zip(p.loop_indices,coords):uv.data[l].uv=tuple(.05+.9*(c[k]-mins[k])/max(1e-10,maxs[k]-mins[k]) for k in range(2))
obj['review_only']=True; obj['collision_policy']='none'; obj['source_lods']=1
finish([obj])
# Retain the tested helper's measured receipt, then add issue-specific checks.
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('SM_Scenery')]
if obj.name in bpy.data.objects: shell=obj
elif len(meshes)==1: shell=meshes[0]
else: shell=next(o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)==60)
shell.name='SM_Scenery_SpiralShell_A'
shell.data.calc_loop_triangles(); tris=len(shell.data.loop_triangles)
assert tris<=120, tris
bounds=[shell.matrix_world@v.co for v in shell.data.vertices]
minimum=[min(v[k] for v in bounds) for k in range(3)]; maximum=[max(v[k] for v in bounds) for k in range(3)]
dims=[maximum[k]-minimum[k] for k in range(3)]
assert all(abs(a-b)<b*.05 for a,b in zip(dims,target))
assert abs(minimum[2])<1e-6
with checked_fbx(shell,'/output/asset.fbx',['Shell'],expected_triangles=tris,expected_sections=1) as imported:
    readback={'passed':True,'dimensions_m':list(imported.dimensions),'triangles':len(imported.data.loop_triangles),'material_slots':[m.name.split('.')[0] for m in imported.data.materials]}
p=out/'validation.json'
try: report=json.loads(p.read_text())
except Exception: report={}
edge_uses={}
for face in shell.data.polygons:
    ids=list(face.vertices)
    for a,b in zip(ids,ids[1:]+ids[:1]):
        key=tuple(sorted((a,b))); edge_uses[key]=edge_uses.get(key,0)+1
report.update({'asset':'SM_Scenery_SpiralShell_A','review_only':True,'dimensions_m':dims,'bounds_m':[minimum,maximum],'minZ':minimum[2],'pivot':list(shell.location),'scale':list(shell.scale),'rotation':list(shell.rotation_euler),'triangles':tris,'material_count':len(shell.data.materials),'material':{'name':'Shell','base_color':list(mat.diffuse_color),'roughness':.78},'closed_manifold_edges':all(n==2 for n in edge_uses.values()),'flat_shaded':all(not f.use_smooth for f in shell.data.polygons),'uv0_finite':all(math.isfinite(x) for d in shell.data.uv_layers.active.data for x in d.uv),'normals_finite':all(math.isfinite(x) for f in shell.data.polygons for x in f.normal),'fbx_roundtrip':readback,'approved_references':refs,'kit_manifest_sha256':kit_hash,'collision_policy':'none','source_lod_count':1,'production_changes':False,'visual_acceptance':'pending human source review','preview_note':'Close-up only; does not establish city-distance readability. No scale reference exported.'})
p.write_text(json.dumps(report,indent=2))
(out/'provenance.json').write_text(json.dumps({'issue':'D108 spiral-shell / #131','source_sha':'e5425d699e1a4f80b2303c4f7eff5e31fb3bf009','references':refs,'geometry':'15 four-sided cross-section rings; capped continuous increasing spiral; 116 triangles','status':'review-only, not production-approved'},indent=2))
# Save the helper-authored review scene before optional alternative camera view.
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=8
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
camera=scene.camera
if camera:
    oldmat=camera.matrix_world.copy(); oldtype=camera.data.type
    camera.location=(0,0,.48); direction=Vector((0,0,.055))-camera.location
    camera.rotation_euler=direction.to_track_quat('-Z','Y').to_euler(); camera.data.type='ORTHO'; camera.data.ortho_scale=.21
    scene.render.filepath='/output/preview_top.png'; bpy.ops.render.render(write_still=True)
    camera.matrix_world=oldmat; camera.data.type=oldtype
try:
    source=Path(__file__)
    if source.exists() and source.resolve()!= (out/'recipe.py').resolve():shutil.copyfile(source,out/'recipe.py')
except Exception:pass

import bpy, sys, math, json, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker'); sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous, finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output'); out.mkdir(exist_ok=True)
objects=load_previous()
# Decode pinned concepts before authoring; images are reference-only, never textures.
refs=[]
for issue in (123,124):
    base=Path('/repo/ArtSource/Generated/comfy')/('issue-'+str(issue))/'v1'
    record={'issue':issue,'version':1,'files':{}}
    for name in ('asset.png','approval.json','unreal-handoff.json'):
        raw=(base/name).read_bytes()
        record['files'][name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
        if name.endswith('.json'):record['files'][name]['content']=json.loads(raw)
    image=bpy.data.images.load(str(base/'asset.png'),check_existing=True)
    size=list(image.size); first=float(image.pixels[0]); loaded=bool(image.has_data)
    assert loaded and min(size)>0
    record.update(image_loaded=loaded,image_dimensions=size,first_pixel=first)
    refs.append(record)
# Explicit requested replacement: remove the rolled strip, retaining history read-only.
for obj in objects:
    if obj.name in bpy.data.objects:bpy.data.objects.remove(obj,do_unlink=True)
verts=[(-.08,0,.055)]; faces=[]
# Seven broad octagonal stations: a dominant filled ovoid, then short stepped tip.
# Gentle rotating eccentricity of the last stations suggests whorls without a tunnel.
stations=[(-.070,.029,.027,0,0),(-.050,.052,.048,0,0),(-.020,.060,.055,0,0),(.014,.053,.049,0,0),(.034,.037,.035,.002,.003),(.049,.030,.028,-.002,.007),(.064,.017,.016,.001,.010)]
for i,(x,ry,rz,dy,dz) in enumerate(stations):
    phase=0 if i<4 else (i-3)*.16
    for j in range(8):
        a=2*math.pi*j/8+phase
        verts.append((x,dy+ry*math.cos(a),.055+dz+rz*math.sin(a)))
end=len(verts); verts.append((.08,0,.068))
for j in range(8):faces.append((0,1+(j+1)%8,1+j))
for i in range(6):
    a=1+8*i; b=a+8
    for j in range(8):faces.append((a+j,a+(j+1)%8,b+(j+1)%8,b+j))
for j in range(8):faces.append((49+j,49+(j+1)%8,end))
mesh=bpy.data.meshes.new('RoundedShell_broad_closed_whorls'); mesh.from_pydata(verts,[],faces); mesh.update()
shell=bpy.data.objects.new('SM_Scenery_SpiralShell_A',mesh); bpy.context.collection.objects.link(shell)
bpy.ops.object.select_all(action='DESELECT'); shell.select_set(True); bpy.context.view_layer.objects.active=shell
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.object.mode_set(mode='OBJECT')
mat=bpy.data.materials.get('Shell') or bpy.data.materials.new('Shell'); mat.use_nodes=True
mat.diffuse_color=(.72,.675,.59,1)
p=mat.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=mat.diffuse_color; p.inputs['Roughness'].default_value=.79; p.inputs['Metallic'].default_value=0; p.inputs['Alpha'].default_value=1
mesh.materials.clear(); mesh.materials.append(mat)
uv=mesh.uv_layers.new(name='UV0')
for face in mesh.polygons:
    face.use_smooth=False
    axis=max(range(3),key=lambda k:abs(face.normal[k])); axes=[k for k in range(3) if k!=axis]
    for li in face.loop_indices:
        co=mesh.vertices[mesh.loops[li].vertex_index].co
        uv.data[li].uv=(.5+co[axes[0]]*4,.1+co[axes[1]]*4)
shell['review_only']=True; shell['collision_policy']='none'; shell['source_lod_count']=1
finish([shell])
# Helper may join/rename the source: identify its unique 58-vertex replacement.
shell=next(o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)==58)
shell.name='SM_Scenery_SpiralShell_A'; mesh=shell.data; mesh.calc_loop_triangles()
triangles=len(mesh.loop_triangles); assert triangles==112
coords=[shell.matrix_world@v.co for v in mesh.vertices]
lo=[min(v[k] for v in coords) for k in range(3)]; hi=[max(v[k] for v in coords) for k in range(3)]; dims=[hi[k]-lo[k] for k in range(3)]
assert all(abs(a-b)<=b*.05 for a,b in zip(dims,(.16,.12,.11)))
assert abs(lo[2])<1e-6 and shell.location.length<1e-6
edges={}
for f in mesh.polygons:
    ids=list(f.vertices)
    for a,b in zip(ids,ids[1:]+ids[:1]):
        key=tuple(sorted((a,b))); edges[key]=edges.get(key,0)+1
assert all(v==2 for v in edges.values())
uvdata=mesh.uv_layers.active.data
uv_areas=[]
for t in mesh.loop_triangles:
    a,b,c=[uvdata[i].uv for i in t.loops]
    uv_areas.append(abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x))*.5)
assert min(uv_areas)>1e-10
assert all(math.isfinite(x) for d in uvdata for x in d.uv)
with checked_fbx(shell,'/output/asset.fbx',['Shell'],expected_triangles=112,expected_sections=1) as imported:
    readback={'passed':True,'dimensions_m':list(imported.dimensions),'triangles':len(imported.data.loop_triangles),'material_slots':[m.name.split('.')[0] for m in imported.data.materials]}
# Replace building-scale helper illumination with explicit small-object neutral lighting.
scene=bpy.context.scene
for o in list(scene.objects):
    if o.type=='LIGHT':bpy.data.objects.remove(o,do_unlink=True)
for name,pos,power,size in [('Key',(-.22,-.25,.35),6,.23),('Fill',(.20,.18,.25),3,.20)]:
    data=bpy.data.lights.new(name,'AREA'); data.energy=power; data.shape='DISK'; data.size=size
    light=bpy.data.objects.new(name,data); scene.collection.objects.link(light); light.location=pos
    light.rotation_euler=(Vector((0,0,.05))-light.location).to_track_quat('-Z','Y').to_euler()
scene.world.use_nodes=True; scene.world.node_tree.nodes.get('Background').inputs[0].default_value=(.21,.23,.26,1); scene.world.node_tree.nodes.get('Background').inputs[1].default_value=.35
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=8
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
cam=scene.camera
cam.data.type='ORTHO'; cam.data.ortho_scale=.215; cam.data.clip_start=.001; cam.data.clip_end=100
views=[('preview.png',(.24,-.32,.23)),('preview_top.png',(0,0,.45)),('preview_side.png',(.015,-.45,.07))]
for filename,pos in views:
    cam.location=pos; cam.rotation_euler=(Vector((0,0,.055))-cam.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath='/output/'+filename; bpy.ops.render.render(write_still=True)
cam.location=views[0][1]; cam.rotation_euler=(Vector((0,0,.055))-cam.location).to_track_quat('-Z','Y').to_euler(); scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
path=out/'validation.json'
report=json.loads(path.read_text()) if path.exists() else {}
report.update(asset=shell.name,revision=2,review_only=True,dimensions_m=dims,bounds_m=[lo,hi],minZ=lo[2],pivot=list(shell.location),rotation=list(shell.rotation_euler),scale=list(shell.scale),triangles=triangles,material_count=len(mesh.materials),material={'name':'Shell','color':list(mat.diffuse_color),'roughness':.79,'opaque':True},closed_manifold_edges=True,uv0_finite=True,uv0_min_triangle_area=min(uv_areas),normals_finite=all(math.isfinite(x) for f in mesh.polygons for x in f.normal),minimum_face_area=min(f.area for f in mesh.polygons),flat_shaded=True,fbx_roundtrip=readback,approved_references=refs,collision_policy='none',source_lod_count=1,production_changes=False,visual_acceptance='Pending Shaun review; no human approval claimed',geometry_comparison={'replacement':'Closed filled ovoid replaces the planar rolled strip entirely','body_x_extent_m':.114,'total_x_extent_m':.16,'tip_note':'Short tapered stepped terminal stations; broad octagonal facets, no separate inner mesh or open channel'},preview_note='Close-up only, not city-distance readability. Geometry remains true metric scale. Two area lights 6W/3W at small-object distances; three neutral 512px CPU views.')
path.write_text(json.dumps(report,indent=2))
(out/'provenance.json').write_text(json.dumps({'issue':'D108 / #131','revision':2,'previous':'/previous/asset.blend retained read-only','source_sha':'e5425d699e1a4f80b2303c4f7eff5e31fb3bf009','references':refs,'geometry':'58 vertices, 112 triangles; closed ovoid with seven broad stations and short tapered whorl end','status':'Review only; checked source FBX is not runtime integration'},indent=2))
try:
    src=Path(__file__)
    if src.exists() and src.resolve()!=(out/'recipe.py').resolve():shutil.copyfile(src,out/'recipe.py')
except Exception:pass

import sys, json, math
from pathlib import Path
import bpy
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
from CityBuildingStudyIO import checked_fbx

# One closed, static, human-scale source study; no production input modified.
body_col=(0.075,0.32,0.31,1)
trim_col=(0.88,0.81,0.64,1)
def material(name,col):
    m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.72
    return m
bodymat=material('Body',body_col); trimmat=material('Trim',trim_col)
objects=[]
def assign(o,m):
    o.data.materials.clear();o.data.materials.append(m);objects.append(o);return o

def ring_shape(name,rings,mat):
    verts=[]
    for w,d,z,b in rings:
        verts.extend([(-w/2+b,-d/2,z),(w/2-b,-d/2,z),(w/2,-d/2+b,z),(w/2,d/2-b,z),(w/2-b,d/2,z),(-w/2+b,d/2,z),(-w/2,d/2-b,z),(-w/2,-d/2+b,z)])
    faces=[tuple(reversed(range(8)))]
    for j in range(len(rings)-1):
        for i in range(8):faces.append((j*8+i,j*8+(i+1)%8,(j+1)*8+(i+1)%8,(j+1)*8+i))
    faces.append(tuple(range((len(rings)-1)*8,len(rings)*8)))
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);return assign(o,mat)
ring_shape('Faceted insulated body',[(.486,.316,0,.026),(.508,.338,.018,.03),(.54,.368,.275,.035),(.536,.364,.29,.033)],bodymat)
ring_shape('Closed cream lid',[(.536,.366,.292,.032),(.55,.38,.3,.034),(.55,.38,.323,.034),(.534,.364,.333,.03)],trimmat)
# Raised rigid bail. End uprights sit outside the narrow ends, leaving an open grip gap.
for s in (-1,1):
    assign(box('Fixed handle upright',(.021,.028,.12),(s*.264,0,.35),trim_col),trimmat)
    o=cylinder('Handle pivot',.021,.016,(s*.267,0,.278),trim_col,vertices=8)
    o.rotation_euler[1]=math.pi/2;assign(o,trimmat)
assign(box('Carry grip',(.535,.032,.026),(0,0,.407),trim_col),trimmat)
for x in (-.172,.172):
    assign(box('Front latch',(.033,.014,.052),(x,-.185,.286),trim_col),trimmat)
# Apply authored component transforms before joining through the tested worker helper.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
finish(objects)

# Keep the asset's ground-contact origin explicit, and enforce the semantic contract.
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name not in {'Ground','Floor'}]
asset=max(meshes,key=lambda o:len(o.data.vertices))
asset.name='D108_PortableBeachCooler_ReviewOnly'
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
# The helper retains component materials; collapse to precisely the two authored slots.
old=list(asset.data.materials)
indices=[0 if old[p.material_index]==bodymat else 1 for p in asset.data.polygons]
asset.data.materials.clear();asset.data.materials.append(bodymat);asset.data.materials.append(trimmat)
for p,i in zip(asset.data.polygons,indices):p.material_index=i
asset.data.calc_loop_triangles()
triangles=len(asset.data.loop_triangles)
assert 160 <= triangles <= 320,triangles
with checked_fbx(asset,Path('/output/asset.fbx'),['Body','Trim']):pass
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=16
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
camera=scene.camera
# Consistent product views, plus a front view with a one-meter image width.
def render_view(path,loc,target,span):
    camera.location=loc;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.type='ORTHO';camera.data.ortho_scale=span
    scene.render.filepath=path;bpy.ops.render.render(write_still=True)
render_view('/output/preview.png',(.85,-1.15,.8),(0,0,.205),.82)
render_view('/output/front_1m.png',(0,-1.5,.21),(0,0,.21),1.0)
render_view('/output/top.png',(0,0,1.8),(0,0,0),.75)
camera.location=(.85,-1.15,.8);camera.rotation_euler=(Vector((0,0,.205))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=.82
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json')
validation=json.loads(p.read_text()) if p.exists() else {}
validation['cooler_contract']={'triangles':triangles,'triangle_budget_pass':160<=triangles<=320,'dimensions_m':list(asset.dimensions),'material_slots':[m.name for m in asset.data.materials],'origin':list(asset.location),'fbx_roundtrip_pass':True,'front_view_width_m':1.0,'review_only':True,'integration_approved':False}
p.write_text(json.dumps(validation,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 Resident portable beach cooler','status':'review-only source; no production promotion','asset':'asset.blend','export':'asset.fbx','views':['preview.png','front_1m.png','top.png'],'units':'meters','up_axis':'Z','materials':['Body','Trim'],'construction':'Closed faceted body and lid; fixed raised handle; two minimal latches; no interior, rig, logo or ground base','triangles':triangles,'dimensions_m':list(asset.dimensions)},indent=2))

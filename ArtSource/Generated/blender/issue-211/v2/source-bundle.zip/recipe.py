import sys, json, hashlib
from pathlib import Path
import bpy
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import load_previous, finish
from CityBuildingStudyIO import snapshot, checked_fbx
objects=load_previous()
assert objects
before=[snapshot(o) for o in objects]
transforms=[list(sum((list(row) for row in o.matrix_world),[])) for o in objects]
for o in objects:
    for m in o.data.materials:
        color=(.045,.235,.215,1) if m.name.split('.')[0]=='Body' else (.72,.65,.49,1)
        m.diffuse_color=color
        m.use_nodes=True
        p=m.node_tree.nodes.get('Principled BSDF')
        assert p is not None
        p.inputs['Base Color'].default_value=color
        p.inputs['Roughness'].default_value=.78
        p.inputs['Metallic'].default_value=0
finish(objects)
asset=objects[0]
assert asset.type=='MESH'
assert len(before)==1, 'Expected validated single mesh'
assert snapshot(asset)==before[0], 'Geometry, UV, face assignments must remain unchanged'
assert list(sum((list(row) for row in asset.matrix_world),[]))==transforms[0]
assert [m.name.split('.')[0] for m in asset.data.materials]==['Body','Trim']
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=16
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.view_settings.exposure=-.45
scene.view_settings.gamma=1
# Replace presentation illumination only: controlled soft product lighting at meter scale.
for o in list(scene.objects):
    if o.type=='LIGHT': bpy.data.objects.remove(o,do_unlink=True)
world=scene.world
world.use_nodes=True
bg=world.node_tree.nodes.get('Background')
bg.inputs['Color'].default_value=(.32,.30,.28,1)
bg.inputs['Strength'].default_value=.45
for o in scene.objects:
    if o.type=='MESH' and o!=asset:
        mat=bpy.data.materials.new('Review_WarmGray')
        mat.use_nodes=True
        mat.diffuse_color=(.24,.22,.20,1)
        p=mat.node_tree.nodes.get('Principled BSDF')
        p.inputs['Base Color'].default_value=mat.diffuse_color
        p.inputs['Roughness'].default_value=.95
        o.data.materials.clear();o.data.materials.append(mat)
def area(name,loc,power,size):
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size
    o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc
    o.rotation_euler=(Vector((0,0,.2))-o.location).to_track_quat('-Z','Y').to_euler()
area('Soft key',(-1,-1.4,2),85,1.6)
area('Soft fill',(1.3,-.3,1),35,1.2)
area('Rim',(0,1.2,1.6),55,1.0)
camera=scene.camera
camera.data.type='ORTHO'
def view(path,loc,target,span):
    camera.location=loc
    camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.ortho_scale=span
    scene.render.filepath=path
    bpy.ops.render.render(write_still=True)
view('/output/preview.png',(.85,-1.15,.8),(0,0,.205),.76)
view('/output/front_1m.png',(0,-1.5,.21),(0,0,.21),1)
view('/output/top.png',(0,0,1.8),(0,0,0),.70)
camera.location=(.85,-1.15,.8)
camera.rotation_euler=(Vector((0,0,.205))-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.ortho_scale=.76
scene.render.filepath='/output/preview.png'
with checked_fbx(asset,Path('/output/asset.fbx'),['Body','Trim']): pass
assert snapshot(asset)==before[0]
asset.data.calc_loop_triangles()
tri=len(asset.data.loop_triangles)
assert 160<=tri<=320
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json')
v=json.loads(p.read_text()) if p.exists() else {}
v['revision']={'review_only':True,'geometry_preserved':True,'mesh_snapshot_equal':True,'transforms_preserved':True,'triangles':tri,'dimensions_m':list(asset.dimensions),'origin':list(asset.location),'material_slots':[m.name for m in asset.data.materials],'fbx_roundtrip_pass':True,'presentation':'Muted teal and cream, warm-gray surroundings, exposure -0.45','front_view_width_m':1.0,'integration_approved':False}
p.write_text(json.dumps(v,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 Resident portable beach cooler','revision':'v2 presentation-only','source':'/previous/asset.blend','asset':'asset.blend','export':'asset.fbx','views':['preview.png','front_1m.png','top.png'],'units':'meters','up_axis':'Z','triangles':tri,'dimensions_m':list(asset.dimensions),'materials':['Body','Trim'],'geometry_preserved':True,'status':'Review only; no export approval or Unreal integration implied'},indent=2))

import bpy, sys, json, shutil, hashlib, math
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
O=Path('/output'); O.mkdir(exist_ok=True)
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
# Review-only, independent authored source. Never load or modify approved meshes.
for ob in list(bpy.data.objects):
    if ob.type=='MESH': bpy.data.objects.remove(ob,do_unlink=True)
for me in list(bpy.data.meshes):
    if me.users==0:bpy.data.meshes.remove(me)
for ma in list(bpy.data.materials):
    if ma.users==0:bpy.data.materials.remove(ma)
tex={}; receipts=[]
(O/'textures').mkdir(exist_ok=True)
for folder,stem in [('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
    for suffix in ['BaseColor','Normal','ORM']:
        src=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+suffix+'.png'); dst=O/'textures'/src.name; shutil.copyfile(src,dst)
        im=bpy.data.images.load(str(dst),check_existing=True); im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'; im.pack(); tex[stem,suffix]=im
        receipts.append(dict(file='textures/'+dst.name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
materials={}; specs={}
def material(name,color,stem=None,tint=None,metal=0,rough=.75):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    ns=m.node_tree.nodes; ls=m.node_tree.links; p=ns.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1); p.inputs['Roughness'].default_value=rough; p.inputs['Metallic'].default_value=metal
    if stem:
        images={}
        for s in ['BaseColor','Normal','ORM']:
            n=ns.new('ShaderNodeTexImage'); n.image=tex[stem,s]; images[s]=n
        sep=ns.new('ShaderNodeSeparateColor'); ls.new(images['ORM'].outputs['Color'],sep.inputs['Color'])
        ao=ns.new('ShaderNodeMixRGB'); ao.blend_type='MULTIPLY'; ao.inputs[0].default_value=1; ls.new(images['BaseColor'].outputs['Color'],ao.inputs[1]); ls.new(sep.outputs['Red'],ao.inputs[2])
        mul=ns.new('ShaderNodeMixRGB'); mul.blend_type='MULTIPLY'; mul.inputs[0].default_value=1; mul.inputs[2].default_value=(*(tint or color),1); ls.new(ao.outputs[0],mul.inputs[1]); ls.new(mul.outputs[0],p.inputs['Base Color'])
        ls.new(sep.outputs['Green'],p.inputs['Roughness']); ls.new(sep.outputs['Blue'],p.inputs['Metallic'])
        normal=ns.new('ShaderNodeNormalMap'); normal.inputs['Strength'].default_value=.25; ls.new(images['Normal'].outputs['Color'],normal.inputs['Color']); ls.new(normal.outputs['Normal'],p.inputs['Normal'])
    materials[name]=m; specs[name]=dict(base_color=color,texture_set=stem,tint_multiply=tint or color,roughness=rough,metallic=metal,transmission=0,normal_strength=.25 if stem else 0)
material('CivicBrick',(.54,.43,.34),'CityBrick',(.64,.52,.42))
material('LightStone',(.79,.75,.64))
material('RoofMembrane',(.17,.20,.24),'RoofMembrane',(.19,.23,.29))
material('EquipmentMetal',(.4,.43,.46),'CityMechanical',(.5,.54,.58))
material('WindowGlass',(.12,.23,.29),rough=.32)
material('ServiceAccent',(.075,.15,.24),rough=.6)
objs=[]; groups={}; bounds={}; windows=[]; doors=[]
def register(ob,mat,group):
    ob.data.materials.clear(); ob.data.materials.append(materials[mat]); objs.append(ob); groups.setdefault(group,[]).append(ob.name)
    bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); bpy.context.view_layer.objects.active=ob; bpy.ops.object.transform_apply(location=False,rotation=True,scale=True); bpy.context.view_layer.update()
    vs=[ob.matrix_world@v.co for v in ob.data.vertices]; lo=[min(v[i] for v in vs) for i in range(3)]; hi=[max(v[i] for v in vs) for i in range(3)]; bounds[ob.name]=(lo,hi)
    vg=ob.vertex_groups.new(name=ob.name); vg.add(list(range(len(ob.data.vertices))),1,'REPLACE')
    uv=ob.data.uv_layers.active or ob.data.uv_layers.new(name='UV0'); uv.name='UV0'
    for poly in ob.data.polygons:
        ax=max(range(3),key=lambda i:abs(poly.normal[i])); ij=[i for i in range(3) if i!=ax]
        for li in poly.loop_indices:
            co=ob.matrix_world@ob.data.vertices[ob.data.loops[li].vertex_index].co; uv.data[li].uv=(co[ij[0]]/2,co[ij[1]]/2)
    return ob
def B(n,lo,hi,mat='LightStone',g='detail'):
    return register(box(n,tuple(hi[i]-lo[i] for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),(1,1,1,1)),mat,g)
B('AdminOccupied',(-16,-5,0),(-4,8,6.5),'CivicBrick','admin')
B('GarageOccupied',(-2,-5,0),(6,8,5.3),'CivicBrick','garage')
B('EnclosedConnector',(-4,2,0),(-2,6,3.5),'CivicBrick','body')
# Individual attached panes and nonoverlapping four-piece hollow frames.
def window(n,back,axis,sign,u,z,w=1.45,h=1.5):
    lo,hi=bounds[back]; face=(lo if sign<0 else hi)[axis]; tang=1-axis; t=.105
    def part(name,a,b,z0,z1,d0,d1,mat):
        l=[0,0,z0]; r=[0,0,z1]; l[tang]=a; r[tang]=b; l[axis]=min(face+sign*d0,face+sign*d1); r[axis]=max(face+sign*d0,face+sign*d1); return B(name,l,r,mat,'windows')
    x0=u-w/2; x1=u+w/2; z0=z-h/2; z1=z+h/2
    pane=part(n+'_Pane',x0+t,x1-t,z0+t,z1-t,.008,.035,'WindowGlass')
    frame=[part(n+'_JambL',x0,x0+t,z0,z1,-.01,.10,'LightStone'),part(n+'_JambR',x1-t,x1,z0,z1,-.01,.10,'LightStone'),part(n+'_Sill',x0+t+.001,x1-t-.001,z0,z0+t,-.01,.10,'LightStone'),part(n+'_Head',x0+t+.001,x1-t-.001,z1-t,z1,-.01,.10,'LightStone')]
    assert x0>=lo[tang]+.12 and x1<=hi[tang]-.12 and z0>=lo[2]+.12 and z1<=hi[2]-.12
    windows.append(dict(pane=pane.name,frame_parts=[o.name for o in frame],backing=back,axis=axis,sign=sign,wall_face=face,pane_bounds=bounds[pane.name],frame_bounds=[bounds[o.name] for o in frame]))
for z in [1.65,4.7]:
    for x in [-14.4,-12.3,-7.7,-5.6]: window('Front_%s_%s'%(z,x),'AdminOccupied',1,-1,x,z)
    for y in [-2.7,.3,3.3,6.2]:window('West_%s_%s'%(z,y),'AdminOccupied',0,-1,y,z)
    for x in [-14,-11.3,-8.6,-5.9]:window('Rear_%s_%s'%(z,x),'AdminOccupied',1,1,x,z)
for y in [-2.8,.4,3.6,6.6]:window('GarageEast_'+str(y),'GarageOccupied',0,1,y,3.5,1.4,1.3)
# Cornice and parapet rims, no floor or site geometry.
for name,x0,x1,y0,y1,z in [('Admin',-16,-4,-5,8,6.5),('Garage',-2,6,-5,8,5.3),('Link',-4,-2,2,6,3.5)]:
    B(name+'Roof',(x0-.10,y0-.10,z),(x1+.10,y1+.10,z+.16),'RoofMembrane','roof')
    B(name+'FrontFascia',(x0-.14,y0-.16,z-.15),(x1+.14,y0+.06,z+.10),'LightStone','roof')
    for suffix,l,h in [('W',(x0,y0,z+.16),(x0+.13,y1,z+.43)),('E',(x1-.13,y0,z+.16),(x1,y1,z+.43)),('N',(x0+.13,y1-.13,z+.16),(x1-.13,y1,z+.43)),('S',(x0+.13,y0,z+.16),(x1-.13,y0+.13,z+.43))]:B(name+'Parapet'+suffix,l,h,'LightStone','roof')
# Public closed double leaves; actual door set behind slim jambs. No glass door material needing a pane record.
for side,a,b in [('L',-10.94,-10.01),('R',-9.99,-9.06)]:B('ReceptionLeaf'+side,(a,-5.055,0),(b,-5.005,2.65),'ServiceAccent','entry')
for x in [-11.12,-9.06]:B('EntryJamb'+str(x),(x,-5.13,0),(x+.18,-4.99,2.85),'LightStone','entry')
B('EntryHeader',(-11.12,-5.13,2.65),(-8.88,-4.99,2.85),'LightStone','entry')
B('PublicCanopy',(-11.65,-6.25,2.98),(-8.35,-4.9,3.20),'ServiceAccent','entry')
for x in [-10.15,-9.9]:B('Handle'+str(x),(x,-5.10,1.0),(x+.04,-5.055,1.42),'EquipmentMetal','entry')
# Bay 4.5m x3.6m clear, closed sectional leaf at face.
B('Bay01Leaf',(-.25,-5.04,0),(4.25,-5.005,3.6),'ServiceAccent','garage')
for x in [-.47,4.25]:B('BayJamb'+str(x),(x,-5.15,0),(x+.22,-4.99,3.82),'LightStone','garage')
B('BayLintel',(-.47,-5.15,3.6),(4.47,-4.99,3.85),'LightStone','garage')
for z in [.6,1.2,1.8,2.4,3.0]:B('SectionSeam'+str(z),(-.23,-5.065,z),(4.23,-5.04,z+.026),'EquipmentMetal','garage')
# Attached compact original shield relief above the canopy; a closed extruded five-sided solid.
verts2=[(-.48,.45),(.48,.45),(.45,-.08),(0,-.54),(-.45,-.08)]
vs=[(-10+x,y,4.02+z) for y in [-5.16,-4.99] for x,z in verts2]; fs=[tuple(range(4,-1,-1)),tuple(range(5,10))]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)]
me=bpy.data.meshes.new('ShieldMesh');me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new('ReceptionShield',me);bpy.context.collection.objects.link(ob);register(ob,'ServiceAccent','emblem')
B('ShieldCentralBar',(-10.055,-5.19,3.75),(-9.945,-5.16,4.33),'LightStone','emblem')
B('ShieldCrossL',(-10.28,-5.19,4.00),(-10.056,-5.16,4.10),'LightStone','emblem')
B('ShieldCrossR',(-9.944,-5.19,4.00),(-9.72,-5.16,4.10),'LightStone','emblem')
# Roof-mounted compact radio assembly with planted mast and restrained aerial.
B('RadioPedestal',(-6.6,4.5,6.66),(-5.8,5.3,7.05),'EquipmentMetal','equipment')
register(cylinder('RadioMast',.075,2.4,(-6.2,4.9,8.25),(1,1,1,1),vertices=10),'EquipmentMetal','equipment')
B('RadioPanel',(-6.36,4.80,8.3),(-6.04,5.00,9.05),'LightStone','equipment')
B('RoofVent',(.5,5.5,5.46),(1.5,6.4,5.98),'EquipmentMetal','equipment')
# Independent physical checks, every authored object is one connected solid.
def overlap(a,b):return all(min(a[1][i],b[1][i])-max(a[0][i],b[0][i])>1e-6 for i in range(3))
for w in windows:
    pb=w['pane_bounds']; axis=w['axis']; s=w['sign']; face=w['wall_face']
    ds=sorted([s*(pb[j][axis]-face) for j in [0,1]]);assert ds[0]>=0 and ds[1]<.10
    fb=w['frame_bounds']
    for i in range(4):
        assert not overlap(pb,fb[i])
        assert min(s*(fb[i][j][axis]-face) for j in [0,1])<=-.009
        for j in range(i):assert not overlap(fb[i],fb[j])
anchors=[]
for role,target,x,width,height,end in [('pedestrian','ReceptionLeafL',-10,1.8,2.4,-6.30),('service','Bay01Leaf',2,4.5,3.6,-5.20)]:
    corridor={'min':[x-width/2,-16,0],'max':[x+width/2,end,height]}
    for n,bb in bounds.items():assert not overlap(bb,(corridor['min'],corridor['max'])),(role,n)
    anchors.append(dict(role=role,target=target,xyz_m=[x,end,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-16,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=corridor))
for n,(lo,hi) in bounds.items():assert lo[0]>=-19.5 and hi[0]<=19.5 and lo[1]>=-15.5 and hi[1]<=15.5 and lo[2]>=0,n
components=[dict(name=n,min=bb[0],max=bb[1]) for n,bb in bounds.items()]
tri=sum(len(o.data.polygons)*2 for o in objs if all(len(p.vertices)==4 for p in o.data.polygons))
for o in objs:o.data.calc_loop_triangles()
tri=sum(len(o.data.loop_triangles) for o in objs);assert tri<=5000
write('window-mounts.json',dict(windows=windows,doors=[dict(target='ReceptionLeafL',other_leaf='ReceptionLeafR',backing='AdminOccupied',axis=1,sign=-1,wall_face=-5),dict(target='Bay01Leaf',backing='GarageOccupied',axis=1,sign=-1,wall_face=-5)]))
write('entrance-anchors.json',dict(anchors=anchors))
a=anchors[1];write('vehicle-bays.json',dict(bays=[dict(id='bay01',target=a['target'],xyz_m=a['xyz_m'],outward=a['outward'],width_m=4.5,height_m=3.6,boundary_connector=a['boundary_connector'],reserved_free_corridor=a['reserved_free_corridor'])]))
occupied={'min':[min(bb[0][i] for bb in bounds.values()) for i in range(3)],'max':[max(bb[1][i] for bb in bounds.values()) for i in range(3)]}
write('upgrade-plan.json',dict(family='police',stage='base',stage_index=0,existing_stages=['base','medium','high'],existing_upgrade_count=2,gameplay_changes=False,source_site_m=[40,32],current_native_footprint=[3,2],retained_entrance_centres=[[-10,-5],[2,-5]],progression='Base stage: two-floor reception/admin, single response garage, enclosed connector. Existing medium/high remain separate future source reviews; no invented stages.',occupied_bounds=occupied))
write('civic-contract.json',dict(family='police',stage='base',sourceID='building.police.a',role='welcoming public police station',groups=groups,proposed_site_m=[40,32],integration='HELD',lod_notes='Future LOD1/LOD2 simplify individual rims, shield relief and roof equipment; approved old lowpoly sources retained.'))
write('material-manifest.json',dict(regions=specs,textures=receipts,channels={'R':'AO multiplied with BaseColor before tint','G':'roughness','B':'metallic'},UV0='World-metre dominant-axis planar projection, 2m repeat, finite coordinates',glass='opaque, no transmission or interior'))
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT');objs[0].select_set(True);bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=12;bpy.context.scene.cycles.device='CPU'
finish(objs)
p=O/'validation.json'; v=json.loads(p.read_text()) if p.exists() else {};v.update(dict(components=components,source_triangle_cap=5000,authored_triangles=tri,semantic_regions=list(materials),window_count=len(windows),window_containment_contact_depth_opening_rim_checks=True,strict_all_component_corridor_checks=True,site_bounds_pass=True,review_only=True,integration='HELD',visual_assessment='Pending human review',occupied_bounds=occupied));write('validation.json',v)

import bpy,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
# Load approved parent before the explicitly authorized affected-window rebuild.
parent=load_previous()
parent_materials={m.name: list(m.diffuse_color) for o in parent for m in o.data.materials if m}
for o in list(parent): bpy.data.objects.remove(o,do_unlink=True)
# Meshes MUST be purged before materials, to free the original semantic names.
for mesh in list(bpy.data.meshes):
    if mesh.users==0: bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
    if mat.users==0: bpy.data.materials.remove(mat)
source=Path('/previous/recipe.py').read_text()
start=source.index('# Human-scale wing windows')
end=source.index('# Side wall intake banks',start)
replacement='''# Authorized window-only correction; all other authored calls are unchanged.
window_specs=[]
def mounted_window(name,axis,center,w=1.35,h=1.25):
    # Aperture-sized glass, full-height jambs, heads/sills between jambs.
    # Rear surfaces embed into the actual wall by .005 / .010 metres.
    x,y,z=center
    if axis==1:
        pane=B(name+'_opaque_pane',(w,.08,h),(x,-5.035,z),'WindowAccent')
        parts=[]
        for side in [-1,1]:
            parts.append(B(name+('_left_jamb' if side<0 else '_right_jamb'),(.09,.13,h+.18),(x+side*(w/2+.045),-5.055,z),'Concrete'))
        for side in [-1,1]:
            parts.append(B(name+('_sill' if side<0 else '_head'),(w,.13,.09),(x,-5.055,z+side*(h/2+.045)),'Concrete'))
    else:
        pane=B(name+'_opaque_pane',(.08,w,h),(-8.035,y,z),'WindowAccent')
        parts=[]
        for side in [-1,1]:
            parts.append(B(name+('_left_jamb' if side<0 else '_right_jamb'),(.13,.09,h+.18),(-8.055,y+side*(w/2+.045),z),'Concrete'))
        for side in [-1,1]:
            parts.append(B(name+('_sill' if side<0 else '_head'),(.13,w,.09),(-8.055,y,z+side*(h/2+.045)),'Concrete'))
    window_specs.append(dict(pane=pane.name,frame_parts=[o.name for o in parts],backing='Staffed_control_service_wing',axis=axis,sign=-1,wall_normal=[0,-1,0] if axis==1 else [-1,0,0]))
mounted_window('Control_front_window',1,(-3.45,-5,1.95))
for i,y in enumerate([-2.8,-.5,1.0]):
    mounted_window('Control_side_window_'+str(i+1),0,(-8,y,2.05))
'''
source=source[:start]+replacement+source[end:]
# Family parcel planning only; retain public doorway anchors exactly.
source=source.replace('-12','-16').replace('5000','3500')
source=source.replace("'source_components':components", "'components':components,'source_components':components")
audit='''# Audit transformed actual component geometry, not planned dimensions.
byname={c['name']:c for c in components}
def volume_overlap(a,b):
    return all(min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i])>1e-6 for i in range(3))
for spec in window_specs:
    pane=byname[spec['pane']]; frames=[byname[n] for n in spec['frame_parts']]; wall=byname[spec['backing']]
    axis=spec['axis']; tang=1-axis
    outer_min=[min(f['min'][i] for f in frames) for i in range(3)]
    outer_max=[max(f['max'][i] for f in frames) for i in range(3)]
    margins={str(i):[outer_min[i]-wall['min'][i],wall['max'][i]-outer_max[i]] for i in [tang,2]}
    assert all(v>=.12-1e-6 for pair in margins.values() for v in pair),(spec,margins)
    for part in [pane]+frames:
        embed=part['max'][axis]-wall['min'][axis]
        assert .004<=embed<=.011,(part['name'],embed)
    for i,a in enumerate(frames):
        for b in frames[i+1:]: assert not volume_overlap(a,b),(a['name'],b['name'])
    # Full jambs surround the glass exactly; head/sill terminate at jamb inner edges.
    left,right,sill,head=frames
    assert abs(left['max'][tang]-pane['min'][tang])<1e-5
    assert abs(right['min'][tang]-pane['max'][tang])<1e-5
    assert abs(sill['max'][2]-pane['min'][2])<1e-5
    assert abs(head['min'][2]-pane['max'][2])<1e-5
    for f in [sill,head]:
        assert abs(f['min'][tang]-pane['min'][tang])<1e-5 and abs(f['max'][tang]-pane['max'][tang])<1e-5
    assert pane['min'][axis]>=left['min'][axis]-1e-6 and pane['max'][axis]<=left['max'][axis]+1e-6
    spec.update(pane_bounds=pane,frame_bounds=frames,wall_bounds=wall,wall_edge_margins_m=margins,wall_contact_pass=True,open_rim_pass=True,frame_fit_pass=True,corner_disjoint_pass=True)
assert len(window_specs)==4
# Audit all architectural glazing; personnel door glass is an intrinsic portal fixture.
assert set(c['name'] for c in components if c['material']=='WindowAccent' and ('window' in c['name'].lower()))==set(w['pane'] for w in window_specs)
write('window-mounts.json',{'windows':window_specs,'door_glazing':'Personnel_door_glass retained unchanged; audited separately as portal fixture'})
write('upgrade-stage.json',{'stage':'BASE','asset':'building.power.a','capacity_reference_percent':100,'actual_counts':{'generator_halls':1,'staffed_control_wings':1,'architectural_panes':4},'family_reserved_site_m':[32,32],'boundary_y_m':-16,'runtime_catalog_footprint_changed':False,'gameplay_changes':False})
'''
source=source.replace('anchors=[]\n',audit+'\nanchors=[]\n',1)
source=source.replace("'plot_inset_xy':[-11.5,11.5]", "'plot_inset_xy':[-15.5,15.5],'family_reserved_site_m':[32,32]")
# Existing source remains in its original occupied envelope; stricter old bounds still pass.
source=source.replace("'review_only':True})\nwrite('validation.json',report)","'review_only':True,'window_mounts':{'architectural_panes':4,'all_checks_pass':True},'revision_scope':'complete attached window frames only; last side centre Y=1.0; boundary planning -16m'})\nwrite('validation.json',report)")
# Derivation is executed once; exact original materials, six source maps, equipment and portals.
Path('/output').mkdir(exist_ok=True)
Path('/output/derived-recipe.py').write_text(source)
exec(compile(source,'/output/derived-recipe.py','exec'),globals())
# Extend provenance without replacing helper validation or checked export receipts.
p=Path('/output/provenance.json'); provenance=json.loads(p.read_text())
provenance.update({'parent':'/previous/asset.blend','parent_recipe_sha256':hashlib.sha256(Path('/previous/recipe.py').read_bytes()).hexdigest(),'authorized_change':'Four complete wall-mounted window rims; side final centre 1.0m; reserved family boundary -16m','unchanged':'Masses, portals, roof plant, electrical equipment, material parameters and exact six repository textures','human_review_pending':True})
p.write_text(json.dumps(provenance,indent=2))

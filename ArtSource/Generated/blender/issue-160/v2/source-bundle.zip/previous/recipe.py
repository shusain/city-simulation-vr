import bpy, sys, json, math, hashlib, shutil, inspect
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker'); sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
from CityBuildingStudyIO import checked_fbx
O=Path('/output'); O.mkdir(exist_ok=True)
# Preserve the executable authoring recipe, never write repository inputs.
try:
    p=Path(__file__)
    if p.exists() and p.resolve()!= (O/'recipe.py').resolve(): shutil.copyfile(p,O/'recipe.py')
except NameError: pass
refs=['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json','Tools/CityBuildingStudyIO.py']
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
colors={'Concrete':(.43,.45,.43,1),'BuildingFacade':(.39,.46,.44,1),'RoofService':(.095,.115,.13,1),'EquipmentMetal':(.26,.31,.32,1),'WindowAccent':(.075,.16,.21,1)}
mats={}
for name,c in colors.items():
    m=bpy.data.materials.new(name); m.diffuse_color=c; m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=c; p.inputs['Roughness'].default_value=.68 if name!='WindowAccent' else .28
    mats[name]=m
texture_manifest=[]
(O/'textures').mkdir(exist_ok=True)
for region,folder,prefix in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
    m=mats[region]; nodes=m.node_tree.nodes; links=m.node_tree.links; p=nodes.get('Principled BSDF')
    uv=nodes.new('ShaderNodeTexCoord'); mapping=nodes.new('ShaderNodeVectorMath'); mapping.operation='SCALE'; mapping.inputs[3].default_value=.5; links.new(uv.outputs['UV'],mapping.inputs[0])
    for suffix in ['BaseColor','Normal','ORM']:
        rel=f'ArtSource/Textures/{folder}/{prefix}_{suffix}.png'; dest=O/'textures'/Path(rel).name; shutil.copyfile('/repo/'+rel,dest)
        im=bpy.data.images.load(str(dest),check_existing=False); im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'; im.pack()
        t=nodes.new('ShaderNodeTexImage'); t.image=im; links.new(mapping.outputs['Vector'],t.inputs['Vector'])
        if suffix=='BaseColor': links.new(t.outputs['Color'],p.inputs['Base Color'])
        elif suffix=='Normal':
            n=nodes.new('ShaderNodeNormalMap'); n.space='TANGENT'; n.inputs['Strength'].default_value=.3; links.new(t.outputs['Color'],n.inputs['Color']); links.new(n.outputs['Normal'],p.inputs['Normal'])
        else:
            sep=nodes.new('ShaderNodeSeparateColor'); links.new(t.outputs['Color'],sep.inputs[0]); links.new(sep.outputs['Green'],p.inputs['Roughness']); links.new(sep.outputs['Blue'],p.inputs['Metallic'])
        texture_manifest.append(dict(source=rel,copy=str(dest),sha256=sha(dest),dimensions=list(im.size),channels=im.channels,colorspace=im.colorspace_settings.name,region=region))
# Restrained editable concrete grain.
n=mats['Concrete'].node_tree.nodes; l=mats['Concrete'].node_tree.links; noise=n.new('ShaderNodeTexNoise'); noise.inputs['Scale'].default_value=18; bump=n.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.12; bump.inputs['Distance'].default_value=.035; l.new(noise.outputs['Fac'],bump.inputs['Height']); l.new(bump.outputs['Normal'],n.get('Principled BSDF').inputs['Normal'])
objects=[]
def assign(o,mat):
    o.data.materials.clear(); o.data.materials.append(mats[mat]); objects.append(o); return o
def B(name,d,loc,mat='BuildingFacade'): return assign(box(name,d,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',v=16): return assign(cylinder(name,r,h,loc,colors[mat],vertices=v),mat)
def pipe(name,a,b,r=.09):
    a,b=Vector(a),Vector(b); o=C(name,r,(b-a).length,(a+b)/2,v=12); o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler(); return o
# Compact low-rise, offset staffed wing and engine hall.
B('Generator_engine_hall',(9,10,5.5),(2.5,1,2.75))
B('Staffed_control_service_wing',(6,7,4.1),(-5,-1.5,2.05))
B('Hall_charcoal_service_roof',(9.35,10.3,.22),(2.5,1,5.61),'RoofService')
B('Control_charcoal_roof',(6.3,7.3,.22),(-5,-1.5,4.21),'RoofService')
# Structural corner uprights, no site base or foundation.
for x,y,h in [(-8,-5,4.1),(-8,2,4.1),(-2,-5,4.1),(-2,-4,5.5),(7,-4,5.5),(7,6,5.5),(-2,6,5.5)]: B('Concrete_structural_column',( .22,.22,h),(x,y,h/2),'Concrete')
# Actual personnel portal and intrinsic fixtures.
portal_p=[]
def PB(n,d,loc,m='EquipmentMetal'):
    o=B(n,d,loc,m); portal_p.append(o.name); return o
PB('Personnel_door_leaf',(1.2,.10,2.2),(-5.6,-5.075,1.1))
PB('Personnel_door_glass',(.72,.045,.75),(-5.6,-5.15,1.55),'WindowAccent')
PB('Personnel_door_handle',(.10,.12,.32),(-5.15,-5.22,1.02))
for x in [-6.25,-4.95]: PB('Personnel_portal_jamb',(.10,.18,2.28),(x,-5.09,1.14),'Concrete')
PB('Personnel_portal_head',(1.4,.18,.10),(-5.6,-5.09,2.30),'Concrete')
B('Personnel_shelter_canopy',(2.2,1.15,.13),(-5.6,-5.40,2.75),'RoofService')
# Separate large service shutter on the hall front-right.
portal_v=[]
def VB(n,d,loc,m='EquipmentMetal'):
    o=B(n,d,loc,m); portal_v.append(o.name); return o
VB('Vehicle_service_shutter',(4,.12,3.5),(3,-4.10,1.75))
for i in range(12): VB('Shutter_horizontal_seam',(3.96,.045,.035),(3,-4.185,.15+i*.28),'RoofService')
for x in [.94,5.06]: VB('Vehicle_portal_side',(.13,.22,3.6),(x,-4.10,1.8),'Concrete')
VB('Vehicle_portal_header',(4.26,.22,.16),(3,-4.10,3.66),'Concrete')
B('Bay_overhead_weather_brow',(4.6,.7,.14),(3,-4.25,3.95),'RoofService')
# Human-scale wing windows, neat frames with non-crossing corners.
def window(name,x,y,z,w=1.35,h=1.25):
    B(name+'_opaque_pane',(w,.08,h),(x,y,z),'WindowAccent')
    for xx in [x-w/2-.045,x+w/2+.045]: B(name+'_jamb',(.09,.12,h+.18),(xx,y-.03,z),'Concrete')
    for zz in [z-h/2-.045,z+h/2+.045]: B(name+'_head_sill',(w,.12,.09),(x,y-.03,zz),'Concrete')
window('Control_front_window',-3.45,-5.07,1.95)
for y in [-2.8,-.5,1.2]:
    B('Control_side_window',(.08,1.35,1.25),(-8.075,y,2.05),'WindowAccent')
    for z in [1.37,2.73]: B('Control_side_window_trim',(.12,1.51,.10),(-8.10,y,z),'Concrete')
# Side wall intake banks: deep dark recess and individually readable blades.
for y in [-1.9,2.2]:
    B('Hall_large_intake_recess',(.14,2.8,2.1),(7.08,y,2.55),'RoofService')
    for j in range(10): B('Intake_louver_blade',(.22,2.65,.095),(7.19,y,1.65+j*.20),'EquipmentMetal')
# Subtle facade panel battens.
for y in [-2,0,2,4]: B('Hall_vertical_panel_joint',(.045,.045,5.1),(7.025,y,2.8),'EquipmentMetal')
# Two differentiated rooftop units: exhaust silencer and broad ventilator.
B('Exhaust_rectangular_curb',(1.65,1.9,.26),(.4,2.5,5.85),'EquipmentMetal')
C('Exhaust_silencer_body',.51,1.55,(.4,2.5,6.65),v=20)
C('Exhaust_neck',.26,.7,(.4,2.5,7.65),v=16)
C('Exhaust_weather_cap',.43,.12,(.4,2.5,8.06),'RoofService',20)
for z in [6.0,7.25]: C('Exhaust_clamp',.56,.10,(.4,2.5,z),v=20)
B('Roof_ventilator_curb',(2.6,2.7,.3),(4.4,.5,5.87),'EquipmentMetal')
B('Roof_ventilator_housing',(2.3,2.4,.95),(4.4,.5,6.45),'EquipmentMetal')
B('Roof_ventilator_hood',(2.65,2.75,.16),(4.4,.5,7.0),'RoofService')
for i in range(7): B('Roof_vent_louver',(2.16,.12,.07),(4.4,-.76,6.1+i*.115),'RoofService')
# Compact outdoor transformer and adjacent switchgear, behind entrances.
B('Transformer_main_case',(1.55,2.3,1.65),(9.05,3.65,1.22),'EquipmentMetal')
for x in [8.5,9.6]:
    for y in [2.9,4.4]: B('Transformer_equipment_leg',(.18,.18,.4),(x,y,.2),'EquipmentMetal')
for x in [8.16,9.94]:
    for j in range(9): B('Transformer_radiator_fin',(.28,.10,1.35),(x,2.72+j*.23,1.2),'EquipmentMetal')
for y in [3.0,3.65,4.3]:
    C('Transformer_bushing',.105,.55,(9.05,y,2.30),'WindowAccent',12)
    for z in [2.12,2.27,2.42]: C('Bushing_shed',.16,.045,(9.05,y,z),'WindowAccent',12)
B('Switchgear_cabinet',(1.7,1.0,2.15),(9.1,.65,1.23),'EquipmentMetal')
for x in [8.6,9.6]: B('Switchgear_leg',(.15,.65,.16),(x,.65,.08),'EquipmentMetal')
for x in [8.65,9.5]:
    B('Switchgear_door_panel',(.78,.06,1.92),(x,.11,1.27),'BuildingFacade')
    B('Switchgear_handle',(.045,.08,.25),(x+.24,.045,1.2),'RoofService')
for a,b in [((7,4.9,1),(8,4.9,1)),((8,4.9,1),(8,4.9,.4)),((8,4.9,.4),(9,4.9,.4)),((9,.8,2.4),(9,2.4,2.4)),((9,2.4,2.4),(9,2.4,1.7))]: pipe('Visible_power_conduit',a,b)
# Measured components and metric planar UV0 before joining.
components=[]
for o in objects:
    bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o
    bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
    uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UVMap')
    for f in o.data.polygons:
        axis=max(range(3),key=lambda i:abs(f.normal[i])); axes=[i for i in range(3) if i!=axis]
        for li in f.loop_indices:
            co=o.matrix_world @ o.data.vertices[o.data.loops[li].vertex_index].co; uv.data[li].uv=(co[axes[0]],co[axes[1]])
    bpy.context.view_layer.update()
    vs=[o.matrix_world@v.co for v in o.data.vertices]
    low=[min(v[i] for v in vs) for i in range(3)]; high=[max(v[i] for v in vs) for i in range(3)]
    o.data.calc_loop_triangles(); components.append(dict(name=o.name,min=low,max=high,triangles=len(o.data.loop_triangles),material=o.data.materials[0].name))
anchors=[]
for role,target,x,y,width,clear,height,names in [('pedestrian','Personnel_door_leaf',-5.6,-5.125,1.2,1.8,2.4,portal_p),('vehicle_service','Vehicle_service_shutter',3,-4.16,4,4,3.8,portal_v)]:
    portal=[c for c in components if c['name'] in names]; end=min(y-.02,min(c['min'][1] for c in portal)-.02)
    corridor={'min':[x-clear/2,-12,0],'max':[x+clear/2,end,height]}
    hits=[c['name'] for c in components if all(c['max'][i]>corridor['min'][i]+1e-6 and c['min'][i]<corridor['max'][i]-1e-6 for i in range(3))]
    assert not hits,(role,hits)
    anchors.append(dict(role=role,target=target,xyz_m=[x,y,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-12,0],outward=[0,-1,0],width_m=clear,grade_m=0),reserved_free_corridor=corridor,portal_components=portal,overlaps=hits))
assert all(c['min'][0]>=-11.5 and c['max'][0]<=11.5 and c['min'][1]>=-11.5 and c['max'][1]<=11.5 and c['min'][2]>=-1e-5 for c in components)
tri=sum(c['triangles'] for c in components); assert tri<=5000
write('entrance-anchors.json',{'anchors':anchors})
write('material-manifest.json',{'textures':texture_manifest,'semantic_regions':list(mats),'graphs':{k:[{'from_node':l.from_node.name,'from_socket':l.from_socket.name,'to_node':l.to_node.name,'to_socket':l.to_socket.name} for l in m.node_tree.links] for k,m in mats.items()},'ORM':'R AO retained in source image; G roughness -> Principled Roughness; B metallic -> Principled Metallic. AO not multiplied into base color.','UV':'dominant-axis world metre projection; shader scale 0.5','native_reconstruction':'FBX does not preserve shader graphs; deferred'})
write('provenance.json',{'asset':'building.power.a','stage':'BASE only','review_only':True,'new_geometry':True,'references':[{'path':r,'sha256':sha('/repo/'+r)} for r in refs],'lod_plan':'Future simpler meshes retain hall/wing silhouettes, two exhaust/vent identities, portals and major conduit routes. Reduce cylinder segments; remove minor louvers, handles, bushings and radiator fins; merge secondary cabinets. No LOD exports or performance/device claims.','production_inputs_modified':False})
finish(objects)
# Retain the tested helper report and add focused source measurements.
report_path=O/'validation.json'; report=json.loads(report_path.read_text()) if report_path.exists() else {}
assets=[o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.polygons)>20 and o.name not in ['Ground','StudioGround']]
# Joined plant identified by measured triangle count, not studio floor names.
plant=None
for o in assets:
    o.data.calc_loop_triangles()
    if len(o.data.loop_triangles)==tri: plant=o; break
assert plant is not None,'Joined plant missing'
bpy.ops.object.select_all(action='DESELECT'); plant.select_set(True); bpy.context.view_layer.objects.active=plant
bpy.context.scene.cursor.location=(0,0,0); bpy.ops.object.origin_set(type='ORIGIN_CURSOR'); bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
plant.name='StarterPower_BASE_ReviewOnly'
with checked_fbx(plant,O/'asset.fbx',slots=[m.name for m in plant.data.materials]) as imported:
    roundtrip={'triangles':len(imported.data.loop_triangles),'sections':len(imported.data.materials),'dimensions_m':list(imported.dimensions),'pass':True}
report.update({'source_components':components,'source_triangles':tri,'triangle_cap':5000,'semantic_slots':[m.name for m in plant.data.materials],'metric_uv0':bool(plant.data.uv_layers.active),'entrance_corridors':{'strict_aabb_test':True,'overlaps':[]},'checked_final_fbx':roundtrip,'ground_contract':{'no_site_slab_or_terrain':True,'grade_m':0,'front_boundary_y_m':-12,'plot_inset_xy':[-11.5,11.5],'origin':[0,0,0]},'review_only':True})
write('validation.json',report)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

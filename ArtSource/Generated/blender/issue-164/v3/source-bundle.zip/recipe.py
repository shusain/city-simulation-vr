import bpy, sys, os, json, math, hashlib, shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
from CityBuildingStudyIO import checked_fbx
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
# Fresh source study: there is no completed parent in the staged inputs.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for m in list(bpy.data.meshes):
    if m.users==0: bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
    if m.users==0: bpy.data.materials.remove(m)
bpy.context.scene.unit_settings.system='METRIC'
bpy.context.scene.unit_settings.scale_length=1
colors={'Concrete':(.43,.45,.43,1),'BuildingFacade':(.39,.46,.44,1),'RoofService':(.095,.115,.13,1),'EquipmentMetal':(.26,.31,.32,1),'WindowAccent':(.075,.16,.21,1)}
mats={}
for name,col in colors.items():
    m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=col
    p.inputs['Roughness'].default_value=.72 if name!='WindowAccent' else .3
    mats[name]=m
manifest={'regions':list(colors),'base_colors':colors,'metric_uv_scale':.5,'normal_strength':.3,'orm_channels':{'roughness':'G','metallic':'B'},'files':[]}
for region,folder,stem in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
    mat=mats[region]; nodes=mat.node_tree.nodes; links=mat.node_tree.links; p=nodes.get('Principled BSDF')
    textures={}
    for kind in ['BaseColor','Normal','ORM']:
        src=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+kind+'.png')
        dest=OUT/'textures'/src.name; dest.parent.mkdir(exist_ok=True); shutil.copyfile(src,dest)
        im=bpy.data.images.load(str(dest),check_existing=False)
        im.colorspace_settings.name='sRGB' if kind=='BaseColor' else 'Non-Color'
        manifest['files'].append({'region':region,'source':str(src),'copy':str(dest),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'dimensions':list(im.size),'colorspace':im.colorspace_settings.name})
        im.pack(); t=nodes.new('ShaderNodeTexImage'); t.image=im; textures[kind]=t
    links.new(textures['BaseColor'].outputs['Color'],p.inputs['Base Color'])
    sep=nodes.new('ShaderNodeSeparateColor'); links.new(textures['ORM'].outputs['Color'],sep.inputs['Color'])
    links.new(sep.outputs['Green'],p.inputs['Roughness']); links.new(sep.outputs['Blue'],p.inputs['Metallic'])
    normal=nodes.new('ShaderNodeNormalMap'); normal.inputs['Strength'].default_value=.3
    links.new(textures['Normal'].outputs['Color'],normal.inputs['Color']); links.new(normal.outputs['Normal'],p.inputs['Normal'])
objects=[]
def assign(o,mat):
    o.data.materials.clear(); o.data.materials.append(mats[mat]); objects.append(o); return o
def B(name,d,loc,mat='BuildingFacade'): return assign(box(name,d,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',v=16): return assign(cylinder(name,r,h,loc,colors[mat],vertices=v),mat)
def pipe(name,a,b,r=.09):
    a,b=Vector(a),Vector(b); o=C(name,r,(b-a).length,(a+b)/2,v=12); o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler(); return o
hall=B('Generator_engine_hall',(9,10,5.5),(2.5,1,2.75))
control=B('Staffed_control_service_wing',(6,7,7.1),(-5,-1.5,3.55))
B('Hall_charcoal_service_roof',(9.35,10.3,.22),(2.5,1,5.61),'RoofService')
B('Control_charcoal_roof',(6.3,7.3,.22),(-5,-1.5,7.21),'RoofService')
for x,y,h in [(-8,-5,7.1),(-8,2,7.1),(-2,-5,7.1),(-2,-4,5.5),(7,-4,5.5),(7,6,5.5),(-2,6,5.5)]: B('Concrete_structural_column',(.22,.22,h),(x,y,h/2),'Concrete')
portal_p=[]
def PB(n,d,loc,m='EquipmentMetal'):
    o=B(n,d,loc,m); portal_p.append(o.name); return o
PB('Personnel_door_leaf',(1.2,.10,2.2),(-5.6,-5.075,1.1))
PB('Personnel_door_glass',(.72,.045,.75),(-5.6,-5.15,1.55),'WindowAccent')
PB('Personnel_door_handle',(.10,.12,.32),(-5.15,-5.22,1.02))
for x in [-6.25,-4.95]: PB('Personnel_portal_jamb',(.10,.18,2.28),(x,-5.09,1.14),'Concrete')
PB('Personnel_portal_head',(1.4,.18,.10),(-5.6,-5.09,2.30),'Concrete')
B('Personnel_shelter_canopy',(2.2,1.15,.13),(-5.6,-5.40,2.75),'RoofService')
portal_v=[]
def VB(n,d,loc,m='EquipmentMetal'):
    o=B(n,d,loc,m); portal_v.append(o.name); return o
VB('Vehicle_service_shutter',(4,.12,3.5),(3,-4.10,1.75))
for i in range(12): VB('Shutter_horizontal_seam',(3.96,.045,.035),(3,-4.185,.15+i*.28),'RoofService')
for x in [.94,5.06]: VB('Vehicle_portal_side',(.13,.22,3.6),(x,-4.10,1.8),'Concrete')
VB('Vehicle_portal_header',(4.26,.22,.16),(3,-4.10,3.66),'Concrete')
B('Bay_overhead_weather_brow',(4.6,.7,.14),(3,-4.25,3.95),'RoofService')
windows=[]
def window(name,x,y,z,w=1.35,h=1.25,axis=1,sign=-1,backing=control):
    # All four frame bars are disjoint at corners; the jambs span full height.
    center=[x,y,z]; wallface=backing.location[axis]+sign*backing.dimensions[axis]/2
    center[axis]=wallface+sign*.07
    tang=1-axis
    dims=[0,0,h]; dims[axis]=.08; dims[tang]=w
    pane=B(name+'_opaque_pane',dims,center,'WindowAccent')
    frames=[]
    fc=list(center); fc[axis]=wallface+sign*.06
    for s in [-1,1]:
        loc=list(fc); loc[tang]+=s*(w/2+.045)
        d=[0,0,h+.18]; d[axis]=.14; d[tang]=.09
        frames.append(B(name+'_jamb',d,loc,'Concrete'))
    for s in [-1,1]:
        loc=list(fc); loc[2]+=s*(h/2+.045)
        d=[0,0,.09]; d[axis]=.14; d[tang]=w
        frames.append(B(name+'_head_sill',d,loc,'Concrete'))
    normal=[0,0,0]; normal[axis]=sign
    windows.append({'pane':pane.name,'frame_parts':[o.name for o in frames],'backing':backing.name,'axis':axis,'sign':sign,'wall_normal':normal})
window('Control_front_window',-3.45,-5.07,1.95)
for y in [-2.8,-.5,1.0]: window('Control_side_lower',-8.075,y,2.05,axis=0)
for y in [-2.8,-.5,1.0]: window('Control_side_upper',-8.075,y,5.25,axis=0)
for x in [-6.6,-3.45]: window('Control_front_upper',x,-5.07,5.25)
B('Control_storey_belt',(6.03,.10,.16),(-5,-5.045,3.8),'Concrete')
B('Control_upper_HVAC',(2.1,2.2,.85),(-5.5,-.1,7.745),'EquipmentMetal')
B('Control_HVAC_hood',(2.3,2.4,.13),(-5.5,-.1,8.235),'RoofService')
for j in range(5): B('Control_HVAC_louver',(1.8,.10,.08),(-5.5,-1.24,7.45+j*.14),'RoofService')
for y in [-1.9,2.2]:
    B('Hall_large_intake_recess',(.14,2.8,2.1),(7.08,y,2.55),'RoofService')
    for j in range(10): B('Intake_louver_blade',(.22,2.65,.095),(7.19,y,1.65+j*.20),'EquipmentMetal')
for y in [-2,0,2,4]: B('Hall_vertical_panel_joint',(.045,.045,5.1),(7.025,y,2.8),'EquipmentMetal')
def exhaust(prefix,x,y,roof):
    B(prefix+'_rectangular_curb',(1.65,1.9,.26),(x,y,roof+.24),'EquipmentMetal')
    C(prefix+'_silencer_body',.51,1.55,(x,y,roof+1.04),v=20)
    C(prefix+'_neck',.26,.7,(x,y,roof+2.04),v=16)
    C(prefix+'_weather_cap',.43,.12,(x,y,roof+2.45),'RoofService',20)
    for z in [roof+.39,roof+1.64]: C(prefix+'_clamp',.56,.10,(x,y,z),v=20)
def vent(prefix,x,y,roof):
    B(prefix+'_curb',(2.6,2.7,.3),(x,y,roof+.26),'EquipmentMetal')
    B(prefix+'_housing',(2.3,2.4,.95),(x,y,roof+.84),'EquipmentMetal')
    B(prefix+'_hood',(2.65,2.75,.16),(x,y,roof+1.39),'RoofService')
    for i in range(7): B(prefix+'_louver',(2.16,.12,.07),(x,y-1.26,roof+.49+i*.115),'RoofService')
exhaust('Exhaust',.4,2.5,5.61)
vent('Roof_ventilator',4.4,.5,5.61)
B('Transformer_main_case',(1.55,2.3,1.65),(9.05,3.65,1.22),'EquipmentMetal')
# Distinct rear-right and rear-left generating units: no duplicated primary entrances.
h2=B('Rear_right_generator_hall',(8,7,5.5),(1.5,10,2.75))
h3=B('Rear_left_generator_hall',(7,9,5.1),(-9,9,2.55))
B('Rear_right_service_roof',(8.3,7.3,.22),(1.5,10,5.61),'RoofService')
B('Rear_left_service_roof',(7.3,9.3,.22),(-9,9,5.21),'RoofService')
for prefix,cx,cy,dx,dy,ht in [('Unit2',1.5,10,8,7,5.5),('Unit3',-9,9,7,9,5.1)]:
    for sx in [-1,1]:
        for sy in [-1,1]: B(prefix+'_structural_column',(.22,.22,ht),(cx+sx*dx/2,cy+sy*dy/2,ht/2),'Concrete')
    for yy in [cy-1.7,cy+1.7]:
        x=cx+dx/2+.08
        B(prefix+'_intake_recess',(.14,2.4,2.1),(x,yy,2.5),'RoofService')
        for j in range(8): B(prefix+'_intake_blade',(.22,2.25,.10),(x+.1,yy,1.65+j*.23),'EquipmentMetal')
    exhaust(prefix+'_exhaust',cx-1.5,cy+1.4,ht+.11)
    vent(prefix+'_vent',cx+1.4,cy-.6,ht+.11)
# Expanded switchgear with useful cabinet-scale forms, not dense miniature insulators.
for i,y in enumerate([1.2,4.4,7.6,10.8]):
    x=10.3
    if i:
        B('Transformer_case_'+str(i),(1.55,2.3,1.65),(x,y,1.22),'EquipmentMetal')
    else: x=9.05
    for sx in [-1,1]:
        B('Transformer_support_foot',(.18,2.0,.4),(x+sx*.57,y,.2),'EquipmentMetal')
        for k in range(5): B('Transformer_cooling_fin',(.25,.11,1.25),(x+sx*.88,y-.8+k*.4,1.25),'EquipmentMetal')
    for yy in [y-.65,y+.65]: C('Transformer_bushing',.15,.48,(x,yy,2.28),'RoofService',12)
for i in range(5):
    y=-1.3+i*2.65
    B('Switchgear_cabinet',(1.65,2.1,2.3),(13.2,y,1.15),'EquipmentMetal')
    B('Switchgear_roof',(1.8,2.25,.13),(13.2,y,2.365),'RoofService')
    B('Switchgear_panel_seam',(.045,1.9,1.95),(12.36,y,1.14),'RoofService')
pipe('Main_process_header',(7.8,5.8,3.3),(7.8,12.7,3.3),.16)
pipe('Unit2_process_branch',(5.5,10,3.3),(7.8,10,3.3),.16)
pipe('Primary_process_branch',(7,5.8,3.3),(7.8,5.8,3.3),.16)
for y in [7,11.8]:
    for x in [7.6,8.0]: B('Header_support_leg',(.10,.15,3.3),(x,y,1.65),'EquipmentMetal')
# Measured world bounds are collected before join, including every fixture.
bpy.context.view_layer.update()
def bounds(o):
    vv=[o.matrix_world@v.co for v in o.data.vertices]
    return ([min(v[i] for v in vv) for i in range(3)],[max(v[i] for v in vv) for i in range(3)])
components=[]; byname={o.name:o for o in objects}; bb={}
for o in objects:
    lo,hi=bounds(o); bb[o.name]=(lo,hi); components.append({'name':o.name,'min':lo,'max':hi})
    assert all(math.isfinite(q) for q in lo+hi)
    assert lo[0]>=-15.5 and hi[0]<=15.5 and lo[1]>=-15.5 and hi[1]<=15.5,(o.name,lo,hi)
    assert lo[2]>=-1e-6,(o.name,lo)
def overlap(a,b): return all(min(a[1][i],b[1][i])-max(a[0][i],b[0][i])>1e-6 for i in range(3))
window_checks=[]
for w in windows:
    axis=w['axis']; tang=1-axis; sign=w['sign']; wall=bb[w['backing']]; pane=bb[w['pane']]
    face=wall[0 if sign<0 else 1][axis]
    frames=[bb[n] for n in w['frame_parts']]
    for f in frames:
        rear=f[1 if sign<0 else 0][axis]
        embed=(rear-face)*(-sign)
        assert -1e-6<=embed<=.020001,(w,embed)
        for a in [tang,2]:
            assert f[0][a]>=wall[0][a]+.12-1e-6 and f[1][a]<=wall[1][a]-.12+1e-6,(w,f,wall)
        assert f[0][axis]<=pane[0][axis]+1e-6 and f[1][axis]>=pane[1][axis]-1e-6
    for i in range(4):
        assert not overlap(pane,frames[i])
        for j in range(i): assert not overlap(frames[i],frames[j])
    window_checks.append({'pane':w['pane'],'edge_margin_pass':True,'contact_and_containment_pass':True})
anchors=[]
for role,target,x,width,height,names in [('pedestrian','Personnel_door_leaf',-5.6,1.8,2.4,portal_p),('vehicle_service','Vehicle_service_shutter',3,4,3.5,portal_v)]:
    end=min(bb[n][0][1] for n in names)-.02
    corridor=([x-width/2,-16,0],[x+width/2,end,height])
    for name,boxbound in bb.items(): assert not overlap(corridor,boxbound),('Entrance obstruction',role,name)
    anchors.append({'role':role,'target':target,'xyz_m':[x,byname[target].location.y,0],'outward':[0,-1,0],'width_m':1.2 if role=='pedestrian' else 4,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':width,'grade_m':0},'reserved_free_corridor':{'min':corridor[0],'max':corridor[1]},'portal_fixtures':names})
# Apply all authored transforms, then derive planar metric UV0 from actual vertices.
for o in objects:
    bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
    uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0'); uv.name='UV0'
    for poly in o.data.polygons:
        axis=max(range(3),key=lambda a:abs(poly.normal[a])); axes=[a for a in range(3) if a!=axis]
        for li in poly.loop_indices:
            co=o.data.vertices[o.data.loops[li].vertex_index].co
            uv.data[li].uv=(co[axes[0]]*.5,co[axes[1]]*.5)
    assert all(math.isfinite(c) for d in uv.data for c in d.uv)
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.select_all(action='DESELECT'); objects[0].select_set(True); bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
triangles=0
for o in objects:
    o.data.calc_loop_triangles(); triangles+=len(o.data.loop_triangles)
assert triangles<=9000,triangles
lo=[min(c['min'][a] for c in components) for a in range(3)]; hi=[max(c['max'][a] for c in components) for a in range(3)]
def write(name,data): (OUT/name).write_text(json.dumps(data,indent=2))
write('material-manifest.json',manifest)
write('window-mounts.json',{'windows':windows})
write('entrance-anchors.json',{'anchors':anchors})
write('upgrade-stage.json',{'asset_id':'building.power.high.a','stage':'high','capacity_percent_reference':300,'module_counts':{'generator_halls':3,'control_storeys':2,'exhaust_units':3,'hall_vent_units':3,'switchgear_cabinets':5,'transformer_cases':4,'primary_entrances':2},'occupied_envelope_m':[hi[a]-lo[a] for a in range(3)],'base_identity':{'source':'review packet baseline; fresh source, no completed parent','primary_hall':[9,10,5.5],'personnel_x':-5.6,'service_x':3,'corrected_control_side_rows_y':[-2.8,-.5,1.0]},'review_only':True,'future_lower_lod_plan':'Preserve three hall masses, two-storey control, primary portals, exhausts and major process pipes; reduce secondary rings, louver blades, frames and cabinet fixtures. No mobile-performance claim.'})
bpy.context.scene.render.engine='CYCLES'; bpy.context.scene.cycles.device='CPU'; bpy.context.scene.cycles.samples=12
bpy.context.scene.render.resolution_x=512; bpy.context.scene.render.resolution_y=512; bpy.context.scene.render.resolution_percentage=100
finish(objects)
# Preserve worker render/readback evidence, and append focused measured source checks.
vp=OUT/'validation.json'; validation=json.loads(vp.read_text()) if vp.exists() else {}
validation.update({'components':components,'window_checks':window_checks,'strict_window_edge_margin_m':.12,'entrance_corridor_all_components_pass':True,'plot_inset_m':15.5,'source_triangle_count':triangles,'triangle_ceiling':9000,'semantic_region_ceiling':5,'review_only':True,'no_parent_loaded':True})
asset=max([o for o in bpy.context.scene.objects if o.type=='MESH'],key=lambda o:len(o.data.vertices))
asset.data.calc_loop_triangles()
assert len(asset.data.loop_triangles)<=9000
assert len(asset.data.materials)==5,[m.name for m in asset.data.materials]
assert set(m.name for m in asset.data.materials)==set(colors)
with checked_fbx(asset,str(OUT/'asset.fbx'),[m.name for m in asset.data.materials],expected_triangles=len(asset.data.loop_triangles),expected_sections=5) as readback:
    validation['focused_fbx_readback']={'triangles':len(readback.data.loop_triangles),'regions':len(readback.data.materials),'dimensions_m':list(readback.dimensions),'pass':True}
write('validation.json',validation)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'asset.blend'))

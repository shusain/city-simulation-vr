import bpy, sys, json, math, shutil, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
O=Path('/output'); O.mkdir(exist_ok=True)
for ob in list(bpy.data.objects):
    if ob.type=='MESH': bpy.data.objects.remove(ob,do_unlink=True)
for m in list(bpy.data.meshes):
    if m.users==0:bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
    if m.users==0:bpy.data.materials.remove(m)
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
# Exact repository textures, packed plus portable copies.
tex={}; records=[]
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
    for suffix in ['BaseColor','Normal','ORM']:
        src=Path('/repo/ArtSource/Textures')/folder/(family+'_'+suffix+'.png')
        dst=O/'textures'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
        im=bpy.data.images.load(str(dst),check_existing=True);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack();tex[(family,suffix)]=im
        records.append(dict(file='textures/'+src.name,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),dimensions=list(im.size),colorspace=im.colorspace_settings.name))
mats={}; specs={}
for name,col,fam in [('CivicBrick',(.54,.24,.14,1),'CityBrick'),('LightStone',(.76,.70,.55,1),None),('RoofMembrane',(.105,.13,.16,1),'RoofMembrane'),('EquipmentMetal',(.35,.39,.41,1),'CityMechanical'),('WindowGlass',(.095,.20,.27,1),None),('ServiceAccent',(.46,.035,.025,1),None)]:
    m=bpy.data.materials.new(name);m.diffuse_color=col;m.use_nodes=True;nt=m.node_tree;p=nt.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.72 if name!='WindowGlass' else .28
    if fam:
        nodes={}
        for s in ['BaseColor','Normal','ORM']:
            n=nt.nodes.new('ShaderNodeTexImage');n.image=tex[(fam,s)];nodes[s]=n
        sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(nodes['ORM'].outputs['Color'],sep.inputs['Color'])
        ao=nt.nodes.new('ShaderNodeMixRGB');ao.blend_type='MULTIPLY';ao.inputs[0].default_value=1;nt.links.new(nodes['BaseColor'].outputs['Color'],ao.inputs[1]);nt.links.new(sep.outputs['Red'],ao.inputs[2])
        tint=nt.nodes.new('ShaderNodeMixRGB');tint.blend_type='MULTIPLY';tint.inputs[0].default_value=1;tint.inputs[2].default_value=col;nt.links.new(ao.outputs[0],tint.inputs[1]);nt.links.new(tint.outputs[0],p.inputs['Base Color'])
        nt.links.new(sep.outputs['Green'],p.inputs['Roughness']);nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
        norm=nt.nodes.new('ShaderNodeNormalMap');norm.inputs['Strength'].default_value=.25;nt.links.new(nodes['Normal'].outputs['Color'],norm.inputs['Color']);nt.links.new(norm.outputs['Normal'],p.inputs['Normal'])
    mats[name]=m;specs[name]=dict(base_color_tint=col,texture_family=fam,AO='ORM.R multiply BaseColor before tint',roughness='ORM.G' if fam else p.inputs['Roughness'].default_value,metallic='ORM.B' if fam else 0,normal_strength=.25 if fam else 0,transmission=0)
objects=[]; comps=[]; groups={}; windows=[]; doors=[]
def add(name,dims,loc,mat,group):
    ob=box(name,dims,loc,(1,1,1,1));ob.data.materials.clear();ob.data.materials.append(mats[mat]);objects.append(ob);groups.setdefault(group,[]).append(name)
    bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);ob.select_set(False);bpy.context.view_layer.update()
    # Bake positions for identity transforms and finite shared two metre box UVs.
    for v in ob.data.vertices:v.co+=ob.location
    ob.location=(0,0,0)
    uv=ob.data.uv_layers.active or ob.data.uv_layers.new(name='UV0');uv.name='UV0'
    for p in ob.data.polygons:
        axis=max(range(3),key=lambda i:abs(p.normal[i]));ab=[i for i in range(3) if i!=axis]
        for li in p.loop_indices:
            co=ob.data.vertices[ob.data.loops[li].vertex_index].co;uv.data[li].uv=(co[ab[0]]/2,co[ab[1]]/2)
    ob.vertex_groups.new(name=name).add(list(range(len(ob.data.vertices))),1,'REPLACE')
    mn=[loc[i]-dims[i]/2 for i in range(3)];mx=[loc[i]+dims[i]/2 for i in range(3)]
    comps.append(dict(name=name,min=mn,max=mx));return ob
walls={}
def wall(n,mn,mx,g):
    walls[n]=(mn,mx);return add(n,[mx[i]-mn[i] for i in range(3)],[(mx[i]+mn[i])/2 for i in range(3)],'CivicBrick',g)
wall('Admin',[-17,-5,0],[-7,8,6.4],'admin')
wall('ApparatusHall',[-5,-5,0],[10,8,6.4],'garage')
wall('EnclosedLink',[-7,2,0],[-5,6,3.5],'body')
wall('TrainingTower',[-16,4,0],[-12,8,10.8],'body')
# Copings and restrained brick articulation, no grade pads.
for name,x,y,w,d,z in [('Admin',-12,1.5,10,13,6.4),('Hall',2.5,1.5,15,13,6.4),('Link',-6,4,2,4,3.5),('Tower',-14,6,4,4,10.8)]:
    add(name+'Roof',(w,d,.16),(x,y,z+.08),'RoofMembrane','roof')
    for tag,dd,ll in [('Front',(w+.12,.18,.22),(x,y-d/2,z+.16)),('Back',(w+.12,.18,.22),(x,y+d/2,z+.16)),('Left',(.18,d,.22),(x-w/2,y,z+.16)),('Right',(.18,d,.22),(x+w/2,y,z+.16))]:add(name+'Coping'+tag,dd,ll,'LightStone','roof')
for x in [-17,-7,-5,2.5,10]:add('FrontPier'+str(x),(.28,.24,6.4),(x,-5.08,3.2),'LightStone','body')
# Windows with four individually connected bars and an open centre.
def window(n,back,axis,sign,u,z,w=1.25,h=1.4):
    mn,mx=walls[back];face=mx[axis] if sign>0 else mn[axis];other=1-axis; t=.095
    def part(tag,uc,zc,ww,hh,depth,offset,mat):
        dims=[0,0,hh];dims[axis]=depth;dims[other]=ww;loc=[0,0,zc];loc[axis]=face+sign*offset;loc[other]=uc
        return add(n+tag,dims,loc,mat,'windows')
    pane=part('Pane',u,z,w-2*t,h-2*t,.06,.02,'WindowGlass')
    parts=[part('JambL',u-w/2+t/2,z,t,h,.12,.05,'LightStone'),part('JambR',u+w/2-t/2,z,t,h,.12,.05,'LightStone'),part('Head',u,z+h/2-t/2,w-2*t-.002,t,.12,.05,'LightStone'),part('Sill',u,z-h/2+t/2,w-2*t-.002,t,.12,.05,'LightStone')]
    pb=next(c for c in comps if c['name']==pane.name);fb=[next(c for c in comps if c['name']==p.name) for p in parts]
    assert u-w/2>=mn[other]+.12 and u+w/2<=mx[other]-.12 and z-h/2>=mn[2]+.12 and z+h/2<=mx[2]-.12
    assert abs((face+sign*.05)-sign*.06-face+.01*sign)<1e-6
    for i,a in enumerate(fb):
        for b in fb[i+1:]:assert not all(min(a['max'][k],b['max'][k])-max(a['min'][k],b['min'][k])>1e-6 for k in range(3))
    assert w-2*t>0 and h-2*t>0
    windows.append(dict(pane=pane.name,frame_parts=[p.name for p in parts],backing=back,axis=axis,sign=sign,wall_face=face,pane_bounds=pb,frame_bounds=fb))
for x in [-15,-12,-9]:window('AdminFront'+str(x),'Admin',1,-1,x,4.85)
for y in [-2.7,.2,3.1,6]:
    for z in [1.9,4.85]:window('AdminWest%s_%s'%(y,z),'Admin',0,-1,y,z)
for x in [-10.5,-8.2]:
    for z in [1.9,4.85]:window('AdminRear%s_%s'%(x,z),'Admin',1,1,x,z,1.2)
for x in [-2.5,.5,4.5,7.5]:window('HallFront'+str(x),'ApparatusHall',1,-1,x,5.25,1.55,.85)
for x in [-3,0,3,6,8.5]:window('HallRear'+str(x),'ApparatusHall',1,1,x,3,1.45,1.8)
for y in [-2,1.5,5]:window('HallEast'+str(y),'ApparatusHall',0,1,y,3,1.6,1.8)
for z in [7.7,9.6]:
    window('TowerFront'+str(z),'TrainingTower',1,-1,-14,z,1.25,1.15)
    window('TowerWest'+str(z),'TrainingTower',0,-1,6,z,1.25,1.15)
# Closed sectional apparatus doors, jambs strictly outside clear response lanes.
bays=[]
for idx,x in enumerate([-1,6]):
    n='Bay%d'% (idx+1);add(n+'Leaf',(4.5,.16,3.6),(x,-5.02,1.8),'ServiceAccent','garage')
    for side in [-1,1]:add(n+'Jamb'+str(side),(.20,.22,3.85),(x+side*2.36,-5.09,1.925),'LightStone','garage')
    add(n+'Header',(4.92,.24,.22),(x,-5.1,3.73),'LightStone','garage')
    for z in [.6,1.2,1.8,2.4,3]:add(n+'Section'+str(z),(4.46,.035,.035),(x,-5.1175,z),'EquipmentMetal','garage')
    add(n+'Handle',(.45,.07,.07),(x,-5.16,1.05),'EquipmentMetal','garage')
    corridor=dict(min=[x-2.25,-16,0],max=[x+2.25,-5.22,3.6])
    bays.append(dict(id=n,target=n+'Leaf',xyz_m=[x,-5.22,0],outward=[0,-1,0],width_m=4.5,height_m=3.6,boundary_connector=dict(xyz_m=[x,-16,0]),reserved_free_corridor=corridor))
    doors.append(dict(target=n+'Leaf',backing='ApparatusHall',clear_width_m=4.5,clear_height_m=3.6))
for x,tag in [(-12.48,'L'),(-11.52,'R')]:add('PublicLeaf'+tag,(.96,.16,2.5),(x,-5.03,1.25),'ServiceAccent','entry')
for x in [-13.08,-10.92]:add('EntryJamb'+str(x),(.20,.25,2.7),(x,-5.1,1.35),'LightStone','entry')
add('EntryHead',(2.36,.25,.20),(-12,-5.1,2.65),'LightStone','entry')
add('EntryCanopy',(3.7,1.65,.18),(-12,-5.68,3.05),'EquipmentMetal','entry')
for x in [-12.12,-11.88]:add('EntryHandle'+str(x),(.045,.09,.48),(x,-5.15,1.2),'EquipmentMetal','entry')
doors.append(dict(target='PublicLeafL',leaves=['PublicLeafL','PublicLeafR'],backing='Admin',clear_width_m=1.92,clear_height_m=2.5))
# Compact original shield and flame relief, attached to front masonry beside entrance.
def relief(n,points,depth,y,mat):
    verts=[(x,yy,z) for yy in [y,y-depth] for x,z in points];k=len(points);faces=[tuple(range(k-1,-1,-1)),tuple(range(k,2*k))]+[(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)]
    mesh=bpy.data.meshes.new(n);mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new(n,mesh);bpy.context.collection.objects.link(ob)
    # use same component registration route, then replace cube mesh and reassign UV/group
    mn=[min(v[i] for v in verts) for i in range(3)];mx=[max(v[i] for v in verts) for i in range(3)]
    bpy.data.objects.remove(ob,do_unlink=True)
    ob=add(n,[mx[i]-mn[i] for i in range(3)],[(mx[i]+mn[i])/2 for i in range(3)],mat,'emblem');old=ob.data;ob.data=mesh;mesh.materials.append(mats[mat]);bpy.data.meshes.remove(old)
    ob.vertex_groups.clear();ob.vertex_groups.new(name=n).add(list(range(len(verts))),1,'REPLACE');uv=mesh.uv_layers.new(name='UV0')
    for l in mesh.loops:uv.data[l.index].uv=(verts[l.vertex_index][0]/2,verts[l.vertex_index][2]/2)
relief('Shield',[(-15.95,2.8),(-14.55,2.8),(-14.55,1.95),(-15.25,1.5),(-15.95,1.95)],.09,-4.995,'LightStone')
relief('Flame',[(-15.55,1.95),(-15.65,2.22),(-15.35,2.55),(-15.3,2.2),(-15.05,2.65),(-14.87,2.22),(-15.02,1.95)],.04,-5.085,'ServiceAccent')
# Mounted roof service capacity.
for i,x in enumerate([1,5]):
    add('RoofCurb'+str(i),(1.9,2.3,.22),(x,4.5,6.67),'EquipmentMetal','roof')
    add('VentUnit'+str(i),(1.7,2.1,.85),(x,4.5,7.205),'EquipmentMetal','roof')
    for z in [7,7.18,7.36]:add('VentLouvre%s_%s'%(i,z),(1.5,.04,.06),(x,3.43,z),'RoofMembrane','roof')
for z in [7.4,7.65,7.9,9.35,9.6,9.85]:add('TowerLouvre'+str(z),(1.04,.07,.055),(-14,3.86,z),'EquipmentMetal','body')
anchors=[]
for role,x,width,h,end,target in [('pedestrian',-12,1.92,2.4,-5.24,'PublicLeafL'),('service',-1,4.5,3.6,-5.22,'Bay1Leaf')]:
    anchors.append(dict(role=role,target=target,xyz_m=[x,end,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-16,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=dict(min=[x-width/2,-16,0],max=[x+width/2,end,h])))
for a in anchors+bays:
    r=a['reserved_free_corridor']
    for c in comps:assert not all(min(r['max'][k],c['max'][k])-max(r['min'][k],c['min'][k])>1e-6 for k in range(3)),(a,c)
for c in comps:assert c['min'][0]>=-19.5 and c['max'][0]<=19.5 and c['min'][1]>=-15.5 and c['max'][1]<=15.5 and c['min'][2]>=0
assert len(set(c['name'] for c in comps))==len(comps)
assert set(w['pane'] for w in windows)==set(o.name for o in objects if o.data.materials[0].name=='WindowGlass')
write('material-manifest.json',dict(materials=specs,textures=records,uv_recipe='UV0 planar dominant-face-axis projection of metre coordinates divided by 2; shared 2m repeat'))
write('window-mounts.json',dict(windows=windows,doors=doors))
write('entrance-anchors.json',dict(anchors=anchors));write('vehicle-bays.json',dict(bays=bays))
bounds=dict(min=[min(c['min'][i] for c in comps) for i in range(3)],max=[max(c['max'][i] for c in comps) for i in range(3)])
write('upgrade-plan.json',dict(family='fire',stage='medium',stage_index=1,existing_stages=['base','medium','high'],existing_upgrade_count=2,gameplay_changes=False,source_site_m=[40,32],current_native_footprint=[3,2],retained_entrance_centres=dict(pedestrian=[-12,-5],service=[-1,-5]),progression='Second matching apparatus bay and additional mounted roof service capacity; fixed crew block and training tower, no arbitrary scaling.',occupied_bounds=bounds,LOD_notes='Future LOD1 simplify frames and roof louvres; LOD2 flatten emblem and rims. Not authored or promoted.'))
write('civic-contract.json',dict(family='fire',stage='medium',sourceID='building.fire_medium.a',role='fire station',groups=groups,proposed_site_m=[40,32],integration='HELD; review only'))
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
p=O/'validation.json';v=json.loads(p.read_text());v.update(components=comps,occupied_bounds=bounds,window_count=len(windows),semantic_regions=list(mats),source_triangle_cap=7000,checks=dict(window_wall_containment=True,window_contact=True,frame_clear_opening=True,rim_disjointness=True,all_glass_registered=True,all_corridors_no_positive_intersection=True,site_bounds=True),review_only=True,integration_held=True)
# Strict helper export/readback remains authoritative; record actual final triangle budget too.
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];tri=sum(len(o.data.loop_triangles) for o in meshes);assert tri<7000,(tri,'triangle cap');v['actual_scene_triangles']=tri
write('validation.json',v)

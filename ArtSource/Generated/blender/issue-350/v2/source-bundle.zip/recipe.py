import bpy, sys, math, json
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
# Issue-owned review geometry only. Never load or alter production sources.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
palette={'BodyPaint':((.88,.91,.89,1),.34,0),'Glass':((.025,.085,.13,1),.19,0),'Rubber':((.022,.027,.032,1),.78,0),'MetalTrim':((.22,.27,.3,1),.32,.65),'MedicalRed':((.72,.018,.025,1),.36,0),'Headlight':((.92,.93,.69,1),.23,0),'Taillight':((.55,.012,.018,1),.24,0),'RedLens':((.9,.018,.028,1),.21,0),'BlueLens':((.018,.15,.85,1),.21,0)}
mats={}
for name,(color,rough,metal) in palette.items():
 m=bpy.data.materials.new(name);m.diffuse_color=color;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=color;p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 mats[name]=m
parts=[]
def ready(o,name,mat,bevel=0):
 o.name=name;o.data.materials.clear();o.data.materials.append(mats[mat]);parts.append(o)
 if bevel:
  mod=o.modifiers.new('Restrained edge bevel','BEVEL');mod.width=bevel;mod.segments=2
  bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 return o
def box(name,size,loc,mat='BodyPaint',bevel=.018):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return ready(o,name,mat,bevel)
def mesh(name,verts,faces,mat):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);return ready(o,name,mat)
def prism(name,profile,width,mat):
 n=len(profile);v=[(x,y,z) for y in (-width/2,width/2) for x,z in profile]
 return mesh(name,v,[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],mat)
def cyl(name,r,depth,loc,mat):
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=r,depth=depth,location=loc,rotation=(math.pi/2,0,0));o=bpy.context.object
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);ready(o,name,mat,.025)
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 return o
# Nose +X; patient compartment deliberately taller than cab.
box('Patient module',(3.85,2.23,1.67),(-1.19,0,2.015),bevel=.045)
box('Chassis',(5.95,1.65,.22),(-.02,0,.73),'MetalTrim')
# Actual raked cab and sloping hood rather than solid block windscreen.
prism('Cab shell',[(.69,1.02),(3.08,1.02),(3.08,1.45),(2.08,1.6),(1.51,2.43),(.69,2.43)],2.04,'BodyPaint')
# Windscreen spans sloped forward cab face.
mesh('Opaque raked windshield',[(2.043,-.89,1.68),(2.043,.89,1.68),(1.565,.89,2.365),(1.565,-.89,2.365)],[(0,1,2,3)],'Glass')
for s in (-1,1):
 y=s*1.026
 mesh('Cab side glass',[(.84,y,1.67),(1.91,y,1.67),(1.45,y,2.34),(.84,y,2.34)],[(0,1,2,3)],'Glass')
 box('Window divider',(.055,.032,.7),(1.13,y,2.0))
 box('Cab door sill',(1.18,.04,.06),(1.3,y,1.58),'MetalTrim')
 box('Door handle',(.19,.055,.055),(.94,s*1.05,1.49),'MetalTrim')
 box('Mirror stalk',(.12,.23,.045),(1.83,s*1.1,1.7),'MetalTrim')
 box('Mirror',(.18,.13,.28),(1.83,s*1.22,1.77),'MetalTrim',.025)
 box('Medical stripe',(3.86,.026,.23),(-1.19,s*1.126,1.55),'MedicalRed',.003)
 box('Cab stripe',(1.25,.026,.17),(1.36,s*1.032,1.3),'MedicalRed',.002)
 # Cross above stripe for immediate role readability.
 box('Medical cross upright',(.22,.035,.77),(-1.17,s*1.14,2.17),'MedicalRed',.008)
 box('Medical cross arms',(.77,.038,.22),(-1.17,s*1.145,2.17),'MedicalRed',.008)
 # Lower skirts stop at wheel opening; tires are never buried inside body.
 for x,L in [(-2.92,.38),(-.55,2.24)]:
  box('Module lower skirt',(L,.14,.3),(x,s*1.045,1.035))
 for x in (-2.05,2.13):
  cyl('Tire',.55,.29,(x,s*1.0,.55),'Rubber')
  cyl('Wheel hub',.31,.035,(x,s*1.158,.55),'MetalTrim')
  cyl('Hub center',.13,.045,(x,s*1.18,.55),'BodyPaint')
  # Open upper half fender, not a solid disk intersecting the wheel.
  vs=[]
  for j in range(17):
   a=j*math.pi/16
   for r in (.585,.665):vs.append((x+r*math.cos(a),s*1.15,.55+r*math.sin(a)))
  mesh('Wheel arch trim',vs,[(2*j,2*j+1,2*j+3,2*j+2) for j in range(16)],'MetalTrim')
 box('Upper side emergency lens',(.32,.065,.13),(-2.65,s*1.15,2.65),'RedLens')
box('Front bumper',(.18,2.14,.21),(3.19,0,.86),'MetalTrim',.035)
box('Grille',(.035,.91,.3),(3.096,0,1.2),'Rubber',.01)
for z in (1.1,1.2,1.3):box('Grille bar',(.045,.85,.022),(3.12,0,z),'MetalTrim',.003)
for s in (-1,1):
 box('Headlight',(.055,.38,.22),(3.11,s*.76,1.25),'Headlight',.025)
box('Lightbar mount',(.38,1.48,.065),(1.14,0,2.48),'MetalTrim')
for s,mat in [(-1,'RedLens'),(1,'BlueLens')]:box('Emergency roof lens',(.32,.59,.16),(1.14,s*.38,2.585),mat,.035)
# Clearly separate rear double doors and glazing.
for s in (-1,1):
 box('Rear door frame',(.035,.98,1.46),(-3.13,s*.525,1.96),'MetalTrim',.012)
 box('Rear door leaf',(.045,.923,1.4),(-3.155,s*.525,1.96),'BodyPaint',.012)
 box('Rear window',(.025,.63,.44),(-3.185,s*.525,2.33),'Glass',.025)
 box('Rear stripe',(.028,.93,.23),(-3.185,s*.525,1.55),'MedicalRed',.002)
 box('Rear handle',(.055,.045,.19),(-3.199,s*.16,1.87),'MetalTrim')
 box('Rear red lamp',(.055,.17,.26),(-3.19,s*1.004,1.18),'Taillight',.018)
 box('Rear reverse lamp',(.06,.17,.1),(-3.19,s*1.004,.98),'Headlight',.009)
box('Rear step',(.27,2.19,.16),(-3.18,0,.78),'MetalTrim')
# Join then rebuild exactly one slot per used shared semantic, in polygon encounter order.
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();obj=bpy.context.object;obj.name='Ambulance_Review_v1'
old=list(obj.data.materials);poly_mats=[old[p.material_index] for p in obj.data.polygons];unique=[]
for m in poly_mats:
 if m not in unique:unique.append(m)
obj.data.materials.clear()
for m in unique:obj.data.materials.append(m)
for p,m in zip(obj.data.polygons,poly_mats):p.material_index=unique.index(m)
scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False) if hasattr(bpy.ops.mesh,'normals_make_consistent') else None
bpy.ops.uv.smart_project(angle_limit=1.15192,island_margin=.015);bpy.ops.object.mode_set(mode='OBJECT')
obj['review_only']=True;obj['glass_semantics']='Opaque blue-gray glossy; no transparency required';obj['lens_semantics']='Opaque colored lenses, native remapping pending human review'
finish([obj])
# Supplemental orthographic source views using the runner studio setup.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera;cam.data.type='ORTHO';cam.data.ortho_scale=8.0
for name,loc in [('side',(0,-11,1.5)),('front',(12,0,1.5)),('rear',(-12,0,1.5))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,0,1.45))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)

import bpy,bmesh,sys,json,hashlib,itertools
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,box,finish
objects=load_previous()
out=Path('/output');out.mkdir(exist_ok=True)
source=Path('/repo/ArtSource/Blender/CityCivicSurfaces.blend')
refs={str(p.relative_to('/repo')):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/repo/ArtSource').rglob('*') if p.is_file()}
image=bpy.data.images.load('/repo/ArtSource/Generated/comfy/issue-38/v2/asset.png',check_existing=True)
assert image.size[0]>0
# Preserve all original islands except the solid window-surround and door-frame boxes.
removed=0
for obj in objects:
    if obj.type!='MESH':continue
    bm=bmesh.new();bm.from_mesh(obj.data);seen=set();discard=[]
    for v in list(bm.verts):
        if v in seen:continue
        stack=[v];island=[];seen.add(v)
        while stack:
            q=stack.pop();island.append(q)
            for e in q.link_edges:
                r=e.other_vert(q)
                if r not in seen:seen.add(r);stack.append(r)
        xyz=[obj.matrix_world @ q.co for q in island]
        size=[max(c[i] for c in xyz)-min(c[i] for c in xyz) for i in range(3)]
        targets=[(1.65,.14,1.52),(.14,1.65,1.52),(1.32,.18,2.3)]
        if any(all(abs(a-b)<.002 for a,b in zip(size,t)) for t in targets):discard+=island;removed+=1
    bmesh.ops.delete(bm,geom=discard,context='VERTS');bm.to_mesh(obj.data);bm.free()
assert removed==45,removed
mats={m.name.split('.')[0]:m for o in objects for m in o.data.materials}
frames=[]
def block(name,dims,loc,mat='LightMetal',test=False):
    o=box(name,dims,loc,tuple(mats[mat].diffuse_color));o.data.materials.clear();o.data.materials.append(mats[mat]);objects.append(o)
    if test:frames.append(o);o['frame_component']=name
    return o
def frame(x,y,z,w,h,side=False,door=False):
    t=.14 if not door else .11;depth=.20
    def part(label,u,v,a,b):
        loc=(x,y+u,z+v) if side else (x+u,y,z+v)
        dims=(depth,a,b) if side else (a,depth,b)
        return block(label,dims,loc,test=True)
    for sign in [-1,1]:part('Continuous stile',sign*(w-t)/2,0,t,h)
    for sign in [-1,1]:part('Clear span header or sill',0,sign*(h-t)/2,w-2*t,t)
for z in [1.65,4.02]:
    for x in [-8,-5.5,-3,3,5.5,8]:
        for y in [-9.075,9.075]:frame(x,y,z,1.65,1.52)
    for x in [-10.075,10.075]:
        for y in [-6,-3,0,3,6]:frame(x,y,z,1.65,1.52,True)
frame(0,-9.26,1.45,1.32,2.3,door=True)
block('Threshold', (1.1,.32,.055),(0,-9.42,.325))
block('Latch plate',(.085,.035,.24),(.36,-9.485,1.4))
block('Service access panel',(.055,1.0,1.25),(10.04,6.8,1.3),'RoofService')
for y in [-9.22,9.22]:block('Eave gutter',(20.5,.12,.15),(0,y,5.48),'RoofService')
# Actual bounds evidence before joining. Only rebuilt axis-aligned frames are tested.
bpy.context.view_layer.update()
bounds=[]
for o in frames:
    cs=[o.matrix_world@v.co for v in o.data.vertices]
    bounds.append(([min(v[i] for v in cs) for i in range(3)],[max(v[i] for v in cs) for i in range(3)]))
pairs=overlaps=joints=0;volume=0.0
for (a,b),(c,d) in itertools.combinations(bounds,2):
    pairs+=1;s=[min(b[i],d[i])-max(a[i],c[i]) for i in range(3)]
    if min(s)>1e-5:overlaps+=1;volume+=s[0]*s[1]*s[2]
    if sum(abs(v)<1e-5 for v in s)==1 and sum(v>1e-5 for v in s)==2:joints+=1
assert overlaps==0 and joints>0
# Detect duplicate exposed polygons, distinguish internal opposite butt caps.
faces={};dupes=0;internal=0
for o in frames:
    for p in o.data.polygons:
        key=tuple(sorted(tuple(round(v,5) for v in o.matrix_world@o.data.vertices[i].co) for i in p.vertices))
        normal=tuple(round(v,4) for v in p.normal)
        if key in faces:
            if sum(a*b for a,b in zip(normal,faces[key]))<-.99:internal+=1
            else:dupes+=1
        faces[key]=normal
assert dupes==0
# Reuse source civic brick nodes and original packed image maps, without inventing a bake.
with bpy.data.libraries.load(str(source),link=False) as (a,b):
    names=[n for n in a.materials if 'brick' in n.lower()]
    preferred=[n for n in names if 'college' in n.lower()]
    b.materials=(preferred or names)[:1]
map_manifest=[]
if b.materials:
    civic=b.materials[0];old=mats['OpaqueFacade'];civic.name='ReusedCivicBrick'
    for o in objects:
        for i,m in enumerate(o.data.materials):
            if m==old:o.data.materials[i]=civic
    old.name='UnusedFacade';civic.name='OpaqueFacade';mats['OpaqueFacade']=civic
    for n in civic.node_tree.nodes:
        if n.type=='TEX_IMAGE' and n.image:
            im=n.image
            try:im.pack()
            except Exception:pass
            map_manifest.append({'region':'OpaqueFacade','image':im.name,'original_path':im.filepath,'packed':bool(im.packed_file),'outputs':[l.to_socket.name for s in n.outputs for l in s.links]})
# Metric planar UVs: one UV unit per metre for reused civic maps, all components have UV0.
for o in objects:
    uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UVMap')
    for p in o.data.polygons:
        if o.data.materials[p.material_index]!=mats['OpaqueFacade'] and o.data.uv_layers.active:continue
        axes=(0,1) if abs(p.normal.z)>.5 else ((0,2) if abs(p.normal.y)>.5 else (1,2))
        for li in p.loop_indices:
            v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]],v[axes[1]])
finish(objects)
scene=bpy.context.scene;scene.cycles.samples=8;scene.cycles.device='CPU'
asset=max((o for o in scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices))
asset['presentation_yaw_offset_quarter_turns']=2;asset['native_quarter_turn_degrees']=180;asset['front_direction']='-Y';asset['review_only']=True
cam=scene.camera;matrix=cam.matrix_world.copy();typ=cam.data.type;scale=cam.data.ortho_scale
for name,pos,target,extent in [('front',(0,-40,7),(0,0,4.5),27),('window_corner',(-7,-15,5.6),(-7.2,-9.1,4.6),2.7),('door_corner',(2,-15,3.5),(.55,-9.3,2.4),2.6)]:
    cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=extent
    scene.render.filepath='/output/'+name+'.png';bpy.ops.render.render(write_still=True)
cam.matrix_world=matrix;cam.data.type=typ;cam.data.ortho_scale=scale
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=out/'validation.json';v=json.loads(p.read_text());asset.data.calc_loop_triangles()
v.update({'revision':'v3 technical recovery from v1','references_sha256':refs,'reference_image_loaded':True,'concept':'approved TOP-LEFT; original body and angled roof preserved','presentation_yaw_offset_quarter_turns':2,'source_front':'-Y','removed_solid_surrounds':removed,'frame_checks':{'scope':'all rebuilt axis-aligned window and door frame pieces including side facades; unchanged angled roof excluded','tested_pairs':pairs,'butt_joint_count':joints,'positive_overlap_pairs':overlaps,'positive_overlap_volume_m3':volume,'exposed_duplicate_faces':dupes,'internal_opposite_duplicate_caps':internal,'tolerance_m':1e-5,'bounds_before_join':bounds},'triangles_actual':len(asset.data.loop_triangles),'triangle_limit_pass':len(asset.data.loop_triangles)<=5000,'uv0':bool(asset.data.uv_layers),'native_channels_pending':True,'visual_acceptance_claimed':False})
p.write_text(json.dumps(v,indent=2))
(out/'material_manifest.json').write_text(json.dumps({'maps':map_manifest,'regions':[m.name for m in asset.data.materials],'provenance':str(source),'handoff':'Civic source material reuse in Blender; FBX does not transfer shader graphs. Native basecolor/normal/roughness mapping and runtime appearance pending; other regions retain opaque v1 constants.'},indent=2))
(out/'provenance.json').write_text(json.dumps({'previous_sha256':hashlib.sha256(Path('/previous/asset.blend').read_bytes()).hexdigest(),'references':refs,'review_only':True,'preserved':'body, roof and all non-surround original mesh islands; no repository writes'},indent=2))

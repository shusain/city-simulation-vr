import bpy, sys, math, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
out=Path('/output'); out.mkdir(exist_ok=True)
# Read-only pinned reference: consume the selected quadrant as an image, never a texture.
refs={}
for p in [ 'ArtSource/Generated/comfy/issue-38/v2/asset.png','ArtSource/Generated/comfy/issue-38/v2/approval.json','ArtSource/Generated/comfy/issue-38/v2/unreal-handoff.json','ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json','Tools/CityBuildingStudyIO.py']:
    refs[p]=hashlib.sha256((Path('/repo')/p).read_bytes()).hexdigest()
assert refs['ArtSource/Generated/comfy/issue-38/v2/asset.png']=='a475c564ebafbc3c8da8199a16133cc2df2f7fc6d9ede90f1782d78f4a650d78'
assert refs['ArtSource/Generated/comfy/issue-38/v2/approval.json']=='76e517fccc513ce1a88972721cddb0cde5f66c10788b5719694894eeef342043'
img=bpy.data.images.load('/repo/ArtSource/Generated/comfy/issue-38/v2/asset.png',check_existing=True)
w,h=img.size
# Access the top-left concept pixels; source remains unchanged and is not bound to geometry.
reference_sample=list(img.pixels[4*((3*h//4)*w+w//4):4*((3*h//4)*w+w//4)+4])
palette={'OpaqueFacade':(.43,.235,.145,1),'TechGlass':(.035,.34,.36,1),'LightMetal':(.76,.79,.73,1),'RoofService':(.095,.125,.135,1),'DoorAccent':(.035,.12,.145,1)}
mats={}
for name,c in palette.items():
    m=bpy.data.materials.new(name); m.diffuse_color=c; m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=c
    bs.inputs['Roughness'].default_value=.32 if name=='TechGlass' else .53
    bs.inputs['Metallic'].default_value=.35 if name=='LightMetal' else 0
    mats[name]=m
objects=[]
def assign(o,mat):
    o.data.materials.clear(); o.data.materials.append(mats[mat]); objects.append(o); return o
def block(name,dims,loc,mat):return assign(box(name,dims,loc,palette[mat]),mat)
def beam(name,a,b,width=.075,mat='LightMetal'):
    a,b=Vector(a),Vector(b); d=b-a
    o=block(name,(width,width,d.length),(a+b)/2,mat)
    o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o
block('Foundation',(20.5,18.5,.3),(0,0,.15),'RoofService')
block('Warm masonry research block',(20,18,5.2),(0,0,2.9),'OpaqueFacade')
# Pale horizontal civic bands and coping, deliberately broad at tabletop scale.
for z,t in [(.48,.26),(2.85,.22),(5.25,.35)]:
    block('Front pale band',(20.25,.19,t),(0,-9.03,z),'LightMetal')
    block('Rear pale band',(20.25,.19,t),(0,9.03,z),'LightMetal')
    for x in [-10.03,10.03]:block('Side pale band',(.19,18.1,t),(x,0,z),'LightMetal')
# Restrained square glazing with light frames, two storeys.
for z in [1.65,4.02]:
    for x in [-8,-5.5,-3,3,5.5,8]:
        for y in [-9.075,9.075]:
            block('Window surround',(1.65,.14,1.52),(x,y,z),'LightMetal')
            block('Opaque teal window',(1.37,.17,1.25),(x,y+(-.03 if y<0 else .03),z),'TechGlass')
    for x in [-10.075,10.075]:
        for y in [-6,-3,0,3,6]:
            block('Side window surround',(.14,1.65,1.52),(x,y,z),'LightMetal')
            block('Side teal window',(.17,1.37,1.25),(x+(-.03 if x<0 else .03),y,z),'TechGlass')
# Entry on negative Y, exact human-scale leaf, shaded reveal and small canopy.
block('Entry dark recess',(2.65,.19,2.5),(0,-9.13,1.55),'RoofService')
block('Door frame',(1.32,.18,2.3),(0,-9.26,1.45),'LightMetal')
block('Door 1.1 by 2.1 metres',(1.1,.19,2.1),(0,-9.37,1.4),'DoorAccent')
block('Door vision pane',(.72,.035,1.05),(0,-9.48,1.75),'TechGlass')
block('Door pull',(.035,.06,.4),(.36,-9.51,1.4),'LightMetal')
block('Entry canopy',(3.8,1.65,.18),(0,-9.7,2.85),'LightMetal')
for x in [-1.65,1.65]:block('Canopy slim post',(.11,.11,2.6),(x,-10.3,1.48),'LightMetal')
block('Entry landing',(3.8,1.9,.16),(0,-9.75,.23),'LightMetal')
block('Short approach path',(2.9,1.25,.09),(0,-11.1,.045),'LightMetal')
# Dominant glazed hipped roof; longitudinal ridge keeps the broad low research silhouette.
verts=[(-10.25,-9.25,5.5),(10.25,-9.25,5.5),(10.25,9.25,5.5),(-10.25,9.25,5.5),(-3,0,9.25),(3,0,9.25)]
faces=[(0,1,5,4),(1,2,5),(2,3,4,5),(3,0,4),(3,2,1,0)]
mesh=bpy.data.meshes.new('Hipped glazed research roof');mesh.from_pydata(verts,[],faces);mesh.update()
o=bpy.data.objects.new('Teal glass hipped roof',mesh);bpy.context.collection.objects.link(o);assign(o,'TechGlass')
uv=mesh.uv_layers.new(name='UVMap')
for p in mesh.polygons:
    for li in p.loop_indices:
        v=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=((v.x+11)/22,(v.y+10)/20)
for a,b in [(0,1),(1,2),(2,3),(3,0),(0,4),(1,5),(2,5),(3,4),(4,5)]:beam('Roof primary frame',verts[a],verts[b],.12)
# Grid on each roof slope: interpolate parallel rows and radial subdivisions.
for face in faces[:4]:
    if len(face)==4:
        a,b,c,d=[Vector(verts[i]) for i in face]
        for t in [.25,.5,.75]:beam('Roof horizontal mullion',a.lerp(d,t),b.lerp(c,t),.065)
        for i in range(1,10):
            t=i/10;beam('Roof vertical mullion',a.lerp(b,t),d.lerp(c,t),.065)
    else:
        a,b,c=[Vector(verts[i]) for i in face]
        for t in [.25,.5,.75]:beam('Hip horizontal mullion',a.lerp(c,t),b.lerp(c,t),.065)
        for t in [.2,.4,.6,.8]:beam('Hip radial mullion',a.lerp(b,t),c,.065)
# Ensure UV0 on every authored component before the joined checked export.
for o in objects:
    if not o.data.uv_layers:
        layer=o.data.uv_layers.new(name='UVMap')
        for p in o.data.polygons:
            n=p.normal; axes= [0,1] if abs(n.z)>.5 else ([0,2] if abs(n.y)>.5 else [1,2])
            for li in p.loop_indices:
                v=o.data.vertices[o.data.loops[li].vertex_index].co
                layer.data[li].uv=(v[axes[0]]*.1,v[axes[1]]*.1)
# Tested worker owns join, ground-centre pivot, CPU lighting/render and checked FBX.
finish(objects)
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
# Additional useful elevation while leaving the primary isometric camera intact in the blend.
cam=scene.camera
oldmat=cam.matrix_world.copy();oldtype=cam.data.type;oldscale=cam.data.ortho_scale
cam.location=(0,-39,14);cam.rotation_euler=(Vector((0,0,4.4))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=29
scene.render.filepath='/output/front.png';bpy.ops.render.render(write_still=True)
cam.matrix_world=oldmat;cam.data.type=oldtype;cam.data.ortho_scale=oldscale
scene.render.filepath='/output/preview.png'
asset=max((o for o in scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices))
asset['catalog_id']='AIInstitute';asset['front_direction']='-Y';asset['native_quarter_turn_degrees']=90;asset['integration_note']='Reconcile established quarter-turn during later import; no gameplay lot change.'
asset['review_only']=True
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=out/'validation.json';v=json.loads(p.read_text()) if p.exists() else {}
coords=[asset.matrix_world @ Vector(c) for c in asset.bound_box]
lo=[min(c[i] for c in coords) for i in range(3)];hi=[max(c[i] for c in coords) for i in range(3)]
asset.data.calc_loop_triangles()
v.update({'issue':'D90.A6','catalog_id':'AIInstitute','review_only':True,'source_sha':'e7eaa0998cb94a6cdc1c76e46e51bf82367b5a9d','reference_sha256':refs,'selected_concept':'issue-38 v2 TOP-LEFT only','reference_image_loaded':True,'reference_pixel_sample':reference_sample,'bounds_min_m':lo,'bounds_max_m':hi,'dimensions_m':[hi[i]-lo[i] for i in range(3)],'lot_contract_pass':lo[0]>=-12 and lo[1]>=-12 and hi[0]<=12 and hi[1]<=12 and hi[2]<=10,'triangles_actual':len(asset.data.loop_triangles),'semantic_slots':[m.name for m in asset.data.materials],'uv0_present':bool(asset.data.uv_layers),'entrance':{'axis':'-Y','door_m':[1.1,2.1],'native_yaw_degrees':90,'later_import_reconciliation_required':True},'material_handoff':'Opaque preview colors; reuse native semantic materials on later integration. No procedural shader export promise.','production_inputs_modified':False,'visual_acceptance_claimed':False})
p.write_text(json.dumps(v,indent=2))
(out/'provenance.json').write_text(json.dumps({'references':refs,'selection':'TOP-LEFT','approval_comment':522,'scope':'new isolated static exterior study only','outputs':['asset.blend','asset.fbx','preview.png','front.png','validation.json'],'notes':'No Unreal edits, builds, gameplay lot changes or source promotion.'},indent=2))

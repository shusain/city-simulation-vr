import bpy, math, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
objects=load_previous()
# Explicit replacement requested: preserve the read-only original, replace its scatter locally.
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
O=Path('/output'); O.mkdir(exist_ok=True)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
verts=[]
# Three gently irregular octagonal rings: stable sole, rounded shoulder, broad crown.
for radius,z in [(.57,0),(1,.014),(.69,.030)]:
    for i in range(8):
        a=i*math.tau/8
        f=1+.025*math.sin(3*a+.4)
        verts.append((.060*radius*f*math.cos(a),.045*radius*f*math.sin(a),z+(0 if z==0 else .0008*math.sin(2*a+.3))))
verts.append((-.002,.001,.035))
# Normalize exact bounds in mesh coordinates, origin at ground center.
lo=[min(v[k] for v in verts) for k in range(3)]; hi=[max(v[k] for v in verts) for k in range(3)]
verts=[tuple((v[k]-(lo[k] if k==2 else (lo[k]+hi[k])/2))*(.12,.09,.035)[k]/(hi[k]-lo[k]) for k in range(3)) for v in verts]
faces=[tuple(reversed(range(8)))]
for r in range(2):
    for i in range(8):
        j=(i+1)%8; faces.append((r*8+i,r*8+j,(r+1)*8+j,(r+1)*8+i))
for i in range(8):faces.append((16+i,16+(i+1)%8,24))
mesh=bpy.data.meshes.new('SingleWaveWornPebble'); mesh.from_pydata(verts,[],faces); mesh.update()
obj=bpy.data.objects.new('D108_SingleBeachPebble',mesh); scene.collection.objects.link(obj)
bpy.context.view_layer.objects.active=obj; obj.select_set(True)
mat=bpy.data.materials.new('Pebble'); mat.use_nodes=True; mat.diffuse_color=(.245,.23,.205,1)
p=mat.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=mat.diffuse_color; p.inputs['Roughness'].default_value=.57
mesh.materials.clear(); mesh.materials.append(mat)
# Smooth normals soften polygon boundaries while retaining the economical broad faceted silhouette.
for poly in mesh.polygons: poly.use_smooth=True
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.uv.smart_project(island_margin=.035); bpy.ops.object.mode_set(mode='OBJECT')
mesh.uv_layers.active.name='UV0'
mesh.calc_loop_triangles(); bpy.context.view_layer.update()
assert len(mesh.loop_triangles)==46
edges={}
for f in faces:
    for a,b in zip(f,f[1:]+f[:1]):
        key=tuple(sorted((a,b))); edges[key]=edges.get(key,0)+1
assert all(n==2 for n in edges.values())
with checked_fbx(obj,O/'asset.fbx',['Pebble'],expected_triangles=46,expected_sections=1,dimension_tolerance=.00001) as check:
    assert check.data.uv_layers.active is not None
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.world=bpy.data.worlds.new('NeutralReviewWorld'); scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.16,.16,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
scene.view_settings.view_transform='AgX'
def area(name,loc,power,size):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.shape='DISK'; d.size=size
    ob=bpy.data.objects.new(name,d); scene.collection.objects.link(ob); ob.location=loc; ob.rotation_euler=(Vector((0,0,.015))-ob.location).to_track_quat('-Z','Y').to_euler()
area('SoftKey',(-.25,-.3,.45),8,.35); area('SoftFill',(.3,.15,.25),3,.3)
d=bpy.data.cameras.new('ReviewCamera'); cam=bpy.data.objects.new('ReviewCamera',d); scene.collection.objects.link(cam); scene.camera=cam; d.type='ORTHO'; d.clip_start=.001

def view(loc,scale,name,target=(0,0,.0175)):
    cam.location=loc; cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler(); d.ortho_scale=scale
    scene.render.filepath=str(O/name); bpy.ops.render.render(write_still=True)
view((.19,-.27,.20),.18,'preview.png')
view((0,0,.4),.16,'top.png')
view((0,-.4,.0175),.16,'side.png')
view((0,0,.6),1,'scale_1m.png',(0,0,0))
cam.location=(.19,-.27,.20); cam.rotation_euler=(Vector((0,0,.0175))-cam.location).to_track_quat('-Z','Y').to_euler(); d.ortho_scale=.18
scene.render.filepath=str(O/'preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(O/'asset.blend'))
uv=mesh.uv_layers.active
report={'issue':'D108','review_only':True,'replacement_of':'v1 joined scatter; replacement geometry explicitly requested','stones':1,'mesh_objects':1,'dimensions_m':list(obj.dimensions),'triangles':len(mesh.loop_triangles),'closed_manifold':all(n==2 for n in edges.values()),'connected_components':1,'material_slots':[m.name for m in mesh.materials],'uv0':uv.name,'uv_finite':all(math.isfinite(c) for v in uv.data for c in v.uv),'applied_transforms':list(obj.scale)==[1,1,1] and list(obj.rotation_euler)==[0,0,0],'pivot':'ground-center','contact_vertices':sum(abs(v.co.z)<1e-8 for v in mesh.vertices),'min_z':min(v.co.z for v in mesh.vertices),'fbx_roundtrip_pass':True,'renders':{'preview.png':'three-quarter','top.png':'top','side.png':'side','scale_1m.png':'exactly 1 m orthographic field width; no shared base'},'human_review':'pending','production_changes':False}
(O/'validation.json').write_text(json.dumps(report,indent=2))
manifest={'issue':'D108','version':2,'source_revision':'322ad23f7d717783f6073245c579cc986721e9c7','source_previous':'/previous/asset.blend loaded via load_previous; replaced per request; not modified','scope':'external review only; no integration or promotion','files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.suffix in ['.blend','.fbx','.png']}}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2))
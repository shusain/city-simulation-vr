import bpy, math, random, json, sys, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
O=Path('/output'); O.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
rng=random.Random(108)
# Nine separate wave-worn, bevelled volumes: 20 triangles each, no base geometry.
layout=[(-.255,-.157,.105,.070,.095,-.25),(-.032,-.185,.086,.064,.073,.53),(.205,-.158,.121,.079,.115,-.44),(-.284,.032,.079,.105,.12,.18),(-.069,-.018,.102,.072,.14,-.38),(.153,.035,.083,.061,.089,.62),(-.185,.195,.105,.072,.091,.31),(.031,.174,.080,.069,.11,-.73),(.248,.182,.088,.075,.085,.12)]
verts=[]; faces=[]; colors=[]; ranges=[]
palette=[(.24,.255,.25,1),(.30,.272,.231,1),(.19,.215,.217,1),(.34,.32,.278,1),(.25,.238,.214,1),(.36,.355,.32,1),(.22,.24,.235,1),(.29,.275,.25,1),(.27,.29,.285,1)]
for s,(cx,cy,rx,ry,h,rot) in enumerate(layout):
    start=len(verts); jitter=[rng.uniform(.9,1.08) for _ in range(5)]
    def point(x,y,z):
        return (cx+x*math.cos(rot)-y*math.sin(rot),cy+x*math.sin(rot)+y*math.cos(rot),z)
    verts.append(point(-rx*.05,ry*.03,0))
    for ring in range(2):
        for i in range(5):
            a=2*math.pi*i/5+.17
            f=jitter[i]*(1 if ring==0 else .87)
            verts.append(point(rx*f*math.cos(a),ry*f*math.sin(a),h*(.19 if ring==0 else .74)+rng.uniform(-.025,.025)*h))
    verts.append(point(rx*.07,-ry*.06,h))
    for i in range(5):
        j=(i+1)%5
        faces.extend([(start,start+1+j,start+1+i),(start+1+i,start+1+j,start+6+j),(start+1+i,start+6+j,start+6+i),(start+6+i,start+6+j,start+11)])
    ranges.append((start,len(verts))); colors.extend([palette[s]]*12)
# Normalize measured overall footprint and ground-center origin, keeping common ground contacts.
mins=[min(v[k] for v in verts) for k in range(3)]; maxs=[max(v[k] for v in verts) for k in range(3)]
target=(.75,.55,.14)
verts=[tuple((v[k]-(0 if k==2 else (mins[k]+maxs[k])/2))*target[k]/(maxs[k]-mins[k]) for k in range(3)) for v in verts]
mesh=bpy.data.meshes.new('PebbleScatterMesh'); mesh.from_pydata(verts,[],faces); mesh.update()
obj=bpy.data.objects.new('D108_LooseBeachPebbles_Review',mesh); scene.collection.objects.link(obj)
bpy.context.view_layer.objects.active=obj; obj.select_set(True)
mat=bpy.data.materials.new('Pebble'); mat.diffuse_color=(.28,.27,.245,1); mat.use_nodes=True
p=mat.node_tree.nodes.get('Principled BSDF'); p.inputs['Roughness'].default_value=.66
vc=mat.node_tree.nodes.new('ShaderNodeVertexColor'); vc.layer_name='PebbleTint'; mat.node_tree.links.new(vc.outputs['Color'],p.inputs['Base Color'])
mesh.materials.append(mat)
a=mesh.color_attributes.new(name='PebbleTint',type='FLOAT_COLOR',domain='CORNER')
for poly in mesh.polygons:
    for li in poly.loop_indices:a.data[li].color=colors[mesh.loops[li].vertex_index]
bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.uv.smart_project(island_margin=.025); bpy.ops.object.mode_set(mode='OBJECT')
mesh.calc_loop_triangles(); bpy.context.view_layer.update()
assert len(mesh.loop_triangles)==180
contacts=[min(mesh.vertices[i].co.z for i in range(lo,hi)) for lo,hi in ranges]
assert all(abs(z)<1e-7 for z in contacts)
with checked_fbx(obj,O/'asset.fbx',['Pebble'],expected_triangles=180,expected_sections=1) as check:
    assert check.data.uv_layers.active is not None
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
scene.world.color=(.22,.22,.22)
scene.view_settings.view_transform='AgX'
def area(name,loc,power,size):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.shape='DISK'; d.size=size
    ob=bpy.data.objects.new(name,d); scene.collection.objects.link(ob); ob.location=loc; ob.rotation_euler=(Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
area('Large soft key',(-1.4,-1.5,2.5),160,2)
area('Soft fill',(1.2,.5,1.8),65,1.6)
camd=bpy.data.cameras.new('ReviewCamera'); cam=bpy.data.objects.new('ReviewCamera',camd); scene.collection.objects.link(cam); scene.camera=cam; camd.type='ORTHO'
def view(loc,scale,path):
    cam.location=loc; cam.rotation_euler=(Vector((0,0,.035))-cam.location).to_track_quat('-Z','Y').to_euler(); camd.ortho_scale=scale
    scene.render.filepath=str(O/path); bpy.ops.render.render(write_still=True)
scene.render.image_settings.file_format='PNG'
view((1,-1.4,1.3),1.02,'preview.png')
view((0,0,2),.94,'top.png')
# Orthographic one-metre field: scale is stated without adding forbidden text or extra mesh.
view((0,0,2),1.0,'scale_1m.png')
cam.location=(1,-1.4,1.3); cam.rotation_euler=(Vector((0,0,.035))-cam.location).to_track_quat('-Z','Y').to_euler(); camd.ortho_scale=1.02
scene.render.filepath=str(O/'preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(O/'asset.blend'))
uv=mesh.uv_layers.active
report={'review_only':True,'issue':'D108 loose natural beach-pebble scatter','stones':9,'mesh_objects':1,'triangles':len(mesh.loop_triangles),'dimensions_m':list(obj.dimensions),'material_slots':[m.name for m in mesh.materials],'ground_contacts_m':contacts,'pivot':'ground-center','rotation':list(obj.rotation_euler),'scale':list(obj.scale),'uv0_loops':len(uv.data),'uv_finite':all(math.isfinite(c) for d in uv.data for c in d.uv),'fbx_roundtrip_pass':True,'renders':{'preview.png':'neutral three-quarter','top.png':'top','scale_1m.png':'top orthographic field exactly 1m wide'},'production_changes':False,'visual_acceptance':'pending human review'}
(O/'validation.json').write_text(json.dumps(report,indent=2))
manifest={'issue':'D108','version':1,'seed':108,'source_revision':'322ad23f7d717783f6073245c579cc986721e9c7','reference':'#199 v2 lower-left direction as described in issue; reference image not staged','approved_reference_png_sha256':'515efb327e365a4b7cbac766503c9ddf263c06625fb2f19c6612c3d587005cbb','scope':'isolated source study only; no production promotion or Unreal integration','files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.suffix in ['.blend','.fbx','.png']}}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2))
import bpy, sys, json
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
parents=load_previous()
for o in list(parents):
 bpy.data.objects.remove(o,do_unlink=True)
for me in list(bpy.data.meshes):
 if me.users==0:bpy.data.meshes.remove(me)
for m in list(bpy.data.materials):
 if m.users==0:bpy.data.materials.remove(m)
for im in list(bpy.data.images):
 if im.users==0:bpy.data.images.remove(im)
paths=[Path('/previous/recipe.py'),Path('/repo/previous/recipe.py')]
p=next(p for p in paths if p.exists())
source=p.read_text()
source=source.replace("return assign(box(name,dims,loc,colors[mat]),mat)","\n if name in {'Control_Window_Trim','Control_Window','Control_West_Window','Turbine_East_Window','Turbine_Front_Clerestory','Boiler_Window','Monitor_Glazing'}: return None\n return assign(box(name,dims,loc,colors[mat]),mat)")
insertion=r'''
window_specs=[]
def glazed(name,backing,axis,sign,t,z,w,h):
 wall=next(o for o in objects if o.name==backing)
 bpy.context.view_layer.update()
 pp=[wall.matrix_world@v.co for v in wall.data.vertices]
 plane=(max if sign>0 else min)(p[axis] for p in pp)
 tangent=1-axis
 center=[0.,0.,z];center[axis]=plane;center[tangent]=t
 def part(label,tc,zc,ww,hh,dep,offset,mat):
  loc=center.copy();loc[tangent]=tc;loc[2]=zc;loc[axis]=plane+sign*offset
  dims=[0.,0.,hh];dims[tangent]=ww;dims[axis]=dep
  return B(name+'_'+label,tuple(dims),tuple(loc),mat)
 rim=.10
 parts=[part('LeftJamb',t-w/2+rim/2,z,rim,h,.16,.07,'EquipmentMetal'),part('RightJamb',t+w/2-rim/2,z,rim,h,.16,.07,'EquipmentMetal'),part('Head',t,z+h/2-rim/2,w-2*rim,rim,.16,.07,'EquipmentMetal'),part('Sill',t,z-h/2+rim/2,w-2*rim,rim,.16,.07,'EquipmentMetal')]
 pane=part('Pane',t,z,w-2*rim-.012,h-2*rim-.012,.035,.065,'WindowAccent')
 window_specs.append(dict(pane=pane.name,frame_parts=[o.name for o in parts],backing=backing,axis=axis,sign=sign,wall_normal=[sign if i==axis else 0 for i in range(3)]))
for i,x in enumerate([-12.6,-7.9,-6.2]):
 for j,z in enumerate([1.65,3.25]):glazed(f'ControlFront_{i}_{j}','Worker_Control_Wing',1,-1,x,z,1.46,1.04)
for i,y in enumerate([-7.6,-5.5,-3.5]):glazed(f'ControlWest_{i}','Worker_Control_Wing',0,-1,y,2.5,1.55,1.35)
for i,y in enumerate([-6.5,-2.2,2.2,6.5]):
 for j,z in enumerate([2.8,5.05]):glazed(f'TurbineEast_{i}_{j}','Turbine_Generator_Hall',0,1,y,z,2.6,1.25)
for i,x in enumerate([1,3,9,11]):glazed(f'TurbineFront_{i}','Turbine_Generator_Hall',1,-1,x,5.2,1.55,1.05)
for i,x in enumerate([-8.2,-5.2,-2.2]):
 for j,z in enumerate([5,7]):glazed(f'BoilerFront_{i}_{j}','Tall_Boiler_Block',1,-1,x,z,1.8,.9)
for i,y in enumerate([-4.5,-2.5,-.5,1.5,3.5,5.0]):
 for side in [-1,1]:glazed(f'Monitor_{i}_{side}','Turbine_Long_Roof_Monitor',0,side,y,7.25,1.55,.7)
colors['CoalFuel']=(.035,.039,.042,1)
m=bpy.data.materials.new('CoalFuel');m.diffuse_color=colors['CoalFuel'];m.use_nodes=True
m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=colors['CoalFuel']
m.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.95
materials['CoalFuel']=m
B('Coal_Bin_Back_Wall',(6,.22,1.05),(-4,-11, .525),'Concrete')
for x in [-7,-1]:B('Coal_Bin_Side_Wall',(.22,3,1.05),(x,-12.4,.525),'Concrete')
verts=[(-6.8,-13.78,.03),(-1.2,-13.78,.03),(-1.2,-11.18,.03),(-6.8,-11.18,.03),(-5.7,-12.4,1.18),(-3.9,-12.15,1.32),(-2.4,-12.4,1.12)]
faces=[(0,1,6),(0,6,4),(4,6,5),(1,2,6),(2,5,6),(2,3,5),(3,4,5),(3,0,4),(3,2,1,0)]
me=bpy.data.meshes.new('Contained_Coal_Heap');me.from_pydata(verts,[],faces);me.update()
o=bpy.data.objects.new('Contained_Coal_Heap',me);bpy.context.collection.objects.link(o);assign(o,'CoalFuel')
'''
source=source.replace('records=[]',insertion+'\nrecords=[]',1)
checks=r'''
byname={r['name']:r for r in records}
def overlap(a,b):return all(min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i])>1e-6 for i in range(3))
mounts=[]
for spec in window_specs:
 axis=spec['axis'];sgn=spec['sign'];tangent=1-axis
 wall=byname[spec['backing']];pane=byname[spec['pane']];frames=[byname[n] for n in spec['frame_parts']]
 plane=wall['max' if sgn>0 else 'min'][axis]
 margins=[];gaps=[]
 for r in [pane]+frames:
  margins.extend([r['min'][k]-wall['min'][k] for k in [tangent,2]])
  margins.extend([wall['max'][k]-r['max'][k] for k in [tangent,2]])
 assert min(margins)>=.12-1e-5,(spec,min(margins))
 for f in frames:
  rear=f['min' if sgn>0 else 'max'][axis];gaps.append(sgn*(rear-plane))
 assert all(-.021<=gap<=.02 for gap in gaps),(spec,gaps)
 assert not any(overlap(a,b) for i,a in enumerate(frames) for b in frames[i+1:]),spec
 left,right,head,sill=frames
 fit=[pane['min'][tangent]-left['max'][tangent],right['min'][tangent]-pane['max'][tangent],pane['min'][2]-sill['max'][2],head['min'][2]-pane['max'][2]]
 assert min(fit)>0,(spec,fit)
 assert all(pane['min'][axis]>=f['min'][axis]-1e-6 and pane['max'][axis]<=f['max'][axis]+1e-6 for f in frames)
 mounts.append(dict(**spec,pane_bounds=pane,frame_bounds=frames,backing_bounds=wall,minimum_edge_margin_m=min(margins),rear_wall_gaps_m=gaps,pane_opening_gaps_m=fit,positive_volume_corner_overlaps=[]))
(OUT/'window-mounts.json').write_text(json.dumps({'windows':mounts,'door_inserts':[r for r in records if r['name'].startswith('Personnel_Door')],'method':'Measured transformed component geometry before join; all architectural panes enumerated.'},indent=2))
'''
source=source.replace('anchors=[]',checks+'\nanchors=[]',1)
source=source.replace('assert tri<=5000,tri','assert tri<=6000,tri')
source=source.replace("report.update(components=records,", "report.update(window_mounts=mounts,revision='Framed glazing and contained coal bin only; original recipe masses retained',triangle_limit=6000,semantic_region_limit=6,components=records,")
Path('/output/rebuilt-v2-recipe.py').write_text(source)
Path('/output/provenance.json').write_text(json.dumps({'parent':'/previous/asset.blend','recipe_parent':str(p),'scope':'Authorized replacement of architectural glazing/frames and addition of coal store; remaining original recipe geometry retained','references':['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json'],'review_only':True,'lod_plan':'Preserve principal silhouettes, portals, stacks and fuel identity; later reduce frame members, fuel facets, cylinder segments and small equipment. No device performance claim.'},indent=2))
exec(compile(source,'/output/rebuilt-v2-recipe.py','exec'))
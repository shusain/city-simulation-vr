import bpy, sys, math, json, hashlib, shutil, os
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import box, cylinder, finish
OUT=Path('/output'); OUT.mkdir(exist_ok=True)
materials={}
colors={'Concrete':(.47,.49,.46,1),'BuildingFacade':(.34,.40,.40,1),'RoofService':(.12,.15,.17,1),'EquipmentMetal':(.32,.37,.39,1),'WindowAccent':(.11,.22,.29,1)}
for name,c in colors.items():
 m=bpy.data.materials.new(name); m.diffuse_color=c; m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=c;p.inputs['Roughness'].default_value=.72
 if name=='EquipmentMetal':p.inputs['Metallic'].default_value=.65
 materials[name]=m
texture_manifest=[]
for region,folder,stem in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
 m=materials[region];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
 uv=n.new('ShaderNodeTexCoord'); scale=n.new('ShaderNodeVectorMath');scale.operation='SCALE';scale.inputs[3].default_value=.5;l.new(uv.outputs['UV'],scale.inputs[0])
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{stem}_{suffix}.png';src=Path('/repo')/rel;dst=OUT/'textures'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
  im=bpy.data.images.load(str(dst),check_existing=True);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  t=n.new('ShaderNodeTexImage');t.image=im;l.new(scale.outputs['Vector'],t.inputs['Vector'])
  if suffix=='BaseColor':l.new(t.outputs['Color'],p.inputs['Base Color'])
  elif suffix=='Normal':
   normal=n.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.35;l.new(t.outputs['Color'],normal.inputs['Color']);l.new(normal.outputs['Normal'],p.inputs['Normal'])
  else:
   sep=n.new('ShaderNodeSeparateColor');l.new(t.outputs['Color'],sep.inputs['Color']);l.new(sep.outputs['Green'],p.inputs['Roughness']);l.new(sep.outputs['Blue'],p.inputs['Metallic'])
  texture_manifest.append({'source':rel,'copy':str(dst),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'dimensions':list(im.size),'channels':im.channels,'colorspace':im.colorspace_settings.name,'region':region,'mapping':'metric UV0 scaled 0.5','ORM':'R AO retained; G roughness connected; B metallic connected' if suffix=='ORM' else None})
m=materials['Concrete'];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=5;bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.06;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
objects=[]
def assign(o,mat):
 o.data.materials.clear();o.data.materials.append(materials[mat]);objects.append(o);return o
def B(name,dims,loc,mat='Concrete'):
 return assign(box(name,dims,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',v=16):
 return assign(cylinder(name,r,h,loc,colors[mat],vertices=v),mat)
def beam(name,a,b,width=.14,mat='EquipmentMetal'):
 a,b=Vector(a),Vector(b);o=B(name,(width,width,(b-a).length),(a+b)/2,mat);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
B('Worker_Control_Wing',(9,7,4.4),(-9,-6,2.2),'BuildingFacade')
B('Control_Roof',(9.4,7.4,.25),(-9,-6,4.52),'RoofService')
B('Turbine_Generator_Hall',(12,18,6.5),(6,0,3.25),'BuildingFacade')
B('Turbine_Roof',(12.3,18.3,.28),(6,0,6.64),'RoofService')
B('Tall_Boiler_Block',(9,9,9),(-5,6,4.5))
B('Boiler_Roof',(9.3,9.3,.3),(-5,6,9.15),'RoofService')
portal_p=[];portal_v=[]
portal_p.append(B('Personnel_Door_Leaf',(1.2,.12,2.2),(-10,-9.57,1.1),'EquipmentMetal'))
portal_p.append(B('Personnel_Door_Glass',(.84,.04,1.05),(-10,-9.65,1.48),'WindowAccent'))
portal_p.append(B('Personnel_Handle',(.08,.10,.30),(-9.56,-9.71,1.05),'EquipmentMetal'))
B('Entrance_Canopy',(2.2,1.2,.16),(-10,-9.75,2.85),'RoofService')
for x in [-10.71,-9.29]:B('Personnel_Jamb',(.16,.15,2.35),(x,-9.58,1.175),'Concrete')
B('Personnel_Lintel',(1.58,.15,.16),(-10,-9.58,2.37))
portal_v.append(B('Service_Shutter',(4,.12,3.5),(6,-9.07,1.75),'EquipmentMetal'))
for z in [.4,.8,1.2,1.6,2,2.4,2.8,3.2]:portal_v.append(B('Shutter_Seam',(3.9,.035,.035),(6,-9.15,z),'RoofService'))
for x in [3.88,8.12]:B('Service_Bay_Jamb',(.22,.22,3.65),(x,-9.08,1.825))
B('Service_Bay_Header',(4.5,.22,.24),(6,-9.08,3.76))
for x in [-12.6,-7.9,-6.2]:
 for z in [1.65,3.25]:
  B('Control_Window_Trim',(1.46,.12,1.04),(x,-9.55,z),'Concrete');B('Control_Window',(1.24,.05,.84),(x,-9.63,z),'WindowAccent')
for y in [-7.7,-5.4,-3.1]:
 B('Control_West_Window',(.08,1.35,1.15),(-13.54,y,2.5),'WindowAccent')
for y in [-7,-3,1,5,8]:
 B('Turbine_East_Pilaster',(.22,.25,6.45),(12.08,y,3.225))
 for z in [2.8,5.05]:
  B('Turbine_East_Window',(.08,2.4,1.05),(12.14,y+1,z),'WindowAccent')
for x in [1,3,9,11]:B('Turbine_Front_Clerestory',(1.35,.08,.85),(x,-9.08,5.2),'WindowAccent')
for x in [-9.3,-6.4,-3.5,-.7]:
 B('Boiler_Front_Rib',(.19,.2,8.8),(x,1.43,4.4),'BuildingFacade')
 for z in [5,7]:B('Boiler_Window',(1.6,.08,.7),(x+.8,1.36,z),'WindowAccent')
for y in [3,6,9]:B('Boiler_West_Rib',(.18,.22,8.8),(-9.56,y,4.4),'BuildingFacade')
B('Turbine_Long_Roof_Monitor',(3,12,1),(6,0,7.25),'BuildingFacade')
B('Monitor_Cap',(3.4,12.3,.16),(6,0,7.83),'RoofService')
for y in [-4.5,-2.5,-.5,1.5,3.5,5.2]:
 for x in [4.46,7.54]:B('Monitor_Glazing',(.05,1.35,.5),(x,y,7.3),'WindowAccent')
for x in [-11,-7]:
 B('Control_Rooftop_Vent',(1.15,1.3,.7),(x,-5.6,4.98),'EquipmentMetal')
 for z in [4.8,5,5.2]:B('Vent_Louver',(1.2,.08,.05),(x,-6.28,z),'RoofService')
def stack(name,x,y,height):
 N=24;verts=[];faces=[]
 rings=[(0,1.05),(3,1.05),(3.15,.87),(height-.25,.72),(height,.8),(height,.60),(height-2,.60)]
 for z,r in rings:
  verts += [(x+r*math.cos(i*2*math.pi/N),y+r*math.sin(i*2*math.pi/N),z) for i in range(N)]
 for k in range(len(rings)-1):
  for i in range(N):j=(i+1)%N;faces.append((k*N+i,k*N+j,(k+1)*N+j,(k+1)*N+i))
 faces.append(tuple(range(6*N,7*N)));faces.append(tuple(reversed(range(N))))
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);assign(o,'Concrete')
 for z in [5,9,height-1.1]:
  vs=[];fs=[]
  for zz,rr in [(z-.10,.80),(z+.10,.80),(z+.10,.72),(z-.10,.72)]:vs += [(x+rr*math.cos(i*2*math.pi/N),y+rr*math.sin(i*2*math.pi/N),zz) for i in range(N)]
  for k in range(4):
   for i in range(N):j=(i+1)%N;fs.append((k*N+i,k*N+j,((k+1)%4)*N+j,((k+1)%4)*N+i))
  mesh=bpy.data.meshes.new(name+'_band');mesh.from_pydata(vs,[],fs);ob=bpy.data.objects.new(name+'_Collar',mesh);bpy.context.collection.objects.link(ob);assign(ob,'EquipmentMetal')
stack('West_Exhaust_Stack',2,12.5,15)
stack('East_Exhaust_Stack',9,12.5,14)
for x in [2,8]:
 C('Flue_Filter_Vessel',1.25,4,(x,9.6,2.4))
 C('Filter_Top',1.35,.25,(x,9.6,4.5))
 for dx in [-.8,.8]:B('Filter_Leg',(.18,.25,.6),(x+dx,9.6,.3),'EquipmentMetal')
 beam('Flue_To_Stack',(x,9.6,3.7),(x,12.5,3.7),.85)
B('Receiving_Hopper_Throat',(1.3,1.7,.6),(-12,2.5,1.2),'EquipmentMetal')
for x in [-13.4,-10.6]:
 for y in [1.1,3.9]:B('Hopper_Support',(.20,.20,2.8),(x,y,1.4),'EquipmentMetal')
vs=[]
for z,dx,dy in [(1.4,.65,.85),(3.3,1.7,1.7)]:
 vs += [(-12+sx*dx,2.5+sy*dy,z) for sx,sy in [(-1,-1),(1,-1),(1,1),(-1,1)]]
me=bpy.data.meshes.new('Hopper_Shell');me.from_pydata(vs,[],[(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(0,3,2,1)]);o=bpy.data.objects.new('Coal_Receiving_Hopper',me);bpy.context.collection.objects.link(o);assign(o,'EquipmentMetal')
B('Dark_Coal_In_Hopper',(1.25,1.65,.12),(-12,2.5,1.55),'RoofService')
a=Vector((-11.6,3.6,2.5));b=Vector((-5,5.7,8));beam('Enclosed_Inclined_Coal_Conveyor',a,b,1.05,'RoofService')
for t in [.15,.45,.75]:
 p=a.lerp(b,t)
 for off in [-.48,.48]:beam('Conveyor_Trestle',(p.x+off,p.y,0),(p.x+off,p.y,p.z-.4),.16)
 beam('Conveyor_Crossbrace',(p.x-.48,p.y,0.2),(p.x+.48,p.y,p.z-.5),.10)
for y in [-6,-3.7]:
 B('Transformer_Tank',(1.8,1.6,1.8),(-1.9,y,1.15),'EquipmentMetal')
 for x in [-2.7,-1.1]:
  for yy in [y-.5,y,y+.5]:C('Transformer_Insulator',.10,.55,(x,yy,2.32),'WindowAccent',8)
 for yy in [y-.6,y-.3,y,y+.3,y+.6]:B('Transformer_Cooling_Fin',(.13,.10,1.25),(-2.88,yy,1.25),'EquipmentMetal')
for y in [-7,-5.5,-4]:B('Switchgear_Cabinet',(.7,1,1.9),(.0,y,.95),'EquipmentMetal')
records=[]
for o in objects:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0')
 for p in o.data.polygons:
  axis=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in p.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]],co[axes[1]])
 bpy.context.view_layer.update();points=[o.matrix_world@v.co for v in o.data.vertices];lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)]
 assert lo[0]>=-15.5 and hi[0]<=15.5 and lo[1]>=-15.5 and hi[1]<=15.5 and lo[2]>=-.001,(o.name,lo,hi)
 records.append({'name':o.name,'min':lo,'max':hi})
anchors=[]
for role,x,y,w,clear,h,portals in [('pedestrian',-10,-9.57,1.2,1.8,2.4,portal_p),('vehicle_service',6,-9.07,4,4,3.5,portal_v)]:
 names=[o.name for o in portals];pr=[r for r in records if r['name'] in names];end=min(y-.02,min(r['min'][1] for r in pr)-.02)
 corridor={'min':[x-clear/2,-16,0],'max':[x+clear/2,end,h]}
 hits=[r['name'] for r in records if all(r['max'][i]>corridor['min'][i]+1e-6 and r['min'][i]<corridor['max'][i]-1e-6 for i in range(3))]
 assert not hits,(role,hits)
 anchors.append({'role':role,'target':names[0],'xyz_m':[x,y,0],'outward':[0,-1,0],'width_m':w,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':clear,'grade_m':0},'reserved_free_corridor':corridor,'portal_components':pr,'overlap_test':{'pass':True,'hits':hits}})
(OUT/'entrance-anchors.json').write_text(json.dumps({'anchors':anchors},indent=2))
connections={name:[{'from':l.from_node.bl_idname+'.'+l.from_socket.name,'to':l.to_node.bl_idname+'.'+l.to_socket.name} for l in m.node_tree.links] for name,m in materials.items()}
(OUT/'material-manifest.json').write_text(json.dumps({'semantic_regions':list(materials),'textures':texture_manifest,'node_connections':connections,'native_reconstruction':'Deferred; FBX does not transfer shader graphs.'},indent=2))
tri=sum((o.data.calc_loop_triangles() or len(o.data.loop_triangles)) for o in objects);assert tri<=5000,tri
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0]
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
rp=OUT/'validation.json';report=json.loads(rp.read_text());report.update(components=records,entrance_anchors=anchors,ground_contract='Grade0; no paths/foundations/slab; source-only review',lod_plan='Retain principal masses/entrances/ducts; reduce circular segments and remove tiny louvers/handles/fins later; no device claim');rp.write_text(json.dumps(report,indent=2))

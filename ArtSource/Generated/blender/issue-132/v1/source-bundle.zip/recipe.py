import bpy, sys, math, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
sys.path.insert(0,'/repo/Tools')
from CityRunnerPreview import finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output'); out.mkdir(exist_ok=True)
# Verify exact approved read-only dependencies before authoring.
expected={
'123': ['a4f1eadbcef4ce61879463b710bd54910f10864179e93a4eff69efec38d0a3b4','cd720b85c44386dec305e3110d7c8d1aa702dc62aa689b4375d88e8dba508fbf','5fba12a32587cb88e0a3791f19394d718ea4cbeca113d916e603916836ae3b9f'],
'124': ['1ddcd5e5043988801680dcf070607df1f7411050c21d0d463f985b64b071f1ee','e9a5b23f9b0ce83d28d976158d7cfeeb5f262dbb283876909389dd15111f6a40','6924da5d2fb7a1cefc95c02b4dd1fd67197d12f26c10b178f161fade64b4d161']}
refs=[]
for issue, hashes in expected.items():
    for filename, digest in zip(['asset.png','approval.json','unreal-handoff.json'], hashes):
        path=Path('/repo/ArtSource/Generated/comfy')/('issue-'+issue)/'v1'/filename
        data=path.read_bytes(); actual=hashlib.sha256(data).hexdigest()
        assert actual==digest, str(path)
        record={'path':str(path),'sha256':actual}
        if filename.endswith('.png'):
            image=bpy.data.images.load(str(path),check_existing=True)
            record.update(image_loaded=bool(image.has_data),size=list(image.size),usage='concept reference only; not a texture')
            assert image.has_data
        else:
            record['json_read']=isinstance(json.loads(data), (dict,list))
        refs.append(record)
# One closed, broad-faceted organic five-arm mesh. Longest radial arm is +Y.
verts=[]
lengths=[1.0,.91,.95,.89,.93]
for j in range(10):
    a=math.pi/2+2*math.pi*j/10
    r=lengths[j//2] if j%2==0 else [.35,.38,.34,.37,.36][j//2]
    # Slight asymmetry is intentional, without surface beads.
    verts.append((r*math.cos(a),r*math.sin(a),.008 if j%2==0 else .013))
xs=[v[0] for v in verts]; ys=[v[1] for v in verts]
sx=.3/(max(xs)-min(xs)); sy=.29/(max(ys)-min(ys))
# Keep crown and contact pivot at XY origin; bounds need not be symmetrically centered.
verts=[(x*sx,y*sy,z) for x,y,z in verts]
for j in range(10):
    x,y,z=verts[j]
    verts.append((x*.39,y*.39,.034 if j%2==0 else .027))
verts.append((0,0,.045))
verts.extend([(x,y,0) for x,y,z in verts[:10]])
verts.append((0,0,0))
faces=[]
for j in range(10):
    k=(j+1)%10
    faces.extend([(20,10+j,10+k),(10+j,j,k),(10+j,k,10+k), (j,21+j,21+k),(j,21+k,k),(31,21+k,21+j)])
mesh=bpy.data.meshes.new('Starfish_FacetedClosed'); mesh.from_pydata(verts,[],faces); mesh.update()
obj=bpy.data.objects.new('SM_Scenery_Starfish_A',mesh); bpy.context.collection.objects.link(obj)
mat=bpy.data.materials.new('Starfish'); mat.diffuse_color=(.57,.32,.115,1); mat.use_nodes=True
bsdf=mat.node_tree.nodes.get('Principled BSDF'); bsdf.inputs['Base Color'].default_value=mat.diffuse_color; bsdf.inputs['Roughness'].default_value=.83
mesh.materials.append(mat)
# Independent finite, nondegenerate triangle islands; no textures required.
uv=mesh.uv_layers.new(name='UVMap')
for p in mesh.polygons:
    p.use_smooth=False
    a,b,c=[mesh.vertices[i].co for i in p.vertices]
    e=b-a; f=c-a; L=e.length; x=f.dot(e.normalized()); y=math.sqrt(max(0,f.length_squared-x*x))
    coords=[(.05,.05),(.05+L*2,.05),(.05+x*2,.05+y*2)]
    for li,co in zip(p.loop_indices,coords): uv.data[li].uv=co
obj['review_only']=True; obj['collision_policy']='none'; obj['source_LODs']=1
bpy.context.view_layer.update()
finish([obj])
# Preserve the exact semantic name and gather explicit checked FBX measurements.
obj.name='SM_Scenery_Starfish_A'
mesh=obj.data; mesh.calc_loop_triangles()
with checked_fbx(obj,'/output/asset.fbx',['Starfish'],expected_triangles=60,expected_sections=1) as imported:
    rt={'pass':True,'dimensions_m':list(imported.dimensions),'triangles':len(imported.data.loop_triangles),'materials':[m.name.split('.')[0] for m in imported.data.materials]}
scene=bpy.context.scene; scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
# Tight isolated inspection camera: world-scale geometry is never enlarged.
cam=scene.camera; cam.data.type='ORTHO'; cam.data.ortho_scale=.40
cam.location=(.32,-.46,.49); target=Vector((0,0,.016)); cam.rotation_euler=(target- cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath='/output/preview.png'; bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend'); bpy.ops.render.render(write_still=True)
loc=cam.location.copy(); rot=cam.rotation_euler.copy()
cam.location=(0,0,.65); cam.rotation_euler=(0,0,0); cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath='/output/preview_top.png'; bpy.ops.render.render(write_still=True)
cam.location=loc; cam.rotation_euler=rot; scene.render.filepath='/output/preview.png'
coords=[obj.matrix_world@v.co for v in mesh.vertices]
mins=[min(v[i] for v in coords) for i in range(3)]; maxs=[max(v[i] for v in coords) for i in range(3)]
edge_counts={}
for p in mesh.polygons:
    vv=list(p.vertices)
    for a,b in zip(vv,vv[1:]+vv[:1]):
        key=tuple(sorted((a,b))); edge_counts[key]=edge_counts.get(key,0)+1
uv_ok=all(math.isfinite(c) for item in mesh.uv_layers.active.data for c in item.uv)
uv_areas=[]
for p in mesh.polygons:
    a,b,c=[mesh.uv_layers.active.data[i].uv for i in p.loop_indices]
    uv_areas.append(abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x))/2)
validation={'asset_name':obj.name,'review_only':True,'dimensions_m':list(obj.dimensions),'target_dimensions_m':[.3,.29,.045],'bounds_m':{'min':mins,'max':maxs},'minZ':mins[2],'pivot_m':list(obj.location),'rotation_radians':list(obj.rotation_euler),'scale':list(obj.scale),'triangles':len(mesh.loop_triangles),'budget':80,'material_count':len(mesh.materials),'material':{'name':'Starfish','rgba':list(mat.diffuse_color),'roughness':.83},'closed_manifold':all(n==2 for n in edge_counts.values()),'normals':{'flat_shaded':all(not p.use_smooth for p in mesh.polygons),'nonzero_face_areas':all(p.area>1e-10 for p in mesh.polygons)},'UV0':{'finite':uv_ok,'nondegenerate':min(uv_areas)>1e-10},'fbx_roundtrip':rt,'references':refs,'collision':'none','source_LODs':1,'export_meshes':1,'preview_only_scale_reference':False,'notes':['No concept textures or bead geometry.','Close-up inspection does not establish city-distance readability.','No production changes or Unreal integration; awaiting human source review.']}
assert all(abs(a-b)<=b*.05 for a,b in zip(obj.dimensions,[.3,.29,.045]))
assert validation['closed_manifold'] and validation['UV0']['nondegenerate']
Path('/output/validation.json').write_text(json.dumps(validation,indent=2))
Path('/output/provenance.json').write_text(json.dumps({'issue':'D108 beach-starfish / #132','pinned_source':'e5425d699e1a4f80b2303c4f7eff5e31fb3bf009','references':refs,'status':'initial review only'},indent=2))
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

import bpy, sys, json, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
out=Path('/output')
# Five plain semantic regions, deliberately opaque and without procedural maps.
colors={'OpaqueFacade':(.62,.67,.66,1),'TechGlass':(.035,.28,.32,1),'LightMetal':(.77,.84,.85,1),'RoofService':(.075,.105,.12,1),'DoorAccent':(.12,.19,.21,1)}
mats={}
for name,col in colors.items():
 m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=col
 p.inputs['Roughness'].default_value=.28 if name=='TechGlass' else (.32 if name=='LightMetal' else .72)
 p.inputs['Metallic'].default_value=.55 if name=='LightMetal' else 0
 mats[name]=m
objects=[]
def B(name,dims,loc,region):
 o=box(name,dims,loc,colors[region]); o.data.materials.clear(); o.data.materials.append(mats[region]); objects.append(o); return o
# Asymmetric stepped campus, not a compute tower: left demo pavilion,
# right two-level training offices, small rear service shoulder.
B('Public forecourt',(20,19,.12),(0,-.5,.06),'OpaqueFacade')
B('Training wing',(9,12,6.5),(4.5,1,3.37),'OpaqueFacade')
B('Demo pavilion',(9,10,3.65),(-4.5,-1,1.945),'OpaqueFacade')
B('Rear service shoulder',(7,4,3.1),(-4.5,6,1.67),'RoofService')
B('Pavilion roof shadow',(9.5,10.5,.22),(-4.5,-1,3.88),'RoofService')
B('Pavilion floating fascia',(9.7,10.7,.22),(-4.5,-1,4.08),'LightMetal')
B('Office roof shadow',(9.4,12.4,.22),(4.5,1,6.73),'RoofService')
B('Office floating fascia',(9.6,12.6,.22),(4.5,1,6.94),'LightMetal')
B('Service roof',(7.3,4.3,.18),(-4.5,6,3.31),'LightMetal')
# Broad opaque teal panes and explicit pale frame grid.
B('Demo front glass',(8.45,.10,2.55),(-4.5,-6.06,1.955),'TechGlass')
B('Demo west glass',(.10,8.6,2.55),(-9.06,-1,1.955),'TechGlass')
for x in [-8.8,-6.65,-4.5,-2.35,-.2]:
 B('Demo mullion',(.12,.19,2.8),(x,-6.13,1.96),'LightMetal')
for z in [.57,3.35]:
 B('Demo horizontal frame',(9,.19,.14),(-4.5,-6.13,z),'LightMetal')
for y in [-5.3,-2.5,.3,3.3]:
 B('West mullion',(.18,.12,2.8),(-9.13,y,1.96),'LightMetal')
for z in [1.85,4.9]:
 B('Training front glazing',(8.4,.11,1.9),(4.5,-5.06,z),'TechGlass')
 B('Training east glazing',(.11,10.9,1.9),(9.06,1,z),'TechGlass')
 for x in [.4,3.1,5.9,8.6]:
  B('Training mullion',(.13,.18,2.03),(x,-5.13,z),'LightMetal')
 for y in [-4.3,-1.6,1.1,3.8,6.3]:
  B('East mullion',(.18,.13,2.03),(9.13,y,z),'LightMetal')
for z in [.85,2.86,3.9,5.91]:
 B('Front window rail',(8.6,.18,.12),(4.5,-5.13,z),'LightMetal')
 B('East window rail',(.18,11.1,.12),(9.13,1,z),'LightMetal')
# Dedicated entry is human-scale, lower and projecting from office face.
B('Entry surround',(2.15,.48,2.65),(1.45,-5.35,1.445),'LightMetal')
B('Public door 1.1 x 2.1',(1.1,.10,2.1),(1.45,-5.61,1.17),'DoorAccent')
B('Door inset',(.82,.03,1.25),(1.45,-5.68,1.47),'TechGlass')
B('Door pull',(.045,.08,.48),(1.85,-5.74,1.25),'LightMetal')
B('Entry canopy',(3.6,2.25,.18),(1.5,-6.05,2.95),'LightMetal')
B('Entry path',(3.1,5.15,.045),(1.5,-8.375,.145),'LightMetal')
# No emissive equipment/status indicators.
B('Rear service door',(1.1,.08,2.1),(-4.5,8.045,1.17),'DoorAccent')
B('Service equipment',(2.5,1.8,.9),(-5,6,3.85),'RoofService')
for x in [-5.8,-5.4,-5,-4.6,-4.2]:
 B('Equipment grille',(.09,1.5,.06),(x,6,4.33),'LightMetal')
B('Office rooftop plant',(2.6,2,.9),(5,3.5,7.48),'RoofService')
# all authored bounds < 8m high and inside the fixed 24m lot
for o in objects:
 bpy.context.view_layer.objects.active=o; o.select_set(True)
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True); o.select_set(False)
finish(objects)
# Augment tested helper artifacts with issue-specific measured contract.
asset=max((o for o in bpy.context.scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices))
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True); bpy.context.view_layer.objects.active=asset
bpy.context.scene.cursor.location=(0,0,0); bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
asset.name='EnterpriseAICenter_REVIEW_ONLY'
if not asset.data.uv_layers:
 bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.uv.smart_project(); bpy.ops.object.mode_set(mode='OBJECT')
asset.data.uv_layers.active.name='UV0'
asset['catalog_id']='EnterpriseAICenter'; asset['entrance_side']='-Y'; asset['presentation_yaw_offset_quarter_turns']=2
asset['import_note']='Reconcile established catalog quarter-turn mapping on later integration; no gameplay lot edits.'
asset.data.calc_loop_triangles()
pts=[asset.matrix_world@v.co for v in asset.data.vertices]
lo=[min(v[i] for v in pts) for i in range(3)]; hi=[max(v[i] for v in pts) for i in range(3)]
assert lo[0]>=-12 and lo[1]>=-12 and hi[0]<=12 and hi[1]<=12 and hi[2]<=8
assert len(asset.data.materials)<=5
with checked_fbx(asset,out/'asset.fbx') as imported:
 roundtrip={'passed':True,'triangles':len(imported.data.loop_triangles),'dimensions_m':list(imported.dimensions),'uv0_present':bool(imported.data.uv_layers)}
refs={}
for rel in ['Tools/CityBuildingStudyIO.py','ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json']:
 p=Path('/repo')/rel; refs[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
validation_path=out/'validation.json'
validation=json.loads(validation_path.read_text()) if validation_path.exists() else {}
validation['D90_A7']={'review_only':True,'bounds_min_m':lo,'bounds_max_m':hi,'dimensions_m':list(asset.dimensions),'pivot':list(asset.location),'scale':list(asset.scale),'rotation':list(asset.rotation_euler),'triangles':len(asset.data.loop_triangles),'triangle_target':5000,'semantic_regions':[m.name for m in asset.data.materials],'UV0':asset.data.uv_layers.active.name,'entrance':'-Y','door_m':[1.1,2.1],'presentation_yaw_offset_quarter_turns':2,'yaw_reconciliation':'pending later native import','fbx_roundtrip':roundtrip,'reference_sha256':refs,'material_handoff':'Opaque constant PBR regions only. Rebind existing native facade/roof/metal and opaque TechGlass materials at integration. No procedural shader export assumption.','approval':'not claimed','runtime_validation':'not performed'}
validation_path.write_text(json.dumps(validation,indent=2))
(out/'provenance.json').write_text(json.dumps({'issue':'D90.A7','subject':'EnterpriseAICenter','source_commit':'88e57d79778d6a33f1bd25c5616a7a4d9a31f309','design':'Original stepped business training/demo frontage from written brief; not future compute concept.','references':refs,'production_modified':False},indent=2))
scene=bpy.context.scene; scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=8
scene.render.resolution_x=512; scene.render.resolution_y=512; scene.render.resolution_percentage=100
# Preserve the helper isometric as preview.png, add an explicit front elevation.
cam=scene.camera
cam.location=(0,-38,8); target=Vector((0,0,3.3)); cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.type='ORTHO'; cam.data.ortho_scale=25
scene.render.filepath='/output/front.png'; bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

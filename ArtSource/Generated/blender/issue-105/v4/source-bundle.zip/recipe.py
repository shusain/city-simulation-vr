import bpy,sys,json,hashlib,itertools,bmesh
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,box,finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
O=Path('/output'); objects=load_previous()
# Recover disconnected authored boxes without changing the retained body surfaces.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
objects=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.select_get()]
mats={m.name.split('.')[0]:m for o in objects for m in o.data.materials}
def bounds(o):
 p=[o.matrix_world@v.co for v in o.data.vertices]
 return ([min(v[i] for v in p) for i in range(3)],[max(v[i] for v in p) for i in range(3)])
removed=0
for o in objects[:]:
 a,b=bounds(o);d=[b[i]-a[i] for i in range(3)];c=[(a[i]+b[i])/2 for i in range(3)]
 used={o.data.materials[p.material_index].name.split('.')[0] for p in o.data.polygons}
 trim=used=={'LightMetal'} and ((c[1]<-5 and c[2]<6.3 and (d[0]<.25 or d[2]<.2) and d[1]<.3) or (abs(c[0])>9 and c[2]<6.3 and (d[1]<.25 or d[2]<.2)) or (abs(c[0]-1.45)<.02 and abs(c[1]+5.35)<.02))
 if trim:objects.remove(o);bpy.data.objects.remove(o,do_unlink=True);removed+=1
frames=[]
def B(n,d,c,r='LightMetal',frame=False):
 o=box(n,d,c,tuple(mats[r].diffuse_color));o.data.materials.clear();o.data.materials.append(mats[r]);objects.append(o)
 if frame:o['frame_id']=n;frames.append(o)
 return o
# Rails are individual clear spans; all posts are continuous to the outside corners.
def facade(tag,axis,fixed,posts,z0,z1,t=.14):
 for k,u in enumerate(posts):
  c=[u,fixed,(z0+z1)/2] if axis==0 else [fixed,u,(z0+z1)/2]
  d=[t,.20,z1-z0] if axis==0 else [.20,t,z1-z0]
  B(tag+' post '+str(k),d,c,frame=True)
 for k,(u,v) in enumerate(zip(posts,posts[1:])):
  for z in [z0+.07,z1-.07]:
   c=[(u+v)/2,fixed,z] if axis==0 else [fixed,(u+v)/2,z]
   d=[v-u-t,.20,.14] if axis==0 else [.20,v-u-t,.14]
   B(tag+' rail '+str(k)+' '+str(z),d,c,frame=True)
facade('Demo',0,-6.13,[-9.13,-6.65,-4.5,-2.35,-.2],.50,3.42,.20)
# Shared square corner belongs to front; return has no doubled post there.
def ret(tag,x,y0,ys,z0,z1):
 for y in ys:B(tag+' post '+str(y),(.20,.20,z1-z0),(x,y,(z0+z1)/2),frame=True)
 for u,v in zip([y0]+ys,ys):
  for z in [z0+.07,z1-.07]:B(tag+' rail '+str(u)+' '+str(z),(.20,v-u-.20,.14),(x,(u+v)/2,z),frame=True)
ret('West',-9.13,-6.13,[-2.5,.3,3.3],.50,3.42)
facade('Office lower',0,-5.13,[2.65,5.9,9.13],.78,2.93,.20)
facade('Office upper',0,-5.13,[.4,3.1,5.9,9.13],3.83,5.98,.20)
for z0,z1 in [(.78,2.93),(3.83,5.98)]:ret('East '+str(z0),9.13,-5.13,[-1.6,1.1,3.8,6.3],z0,z1)
# Door opening clear dimensions 1.1 x 2.1 m; jambs alone reach outer corners.
facade('Door',0,-5.72,[.83,2.07],.12,2.36,.14)
B('Threshold',(1.1,.46,.055),(1.45,-5.77,.1475),'DoorAccent')
for x in [.3,2.7]:B('Canopy bracket',(.08,.7,.10),(x,-5.62,2.77))
B('Service access panel',(1.1,.06,.72),(-6.4,8.05,1.25),'DoorAccent')
for z in [1.03,1.17,1.31,1.45]:B('Service louver',(.86,.055,.035),(-6.4,8.1,z))
B('Rear gutter',(7.1,.12,.12),(-4.5,8.16,3.24),'RoofService')
B('Downpipe',(.10,.10,2.95),(-7.9,8.16,1.67),'RoofService')
for x in [3.2,5.8,8.4]:B('Facade panel reveal',(.035,.025,.62),(x,-5.015,3.36),'RoofService')
# Actual generated axis-aligned vertex bounds, pair intersections and cap classification.
tol=1e-5; rows=[]
for o in frames:
 a,b=bounds(o);rows.append({'name':o.name,'min':a,'max':b})
off=[];joints=[];tested=0
for a,b in itertools.combinations(rows,2):
 tested+=1;ds=[min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i]) for i in range(3)]
 if min(ds)>tol:off.append([a['name'],b['name'],ds[0]*ds[1]*ds[2]])
 elif all(d>=-tol for d in ds) and sum(d>tol for d in ds)==2:joints.append([a['name'],b['name']])
# Exposed duplicate faces: matching vertex set with same-facing normals.
faces={};exposed=[];internal=[]
for o in frames:
 for p in o.data.polygons:
  vs=[o.matrix_world@o.data.vertices[i].co for i in p.vertices]
  key=tuple(sorted(tuple(round(c,5) for c in v) for v in vs))
  normal=o.matrix_world.to_3x3()@p.normal
  for name,n in faces.get(key,[]):
   (exposed if n.dot(normal)>.99 else internal).append([name,o.name])
  faces.setdefault(key,[]).append((o.name,normal))
report={'tolerance_m':tol,'tested_pairs':tested,'butt_joint_count':len(joints),'joints':joints,'offending_pairs':off,'exposed_duplicate_faces':exposed,'internal_opposite_full_caps':internal,'pieces':rows,'scope':'Replaced axis-aligned window/door/return trim only. Retained roof/fascia and canopy geometry excluded; no angled-solid proof claimed.'}
(O/'frame_checks.json').write_text(json.dumps(report,indent=2))
assert tested>0 and joints and not off and not exposed,report
# Use original civic materials including their original image nodes; no new texture synthesis.
src=Path('/repo/ArtSource/Blender/CityCivicSurfaces.blend')
with bpy.data.libraries.load(str(src),link=False) as (a,b):
 names=a.materials[:]; brick=next((n for n in names if 'CivicBrick' in n and ('School' in n or 'College' in n)),None)
 brick=brick or next(n for n in names if 'CivicBrick' in n)
 roof=next(n for n in names if 'CivicAsphalt' in n);b.materials=[brick,roof]
manifest={}; replacements={}
for region,m in zip(['OpaqueFacade','RoofService'],b.materials):
 original=m.name;new=m.copy();new.name=region+'_CivicReuse';replacements[region]=new;maps=[]
 if new.use_nodes:
  for node in new.node_tree.nodes:
   if node.type=='TEX_IMAGE' and node.image:
    im=node.image
    try:im.pack()
    except RuntimeError:pass
    raw=bytes(im.packed_file.data) if im.packed_file else b''
    maps.append({'image':im.name,'path':im.filepath,'packed':bool(im.packed_file),'sha256':hashlib.sha256(raw).hexdigest() if raw else None,'outputs_to':[l.to_socket.name for s in node.outputs for l in s.links]})
 manifest[region]={'source_material':original,'original_maps':maps,'reuse':'Original civic material nodes/images, packed where available; no baked maps','native_binding':('MI_CivicAsphaltRoof' if region=='RoofService' else 'Approved civic brick binding matching source material'),'native_channels':'Native roughness/normal/ORM binding pending verification; Blender shader graph is not an FBX handoff'}
for o in objects:
 for i,m in enumerate(o.data.materials):
  key=m.name.split('.')[0]
  if key in replacements:o.data.materials[i]=replacements[key]
# Metric planar UV0: one UV repeat per metre, independent of object bounds.
for o in objects:
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0');uv.name='UV0'
 for p in o.data.polygons:
  axis=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in p.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]],v[axes[1]])
for r in ['TechGlass','LightMetal','DoorAccent']:
 p=mats[r].node_tree.nodes.get('Principled BSDF');manifest[r]={'source_material':mats[r].name,'maps':[],'basecolor':list(p.inputs['Base Color'].default_value),'roughness':p.inputs['Roughness'].default_value,'metallic':p.inputs['Metallic'].default_value,'native_binding':'Reusable opaque PBR semantic; native assignment pending'}
(O/'materials.json').write_text(json.dumps({'regions':manifest,'uv_density':'1 repeat/metre planar UV0','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'previous_sha256':hashlib.sha256(Path('/previous/asset.blend').read_bytes()).hexdigest()},indent=2))
finish(objects)
asset=max((o for o in bpy.context.scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices))
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
asset['entrance']='-Y';asset['presentation_yaw_offset_quarter_turns']=2;asset['review_only']=True
asset.data.calc_loop_triangles();a,b=bounds(asset)
assert min(a[:2])>=-12 and max(b[:2])<=12 and b[2]<=8.00001 and len(asset.data.loop_triangles)<=5000 and len(asset.data.materials)<=5
with checked_fbx(asset,O/'asset.fbx') as imp:rt={'passed':True,'triangles':len(imp.data.loop_triangles),'UV0':bool(imp.data.uv_layers)}
vpath=O/'validation.json';v=json.loads(vpath.read_text());v['revision']={'base':'v2 preserved read-only','removed_trim_components':removed,'bounds':[a,b],'triangles':len(asset.data.loop_triangles),'regions':[m.name for m in asset.data.materials],'pivot':list(asset.location),'scale':list(asset.scale),'rotation':list(asset.rotation_euler),'entrance':'-Y','yaw_quarter_turns':2,'native_yaw_reconciliation':'pending','fbx':rt,'frames':report,'native_validation':'Not performed; review only'};vpath.write_text(json.dumps(v,indent=2))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
for name,pos,target,scale in [('front',(0,-38,7),(0,0,3.5),24),('window_corner',(-11,-12,6),(-9.0,-6.1,3.25),3.2),('door_corner',(4,-11,4.4),(2.0,-5.72,2.25),2.3),('return_corner',(13,-10,8),(9.1,-5.1,5.8),3.4)]:
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;scene.render.filepath=str(O/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

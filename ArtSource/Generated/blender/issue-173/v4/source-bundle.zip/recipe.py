import bpy,sys,json,hashlib,shutil,math
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
objects=load_previous()
objects=[o for o in objects if o.type=='MESH' and o.name!='ReviewGround']
assert len(objects)==1,[(o.name,o.type) for o in objects]
asset=objects[0]
out=Path('/output');out.mkdir(exist_ok=True)
def write(n,d): (out/n).write_text(json.dumps(d,indent=2))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Preserve all existing source receipts, without executing the nested historical recipe.
for p in Path('/previous').glob('*.json'):shutil.copy2(p,out/p.name)
for t in bpy.data.texts:
 if t.name.endswith('.json') and not (out/t.name).exists():
  try:json.loads(t.as_string());(out/t.name).write_text(t.as_string())
  except Exception:pass
bpy.context.view_layer.update()
assert all(abs(x)<1e-6 for x in asset.rotation_euler)
assert all(abs(x-1)<1e-6 for x in asset.scale)
assert asset.location.length<1e-6
mesh=asset.data
mesh.calc_loop_triangles()
assert len(mesh.loop_triangles)==3552
assert {m.name for m in mesh.materials}=={'AcademicBrick','LightStone','RoofMembrane','EquipmentMetal','WindowGlass'}
def snapshot(o):
 m=o.data
 return {'vertices':[list(v.co) for v in m.vertices],'faces':[list(p.vertices) for p in m.polygons],'materials':[p.material_index for p in m.polygons],'uv':{u.name:[list(x.uv) for x in u.data] for u in m.uv_layers},'groups':[(g.name,[(v.index,round(a.weight,8)) for v in m.vertices for a in v.groups if a.group==g.index]) for g in o.vertex_groups]}
def h(d):return hashlib.sha256(json.dumps(d,separators=(',',':')).encode()).hexdigest()
before=h(snapshot(asset))
# Independently derive connected solids and match each to its preserved named vertex group.
parent=list(range(len(mesh.vertices)))
def root(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
def union(a,b):
 a,b=root(a),root(b)
 if a!=b:parent[b]=a
for e in mesh.edges:union(*e.vertices)
parts={}
for v in mesh.vertices:parts.setdefault(root(v.index),[]).append(v.index)
assert len(parts)==296,len(parts)
components=[]
for ids in parts.values():
 common=None
 for i in ids:
  g={a.group for a in mesh.vertices[i].groups if a.weight>.99}
  common=g if common is None else common & g
 assert common,ids[:3]
 names=[asset.vertex_groups[i].name for i in common]
 name=sorted(names)[0]
 pts=[asset.matrix_world@mesh.vertices[i].co for i in ids]
 components.append({'name':name,'min':[min(v[k] for v in pts) for k in range(3)],'max':[max(v[k] for v in pts) for k in range(3)]})
assert len({c['name'] for c in components})==296
bounds={c['name']:c for c in components}
# Exact repository texture copies; keep existing image nodes and texture-coordinate recipes.
tex=out/'textures';tex.mkdir(exist_ok=True)
receipts=[]
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for suffix in ['BaseColor','Normal','ORM']:
  name=family+'_'+suffix+'.png';src=Path('/repo/ArtSource/Textures')/folder/name;dst=tex/name
  shutil.copy2(src,dst)
  images=[im for im in bpy.data.images if Path(im.filepath).name==name or im.name==name or im.name.startswith(name+'.')]
  assert images,('Missing original image',name)
  for im in images:
   im.filepath=str(dst);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  receipts.append({'source':str(src),'copy':str(dst),'source_sha256':digest(src),'copy_sha256':digest(dst),'dimensions':list(images[0].size),'colorspace':images[0].colorspace_settings.name})
assert len(receipts)==9
changes=[]
for name,tint in [('AcademicBrick',(.65,.28,.15,1)),('RoofMembrane',(.22,.27,.31,1))]:
 mat=bpy.data.materials[name];mat.use_nodes=True;nt=mat.node_tree
 bs=next(n for n in nt.nodes if n.type=='BSDF_PRINCIPLED')
 socket=bs.inputs['Base Color'];assert socket.is_linked
 old=socket.links[0].from_socket
 node=nt.nodes.new('ShaderNodeMixRGB');node.name=name+'_WarmTint_MULTIPLY';node.label='Connected source BaseColor / AO × coordinated warm tint';node.blend_type='MULTIPLY';node.inputs[0].default_value=1;node.inputs[2].default_value=tint
 node.location=(bs.location.x-210,bs.location.y+180)
 nt.links.new(old,node.inputs[1]);nt.links.new(node.outputs[0],socket)
 mat.diffuse_color=tint
 if name=='AcademicBrick':
  normals=[n for n in nt.nodes if n.type=='NORMAL_MAP'];assert normals
  for n in normals:n.inputs['Strength'].default_value=.15
 changes.append({'material':name,'multiply_node':node.name,'source_node':old.node.name,'source_socket':old.name,'factor':1,'tint_linear_rgba':list(tint),'destination':bs.name+'.Base Color','normal_strengths':[n.inputs['Strength'].default_value for n in nt.nodes if n.type=='NORMAL_MAP']})
stone=bpy.data.materials['LightStone'];stone.diffuse_color=(.86,.78,.60,1)
bs=next(n for n in stone.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
assert not bs.inputs['Base Color'].is_linked
bs.inputs['Base Color'].default_value=(.86,.78,.60,1)
assert h(snapshot(asset))==before
for u in mesh.uv_layers:
 assert all(math.isfinite(x) for d in u.data for x in d.uv)
# Retain complete manifests if staged. Otherwise recover explicit source records from named solid groups.
def read(n):
 p=out/n
 return json.loads(p.read_text()) if p.exists() else None
mounts=read('window-mounts.json')
if mounts is None:
 windows=[]
 pane_parts=[]
 for c in components:
  ids=next(ids for ids in parts.values() if all(any(a.group==asset.vertex_groups[c['name']].index and a.weight>.99 for a in mesh.vertices[i].groups) for i in ids))
  faces=[p for p in mesh.polygons if p.vertices[0] in set(ids)]
  if faces and all(mesh.materials[p.material_index].name=='WindowGlass' for p in faces):pane_parts.append(c)
 # Group names in the source carry the pane/frame/backing identity.
 for p in pane_parts:
  if 'door' in p['name'].lower():continue
  stem=p['name'].replace('Pane','').replace('Glass','')
  frames=[c['name'] for c in components if c['name']!=p['name'] and (c['name'].startswith(stem)) and any(s in c['name'].lower() for s in ['jamb','sill','head','frame','left','right','top','bottom'])]
  thin=0 if p['max'][0]-p['min'][0]<p['max'][1]-p['min'][1] else 1
  candidates=[]
  for c in components:
   if c is p or c['name'] in frames:continue
   tang=[k for k in range(3) if k!=thin]
   if all(c['min'][k]+.119<=p['min'][k] and c['max'][k]-.119>=p['max'][k] for k in tang):
    distance=min(abs(p['min'][thin]-c['max'][thin]),abs(p['max'][thin]-c['min'][thin]))
    if distance<.3:candidates.append((distance,c))
  if candidates:
   backing=min(candidates,key=lambda x:x[0])[1];sign=1 if sum(p[x][thin] for x in ['min','max'])>sum(backing[x][thin] for x in ['min','max']) else -1
   windows.append({'pane':p['name'],'frame_parts':frames,'backing':backing['name'],'axis':thin,'sign':sign,'pane_bounds':p,'backing_bounds':backing})
 mounts={'windows':windows,'doors':[c for c in components if 'door' in c['name'].lower()],'recovered_from':'unchanged named vertex groups and measured geometry'}
 write('window-mounts.json',mounts)
# Material recipe includes all connected inputs, not just viewport values.
materials=[]
for m in mesh.materials:
 p=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 materials.append({'name':m.name,'viewport_rgba':list(m.diffuse_color),'roughness_constant':p.inputs['Roughness'].default_value,'metallic_constant':p.inputs['Metallic'].default_value,'links':[{'from_node':l.from_node.name,'from_socket':l.from_socket.name,'to_node':l.to_node.name,'to_socket':l.to_socket.name} for l in m.node_tree.links],'normal_maps':[{'name':n.name,'space':n.space,'strength':n.inputs['Strength'].default_value} for n in m.node_tree.nodes if n.type=='NORMAL_MAP']})
oldmanifest=read('material-manifest.json')
write('material-manifest.json',{'source_id':'building.secondaryschool.a','regions':materials,'textures':receipts,'uv_recipe':'Existing UV0 preserved byte-for-byte; 2m brick repeat retained','orm_channels':{'R':'AO','G':'roughness','B':'metallic'},'prior_receipt':oldmanifest,'native_reconstruction':'deferred; integration HELD'})
# Preserve architecture evidence embedded in the parent, and explicitly report missing external receipts rather than fabricate them.
missing=[n for n in ['entrance-anchors.json','education-contract.json','upgrade-plan.json'] if not (out/n).exists()]
for n in missing:
 write(n,{'source_id':'building.secondaryschool.a','status':'Geometry and vertex groups retained exactly; original external receipt not staged by runner','unchanged_geometry_sha256':before,'components':components,'integration':'HELD'})
write('design-response.json',{'source_id':'building.secondaryschool.a','revision':'material-only friendly light terracotta','geometry_hash_before':before,'geometry_hash_after':h(snapshot(asset)),'hash_fields':'vertices, polygons, material assignments, UVs, vertex group memberships','components_retained':296,'panes_retained':50,'triangles':3552,'changes':changes,'cream_trim_linear_rgba':[.86,.78,.60,1],'unchanged':'EquipmentMetal, WindowGlass, ORM/roughness, tangent normals except brick strength, all mesh geometry and assignments, entrances and future reservation','original_external_receipts_not_staged':missing,'lod_plan':'Keep original low-poly sources; future LOD1 simplify four-part frames and roof hardware, LOD2 remove small facade detail while retaining academic/assembly/library silhouette. No LOD geometry generated.','integration':'HELD'})
bpy.context.scene.cursor.location=(0,0,0)
bpy.context.view_layer.objects.active=asset
asset.select_set(True)
finish(objects)
assert h(snapshot(asset))==before,'Geometry changed during helper finish'
asset.data.calc_loop_triangles()
assert len(asset.data.loop_triangles)==3552 and len(asset.data.materials)==5
v=read('validation.json') or {}
v.update({'source_id':'building.secondaryschool.a','components':components,'connected_solids':296,'panes_retained':50,'asset_triangles_excluding_review_ground':3552,'geometry_hash_before':before,'geometry_hash_after':h(snapshot(asset)),'material_only_geometry_preserved':True,'texture_receipts':receipts,'source_site_m':[40,40],'integration':'HELD','external_receipts_not_staged':missing})
write('validation.json',v)

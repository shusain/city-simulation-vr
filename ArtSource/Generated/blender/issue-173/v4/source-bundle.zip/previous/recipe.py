import bpy,sys,json
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
objects=load_previous()
# Feedback explicitly requests replacement geometry rebuilt from the exact v2 recipe.
# Remove the loaded parent and unused data before recreating its five materials.
for ob in list(bpy.data.objects):
    bpy.data.objects.remove(ob,do_unlink=True)
for mesh in list(bpy.data.meshes):
    if mesh.users==0:bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
    if mat.users==0:bpy.data.materials.remove(mat)
for im in list(bpy.data.images):
    if im.users==0:bpy.data.images.remove(im)
source=Path('/previous/recipe.py').read_text()
needle="for x in[-15.5,-12.8,-10.1,-7.4]:mounted('LibraryReading'"
assert source.count(needle)==1
addition="""# Revision: retain all clerestories and add ten meaningful lower hall bays.
for x in [7.5,9.5,14.5,16.5]:
 mounted('HallGroundFront'+str(x),'AssemblyHall',1,-1,x,2.1,1.5,1.7)
for y in [-1,1.2,3.4,5.6,7.8,10]:
 mounted('HallGroundEast'+str(y),'AssemblyHall',0,1,y,2.1,1.7,1.7)
"""
source=source.replace(needle,addition+needle)
assert source.count('assert len(windows)==40')==1
source=source.replace('assert len(windows)==40','assert len(windows)==50')
# Keep the parent recipe's strict mount, corridor, reservation, UV and FBX checks.
exec(compile(source,'secondary-v3-source.py','exec'),globals())
new_windows=[w for w in windows if w['pane'].startswith('HallGround')]
assert len(new_windows)==10
front=[w for w in new_windows if w['axis']==1]
east=[w for w in new_windows if w['axis']==0]
assert len(front)==4 and len(east)==6
upper=[w for w in windows if w['backing']=='AssemblyHall' and w not in new_windows]
assert len(upper)==11
for w in new_windows:
    assert w['backing']=='AssemblyHall'
    p=bounds[w['pane']]
    assert abs((p['min'][2]+p['max'][2])/2-2.1)<1e-5
    for n in [w['pane']]+w['frame_parts']:
        # No new glazing/frame obstructs either actual door assembly.
        for d in doors:
            for leaf in d['leaves']:assert not overlap(bounds[n],bounds[leaf])
response={'source_id':'building.secondaryschool.a','revision':'v3 ground-level assembly glazing','parent':'exact completed v2 recipe; loaded parent removed before reconstruction','integration':'HELD','ground_front_count':4,'ground_east_count':6,'total_panes':50,'retained_upper_hall_panes':[w['pane'] for w in upper],'new_windows':[{'pane':w['pane'],'frame_parts':w['frame_parts'],'backing':w['backing'],'pane_bounds':bounds[w['pane']],'frame_bounds':[bounds[n] for n in w['frame_parts']],'frame_height_range_m':[min(bounds[n]['min'][2] for n in w['frame_parts']),max(bounds[n]['max'][2] for n in w['frame_parts'])],'facade_normal':[0,-1,0] if w['axis']==1 else [1,0,0]} for w in new_windows],'retained_entrances':anchors,'future_reservation':reservation,'unchanged':'Overall massing, classroom block, library, canopy, five shared materials, nine packed texture maps, existing upper clerestories and empty expansion zone. No production integration.'}
write('design-response.json',response)
assert len(asset.data.loop_triangles)==3552
assert {m.name for m in asset.data.materials}=={'AcademicBrick','LightStone','RoofMembrane','EquipmentMetal','WindowGlass'}
v['ground_hall_windows']=10
v['retained_upper_hall_windows']=11
v['door_glazing_nonintersection']=True
write('validation.json',v)
# Standalone editable revised recipe, with no dependence on the previous mount.
post="\nwrite('design-response.json',"+repr(response)+")\n"
Path('/output/revised-source.py').write_text(source+post)

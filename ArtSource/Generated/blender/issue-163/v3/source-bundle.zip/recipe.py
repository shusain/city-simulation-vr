import sys, os, json, math, hashlib, shutil
from pathlib import Path
sys.path.insert(0,'/worker'); sys.path.insert(0,'/repo/Tools')
import bpy
from mathutils import Vector
from CityRunnerPreview import box,cylinder,finish
from CityBuildingStudyIO import checked_fbx
out=Path('/output'); out.mkdir(exist_ok=True)
def write(n,d): (out/n).write_text(json.dumps(d,indent=2))
for o in list(bpy.data.objects):
 if o.type=='MESH': bpy.data.objects.remove(o,do_unlink=True)
for m in list(bpy.data.meshes):
 if m.users==0:bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
 if m.users==0:bpy.data.materials.remove(m)
colors={k:tuple(v)+(1,) for k,v in {'Concrete':(.43,.45,.43),'BuildingFacade':(.39,.46,.44),'RoofService':(.095,.115,.13),'EquipmentMetal':(.26,.31,.32),'WindowAccent':(.075,.16,.21)}.items()}
mats={}; mf={'parameters':{'normal_strength':.3,'metricUV_scale':.5,'ORM':'G roughness / B metallic'},'textures':[]}
for name,col in colors.items():
 m=bpy.data.materials.new(name); m.diffuse_color=col; m.use_nodes=True; p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=col; p.inputs['Roughness'].default_value=.65; mats[name]=m
for region,folder,stem in [('RoofService','CivicSurfaces','CivicAsphalt'),('EquipmentMetal','BuildingSurfaces','CityMechanical')]:
 m=mats[region]; ns=m.node_tree.nodes; links=m.node_tree.links; p=ns.get('Principled BSDF')
 for suffix in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(stem+'_'+suffix+'.png'); dest=out/'textures'/src.name; dest.parent.mkdir(exist_ok=True); shutil.copyfile(src,dest)
  im=bpy.data.images.load(str(dest),check_existing=False); im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'; im.pack(); t=ns.new('ShaderNodeTexImage'); t.image=im
  if suffix=='BaseColor': links.new(t.outputs['Color'],p.inputs['Base Color'])
  elif suffix=='Normal':
   n=ns.new('ShaderNodeNormalMap'); n.inputs['Strength'].default_value=.3; links.new(t.outputs['Color'],n.inputs['Color']); links.new(n.outputs['Normal'],p.inputs['Normal'])
  else:
   sep=ns.new('ShaderNodeSeparateColor'); links.new(t.outputs['Color'],sep.inputs['Color']); links.new(sep.outputs['Green'],p.inputs['Roughness']); links.new(sep.outputs['Blue'],p.inputs['Metallic'])
  mf['textures'].append({'path':str(dest),'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'dimensions':list(im.size),'colorspace':im.colorspace_settings.name,'region':region})
mf['base_colors']=colors
obj=[]
def assign(o,mat):
 o.data.materials.clear(); o.data.materials.append(mats[mat]); obj.append(o); return o
def B(name,d,loc,mat='BuildingFacade'):return assign(box(name,d,loc,colors[mat]),mat)
def C(name,r,h,loc,mat='EquipmentMetal',v=16):return assign(cylinder(name,r,h,loc,colors[mat],vertices=v),mat)
def pipe(name,a,b,r=.09):
 a,b=Vector(a),Vector(b); o=C(name,r,(b-a).length,(a+b)/2,v=12); o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler(); return o
B('Generator_engine_hall',(9,10,5.5),(2.5,1,2.75))
B('Staffed_control_service_wing',(6,7,4.1),(-5,-1.5,2.05))
B('Hall_charcoal_service_roof',(9.35,10.3,.22),(2.5,1,5.61),'RoofService')
B('Control_charcoal_roof',(6.3,7.3,.22),(-5,-1.5,4.21),'RoofService')
for x,y,h in [(-8,-5,4.1),(-8,2,4.1),(-2,-5,4.1),(-2,-4,5.5),(7,-4,5.5),(7,6,5.5),(-2,6,5.5)]: B('Concrete_structural_column',(.22,.22,h),(x,y,h/2),'Concrete')
portal_p=[]
def PB(n,d,loc,m='EquipmentMetal'):
 o=B(n,d,loc,m);portal_p.append(o.name);return o
PB('Personnel_door_leaf',(1.2,.10,2.2),(-5.6,-5.075,1.1))
PB('Personnel_door_glass',(.72,.045,.75),(-5.6,-5.15,1.55),'WindowAccent')
PB('Personnel_door_handle',(.10,.12,.32),(-5.15,-5.22,1.02))
for x in [-6.25,-4.95]:PB('Personnel_portal_jamb',(.10,.18,2.28),(x,-5.09,1.14),'Concrete')
PB('Personnel_portal_head',(1.4,.18,.10),(-5.6,-5.09,2.30),'Concrete')
B('Personnel_shelter_canopy',(2.2,1.15,.13),(-5.6,-5.40,2.75),'RoofService')
portal_v=[]
def VB(n,d,loc,m='EquipmentMetal'):
 o=B(n,d,loc,m);portal_v.append(o.name);return o
VB('Vehicle_service_shutter',(4,.12,3.5),(3,-4.10,1.75))
for i in range(12):VB('Shutter_horizontal_seam',(3.96,.045,.035),(3,-4.185,.15+i*.28),'RoofService')
for x in [.94,5.06]:VB('Vehicle_portal_side',(.13,.22,3.6),(x,-4.10,1.8),'Concrete')
VB('Vehicle_portal_header',(4.26,.22,.16),(3,-4.10,3.66),'Concrete')
B('Bay_overhead_weather_brow',(4.6,.7,.14),(3,-4.25,3.95),'RoofService')
ww=[]
def window(name,x,y,z,w=1.35,h=1.25,axis=1,sign=-1,backing='Staffed_control_service_wing'):
 center=[x,y,z]; wall=bpy.data.objects[backing]; face=wall.location[axis]+sign*wall.dimensions[axis]/2
 center[axis]=face+sign*.05
 dims=[w,.10,h] if axis==1 else [.10,w,h]
 pane=B(name+'_opaque_pane',dims,center,'WindowAccent'); parts=[]; tangent=1-axis
 for s in [-1,1]:
  c=center.copy();c[tangent]+=s*(w/2+.045);d=[0,0,h+.18];d[axis]=.12;d[tangent]=.09;parts.append(B(name+'_jamb',d,c,'Concrete').name)
 for s in [-1,1]:
  c=center.copy();c[2]+=s*(h/2+.045);d=[0,0,.09];d[axis]=.12;d[tangent]=w;parts.append(B(name+'_head_sill',d,c,'Concrete').name)
 normal=[0,0,0];normal[axis]=sign
 ww.append({'pane':pane.name,'frame_parts':parts,'backing':backing,'axis':axis,'sign':sign,'wall_normal':normal})
window('Control_front_window',-3.45,-5.07,1.95)
for y in [-2.8,-.5,1.0]:window('Control_side_window',-8.075,y,2.05,axis=0)
for y in [-1.9,2.2]:
 B('Hall_large_intake_recess',(.14,2.8,2.1),(7.08,y,2.55),'RoofService')
 for j in range(10):B('Intake_louver_blade',(.22,2.65,.095),(7.19,y,1.65+j*.20),'EquipmentMetal')
for y in [-2,0,2,4]:B('Hall_vertical_panel_joint',(.045,.045,5.1),(7.025,y,2.8),'EquipmentMetal')
def exhaust(prefix,x,y):
 B(prefix+'Exhaust_rectangular_curb',(1.65,1.9,.26),(x,y,5.85),'EquipmentMetal')
 C(prefix+'Exhaust_silencer_body',.51,1.55,(x,y,6.65),v=20)
 C(prefix+'Exhaust_neck',.26,.7,(x,y,7.65),v=16)
 C(prefix+'Exhaust_weather_cap',.43,.12,(x,y,8.06),'RoofService',20)
 for z in [6,7.25]:C(prefix+'Exhaust_clamp',.56,.10,(x,y,z),v=20)
def vent(prefix,x,y):
 B(prefix+'Roof_ventilator_curb',(2.6,2.7,.3),(x,y,5.87),'EquipmentMetal')
 B(prefix+'Roof_ventilator_housing',(2.3,2.4,.95),(x,y,6.45),'EquipmentMetal')
 B(prefix+'Roof_ventilator_hood',(2.65,2.75,.16),(x,y,7),'RoofService')
 for i in range(7):B(prefix+'Roof_vent_louver',(2.16,.12,.07),(x,y-1.26,6.1+i*.115),'RoofService')
exhaust('',.4,2.5);vent('',4.4,.5)
def electrical(prefix,dx=0,dy=0):
 def b(n,d,l,m='EquipmentMetal'):return B(prefix+n,d,(l[0]+dx,l[1]+dy,l[2]),m)
 def c(n,r,h,l,m='EquipmentMetal',v=16):return C(prefix+n,r,h,(l[0]+dx,l[1]+dy,l[2]),m,v)
 b('Transformer_main_case',(1.55,2.3,1.65),(9.05,3.65,1.22))
 for x in [8.5,9.6]:
  for y in [2.9,4.4]:b('Transformer_equipment_leg',(.18,.18,.4),(x,y,.2))
 for x in [8.16,9.94]:
  for j in range(9):b('Transformer_radiator_fin',(.28,.10,1.35),(x,2.72+j*.23,1.2))
 for y in [3,3.65,4.3]:
  c('Transformer_bushing',.105,.55,(9.05,y,2.30),'WindowAccent',12)
  for z in [2.12,2.27,2.42]:c('Bushing_shed',.16,.045,(9.05,y,z),'WindowAccent',12)
 b('Switchgear_cabinet',(1.7,1,2.15),(9.1,.65,1.23))
 for x in [8.6,9.6]:b('Switchgear_leg',(.15,.65,.16),(x,.65,.08))
 for x in [8.65,9.5]:
  b('Switchgear_door_panel',(.78,.06,1.92),(x,.11,1.27),'BuildingFacade');b('Switchgear_handle',(.045,.08,.25),(x+.24,.045,1.2),'RoofService')
electrical('')
for a,b in [((7,4.9,1),(8,4.9,1)),((8,4.9,1),(8,4.9,.4)),((8,4.9,.4),(9,4.9,.4)),((9,.8,2.4),(9,2.4,2.4)),((9,2.4,2.4),(9,2.4,1.7))]:pipe('Visible_power_conduit',a,b)
B('Rear_generator_hall',(9,7,5.5),(1.5,10,2.75))
B('Rear_hall_charcoal_roof',(9.35,7.3,.22),(1.5,10,5.61),'RoofService')
for x in [-3,6]:
 for y in [6.5,13.5]:B('Rear_structural_column',(.22,.22,5.5),(x,y,2.75),'Concrete')
exhaust('Rear_',-.6,11.3);vent('Rear_',3.4,9)
electrical('Second_',0,8)
for a,b in [((6,12.9,1),(8,12.9,1)),((8,12.9,1),(8,12.9,.4)),((8,12.9,.4),(9,12.9,.4)),((9,8.8,2.4),(9,10.4,2.4))]:pipe('Second_visible_conduit',a,b)
for y in [8.1,11.5]:
 window('Rear_hall_side_window',-3,y,3.2,w=1.8,h=1.3,axis=0,backing='Rear_generator_hall')
B('Interhall_service_link',(3,.5,3.4),(1.5,6.25,1.7))
bpy.context.view_layer.update()
bpy.ops.object.select_all(action='DESELECT')
for o in obj:o.select_set(True)
bpy.context.view_layer.objects.active=obj[0];bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.context.view_layer.update()
def bounds(o):
 pts=[o.matrix_world@v.co for v in o.data.vertices];return ([min(v[i] for v in pts) for i in range(3)],[max(v[i] for v in pts) for i in range(3)])
components=[dict(name=o.name,min=bounds(o)[0],max=bounds(o)[1]) for o in obj]; lu={c['name']:c for c in components}
def overlap(a,b):return all(min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i])>1e-5 for i in range(3))
for win in ww:
 wall=lu[win['backing']];pane=lu[win['pane']];axis=win['axis'];t=1-axis;sg=win['sign'];face=wall['min'][axis] if sg<0 else wall['max'][axis]
 frames=[lu[n] for n in win['frame_parts']]
 for f in frames:
  rear=f['max'][axis] if sg<0 else f['min'][axis]
  assert -.02001<=sg*(rear-face)<=.00001
  for i in [t,2]:assert f['min'][i]>=wall['min'][i]+.12-1e-5 and f['max'][i]<=wall['max'][i]-.12+1e-5
 for i,a in enumerate(frames):
  for b in frames[i+1:]:assert not overlap(a,b)
 assert all(pane['min'][axis]>=f['min'][axis]-1e-5 and pane['max'][axis]<=f['max'][axis]+1e-5 for f in frames)
anchors=[]
for role,target,x,width,clear,height,fixtures in [('pedestrian','Personnel_door_leaf',-5.6,1.2,1.8,2.4,portal_p),('vehicle_service','Vehicle_service_shutter',3,4,4,3.5,portal_v)]:
 end=min(lu[n]['min'][1] for n in fixtures)-.02
 corridor={'min':[x-clear/2,-16,0],'max':[x+clear/2,end,height]}
 assert not any(overlap(corridor,c) for c in components)
 anchors.append({'role':role,'target':target,'xyz_m':[x,lu[target]['min'][1],0],'outward':[0,-1,0],'width_m':width,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':clear,'grade_m':0},'reserved_free_corridor':corridor})
lo=[min(c['min'][i] for c in components) for i in range(3)];hi=[max(c['max'][i] for c in components) for i in range(3)]
assert all(lo[i]>=-15.5 and hi[i]<=15.5 for i in [0,1]);assert lo[2]>=-1e-5
tri=0
for o in obj:
 mesh=o.data;uv=mesh.uv_layers.active or mesh.uv_layers.new(name='metricUV0');uv.name='metricUV0'
 for p in mesh.polygons:
  normal=p.normal;drop=max(range(3),key=lambda i:abs(normal[i]));axes=[i for i in range(3) if i!=drop]
  for li in p.loop_indices:
   co=o.matrix_world@mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]*.5,co[axes[1]]*.5)
 assert all(math.isfinite(v) for d in uv.data for v in d.uv)
 mesh.calc_loop_triangles();tri+=len(mesh.loop_triangles)
assert tri<=6000,tri
write('window-mounts.json',{'windows':ww});write('entrance-anchors.json',{'anchors':anchors});write('material-manifest.json',mf)
write('upgrade-stage.json',dict(asset_id='building.power.medium.a',stage='medium',capacity_percent_reference=200,module_counts=dict(generating_halls=2,exhaust_units=2,electrical_groups=2),occupied_envelope_m=[hi[i]-lo[i] for i in range(3)],base_identity='160v1 complete geometry vocabulary',lower_LOD_plan='Preserve masses/portals/major pipes; reduce secondary rings/frames/fixtures later; no device result'))
bpy.ops.object.select_all(action='DESELECT');obj[0].select_set(True);bpy.context.view_layer.objects.active=obj[0];bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(obj)
report_path=out/'validation.json';report=json.loads(report_path.read_text()) if report_path.exists() else {}
report.update(components=components,source_triangles=tri,triangle_ceiling=6000,semantic_regions=list(colors),review_only=True)
write('validation.json',report)
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')

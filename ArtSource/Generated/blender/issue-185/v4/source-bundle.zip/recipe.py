import bpy,sys,json,math,hashlib,shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
O=Path('/output');O.mkdir(exist_ok=True)
def write(n,d): (O/n).write_text(json.dumps(d,indent=2))
objects=[o for o in load_previous() if o.type=='MESH']
assert len(objects)==1
ob=objects[0];me=ob.data
assert all(abs(x)<1e-7 for x in ob.location) and all(abs(x-1)<1e-7 for x in ob.scale)
def collect():
 adj=[[] for v in me.vertices]
 for e in me.edges:
  a,b=e.vertices;adj[a].append(b);adj[b].append(a)
 seen=set();out={}
 for v in me.vertices:
  if v.index in seen:continue
  ids=set();stack=[v.index]
  while stack:
   i=stack.pop()
   if i in ids:continue
   ids.add(i);stack.extend(j for j in adj[i] if j not in ids)
  seen.update(ids)
  gs=set(g.group for g in v.groups if g.weight>.5)
  gs=[g for g in gs if all(any(t.group==g and t.weight>.5 for t in me.vertices[j].groups) for j in ids)]
  assert len(gs)==1
  n=ob.vertex_groups[gs[0]].name;assert n not in out
  co=[me.vertices[j].co for j in sorted(ids)]
  out[n]={'ids':sorted(ids),'min':[min(c[k] for c in co) for k in range(3)],'max':[max(c[k] for c in co) for k in range(3)]}
 return out
before=collect();assert len(before)==235,len(before)
uv=me.uv_layers.active;assert uv
verts=[tuple(v.co) for v in me.vertices];uv_before=[tuple(v.uv) for v in uv.data]
faces=[(tuple(p.vertices),p.material_index) for p in me.polygons]
slots=[m.name for m in me.materials];assert len(slots)==6
changes={}
def bounds(n,axis,lo=None,hi=None):
 c=before[n];a=c['min'][axis];b=c['max'][axis]
 lo=a if lo is None else lo;hi=b if hi is None else hi
 for i in c['ids']:me.vertices[i].co[axis]=lo+(verts[i][axis]-a)*(hi-lo)/(b-a)
 changes[n]=True
for n,lo,hi in [('Public_double_leaf',-16.057,-15.003),('Public_double_leaf.001',-14.997,-13.943)]:
 bounds(n,0,lo,hi);bounds(n,2,.003,2.747)
for n in ['Public_jamb','Public_jamb.001']:bounds(n,2,hi=2.75)
for n in ['Door_pull','Door_pull.001']:bounds(n,1,hi=-8.127)
for n in ['Truck_frame_jamb','Truck_frame_jamb.001']:bounds(n,2,hi=4.425)
step=(4.425-.006)/7
for i in range(7):
 n=f'Truck_section_{i:02d}';bounds(n,0,-4.427,.427)
 bounds(n,2,.003+i*step+.003*(i>0),.003+(i+1)*step-.003*(i<6))
assert len(changes)==15
me.update()
changed_ids={i for n in changes for i in before[n]['ids']}
for p in me.polygons:
 if p.vertices[0] not in changed_ids:continue
 assert all(i in changed_ids for i in p.vertices)
 axis=max(range(3),key=lambda k:abs(p.normal[k]));axes=[k for k in range(3) if k!=axis]
 for li in p.loop_indices:
  co=me.vertices[me.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]/2,co[axes[1]]/2)
after=collect()
assert faces==[(tuple(p.vertices),p.material_index) for p in me.polygons]
for i,v in enumerate(me.vertices):
 if i not in changed_ids:assert tuple(v.co)==verts[i]
for p in me.polygons:
 if p.vertices[0] not in changed_ids:
  for li in p.loop_indices:assert tuple(uv.data[li].uv)==uv_before[li]
assert len(after)==235
for n in before:
 if n not in changes:assert after[n]==before[n]
for n in changes:
 assert any(tuple(me.vertices[i].co)!=verts[i] for i in before[n]['ids'])
assert len(before)-len(changes)==220
me.calc_loop_triangles();assert len(me.loop_triangles)==2856
assert all(math.isfinite(t) for u in uv.data for t in u.uv)
def overlap(a,b):return all(min(a['max'][k],b['max'][k])-max(a['min'][k],b['min'][k])>1e-6 for k in range(3))
def close(a,b):assert abs(a-b)<2e-6,(a,b)
def component(n):return dict(name=n,min=after[n]['min'],max=after[n]['max'])
# Independent rectangular-coverage and source mesh ray tests.
assemblies=[];ray_checks=[]
for id,leaves,jambs,header,xlo,xhi,top in [('public',['Public_double_leaf','Public_double_leaf.001'],['Public_jamb','Public_jamb.001'],'Public_head',-16.06,-13.94,2.75),('receiving-1',[f'Truck_section_{i:02d}' for i in range(7)],['Truck_frame_jamb','Truck_frame_jamb.001'],'Truck_frame_head',-4.43,.43,4.425)]:
 jambs=sorted(jambs,key=lambda n:after[n]['min'][0]);h=after[header]
 close(h['min'][2],top)
 for n in jambs:close(after[n]['max'][2],h['min'][2]);assert not overlap(after[n],h)
 close(after[jambs[0]]['max'][0],xlo);close(after[jambs[1]]['min'][0],xhi)
 for n in leaves:
  c=after[n];assert c['min'][0]>=xlo and c['max'][0]<=xhi and c['min'][2]>=0 and c['max'][2]<=top
  for k in [1]:close(c['min'][k],before[n]['min'][k]);close(c['max'][k],before[n]['max'][k])
  assert c['min'][1]<-8 and c['min'][1]>min(after[j]['min'][1] for j in jambs)
 if id=='public':
  a,b=[after[n] for n in leaves];close(a['min'][0]-xlo,.003);close(xhi-b['max'][0],.003);close(b['min'][0]-a['max'][0],.006)
  for c in [a,b]:close(c['min'][2],.003);close(top-c['max'][2],.003)
 else:
  close(after[leaves[0]]['min'][2],.003);close(top-after[leaves[-1]]['max'][2],.003)
  for i,n in enumerate(leaves):
   c=after[n];close(c['min'][0]-xlo,.003);close(xhi-c['max'][0],.003)
   if i:close(c['min'][2]-after[leaves[i-1]]['max'][2],.006)
 for n in leaves:
  c=after[n]
  for x,z in [(c['min'][0]+.01,c['min'][2]+.01),(c['max'][0]-.01,c['min'][2]+.01),(c['min'][0]+.01,c['max'][2]-.01),(c['max'][0]-.01,c['max'][2]-.01)]:
   hit,loc,normal,fi=ob.ray_cast(Vector((x,-12,z)),Vector((0,1,0)),distance=6)
   assert hit and all(v in after[n]['ids'] for v in me.polygons[fi].vertices),('door ray',n,fi,tuple(loc))
   close(loc.y,c['min'][1]);ray_checks.append(dict(part=n,origin=[x,-12,z],hit=list(loc)))
 assemblies.append(dict(id=id,leaves=leaves,left_jamb=jambs[0],right_jamb=jambs[1],header=header,axis=1,sign=-1,inner_opening={'min':[xlo,-8.4,0],'max':[xhi,-7.9,top]},edge_reveal_m=.003,centre_or_panel_seam_m=.006))
write('assembly-fit-contract.json',dict(family='recycling',stage='base',roof_supports=[],doors=assemblies))
# Preserve prior metadata where staged; fallbacks reproduce the prior recipe verbatim in meaning.
def prior(n):
 p=Path('/previous')/n
 return json.loads(p.read_text()) if p.exists() else None
anchors=prior('entrance-anchors.json')
if anchors is None:
 aa=[]
 for role,x,width,height,target in [('pedestrian',-15,2,2.4,'Public_double_leaf'),('service',-2,4.8,4.2,'Truck_section_00')]:
  aa.append(dict(role=role,target=target,xyz_m=[x,-9.5,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor={'min':[x-width/2,-20,0],'max':[x+width/2,-9.5,height]}))
 anchors={'anchors':aa}
assert len(anchors['anchors'])==2
for a in anchors['anchors']:
 for n,c in after.items():assert not overlap(c,a['reserved_free_corridor']),('corridor',n)
write('entrance-anchors.json',anchors)
bays=prior('vehicle-bays.json') or dict(bays=[dict(id='receiving-1',target='Truck_section_00',xyz_m=[-2,-9.5,0],outward=[0,-1,0],width_m=4.8,height_m=4.34,boundary_connector={'xyz_m':[-2,-20,0]},reserved_free_corridor=anchors['anchors'][1]['reserved_free_corridor'])])
write('vehicle-bays.json',bays)
windows=[]
for n,c in after.items():
 if not n.endswith('_pane'):continue
 prefix=n[:-5];frames=[prefix+s for s in ['_jambL','_jambR','_head','_sill']]
 wall='Admin_occupied_masonry' if n.startswith('Office') else 'Sorting_hall_masonry';w=after[wall]
 axis=0 if '_west_' in n or '_east_' in n else 1;sign=-1 if '_west_' in n or '_front_' in n else 1
 face=w['max'][axis] if sign>0 else w['min'][axis]
 for part in [n]+frames:assert after[part]==before[part]
 windows.append(dict(pane=n,frame_parts=frames,backing=wall,axis=axis,sign=sign,wall_face=face,pane_bounds=[c['min'],c['max']],frame_bounds=[[after[f]['min'],after[f]['max']] for f in frames]))
assert len(windows)==25
wm=prior('window-mounts.json') or dict(windows=windows,doors=[dict(target='Public_double_leaf',clear_width_m=2,headroom_m=2.6),dict(target='Truck_section_00',clear_width_m=4.8,headroom_m=4.34)])
for door in wm['doors']:
 target=door.get('target',door.get('pane'))
 if target in changes:door['bounds']=[after[target]['min'],after[target]['max']]
write('window-mounts.json',wm)
groups={k:[] for k in ['admin','hall','entry','roof','identity','compactor','conveyor','bins','bales']}
for n in after:
 if n.startswith(('Admin','Office','Enclosed','TrimR2')):g='admin'
 elif n.startswith(('Hall_roof','Roof_vent','ParapetR2')):g='roof'
 elif n.startswith(('Public','Entry','Door_pull','Truck')):g='entry'
 elif n.startswith(('Emblem','Cycle')):g='identity'
 elif n.startswith(('Bale_press','Press_')):g='compactor'
 elif n.startswith(('Conveyor','Sorting_hopper')):g='conveyor'
 elif n.startswith(('Bin_','Contained')):g='bins'
 elif n.startswith(('Bound_bale','Bale_strap')):g='bales'
 else:g='hall'
 groups[g].append(n)
write('waste-contract.json',prior('waste-contract.json') or dict(family='recycling',stage='base',sourceID='building.recycling.a',source_site_m=[48,40],groups=groups,integration='HELD'))
occupied={k:[(min if k=='min' else max)(c[k][i] for c in after.values()) for i in range(3)] for k in ['min','max']}
up=prior('upgrade-plan.json') or dict(family='recycling',stage='base',stage_index=0,existing_stages=['base','medium'],existing_upgrade_count=1,gameplay_changes=False,source_site_m=[48,40],current_native_footprint=[4,3],occupied_bounds=occupied,retained_entrance_centres=[[-15,-8],[-2,-8]],progression='Medium adds second receiving bay and longer sorting line; no new tier.')
up['technical_fit_note']='Base only: exactly 15 original door assembly solids adjusted; remaining 220 solids preserved; no design or gameplay changes.';write('upgrade-plan.json',up)
corner=prior('corner-contract.json')
if corner is None:
 names=[n for n in after if n.startswith(('TrimR2_','ParapetR2_'))];joints=[]
 for i,n in enumerate(names):
  a=after[n]
  for m in names[:i]:
   b=after[m];gaps=[max(a['min'][k]-b['max'][k],b['min'][k]-a['max'][k],0) for k in range(3)]
   if max(gaps)<=.001:
    planes=[{'axis':k,'coordinate':a['min'][k]} for k in range(3) if abs(a['min'][k]-b['max'][k])<.001]+[{'axis':k,'coordinate':a['max'][k]} for k in range(3) if abs(a['max'][k]-b['min'][k])<.001]
    joints.append(dict(pair=[n,m],gap_m=max(gaps),contact_planes=planes))
 corner=dict(new_strips=[component(n) for n in names],joints=joints,roof_top_m=after['Hall_roof_deck']['max'][2],correct_inner_surface_contact_tolerance_m=.021,all_original_panes_rims_preserved=True)
write('corner-contract.json',corner)
receipts=[]
for folder,stem in [('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{stem}_{suffix}.png';src=Path('/repo')/rel;dest=O/'textures'/src.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(src,dest)
  ims=[im for im in bpy.data.images if Path(im.filepath).name==src.name or im.name==src.name];assert ims
  for im in ims:im.filepath=str(dest);im.pack()
  receipts.append(dict(source=rel,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),dimensions=list(ims[0].size),colorspace=ims[0].colorspace_settings.name))
manifest=prior('material-manifest.json')
if manifest is None:
 regions=[]
 for m in me.materials:
  nodes=[]
  for n in m.node_tree.nodes:
   inputs={}
   for s in n.inputs:
    if not hasattr(s,'default_value'):continue
    v=s.default_value
    if isinstance(v,(float,int,str)):inputs[s.name]=v
    elif hasattr(v,'__len__'):
     try:inputs[s.name]=list(v)
     except:pass
   nodes.append(dict(name=n.name,type=n.bl_idname,blend_type=getattr(n,'blend_type',None),image=getattr(getattr(n,'image',None),'name',None),inputs=inputs))
  regions.append(dict(name=m.name,diffuse_color=list(m.diffuse_color),nodes=nodes,links=[dict(source=l.from_node.name,output=l.from_socket.name,target=l.to_node.name,input=l.to_socket.name) for l in m.node_tree.links]))
 manifest=dict(textures=receipts,regions=regions,channels='BaseColor sRGB times ORM.R AO times tint; ORM.G roughness ORM.B metallic; tangent normal strength .25',native_reconstruction_required=True)
manifest['uv_recipe']='Preserved original UV0 except 15 changed solids: dominant face world metres / 2.';write('material-manifest.json',manifest)
for c in after.values():assert c['min'][2]>=-1e-5 and c['min'][0]>=-23.5 and c['max'][0]<=23.5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5
components=[component(n) for n in after]
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
finish(objects)
r=json.loads((O/'validation.json').read_text());r.update(components=components,sourceID='building.recycling.a',stage='base',window_count=25,source_triangles=2856,semantic_regions=slots,changed_components=sorted(changes),unchanged_components=220,door_edge_source_rays=ray_checks,checks=dict(exact_15_group_edits=True,remaining_220_geometry_uv_materials_unchanged=True,topology_unchanged=True,windows_unchanged=True,jamb_header_contact=True,exact_rectangular_leaf_coverage_with_permitted_seams=True,unchanged_leaf_depth=True,strict_full_corridors=True,finite_uv=True),integration='HELD; technical base preview only; human review pending');write('validation.json',r)

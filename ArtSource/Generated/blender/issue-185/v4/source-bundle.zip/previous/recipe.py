import bpy,sys,json,math,hashlib,shutil,bmesh,ast
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,box,finish
O=Path('/output');O.mkdir(exist_ok=True)
def write(n,d):(O/n).write_text(json.dumps(d,indent=2))
objects=load_previous()
objects=[o for o in objects if o.type=='MESH']
assert objects
for ob in objects:
 bpy.context.view_layer.objects.active=ob
 bpy.ops.object.select_all(action='DESELECT');ob.select_set(True)
 bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
def collect(obs):
 result={}
 for ob in obs:
  me=ob.data; adj=[[] for v in me.vertices]
  for e in me.edges:
   a,b=e.vertices;adj[a].append(b);adj[b].append(a)
  seen=set()
  for v in me.vertices:
   if v.index in seen:continue
   stack=[v.index];ids=set()
   while stack:
    i=stack.pop()
    if i in ids:continue
    ids.add(i);stack.extend(j for j in adj[i] if j not in ids)
   seen.update(ids)
   names=set(g.group for g in me.vertices[next(iter(ids))].groups if g.weight>.5)
   names=[i for i in names if all(any(g.group==i and g.weight>.5 for g in me.vertices[j].groups) for j in ids)]
   assert len(names)==1,('unique component group',names)
   name=ob.vertex_groups[names[0]].name;assert name not in result,name
   coords=[list(ob.matrix_world@me.vertices[i].co) for i in sorted(ids)]
   uv=me.uv_layers.active;polys=[p for p in me.polygons if p.vertices[0] in ids]
   signature=sorted((tuple(tuple(round(float(x),7) for x in me.vertices[j].co) for j in p.vertices),p.material_index,tuple(tuple(round(float(x),7) for x in uv.data[k].uv) for k in p.loop_indices)) for p in polys)
   result[name]={'min':[min(v[k] for v in coords) for k in range(3)],'max':[max(v[k] for v in coords) for k in range(3)],'signature':signature}
 return result
original=collect(objects)
removed=['Admin_corner_pier','Admin_corner_pier.001','Admin_stringcourse','Admin_stringcourse.001','Admin_stringcourse.002']+[n for n in original if n.startswith(('Hall_parapet_side','Hall_parapet_end'))]
assert len(removed)==9 and all(n in original for n in removed)
slots=[m.name for m in objects[0].data.materials];assert len(slots)==6
stone=next(m for m in objects[0].data.materials if m.name=='LightStone')
for ob in objects:
 indexes={g.index for g in ob.vertex_groups if g.name in removed}
 bm=bmesh.new();bm.from_mesh(ob.data);bm.verts.ensure_lookup_table()
 erase=[bm.verts[v.index] for v in ob.data.vertices if any(g.group in indexes and g.weight>.5 for g in v.groups)]
 bmesh.ops.delete(bm,geom=erase,context='VERTS');bm.to_mesh(ob.data);bm.free();ob.data.update()
 for n in removed:
  g=ob.vertex_groups.get(n)
  if g:ob.vertex_groups.remove(g)
new=[]
def strip(name,lo,hi):
 ob=box(name,tuple(hi[i]-lo[i] for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),(.78,.73,.59,1))
 ob.data.materials.clear();ob.data.materials.append(stone)
 bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 uv=ob.data.uv_layers.active or ob.data.uv_layers.new(name='UV0');uv.name='UV0'
 for p in ob.data.polygons:
  axis=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in p.loop_indices:
   co=ob.data.vertices[ob.data.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]/2,co[axes[1]]/2)
 g=ob.vertex_groups.new(name=name);g.add(list(range(len(ob.data.vertices))),1,'REPLACE');new.append(ob)
for index,z in enumerate([.22,3.20,6.30]):
 for side,lo,hi in [('F',[-20.06,-8.06,z-.06],[-9.94,-7.99,z+.06]),('B',[-20.06,4.99,z-.06],[-9.94,5.06,z+.06]),('W',[-20.06,-7.99,z-.06],[-19.99,4.99,z+.06]),('E',[-10.01,-7.99,z-.06],[-9.94,.99 if index<2 else 4.99,z+.06])]:strip(f'TrimR2_{index}_{side}',lo,hi)
roof_top=original['Hall_roof_deck']['max'][2];assert abs(roof_top-8.22)<.001
for side,lo,hi in [('W',[-8,-8,roof_top-.01],[-7.78,10,roof_top+.37]),('E',[5.78,-8,roof_top-.01],[6,10,roof_top+.37]),('F',[-7.78,-8,roof_top-.01],[5.78,-7.78,roof_top+.37]),('B',[-7.78,9.78,roof_top-.01],[5.78,10,roof_top+.37])]:strip('ParapetR2_'+side,lo,hi)
objects+=new
current=collect(objects)
for n,c in original.items():
 if n not in removed:assert current[n]==c,('preservation',n)
def overlaps(a,b):return all(min(a['max'][i],b['max'][i])-max(a['min'][i],b['min'][i])>1e-6 for i in range(3))
newnames=[o.name for o in new];joints=[]
for i,n in enumerate(newnames):
 a=current[n]
 for m in newnames[:i]:
  b=current[m];assert not overlaps(a,b),(n,m)
  gaps=[max(a['min'][k]-b['max'][k],b['min'][k]-a['max'][k],0) for k in range(3)]
  if max(gaps)<=.001:
   planes=[{'axis':k,'coordinate':a['min'][k]} for k in range(3) if abs(a['min'][k]-b['max'][k])<.001]+[{'axis':k,'coordinate':a['max'][k]} for k in range(3) if abs(a['max'][k]-b['min'][k])<.001]
   joints.append(dict(pair=[n,m],gap_m=max(gaps),contact_planes=planes))
for n in newnames:
 c=current[n]
 if n.startswith('Trim'):
  side=n[-1];axis=1 if side in 'FB' else 0
  inner=c['max'][axis] if side in 'FW' else c['min'][axis]
  face={'F':-8,'B':5,'W':-20,'E':-10}[side]
  assert abs(inner-face)<=.021,(n,inner,face)
 else:assert abs(c['min'][2]-roof_top)<=.021 and abs(c['max'][2]-(roof_top+.37))<1e-5
windows=[]
for n in current:
 if not n.endswith('_pane'):continue
 c=current[n];prefix=n[:-5];frames=[prefix+s for s in ['_jambL','_jambR','_head','_sill']];assert all(f in current for f in frames)
 wall='Admin_occupied_masonry' if n.startswith('Office') else 'Sorting_hall_masonry';w=current[wall]
 axis=0 if '_west_' in n or '_east_' in n else 1;sign=-1 if '_west_' in n or '_front_' in n else 1;tangent=1-axis
 face=w['max'][axis] if sign>0 else w['min'][axis]
 for f in frames:
  b=current[f]
  assert b['min'][tangent]>=w['min'][tangent]+.119 and b['max'][tangent]<=w['max'][tangent]-.119
  assert b['min'][2]>=w['min'][2]+.119 and b['max'][2]<=w['max'][2]-.119
  inner=b['min'][axis] if sign>0 else b['max'][axis];assert abs(inner-face)<=.021
  assert not overlaps(b,c)
 for i,f in enumerate(frames):
  for ff in frames[:i]:assert not overlaps(current[f],current[ff])
 for part in [n]+frames:
  for nn in newnames:assert not overlaps(current[part],current[nn]),('window trim',part,nn)
 windows.append(dict(pane=n,frame_parts=frames,backing=wall,axis=axis,sign=sign,wall_face=face,pane_bounds=[c['min'],c['max']],frame_bounds=[[current[f]['min'],current[f]['max']] for f in frames]))
assert len(windows)==25
anchors=[]
for role,x,width,height,target in [('pedestrian',-15,2,2.4,'Public_double_leaf'),('service',-2,4.8,4.2,'Truck_section_00')]:
 corridor={'min':[x-width/2,-20,0],'max':[x+width/2,-9.5,height]}
 for n,c in current.items():assert not overlaps(c,corridor),('lane',n)
 assert target in current
 anchors.append(dict(role=role,target=target,xyz_m=[x,-9.5,0],outward=[0,-1,0],width_m=width,grade_m=0,boundary_connector=dict(xyz_m=[x,-20,0],outward=[0,-1,0],width_m=width,grade_m=0),reserved_free_corridor=corridor))
write('entrance-anchors.json',dict(anchors=anchors));write('vehicle-bays.json',dict(bays=[dict(id='receiving-1',target='Truck_section_00',xyz_m=[-2,-9.5,0],outward=[0,-1,0],width_m=4.8,height_m=4.34,boundary_connector={'xyz_m':[-2,-20,0]},reserved_free_corridor=anchors[1]['reserved_free_corridor'])]))
write('window-mounts.json',dict(windows=windows,doors=[dict(target='Public_double_leaf',clear_width_m=2,headroom_m=2.6),dict(target='Truck_section_00',clear_width_m=4.8,headroom_m=4.34)]))
groups={k:[] for k in ['admin','hall','entry','roof','identity','compactor','conveyor','bins','bales']}
for n in current:
 if n.startswith(('Admin','Office','Enclosed','TrimR2')):g='admin'
 elif n.startswith(('Hall_roof','Roof_vent','ParapetR2')):g='roof'
 elif n.startswith(('Public','Entry','Door_pull','Truck')):g='entry'
 elif n.startswith(('Emblem','Cycle')):g='identity'
 elif n.startswith(('Bale_press','Press_')):g='compactor'
 elif n.startswith(('Conveyor','Sorting_hopper')):g='conveyor'
 elif n.startswith(('Bin_','Contained')):g='bins'
 elif n.startswith(('Bound_bale','Bale_strap')):g='bales'
 else:g='hall'
 groups[g].append(n)
write('waste-contract.json',dict(family='recycling',stage='base',sourceID='building.recycling.a',source_site_m=[48,40],groups=groups,integration='HELD'))
components=[dict(name=n,min=c['min'],max=c['max']) for n,c in current.items()]
occupied={k:[(min if k=='min' else max)(c[k][i] for c in current.values()) for i in range(3)] for k in ['min','max']}
for c in components:assert c['min'][2]>=-1e-5 and c['min'][0]>=-23.5 and c['max'][0]<=23.5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5
write('upgrade-plan.json',dict(family='recycling',stage='base',stage_index=0,existing_stages=['base','medium'],existing_upgrade_count=1,gameplay_changes=False,source_site_m=[48,40],current_native_footprint=[4,3],occupied_bounds=occupied,retained_entrance_centres=[[-15,-8],[-2,-8]],progression='Medium adds second receiving bay and longer sorting line; no new tier.'))
write('corner-contract.json',dict(removed_names=removed,new_strips=[c for c in components if c['name'] in newnames],joints=joints,roof_top_m=roof_top,correct_inner_surface_contact_tolerance_m=.021,unchanged_components=len(original)-len(removed),all_original_panes_rims_preserved=True))
receipts=[]
for folder,stem in [('BuildingSurfaces','CityBrick'),('BuildingSurfaces','CityMechanical'),('RoofsSigns','RoofMembrane')]:
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{stem}_{suffix}.png';src=Path('/repo')/rel;dest=O/'textures'/src.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(src,dest)
  ims=[im for im in bpy.data.images if Path(im.filepath).name==src.name or im.name==src.name];assert ims,src.name
  for im in ims:im.filepath=str(dest);im.pack()
  receipts.append(dict(source=rel,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),dimensions=list(ims[0].size),colorspace=ims[0].colorspace_settings.name))
regions=[]
for m in objects[0].data.materials:
 nodes=[]
 for n in m.node_tree.nodes:
  inputs={s.name:list(s.default_value) if hasattr(s.default_value,'__len__') else s.default_value for s in n.inputs if hasattr(s,'default_value') and isinstance(s.default_value,(float,int,str,tuple,list,Vector))}
  if n.type=='MIX_RGB':inputs['Color2']=list(n.inputs[2].default_value);inputs['Fac']=n.inputs[0].default_value
  nodes.append(dict(name=n.name,type=n.bl_idname,blend_type=getattr(n,'blend_type',None),image=getattr(getattr(n,'image',None),'name',None),inputs=inputs))
 regions.append(dict(name=m.name,diffuse_color=list(m.diffuse_color),nodes=nodes,links=[dict(source=l.from_node.name,output=l.from_socket.name,target=l.to_node.name,input=l.to_socket.name) for l in m.node_tree.links]))
write('material-manifest.json',dict(textures=receipts,regions=regions,uv_recipe='Preserved original UV0; new trim dominant face world metres /2',channels='BaseColor sRGB times ORM.R AO times tint; ORM.G roughness ORM.B metallic; tangent normal strength .25',native_reconstruction_required=True))
for me in list(bpy.data.meshes):
 if me.users==0:bpy.data.meshes.remove(me)
for m in list(bpy.data.materials):
 if m.users==0:bpy.data.materials.remove(m)
for ob in objects:
 assert all(math.isfinite(x) for v in ob.data.uv_layers.active.data for x in v.uv)
triangles=sum(sum(len(p.vertices)-2 for p in ob.data.polygons) for ob in objects);assert triangles<=6500
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.device='CPU';bpy.context.scene.cycles.samples=12
finish(objects)
p=O/'validation.json';r=json.loads(p.read_text());r.update(components=components,window_count=25,sourceID='building.recycling.a',stage='base',source_triangles=triangles,semantic_regions=slots,checks=dict(original_unremoved_geometry_uv_material_indices_unchanged=True,window_mounts_and_disjoint_open_rims=True,strict_full_corridors=True,trim_disjoint=True,correct_facade_contact=True,parapets_supported=True,finite_uv=True),integration='HELD; HUMAN artistic review required');write('validation.json',r)

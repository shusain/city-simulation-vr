import bpy, sys, os, json, math, shutil, hashlib
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
os.makedirs('/output/textures',exist_ok=True)
refs=['ArtSource/Blender/CityCivicSurfaces.blend','ArtSource/Manifests/city_civic_surface_study.json','ArtSource/Blender/CityLowDensityBuildings.blend','ArtSource/Manifests/city_low_density_buildings.json','Tools/CityBuildingStudyIO.py']
colors=[(.44,.45,.42,1),(.57,.60,.57,1),(.16,.19,.21,1),(.34,.39,.40,1),(.16,.25,.30,1)]
names=['Concrete','BuildingFacade','RoofService','EquipmentMetal','WindowAccent']
mats=[]
for n,c in zip(names,colors):
 m=bpy.data.materials.new(n);m.diffuse_color=c;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=c;p.inputs['Roughness'].default_value=.65
 if n=='EquipmentMetal':p.inputs['Metallic'].default_value=.55
 mats.append(m)
manifest={'references':refs,'textures':[],'shader_transfer':'FBX does not transfer node graphs; native reconstruction deferred.'}
for mi,folder,stem in [(2,'CivicSurfaces','CivicAsphalt'),(3,'BuildingSurfaces','CityMechanical')]:
 m=mats[mi];nt=m.node_tree;p=nt.nodes.get('Principled BSDF')
 tc=nt.nodes.new('ShaderNodeTexCoord');mapping=nt.nodes.new('ShaderNodeVectorMath');mapping.operation='SCALE';mapping.inputs[3].default_value=.5;nt.links.new(tc.outputs['UV'],mapping.inputs[0])
 tex={}
 for suffix in ['BaseColor','Normal','ORM']:
  rel=f'ArtSource/Textures/{folder}/{stem}_{suffix}.png';dst='/output/textures/'+Path(rel).name;shutil.copyfile('/repo/'+rel,dst)
  im=bpy.data.images.load(dst,check_existing=False);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color';im.pack()
  node=nt.nodes.new('ShaderNodeTexImage');node.image=im;nt.links.new(mapping.outputs[0],node.inputs['Vector']);tex[suffix]=node
  manifest['textures'].append({'source':rel,'copy':dst,'sha256':hashlib.sha256(Path(dst).read_bytes()).hexdigest(),'dimensions':list(im.size),'channels':im.channels,'colorspace':im.colorspace_settings.name,'material':m.name})
 sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(tex['ORM'].outputs['Color'],sep.inputs[0])
 mul=nt.nodes.new('ShaderNodeMixRGB');mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1;nt.links.new(tex['BaseColor'].outputs['Color'],mul.inputs[1]);nt.links.new(sep.outputs['Red'],mul.inputs[2]);nt.links.new(mul.outputs[0],p.inputs['Base Color'])
 nt.links.new(sep.outputs['Green'],p.inputs['Roughness']);nt.links.new(sep.outputs['Blue'],p.inputs['Metallic'])
 normal=nt.nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.3;nt.links.new(tex['Normal'].outputs['Color'],normal.inputs['Color']);nt.links.new(normal.outputs[0],p.inputs['Normal'])
 manifest.setdefault('connections',{})[m.name]=['UV metric projection * 0.5 -> image vectors','BaseColor sRGB * ORM.R AO -> Base Color','ORM.G -> Roughness','ORM.B -> Metallic','Normal Non-Color -> tangent NormalMap -> Normal']
nt=mats[0].node_tree;p=nt.nodes.get('Principled BSDF');noise=nt.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=7;bump=nt.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.05;nt.links.new(noise.outputs['Fac'],bump.inputs['Height']);nt.links.new(bump.outputs[0],p.inputs['Normal'])
objects=[]
def adopt(o,mat):
 o.data.materials.clear();o.data.materials.append(mats[mat]);objects.append(o);return o
def B(n,d,l,mat=1):return adopt(box(n,d,l,colors[mat]),mat)
def C(n,r,h,l,mat=3,v=20):return adopt(cylinder(n,r,h,l,colors[mat],vertices=v),mat)
def pipe(n,a,b,r=.18,v=12):
 a,b=Vector(a),Vector(b);o=C(n,r,(b-a).length,(a+b)/2,3,v);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
B('Generation hall',(14,19,6.4),(5,3,3.2),0)
B('Hall fascia',(14.3,19.3,.35),(5,3,6.45),2)
for x in [-1.8,11.8]:
 for y in [-6.2,-2.5,1.2,4.9,8.6,12.2]:B('Hall structural pilaster',(.24,.32,6.3),(x,y,3.15),1)
for y in [-4,0,4,8]:
 B('East clerestory pane',(.09,2.5,1.15),(12.04,y,4.65),4)
 B('East window head',(.17,2.7,.12),(12.1,y,5.28),1)
B('Raised roof monitor',(5.3,14,1.15),(5,3,7.15),1)
B('Monitor cap',(5.8,14.5,.22),(5,3,7.83),2)
for side in [2.31,7.69]:
 for y in [-2.5,0,2.5,5,7.5]:
  B('Monitor ventilation panel',(.08,1.9,.55),(side,y,7.23),4)
  for z in [7.05,7.23,7.41]:B('Monitor louver',(.15,1.95,.045),(side,y,z),3)
B('Worker control building',(9,7,5.9),(-9,-8,2.95),1)
B('Control roof coping',(9.35,7.35,.25),(-9,-8,6.02),2)
for x in [-12,-9,-6]:
 for z in [1.6,4.3]:
  if x==-9 and z==1.6:continue
  B('Control front window frame',(1.85,.16,1.5),(x,-11.55,z),0)
  B('Control front opaque glazing',(1.6,.10,1.26),(x,-11.66,z),4)
for y in [-9,-6]:
 for z in [1.6,4.3]:B('West staff window',(.08,1.6,1.25),(-13.54,y,z),4)
portalP=[];portalV=[]
def PB(n,d,l,mat,arr):
 o=B(n,d,l,mat);arr.append(o.name);return o
PB('Personnel door leaf',(1.2,.16,2.2),(-9,-11.6,1.1),4,portalP)
PB('Personnel handle',(.06,.14,.34),(-8.57,-11.76,1.12),3,portalP)
for x in [-9.69,-8.31]:PB('Personnel jamb',(.14,.25,2.3),(x,-11.61,1.15),0,portalP)
PB('Personnel lintel',(1.52,.25,.14),(-9,-11.61,2.37),0,portalP)
B('Personnel canopy',(2.8,1.3,.16),(-9,-11.9,2.82),2)
PB('Service shutter',(4,.16,3.5),(6,-6.58,1.75),3,portalV)
for z in [.35,.8,1.25,1.7,2.15,2.6,3.05]:PB('Shutter horizontal seam',(3.95,.055,.035),(6,-6.69,z),2,portalV)
for x in [3.85,8.15]:PB('Service bay jamb',(.25,.3,3.65),(x,-6.58,1.825),1,portalV)
PB('Service bay lintel',(4.55,.3,.24),(6,-6.58,3.72),1,portalV)
B('Service bay hood',(5,1.0,.17),(6,-6.85,4.05),2)
def tank(label,y):
 x=-10;r=3.5;N=32
 rings=[(r,0),(r,5.35),(3.57,5.4),(3.57,5.57),(.65,5.95)]
 vs=[(x+rr*math.cos(i*2*math.pi/N),y+rr*math.sin(i*2*math.pi/N),z) for rr,z in rings for i in range(N)]
 fs=[tuple(reversed(range(N)))]
 for j in range(len(rings)-1):
  for i in range(N):fs.append((j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i))
 fs.append(tuple((len(rings)-1)*N+i for i in range(N)))
 mesh=bpy.data.meshes.new(label);mesh.from_pydata(vs,[],fs);mesh.update();o=bpy.data.objects.new(label,mesh);bpy.context.collection.objects.link(o);adopt(o,1)
 for poly in mesh.polygons:
  if len(poly.vertices)==4 and poly.index<=N:poly.use_smooth=True
 C(label+' roof hatch',.52,.16,(x,y,6.02),3,20)
 C(label+' short breather',.16,.48,(x+.9,y,6.05),3,12)
 C(label+' breather cap',.28,.09,(x+.9,y,6.32),2,12)
 for z in [.23,5.25]:
  C(label+' shell collar',3.525,.065,(x,y,z),3,32)
 for z in [.45,1,1.55,2.1,2.65,3.2,3.75,4.3,4.85]:pipe(label+' ladder rung',(x-1,y-3.57,z),(x-.35,y-3.57,z),.035,8)
 for xx in [x-1.04,x-.31]:pipe(label+' ladder rail',(xx,y-3.6,.25),(xx,y-3.6,5.65),.045,8)
tank('Fuel tank A',1);tank('Fuel tank B',9)
for x in [-5.65,-3.45]:
 for y in [1.4,4.4]:B('Pump frame foot',(.14,.18,.7),(x,y,.35),3)
for x in [-5.65,-3.45]:B('Pump skid rail',(.16,3.3,.18),(x,2.9,.7),3)
for y in [2,3.9]:
 pipe('Pump motor',(-5.1,y,1),(-4.15,y,1),.36,20)
 pipe('Pump outlet riser',(-3.8,y,.8),(-3.8,y,2.1),.18)
 C('Valve bonnet',.26,.15,(-3.8,y,2.2),3,12)
 pipe('Valve spindle',(-3.8,y,2.2),(-3.8,y,2.55),.065,8)
 C('Valve handwheel',.29,.06,(-3.8,y,2.56),4,16)
for y in [1,9]:
 pipe('Fuel feed transverse',(-6.6,y,1.15),(-3,y,1.15),.22)
 pipe('Fuel feed riser',(-3,y,1.15),(-3,y,2.8),.22)
pipe('Main fuel header',(-3,1,2.8),(-3,9,2.8),.24)
pipe('Header to turbine hall',(-3,5,2.8),(-1.8,5,2.8),.24)
pipe('Exhaust duct',(9,10,6.8),(10.6,10,6.8),.55,20)
C('Exhaust stack',.57,5,(10.6,10,8.9),3,24)
for z in [6.7,9,11.35]:C('Stack collar',.65,.13,(10.6,10,z),2,24)
C('Stack dark terminal',.48,.035,(10.6,10,11.43),2,24)
for y in [-1.5,1.0,3.5]:
 B('Switchgear cabinet',(1.65,1.8,2.3),(14,y,1.15),1)
 B('Switchgear inset panel',(.09,1.45,1.8),(14.86,y,1.2),3)
 B('Switchgear latch',(.12,.08,.22),(14.95,y-.4,1.2),3)
 B('Switchgear cap',(1.85,1.95,.12),(14,y,2.36),2)
bpy.ops.object.select_all(action='DESELECT')
for o in objects:
 o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o.select_set(False)
bpy.context.view_layer.update()
components=[]
for o in objects:
 coords=[o.matrix_world@v.co for v in o.data.vertices];lo=[min(v[i] for v in coords) for i in range(3)];hi=[max(v[i] for v in coords) for i in range(3)]
 assert lo[0]>=-15.5 and lo[1]>=-15.5 and hi[0]<=15.5 and hi[1]<=15.5 and lo[2]>=-0.00001,(o.name,lo,hi)
 components.append({'name':o.name,'min':lo,'max':hi})
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UVMap')
 for f in o.data.polygons:
  axis=max(range(3),key=lambda i:abs(f.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in f.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]],co[axes[1]])
anchors=[]
for role,x,y,w,h,port in [('pedestrian',-9,-11.6,1.8,2.4,portalP),('vehicle_service',6,-6.58,4,3.5,portalV)]:
 bounds=[c for c in components if c['name'] in port];end=min(y-.02,min(c['min'][1] for c in bounds)-.02)
 lo=[x-w/2,-16,0];hi=[x+w/2,end,h]
 hits=[c['name'] for c in components if all(c['max'][i]>lo[i]+1e-6 and c['min'][i]<hi[i]-1e-6 for i in range(3))]
 assert not hits,(role,hits)
 anchors.append({'role':role,'target':port[0],'xyz_m':[x,y,0],'outward':[0,-1,0],'width_m':1.2 if role=='pedestrian' else 4,'grade_m':0,'boundary_connector':{'xyz_m':[x,-16,0],'outward':[0,-1,0],'width_m':w,'grade_m':0},'reserved_free_corridor':{'min':lo,'max':hi},'portal_components':bounds,'overlaps':hits})
Path('/output/entrance-anchors.json').write_text(json.dumps({'anchors':anchors},indent=2))
Path('/output/material-manifest.json').write_text(json.dumps(manifest,indent=2))
tri=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in objects);assert tri<=5000,tri
bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0]
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
p='/output/validation.json';report=json.loads(Path(p).read_text())
report.update({'review_only':True,'components_before_join':components,'source_triangles_measured':tri,'plot_bounds_xy_m':[-15.5,15.5],'entrance_corridors':anchors,'ground_contract':{'no_ground_or_foundation_mesh':True,'front_boundary_y_m':-16,'grade_z_m':0},'semantic_regions':names,'uv':'Metric dominant face UV0; texture vector scale 0.5','lod_plan':'Preserve hall/monitor silhouette, closed tanks, entrances and major pipe routing. Later reduce circular segments, omit tiny louvers, ladders, handles and flanges; merge secondary machines. LOD0 only; no platform performance claim.','references':refs})
Path(p).write_text(json.dumps(report,indent=2))
Path('/output/provenance.json').write_text(json.dumps({'purpose':'Oil power review-only initial LOD0','source_sha':'328d0b43668bdf2c3f15683aa72861e022cdee20','references':[{'path':r,'sha256':hashlib.sha256(Path('/repo/'+r).read_bytes()).hexdigest()} for r in refs],'production_inputs':'read-only; not changed','units':'metres Z up, front -Y','lod_plan':report['lod_plan']},indent=2))
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
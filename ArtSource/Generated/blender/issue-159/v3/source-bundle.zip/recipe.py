import bpy,sys,math,json
from pathlib import Path
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous
parents=load_previous()
for o in list(parents):
 bpy.data.objects.remove(o,do_unlink=True)
for mesh in list(bpy.data.meshes):
 if mesh.users==0:bpy.data.meshes.remove(mesh)
for mat in list(bpy.data.materials):
 if mat.users==0:bpy.data.materials.remove(mat)
s=Path('/previous/recipe.py').read_text()
s=s.replace("tri<=5000","tri<=6000")
s=s.replace('x=-10;r=3.5;N=32','x=-10;r=3.5;N=28').replace('(x,y,z),3,32)','(x,y,z),3,28)')
s=s.replace("(side,y,7.23),4)","(side,y,7.23),3)")
# Complete, wall-mounted rims instead of isolated panes or solid false frames.
a=s.index('for y in [-4,0,4,8]:')
b=s.index("B('Raised roof monitor'",a)
s=s[:a]+'''window_records=[]
def W(label,wall,center,width,height,normal):
 x,y,z=center
 side=abs(normal[0])>0
 thickness=.10;rim=.10
 if side:
  pane=B(label+' pane',(.10,width,height),(x,y,z),4)
  frames=[B(label+' '+tag,(.17,rim,height+2*rim),(x+normal[0]*.03,y+sign*(width+rim)/2,z),1) for tag,sign in [('jamb A',-1),('jamb B',1)]]
  frames += [B(label+' '+tag,(.17,width,rim),(x+normal[0]*.03,y,z+sign*(height+rim)/2),1) for tag,sign in [('sill',-1),('head',1)]]
 else:
  pane=B(label+' pane',(width,.10,height),(x,y,z),4)
  frames=[B(label+' '+tag,(rim,.17,height+2*rim),(x+sign*(width+rim)/2,y+normal[1]*.03,z),1) for tag,sign in [('jamb A',-1),('jamb B',1)]]
  frames += [B(label+' '+tag,(width,.17,rim),(x,y+normal[1]*.03,z+sign*(height+rim)/2),1) for tag,sign in [('sill',-1),('head',1)]]
 window_records.append({'pane':pane.name,'frames':[o.name for o in frames],'backing_solid':wall,'wall_normal':normal})
for y in [-4,0,4,8]:W('East clerestory '+str(y),'Generation hall',(12.04,y,4.65),2.5,1.15,[1,0,0])
''' +s[b:]
a=s.index('for x in [-12,-9,-6]:');b=s.index('portalP=[]',a)
s=s[:a]+'''for x in [-12,-9,-6]:
 for z in [1.6,4.3]:
  if x==-9 and z==1.6:continue
  W('Control front '+str(x)+' '+str(z),'Worker control building',(x,-11.54,z),1.6,1.26,[0,-1,0])
for y in [-9,-6]:
 for z in [1.6,4.3]:W('West staff '+str(y)+' '+str(z),'Worker control building',(-13.54,y,z),1.6,1.25,[-1,0,0])
''' +s[b:]
a=s.index("pipe('Exhaust duct'");b=s.index('for y in [-1.5,1.0,3.5]:',a)
s=s[:a]+'''# Hollow exhausts: outer shell, thick annular lip, inner liner and recessed floor.
def well(label,x,y,z0,z1,r,inner,depth,material=3,N=16):
 rings=[(r,z0),(r,z1),(inner,z1),(inner,z1-depth)]
 vs=[(x+rr*math.cos(i*2*math.pi/N),y+rr*math.sin(i*2*math.pi/N),z) for rr,z in rings for i in range(N)]
 fs=[]
 for j in range(3):
  for i in range(N):fs.append((j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i))
 fs.append(tuple(3*N+i for i in range(N)))
 me=bpy.data.meshes.new(label);me.from_pydata(vs,[],fs);me.update()
 ob=bpy.data.objects.new(label,me);bpy.context.collection.objects.link(ob);adopt(ob,material)
 return ob
for x,top in [(9,13.4),(11,12.9)]:
 well('Open exhaust stack '+str(x),x,10,6.4,top,.73,.56,1.8)
 # Ring is open too: no solid disk masking the mouth.
 well('Stack open rim '+str(x),x,10,top-.12,top+.06,.79,.56,.18,2)
 pipe('Short exhaust duct '+str(x),(x,8.5,6.95),(x,10,6.95),.48,16)
# Compact side-mounted two-cell mechanical-draft cooling unit on physical legs.
for x in [12.55,15.05]:
 for y in [6.65,11.05]:B('Cooling support leg',(.20,.20,.65),(x,y,.325),3)
B('Cooling louvered body',(3,5,3.3),(13.8,8.85,2.25),1)
B('Cooling lower casing',(3.12,5.12,.18),(13.8,8.85,.72),3)
# Separate top deck strips leave the two fan wells open.
for x in [12.39,15.21]:B('Cooling deck edge',(.18,5.1,.15),(x,8.85,3.95),2)
for y in [6.39,8.85,11.31]:B('Cooling deck cross edge',(2.7,.16,.15),(13.8,y,3.95),2)
for x in [12.26,15.34]:
 for z in [1.1,1.5,1.9,2.3,2.7,3.1,3.5]:B('Cooling horizontal louver',(.14,4.7,.12),(x,8.85,z),3)
for y in [7.58,10.12]:
 well('Cooling fan open shroud '+str(y),13.8,y,3.9,4.65,1.13,.97,.70,3,16)
 C('Cooling fan hub',.20,.24,(13.8,y,4.14),3,12)
 for angle in [0,math.pi/2,math.pi,3*math.pi/2]:
  o=B('Cooling fan blade',(.76,.19,.055),(13.8+.48*math.cos(angle),y+.48*math.sin(angle),4.13),2)
  o.rotation_euler[2]=angle+.24
''' +s[b:]
# Capture real measured window assemblies before joining.
a=s.index('anchors=[]')
s=s[:a]+'''by_name={c['name']:c for c in components}
for rec in window_records:
 rec['measured_bounds']={n:by_name[n] for n in [rec['pane'],rec['backing_solid']]+rec['frames']}
 pane=by_name[rec['pane']];wall=by_name[rec['backing_solid']]
 axis=next(i for i,v in enumerate(rec['wall_normal']) if v)
 tangents=[i for i in range(3) if i!=axis]
 for n in [rec['pane']]+rec['frames']:
  c=by_name[n]
  assert all(c['min'][i]>=wall['min'][i]-1e-5 and c['max'][i]<=wall['max'][i]+1e-5 for i in tangents),(n,'overhang')
  assert c['min'][axis]<=wall['max'][axis]+1e-5 and c['max'][axis]>=wall['min'][axis]-1e-5,(n,'detached')
 rec['complete_rim']=len(rec['frames'])==4
 rec['wall_mount_pass']=True
Path('/output/window-mounts.json').write_text(json.dumps({'windows':window_records,'all_mounts_pass':True},indent=2))
''' +s[a:]
s=s.replace("'purpose':'Oil power review-only initial LOD0'","'purpose':'Oil power exhaust and compact cooling revision, review-only LOD0'")
s=s.replace("'review_only':True,","'review_only':True,'revision':'Tall twin open exhaust stacks and two-cell mechanical draft cooler; retained v2 facility composition','triangle_ceiling':6000,'window_mounts_pass':True,")
# Keep a runnable revised recipe, not an invocation of a missing parent.
Path('/output/recipe.py').write_text(s)
exec(compile(s,'/output/recipe.py','exec'))

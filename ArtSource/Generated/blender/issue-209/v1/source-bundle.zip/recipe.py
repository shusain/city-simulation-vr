import bpy, sys, math, json
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import box, cylinder, finish
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
# New, isolated review geometry only; repository sources are never modified.
wood=(0.48,0.29,0.15,1)
coral=(0.72,0.29,0.23,1)
objects=[]
def block(name,dims,loc,col=wood):
    o=box(name,dims,loc,col); objects.append(o); return o
def rail(name,a,b,width=.035,depth=.035,col=wood):
    a,b=Vector(a),Vector(b)
    o=block(name,(width,depth,(b-a).length),(a+b)/2,col)
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    return o
# Width 0.70m, low 0.39m seat. Front is -Y.
for s in [-1,1]:
    x=s*.302
    rail('Long folding back stile', (x,-.292,.019),(x,.297,.881),.038,.038)
    rail('Crossed folding leg', (x,.292,.019),(x,-.238,.483),.038,.038)
    block('Flat wooden armrest',(.096,.49,.035),(s*.302,-.025,.555))
    rail('Front arm support',(x,-.225,.39),(x,-.225,.538),.028,.028)
# Fabric seat and reclined back: broad uninterrupted low-poly canvas.
rail('Canvas seat', (0,-.251,.387),(0,.120,.421),.548,.014,coral)
rail('Canvas back', (0,.121,.439),(0,.284,.857),.548,.014,coral)
# Structural rungs, visible beneath canvas edges.
for name,y,z in [('Seat front rung',-.261,.373),('Seat rear rung',.121,.409),('Back top rung',.288,.865),('Rear low brace',.249,.080)]:
    rail(name,(-.302,y,z),(.302,y,z),.027,.027)
# Six-sided wooden hinge pins keep the simple construction readable.
for s in [-1,1]:
    o=cylinder('Folding pivot pin',.026,.018,(s*.326,-.03,.390),wood,vertices=6)
    o.rotation_euler[1]=math.pi/2
    objects.append(o)
# Consolidate to exactly the requested semantic material slots.
frame=bpy.data.materials.new('Frame'); frame.diffuse_color=wood; frame.use_nodes=True
fabric=bpy.data.materials.new('Fabric'); fabric.diffuse_color=coral; fabric.use_nodes=True
for m,c,r in [(frame,wood,.68),(fabric,coral,.88)]:
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=c; p.inputs['Roughness'].default_value=r
for o in objects:
    o.data.materials.clear(); o.data.materials.append(fabric if o.name.startswith('Canvas') else frame)
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.join()
asset=bpy.context.object; asset.name='D108_Resident_Folding_Beach_Chair_REVIEW'
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish([asset])
# Retain the tested lighting/scene setup, add explicit focused source checks and views.
asset=bpy.data.objects.get('D108_Resident_Folding_Beach_Chair_REVIEW') or max((o for o in bpy.context.scene.objects if o.type=='MESH'),key=lambda o:len(o.data.vertices))
bpy.ops.object.select_all(action='DESELECT'); asset.select_set(True); bpy.context.view_layer.objects.active=asset
bpy.context.scene.cursor.location=(0,0,0); bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
# Canonicalize material order irrespective of the helper's joining order.
old=list(asset.data.materials)
indices=[0 if old[p.material_index].name.split('.')[0]=='Frame' else 1 for p in asset.data.polygons]
asset.data.materials.clear(); asset.data.materials.append(frame); asset.data.materials.append(fabric)
for p,i in zip(asset.data.polygons,indices):p.material_index=i
asset.data.calc_loop_triangles(); tris=len(asset.data.loop_triangles)
assert 180<=tris<=340, tris
with checked_fbx(asset,'/output/asset.fbx',['Frame','Fabric'],expected_triangles=tris,expected_sections=2):pass
scene=bpy.context.scene
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
cam.data.type='ORTHO';cam.data.ortho_scale=1.22
for filename,pos,target in [('preview.png',(1.35,-1.85,1.20),(0,0,.44)),('front_1m_scale.png',(0,-2,.46),(0,0,.46)),('side.png',(2,0,.46),(0,0,.46))]:
    cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    if filename=='front_1m_scale.png':cam.data.ortho_scale=1.0
    else:cam.data.ortho_scale=1.22
    scene.render.filepath='/output/'+filename;bpy.ops.render.render(write_still=True)
cam.location=(1.35,-1.85,1.20);cam.rotation_euler=(Vector((0,0,.44))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=1.22
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p=Path('/output/validation.json')
try: validation=json.loads(p.read_text())
except Exception:validation={}
validation['chair_review']={'triangles':tris,'triangle_target_pass':180<=tris<=340,'dimensions_m':list(asset.dimensions),'materials':['Frame','Fabric'],'fbx_roundtrip_pass':True,'origin':list(asset.location),'scale':list(asset.scale),'front_view_vertical_span_m':1.0,'review_only':True,'device_or_visual_acceptance_claimed':False}
p.write_text(json.dumps(validation,indent=2))
Path('/output/manifest.json').write_text(json.dumps({'issue':'D108 resident folding beach chair source review','status':'review-only; not approved for production','pose':'static open','units':'meters','up':'Z','front':'-Y','source':'asset.blend','export':'asset.fbx','views':['preview.png','front_1m_scale.png','side.png'],'palette':'quiet coral canvas and warm wood','ground_base_in_asset':False,'repository_inputs_modified':False},indent=2))

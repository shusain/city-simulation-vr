"""Small tested conveniences for agent-authored review studies; not production promotion."""
import bpy, hashlib, json, sys
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,"/repo/Tools")
from CityBuildingStudyIO import checked_fbx

# Start from a fresh scene, independent of desktop preferences.
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)

def material(name,color):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color=tuple(color);m.use_nodes=True
    bsdf=m.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value=tuple(color)
    bsdf.inputs["Roughness"].default_value=.7
    return m

def box(name,dimensions,location,colorRGBA=(.45,.15,.09,1)):
    bpy.ops.mesh.primitive_cube_add(size=1,location=tuple(location))
    obj=bpy.context.object;obj.name=name;obj.dimensions=tuple(dimensions)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    obj.data.materials.append(material(name+"Material",colorRGBA))
    return obj

def cylinder(name,radius,depth,location,colorRGBA=(.22,.22,.24,1),vertices=12):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=tuple(location))
    obj=bpy.context.object;obj.name=name
    obj.data.materials.append(material(name+"Material",colorRGBA))
    return obj

def load_previous():
    """Open the immutable parent blend and remove only the review stage."""
    source=Path("/previous/asset.blend")
    if not source.is_file(): raise ValueError("This revision has no completed parent blend")
    bpy.ops.wm.open_mainfile(filepath=str(source), load_ui=False, use_scripts=False)
    for obj in list(bpy.data.objects):
        if obj.type in ("CAMERA","LIGHT") or obj.name.startswith("ReviewGround"):
            bpy.data.objects.remove(obj,do_unlink=True)
    meshes=[o for o in bpy.context.scene.objects if o.type=="MESH"]
    if not meshes:raise ValueError("Parent blend contains no asset mesh")
    return meshes

def finish(objects,target=None):
    """Join supplied meshes; checked FBX, editable blend, CPU PNG and actual metrics."""
    if not objects or any(o.type!="MESH" for o in objects):raise ValueError("Pass the authored mesh objects to finish")
    bpy.ops.object.select_all(action="DESELECT")
    for obj in objects:obj.select_set(True)
    bpy.context.view_layer.objects.active=objects[0]
    bpy.ops.object.join()
    obj=bpy.context.object;obj.name="ReviewStudy"
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    bpy.context.view_layer.update();obj.data.calc_loop_triangles()
    slots=[m.name for m in obj.data.materials]
    geometry=json.dumps({"vertices":[list(v.co) for v in obj.data.vertices],"polygons":[list(p.vertices) for p in obj.data.polygons]},sort_keys=True).encode()
    before=dict(mesh_geometry_sha256=hashlib.sha256(geometry).hexdigest(),dimensions_m=list(obj.dimensions),triangles=len(obj.data.loop_triangles),material_slots=slots)
    with checked_fbx(obj,Path("/output/asset.fbx"),slots):
        before["roundtrip_pass"]=True
    # Stable material and lighting for a human-readable review image.
    corners=[obj.matrix_world@Vector(v) for v in obj.bound_box]
    low=Vector(tuple(min(v[i] for v in corners) for i in range(3)))
    high=Vector(tuple(max(v[i] for v in corners) for i in range(3)))
    center=(low+high)*.5 if target is None else Vector(target)
    extent=max(high-low)
    ground=box("ReviewGround",(max(20,extent*3),max(20,extent*3),.05),(center.x,center.y,low.z-.05),(.30,.33,.36,1))
    bpy.ops.object.camera_add(location=center+Vector((1.2,-1.5,1.1))*extent)
    camera=bpy.context.object;camera.rotation_euler=(center-camera.location).to_track_quat("-Z","Y").to_euler()
    camera.data.type="ORTHO";camera.data.ortho_scale=extent*1.9
    scene=bpy.context.scene;scene.camera=camera
    bpy.ops.object.light_add(type="AREA",location=center+Vector((.1,-.8,1.6))*extent)
    light=bpy.context.object;light.data.energy=1800;light.data.shape="DISK";light.data.size=extent
    light.rotation_euler=(center-light.location).to_track_quat("-Z","Y").to_euler()
    scene.world=scene.world or bpy.data.worlds.new("ReviewWorld")
    scene.world.use_nodes=True;scene.world.node_tree.nodes["Background"].inputs["Color"].default_value=(.5,.55,.6,1)
    scene.world.node_tree.nodes["Background"].inputs["Strength"].default_value=.6
    scene.render.engine="CYCLES";scene.cycles.device="CPU";scene.cycles.samples=16
    scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
    scene.render.image_settings.file_format="PNG";scene.render.filepath="/output/preview.png"
    scene.view_settings.view_transform="AgX"
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath="/output/asset.blend")
    bpy.ops.render.render(write_still=True)
    references={}
    root=Path("/repo/ArtSource")
    if root.exists():
        for f in sorted(root.rglob("*")):
            if f.is_file():references[str(f.relative_to(Path("/repo")))]=hashlib.sha256(f.read_bytes()).hexdigest()
    before.update(blender_version=bpy.app.version_string,render_engine="CYCLES",render_device="CPU",reference_sha256=references)
    Path("/output/validation.json").write_text(json.dumps(before,indent=2))
    return before

import bpy, sys, math, json
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import finish
# A single watertight extrusion of a curled fabric cross-section. No cloth simulation.
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
# Section in Y/Z: flat underside, 288-degree rolled end, inner return, flat top.
section=[(-.90,0.0),(-.88,0.0),(.84,0.0)]
steps=18
angles=[-math.pi/2+(1.1*math.pi+math.pi/2)*i/steps for i in range(1,steps+1)]
for a in angles: section.append((.84+.060*math.cos(a),.060+.060*math.sin(a)))
for a in reversed([-math.pi/2]+angles): section.append((.84+.048*math.cos(a),.060+.048*math.sin(a)))
section.extend([(-.88,.012),(-.90,.012)])
n=len(section)
verts=[]
for sign in (-1,1):
    for y,z in section:
        width=.355 if y<-.899 else .375
        verts.append((sign*width,y,z))
faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
for i in range(n):
    j=(i+1)%n
    faces.append((i,j,n+j,n+i))
mesh=bpy.data.meshes.new('Closed_faceted_woven_mat_mesh')
mesh.from_pydata(verts,[],faces);mesh.update()
obj=bpy.data.objects.new('D108_Resident_RolledEdge_BeachMat',mesh)
bpy.context.collection.objects.link(obj)
# Recalculate consistent outward normals without changing topology.
import bmesh
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
mat=bpy.data.materials.new('Fabric');mat.diffuse_color=(.56,.245,.18,1);mat.use_nodes=True
p=mat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=mat.diffuse_color;p.inputs['Roughness'].default_value=.88
obj.data.materials.append(mat)
# Planar UVs retained for future fabric work; intentionally no pattern or logos.
uv=mesh.uv_layers.new(name='UVMap')
for poly in mesh.polygons:
    for li in poly.loop_indices:
        v=mesh.vertices[mesh.loops[li].vertex_index].co
        uv.data[li].uv=((v.x+.375)/.75,(v.y+.9)/1.8)
finish([obj])
# Keep the source origin at ground-contact center, irrespective of preview framing.
assets=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.data==mesh]
if not assets:
    assets=[o for o in bpy.context.scene.objects if o.type=='MESH' and 'mat' in o.name.lower()]
asset=assets[0] if assets else obj
bpy.ops.object.select_all(action='DESELECT');asset.select_set(True);bpy.context.view_layer.objects.active=asset
bpy.context.scene.cursor.location=(0,0,0)
bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
# Re-check the final source export after origin normalization.
sys.path.insert(0,'/repo/Tools')
from CityBuildingStudyIO import checked_fbx
with checked_fbx(asset,'/output/asset.fbx',['Fabric']): pass
cam=scene.camera
cam.data.type='ORTHO';cam.data.ortho_scale=2.65
cam.location=(2.5,3.2,2.9);cam.rotation_euler=(Vector((0,0,.025))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath='/output/preview.png'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
bpy.ops.render.render(write_still=True)
cam.location=(0,0,4);cam.rotation_euler=(0,0,0);cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=2.25
scene.render.filepath='/output/top.png';bpy.ops.render.render(write_still=True)
# Separate review-only ruler, never included in source blend or FBX.
ruler_mat=bpy.data.materials.new('Review_Ruler');ruler_mat.diffuse_color=(.1,.24,.26,1)
def line(name,a,b,r=.003):
    curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';curve.bevel_depth=r;curve.bevel_resolution=0
    s=curve.splines.new('POLY');s.points.add(1)
    s.points[0].co=(*a,1);s.points[1].co=(*b,1)
    o=bpy.data.objects.new(name,curve);scene.collection.objects.link(o);o.data.materials.append(ruler_mat)
line('One_metre_reference',(.52,-.5,.01),(.52,.5,.01))
for i in range(11):
    y=-.5+i*.1;line('Ruler_tick',(.50,y,.01),(.56 if i in (0,5,10) else .54,y,.01))
curve=bpy.data.curves.new('Scale_label','FONT');curve.body='1 m';curve.size=.085
text=bpy.data.objects.new('Review_only_scale_label',curve);scene.collection.objects.link(text);text.location=(.59,-.07,.015);text.data.materials.append(ruler_mat)
scene.render.filepath='/output/scale_1m.png';bpy.ops.render.render(write_still=True)
asset.data.calc_loop_triangles();tri=len(asset.data.loop_triangles)
bm=bmesh.new();bm.from_mesh(asset.data);boundary=sum(not e.is_manifold for e in bm.edges);bm.free()
manifest={'issue':'D108 Resident rolled-edge beach mat','status':'review-only; not approved for production export or integration','dimensions_m':list(asset.dimensions),'triangles':tri,'material_slots':[m.name for m in asset.data.materials],'non_manifold_edges':boundary,'origin':'ground contact center, Z-up','units':'meters','views':['preview.png','top.png','scale_1m.png'],'design':'single coral fabric solid; flat rectangular mat with one faceted curled short edge; no sand base, logos, simulation, or transparency','source':'asset.blend','review_fbx':'asset.fbx'}
Path('/output/manifest.json').write_text(json.dumps(manifest,indent=2))
vp=Path('/output/validation.json');validation=json.loads(vp.read_text()) if vp.exists() else {}
validation['focused_mat_checks']=dict(manifest,triangle_target_pass=100<=tri<=200,closed_solid_pass=boundary==0,fbx_roundtrip_pass=True)
vp.write_text(json.dumps(validation,indent=2))

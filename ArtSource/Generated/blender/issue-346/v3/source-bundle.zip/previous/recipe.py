import bpy, sys, math, json
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
objects=load_previous()
# Localized geometry revision of the approved prior assembly, not a rebuild.
windshield_vertices=0
hub_components=0
for obj in objects:
 if obj.type!='MESH': continue
 me=obj.data
 adjacency=[set() for _ in me.vertices]
 for e in me.edges:
  a,b=e.vertices;adjacency[a].add(b);adjacency[b].add(a)
 unseen=set(range(len(me.vertices)))
 while unseen:
  seed=unseen.pop();comp={seed};todo=[seed]
  while todo:
   for j in adjacency[todo.pop()]:
    if j in unseen:unseen.remove(j);comp.add(j);todo.append(j)
  points=[obj.matrix_world @ me.vertices[i].co for i in comp]
  lo=[min(p[k] for p in points) for k in range(3)]
  hi=[max(p[k] for p in points) for k in range(3)]
  # Unique broad front glass quad from v1. Extend down the existing raked plane.
  if lo[0]>.40 and hi[0]<1.01 and lo[2]>.90 and hi[2]>1.39 and lo[1]<-.6 and hi[1]>.6:
   for i in comp:
    p=obj.matrix_world @ me.vertices[i].co
    if p.z<1.0:
     p.x+=.037;p.z-=.033;p.y*=1.025
     me.vertices[i].co=obj.matrix_world.inverted() @ p
     windshield_vertices+=1
  # All alloy faces, dark inset discs, center caps and spokes move inboard.
  # Tires have inner sidewall at |y|=.7225 and are explicitly excluded.
  if lo[2]>.07 and hi[2]<.61 and (lo[1]>.94 or hi[1]<-.94) and (abs((lo[0]+hi[0])/2)-1.28)**2<.08:
   s=1 if lo[1]>0 else -1
   for i in comp:
    p=obj.matrix_world @ me.vertices[i].co;p.y-=s*.067
    me.vertices[i].co=obj.matrix_world.inverted() @ p
   hub_components+=1
 me.update()
assert windshield_vertices==2,('Front glass selection',windshield_vertices)
assert hub_components>=20,('Hub selection',hub_components)
paint=next(m for o in objects for m in o.data.materials if m and m.name.split('.')[0]=='BodyPaint')
# Restrained painted arch lips bridge the body sides to the tire shoulders.
# Preserve the real open wheel clearance and all original body topology.
for x in (-1.28,1.28):
 for s in (-1,1):
  verts=[];faces=[];steps=24
  for j in range(steps+1):
   t=math.pi*j/steps
   for radius,y in ((.400,s*.853),(.444,s*.853),(.400,s*.922),(.444,s*.922)):
    verts.append((x+radius*math.cos(t),y,.34+radius*math.sin(t)))
  for j in range(steps):
   a=4*j;b=a+4
   for u,v in ((0,1),(1,3),(3,2),(2,0)):
    faces.append((a+u,b+u,b+v,a+v))
  faces.extend([(0,2,3,1),(4*steps,4*steps+1,4*steps+3,4*steps+2)])
  mesh=bpy.data.meshes.new('Painted arch lip');mesh.from_pydata(verts,[],faces);mesh.update()
  o=bpy.data.objects.new('Wheel arch fender',mesh);bpy.context.collection.objects.link(o);mesh.materials.append(paint)
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
  # Recalculate winding, then softly break the lip edges.
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
  mod=o.modifiers.new('Fender edge radius','BEVEL');mod.width=.007;mod.segments=2
  bpy.ops.object.modifier_apply(modifier=mod.name)
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.025);bpy.ops.object.mode_set(mode='OBJECT')
  objects.append(o)
finish(objects)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
loc=cam.location.copy();rot=cam.rotation_euler.copy();typ=cam.data.type;scale=cam.data.ortho_scale
for label,pos,sz in [('side',(0,-8,.76),4.95),('front',(8,0,.76),2.75),('rear',(-8,0,.76),2.75)]:
 cam.location=pos;cam.rotation_euler=(Vector((0,0,.74))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=sz
 scene.render.filepath='/output/'+label+'.png';bpy.ops.render.render(write_still=True)
cam.location=loc;cam.rotation_euler=rot;cam.data.type=typ;cam.data.ortho_scale=scale
scene.render.filepath='/output/preview.png';scene.unit_settings.system='METRIC'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p='/output/validation.json'
with open(p) as f:r=json.load(f)
r['revision_scope']='Review-only local edits to previous source: enlarged windshield downward, recessed existing hubs, four new painted wheel arch lips. No production changes or integration.'
r['revision_measurements']={'windshield_lower_edge_extension_m':.0496,'windshield_vertices_changed':windshield_vertices,'hub_inboard_offset_m':.067,'hub_components_changed':hub_components,'fender_count':4,'arch_clearance_radius_m':.400,'tire_radius_m':.340}
r['additional_views']=['side.png','front.png','rear.png']
r['material_semantics']='Retained BodyPaint, opaque glossy blue-gray Glass, Rubber, MetalTrim, pale Headlight and red Taillight. No emergency lens materials; native remapping remains later work.'
r['acceptance']='Human source review pending; no game or headset acceptance claimed.'
with open(p,'w') as f:json.dump(r,f,indent=2)

import bpy, sys, math, json
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous, finish
objects=load_previous()
changes={'glass_components':0,'glass_vertices':0,'wheel_trim_components':0}
# Edit the existing v2 assembly only. Retain body, tires, arch lips and lamps.
for obj in objects:
 if obj.type!='MESH': continue
 mesh=obj.data
 adj=[set() for v in mesh.vertices]
 for e in mesh.edges:
  a,b=e.vertices;adj[a].add(b);adj[b].add(a)
 polys_by_vertex=[[] for v in mesh.vertices]
 for p in mesh.polygons:
  for i in p.vertices: polys_by_vertex[i].append(p)
 unseen=set(range(len(mesh.vertices)))
 while unseen:
  seed=unseen.pop();comp={seed};todo=[seed]
  while todo:
   for j in adj[todo.pop()]:
    if j in unseen: unseen.remove(j);comp.add(j);todo.append(j)
  polys={p.index for i in comp for p in polys_by_vertex[i]}
  names={mesh.materials[mesh.polygons[p].material_index].name.split('.')[0] for p in polys if mesh.materials[mesh.polygons[p].material_index]}
  points={i:obj.matrix_world @ mesh.vertices[i].co for i in comp}
  lo=[min(p[k] for p in points.values()) for k in range(3)]
  hi=[max(p[k] for p in points.values()) for k in range(3)]
  center=sum(points.values(),Vector())/len(points)
  inv=obj.matrix_world.inverted()
  if names and all('glass' in n.lower() for n in names):
   # Small in-plane increase, then lift panes above the retained underlying shell.
   # Preserve each pane's rake and the existing body-colored pillar layout.
   normal=Vector()
   for pi in polys:
    p=mesh.polygons[pi];normal+=obj.matrix_world.to_3x3() @ p.normal * p.area
   if normal.length>0:
    normal.normalize()
    outward=Vector((0,0,1)) if abs(center.y)<.4 else Vector((0,1 if center.y>0 else -1,0))
    if abs(center.y)<.4 and abs(center.x)>.35: outward=Vector((1 if center.x>0 else -1,0,1)).normalized()
    if normal.dot(outward)<0: normal=-normal
    for i,p in points.items():
     delta=p-center
     tangent=delta-normal*delta.dot(normal)
     mesh.vertices[i].co=inv @ (p+tangent*.025+normal*.012)
    changes['glass_components']+=1;changes['glass_vertices']+=len(comp)
  # Existing wheel hardware was pushed inside the tire sidewall in v2.
  # Restore readable alloy discs/spokes, with a bounded near-flush outside face.
  elif lo[2]>.045 and hi[2]<.64 and abs(abs(center.x)-1.28)<.16 and abs(center.y)>.78 and max(hi[0]-lo[0],hi[2]-lo[2])<.61 and not any(('rubber' in n.lower() or 'body' in n.lower() or 'glass' in n.lower()) for n in names):
   s=1 if center.y>0 else -1
   for i,p in points.items():
    # Undo most of v2's 67mm recess without returning to the protruding v1 hardware.
    p.y=s*min(.970,max(.933,abs(p.y)+.050))
    mesh.vertices[i].co=inv @ p
   changes['wheel_trim_components']+=1
 mesh.update()
assert changes['glass_components']>0,changes
assert changes['wheel_trim_components']>=4,changes
for obj in objects:
 if obj.type!='MESH':continue
 for mat in obj.data.materials:
  if not mat:continue
  if 'glass' in mat.name.lower():
   mat.use_nodes=True;p=mat.node_tree.nodes.get('Principled BSDF')
   if p:
    p.inputs['Base Color'].default_value=(.045,.095,.135,1)
    p.inputs['Roughness'].default_value=.22
    p.inputs['Metallic'].default_value=.12
    p.inputs['Alpha'].default_value=1
    p.inputs['Transmission Weight'].default_value=0
   mat.diffuse_color=(.045,.095,.135,1)
# Preserve UVs of edited source geometry; no new mesh primitives are added.
finish(objects)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
cam=scene.camera
loc=cam.location.copy();rot=cam.rotation_euler.copy();typ=cam.data.type;scale=cam.data.ortho_scale
for label,pos,sz in [('side',(0,-8,.76),4.95),('front',(8,0,.76),2.75),('rear',(-8,0,.76),2.75)]:
 cam.location=pos;cam.rotation_euler=(Vector((0,0,.74))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=sz
 scene.render.filepath='/output/'+label+'.png';bpy.ops.render.render(write_still=True)
cam.location=loc;cam.rotation_euler=rot;cam.data.type=typ;cam.data.ortho_scale=scale
scene.render.filepath='/output/preview.png';scene.unit_settings.system='METRIC'
bpy.ops.wm.save_as_mainfile(filepath='/output/asset.blend')
p='/output/validation.json'
with open(p) as f:r=json.load(f)
r['revision_scope']='Review-only v3 localized edits of loaded v2 source. Existing glass enlarged 2.5 percent in its plane and lifted 12mm off shell; existing wheel trim brought outward with maximum absolute y 0.970m. Body, tires, lights and arch geometry retained. No production edits.'
r['revision_measurements']=changes
r['additional_views']=['side.png','front.png','rear.png']
r['material_semantics']='Glass is opaque blue-gray glossy Principled material for later native remapping. BodyPaint, Rubber, MetalTrim, Headlight and Taillight retained. No emergency lens or branding.'
r['acceptance']='Human review pending. Checked runner FBX is validation-only, not an approval handoff. No integration, game rendering or headset claims.'
with open(p,'w') as f:json.dump(r,f,indent=2)

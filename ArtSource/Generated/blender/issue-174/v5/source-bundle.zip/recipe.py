import bpy,sys,json,math,hashlib,shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,finish
objects=load_previous()
out=Path('/output');out.mkdir(exist_ok=True)
for p in Path('/previous').glob('*.json'):shutil.copy2(p,out/p.name)
def read(n,d):
 try:return json.loads((out/n).read_text())
 except:return d
def write(n,d):(out/n).write_text(json.dumps(d,indent=2))
def overlap(a,b):return all(min(a[1][k],b[1][k])-max(a[0][k],b[0][k])>1e-6 for k in range(3))
parts=[];before={};bounds={};components=[]
# Exact connected membership: build the group lookup ONCE per mesh, not per solid.
for o in objects:
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o.select_set(False)
 mesh=o.data
 memberships={g.index:set() for g in o.vertex_groups}
 for v in mesh.vertices:
  for binding in v.groups:
   if binding.weight>.5:memberships[binding.group].add(v.index)
 group_lookup={}
 for g in o.vertex_groups:group_lookup.setdefault(frozenset(memberships[g.index]),[]).append(g.name)
 parent=list(range(len(mesh.vertices)))
 def root(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 for e in mesh.edges:
  a,b=map(root,e.vertices);parent[a]=b
 chunks={}
 for v in mesh.vertices:chunks.setdefault(root(v.index),[]).append(v.index)
 before[o.name]={'vertices':[tuple(v.co) for v in mesh.vertices],'faces':[(tuple(p.vertices),p.material_index) for p in mesh.polygons],'uv':[[tuple(d.uv) for d in uv.data] for uv in mesh.uv_layers]}
 for ids in chunks.values():
  candidates=group_lookup.get(frozenset(ids),[])
  assert len(candidates)==1,(o.name,len(ids),candidates)
  n=candidates[0];assert memberships[o.vertex_groups[n].index]==set(ids)
  parts.append((n,o,ids))
assert len(parts)==521,len(parts)
assert len({n for n,o,ids in parts})==521
emblems=[p for p in parts if p[0].startswith('ScienceArt_')];assert len(emblems)==6
for n,o,ids in emblems:
 inv=o.matrix_world.inverted()
 for i in ids:
  p=o.matrix_world@o.data.vertices[i].co;p.x=-3+2*(p.x+3);p.z=5.53+2*(p.z-5.53);o.data.vertices[i].co=inv@p
for o in objects:o.data.update()
bpy.context.view_layer.update()
for n,o,ids in parts:
 pts=[o.matrix_world@o.data.vertices[i].co for i in ids];lo=[min(p[k] for p in pts) for k in range(3)];hi=[max(p[k] for p in pts) for k in range(3)]
 bounds[n]=[lo,hi];components.append({'name':n,'min':lo,'max':hi})
changed={}
for n,o,ids in parts:
 if not n.startswith('ScienceArt_'):
  assert all(tuple(o.data.vertices[i].co)==before[o.name]['vertices'][i] for i in ids),n
 changed.setdefault(o.name,set()).update(ids if n.startswith('ScienceArt_') else [])
for o in objects:
 s=before[o.name];assert s['faces']==[(tuple(p.vertices),p.material_index) for p in o.data.polygons]
 assert s['uv']==[[tuple(d.uv) for d in uv.data] for uv in o.data.uv_layers]
 for uv in o.data.uv_layers:
  assert all(math.isfinite(x) for d in uv.data for x in d.uv)
assert len(parts)-len(emblems)==515
plaque=bounds['ScienceArt_Teal_Plaque'];assert abs(plaque[0][0]+4.14)<1e-4 and abs(plaque[1][0]+1.86)<1e-4
assert abs(plaque[0][2]-4.39)<1e-4 and abs(plaque[1][2]-6.67)<1e-4
# Contact is measured against real solid wall and the actual relief solids.
wall_candidates=[n for n,b in bounds.items() if not n.startswith('ScienceArt_') and b[0][0]<=plaque[0][0] and b[1][0]>=plaque[1][0] and b[0][2]<=plaque[0][2] and b[1][2]>=plaque[1][2] and abs(b[0][1]+8)<.02 and b[1][1]-b[0][1]>.2]
assert wall_candidates
assert any(overlap(plaque,bounds[n]) for n in wall_candidates)
for n,o,ids in emblems:
 if n!='ScienceArt_Teal_Plaque':assert overlap(bounds[n],plaque),n
reservation=[[15,2,0],[23,19,14]]
for c in components:
 assert not overlap([c['min'],c['max']],reservation),c['name']
 assert c['min'][0]>=-23.5 and c['max'][0]<=23.5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5
mount=read('window-mounts.json',{'windows':[],'doors':[]})
pane_names=[n for n in bounds if n.endswith('_Pane') or (n.startswith('Pane_') and n[5:].isdigit())]
assert len(pane_names)==78,len(pane_names)
old={w['pane']:w for w in mount.get('windows',[]) if w.get('pane') in pane_names}
windows=[]
for n in pane_names:
 pb=bounds[n];w=old.get(n)
 if w is None:
  stem=n[:-5] if n.endswith('_Pane') else n
  fs=[q for q in bounds if q.startswith(stem+'_') and any(t in q.lower() for t in ['jamb','head','sill'])]
  assert len(fs)==4,(n,fs)
  axis=min([0,1],key=lambda k:pb[1][k]-pb[0][k]);t=1-axis;candidates=[]
  for q,b in bounds.items():
   if b[1][axis]-b[0][axis]<.2:continue
   if all(b[0][k]<=pb[0][k] and b[1][k]>=pb[1][k] for k in [t,2]):
    for sign in [-1,1]:
     face=b[1 if sign>0 else 0][axis];d=min(abs(pb[0][axis]-face),abs(pb[1][axis]-face))
     if d<.15:candidates.append((d,q,sign))
  assert candidates,n
  _,backing,sign=min(candidates)
  w={'pane':n,'frame_parts':fs,'backing':backing,'axis':axis,'sign':sign}
 axis=w['axis'];t=1-axis;sign=w['sign'];wb=bounds[w['backing']];fs=w['frame_parts'];assert len(fs)==4
 face=wb[1 if sign>0 else 0][axis]
 for f in fs:
  fb=bounds[f]
  for k in [t,2]:assert fb[0][k]>=wb[0][k]+.12-1e-5 and fb[1][k]<=wb[1][k]-.12+1e-5,(n,f,'containment')
  assert overlap(fb,wb),(n,f,'contact')
  assert not overlap(fb,pb),(n,f,'pane')
  assert not all(min(fb[1][k],pb[1][k])-max(fb[0][k],pb[0][k])>1e-6 for k in [t,2]),(n,f,'projected occlusion')
 for i,f in enumerate(fs):
  for g in fs[i+1:]:assert not overlap(bounds[f],bounds[g]),(f,g)
 # Pane sits within the four-part opening and close to the named wall face.
 rimlo=[min(bounds[f][0][k] for f in fs) for k in range(3)];rimhi=[max(bounds[f][1][k] for f in fs) for k in range(3)]
 for k in [t,2]:assert pb[0][k]>rimlo[k] and pb[1][k]<rimhi[k]
 depths=[sign*(pb[j][axis]-face) for j in [0,1]];assert min(depths)>=-.001 and max(depths)<.15,(n,depths)
 w.update({'pane_bounds':pb,'frame_bounds':{f:bounds[f] for f in fs},'wall_bounds':wb,'checks':{'containment':True,'rim_wall_contact':True,'opening':True,'corner_disjoint':True,'depth':True,'projected_frame_occlusion':False}});windows.append(w)
mount['windows']=windows
# Both inherited approach corridors remain empty including the enlarged relief.
anchors=read('entrance-anchors.json',{})
if not anchors.get('anchors'):
 anchors={'anchors':[]}
 for role,x,width in [('pedestrian',-3,1.8),('service',-15,2.4)]:
  names=[n for n,b in bounds.items() if 'door' in n.lower() and b[0][0]<=x+width/2 and b[1][0]>=x-width/2 and b[0][2]<.1]
  assert names,(role,'door missing')
  front=min(bounds[n][0][1] for n in names)-.02
  anchors['anchors'].append({'role':role,'target':names[0],'xyz_m':[x,front,0],'outward':[0,-1,0],'width_m':width,'grade_m':0,'boundary_connector':{'xyz_m':[x,-20,0],'outward':[0,-1,0],'width_m':width,'grade_m':0},'reserved_free_corridor':{'min':[x-width/2,-20,0],'max':[x+width/2,front,2.4 if role=='pedestrian' else 2.6]}})
assert len(anchors['anchors'])==2
for a in anchors['anchors']:
 c=a['reserved_free_corridor'];bb=[c['min'],c['max']]
 for n,b in bounds.items():assert not overlap(bb,b),(a['role'],n)
# Exact repository maps copied, SHA recorded, and packed without changing shader graphs.
tex=out/'textures';tex.mkdir(exist_ok=True);maps=[]
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for kind in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(family+'_'+kind+'.png');dst=tex/src.name;shutil.copy2(src,dst)
  ims=[im for im in bpy.data.images if Path(bpy.path.abspath(im.filepath)).name==src.name or im.name.split('.')[0]==src.stem];assert ims,src.name
  for im in ims:
   assert im.colorspace_settings.name==('sRGB' if kind=='BaseColor' else 'Non-Color')
   im.filepath=str(dst);im.pack()
  h=hashlib.sha256(src.read_bytes()).hexdigest();assert h==hashlib.sha256(dst.read_bytes()).hexdigest()
  maps.append({'source':str(src),'copy':str(dst),'source_sha256':h,'copy_sha256':h,'dimensions':list(ims[0].size),'colorspace':ims[0].colorspace_settings.name})
tri=0
for o in objects:o.data.calc_loop_triangles();tri+=len(o.data.loop_triangles)
assert tri==6952,tri
regions={m.name.split('.')[0] for o in objects for m in o.data.materials};assert len(regions)==6,regions
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
assets=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name!='ReviewGround']
assert len(assets)==1,[o.name for o in assets]
assets[0].data.calc_loop_triangles();assert len(assets[0].data.loop_triangles)==6952 and len(assets[0].data.materials)==6
v=read('validation.json',{});v.update({'components':components,'source_id':'building.college.a','review_only':True,'integration':'HELD','actual_connected_solids':521,'triangles_prejoin':tri,'semantic_regions':6,'preserved_non_emblem_solids':515,'unchanged_faces_material_assignments_uv':True,'exact_group_membership':True,'panes_validated':78,'all_window_checks_pass':True,'empty_future_reservation':True,'both_approaches_empty':True,'emblem_transform':{'center_xz':[-3,5.53],'factor_xz':2,'y_unchanged':True},'plaque_bounds':plaque,'wall_contact_components':wall_candidates,'post_finish_excludes':'ReviewGround'});write('validation.json',v)
write('window-mounts.json',mount);write('entrance-anchors.json',anchors)
m=read('material-manifest.json',{});m.update({'regions':sorted(regions),'maps':maps,'shader_policy':'Exact completed v3 node graphs and shader constants retained. ORM R=AO G=roughness B=metallic, tangent normals; native reconstruction deferred.','uv_repeat_m':2,'new_materials':False});write('material-manifest.json',m)
occupied=[[min(c['min'][k] for c in components) for k in range(3)],[max(c['max'][k] for c in components) for k in range(3)]]
u=read('upgrade-plan.json',{});u.update({'existing_stages':['base'],'existing_upgrade_count':0,'gameplay_changes':False,'current_footprint_m':[24,24],'source_proposal_m':[48,40],'retained_entrances':anchors['anchors'],'occupied_bounds':occupied,'future_reservations':[{'id':'east_rear','min':reservation[0],'max':reservation[1],'purpose':'hypothetical future wing'}],'measured_intersections':0});write('upgrade-plan.json',u)
ed=read('education-contract.json',{});ed.update({'source_id':'building.college.a','source_site_m':[48,40],'components':components,'occupied_bounds':occupied,'teaching_wings':2,'future_reservation':reservation,'integration':'HELD','groups':{r:[n for n in bounds if r in n.lower()] for r in ['wing','entry','hall','roof','lantern']}});write('education-contract.json',ed)
write('design-response.json',{'revision':'college174 v5 focused technical correction','parent':'exact completed v3','modified_components':[n for n,o,ids in emblems],'planar_factor':2,'center_xz':[-3,5.53],'plaque_bounds':plaque,'non_emblem_components_preserved':515,'total_components':521,'panes':78,'geometry_validation':'actual union-find components and exact one-pass group membership; full pane checks','integration':'HELD','human_review':'pending','lod_plan':'Preserve existing low-poly sources. LOD1 simplify rims and roof equipment and bake relief. LOD2 omit relief and simplify facade detail; not implemented.'})

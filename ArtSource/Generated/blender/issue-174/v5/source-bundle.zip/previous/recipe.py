import bpy,sys,math,json,hashlib,shutil
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,'/worker')
from CityRunnerPreview import load_previous,box,finish
objects=load_previous()
out=Path('/output'); out.mkdir(exist_ok=True)
# Retain the exact completed v2 meshes and shaders, adding only the requested identity features.
for p in Path('/previous').glob('*.json'):
 shutil.copy2(p,out/p.name)
materials={m.name.split('.')[0]:m for o in objects for m in o.data.materials if m}
assert set(['AcademicBrick','LightStone','RoofMembrane','EquipmentMetal','WindowGlass','CampusAccent'])<=set(materials)
for o in objects:
 bpy.context.view_layer.objects.active=o;o.select_set(True)
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 o.select_set(False)
# Record each actual connected inherited solid, using original component vertex groups.
components=[]; bounds={}; newnames=[]
def measure(o):
 bpy.context.view_layer.update();pts=[o.matrix_world@v.co for v in o.data.vertices]
 return [[min(p[k] for p in pts) for k in range(3)],[max(p[k] for p in pts) for k in range(3)]]
for o in objects:
 parent=list(range(len(o.data.vertices)))
 def root(i):
  while parent[i]!=i: parent[i]=parent[parent[i]];i=parent[i]
  return i
 for e in o.data.edges:
  a,b=map(root,e.vertices);parent[a]=b
 chunks={}
 for v in o.data.vertices:chunks.setdefault(root(v.index),[]).append(v.index)
 for ids in chunks.values():
  scores={}
  for i in ids:
   for g in o.data.vertices[i].groups:scores[g.group]=scores.get(g.group,0)+1
  name=o.vertex_groups[max(scores,key=scores.get)].name if scores else o.name
  if name in bounds:name=name+'_solid_'+str(len(components))
  pts=[o.matrix_world@o.data.vertices[i].co for i in ids];lo=[min(p[k] for p in pts) for k in range(3)];hi=[max(p[k] for p in pts) for k in range(3)]
  bounds[name]=[lo,hi];components.append({'name':name,'min':lo,'max':hi,'inherited':True})
  if o.vertex_groups.get(name) is None:
   vg=o.vertex_groups.new(name=name);vg.add(ids,1,'REPLACE')
original_components=len(components)
def B(n,lo,hi,mat):
 o=box(n,tuple(hi[i]-lo[i] for i in range(3)),tuple((hi[i]+lo[i])/2 for i in range(3)),materials[mat].diffuse_color)
 o.data.materials.clear();o.data.materials.append(materials[mat]);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o.select_set(False)
 vg=o.vertex_groups.get(n) or o.vertex_groups.new(name=n);vg.add(list(range(len(o.data.vertices))),1,'REPLACE')
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0')
 for f in o.data.polygons:
  ax=max(range(3),key=lambda i:abs(f.normal[i]));axes=[i for i in range(3) if i!=ax]
  for li in f.loop_indices:
   p=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(p[axes[0]]/2,p[axes[1]]/2)
 objects.append(o);bb=measure(o);bounds[n]=bb;components.append({'name':n,'min':bb[0],'max':bb[1],'inherited':False});newnames.append(n);return o
# Actual roof contact: the new commons structure starts on the existing lobby roof at 7.2m.
B('Lantern_Commons_Wall',[-5.8,-.5,7.2],[-.2,4.5,9.05],'LightStone')
B('Lantern_Teal_Base',[-5.88,-.58,7.2],[-.12,4.58,7.48],'CampusAccent')
B('Lantern_Teal_Cornice',[-5.9,-.6,8.96],[-.1,4.6,9.14],'CampusAccent')
B('Lantern_Stepped_Cap_Lower',[-6,-.7,9.14],[0,4.7,9.29],'RoofMembrane')
B('Lantern_Stepped_Cap_Upper',[-5.55,-.25,9.29],[-.45,4.25,9.44],'RoofMembrane')
newwindows=[]
def window(n,axis,sign,c,w):
 wall=bounds['Lantern_Commons_Wall'];t=1-axis;face=wall[1 if sign>0 else 0][axis];z=8.21;h=1.13;r=.085
 def rect(name,u0,u1,z0,z1,d0,d1,mat):
  lo=[0.,0.,z0];hi=[0.,0.,z1];lo[t]=u0;hi[t]=u1
  ds=[face+sign*d0,face+sign*d1];lo[axis]=min(ds);hi[axis]=max(ds);return B(name,lo,hi,mat)
 lo=c-w/2;hi=c+w/2;bot=z-h/2;top=z+h/2
 pane=n+'_Pane';rect(pane,lo+r+.006,hi-r-.006,bot+r+.006,top-r-.006,.026,.047,'WindowGlass')
 fs=[n+'_JambL',n+'_JambR',n+'_Sill',n+'_Head']
 rect(fs[0],lo,lo+r,bot,top,-.01,.095,'EquipmentMetal');rect(fs[1],hi-r,hi,bot,top,-.01,.095,'EquipmentMetal')
 rect(fs[2],lo+r+.001,hi-r-.001,bot,bot+r,-.01,.095,'EquipmentMetal');rect(fs[3],lo+r+.001,hi-r-.001,top-r,top,-.01,.095,'EquipmentMetal')
 newwindows.append({'pane':pane,'frame_parts':fs,'backing':'Lantern_Commons_Wall','axis':axis,'sign':sign,'pane_bounds':bounds[pane],'frame_bounds':{f:bounds[f] for f in fs},'wall_bounds':wall})
for s in [-1,1]:
 for i,c in enumerate([-4.45,-1.55]):window('Lantern_'+str(s)+'_FrontBack_'+str(i),1,s,c,2.15)
 window('Lantern_'+str(s)+'_End',0,s,2.,3.5)
# A compact atom + creative stylus relief on the blank central pier.
B('ScienceArt_Teal_Plaque',[-3.57,-8.16,4.96],[-2.43,-7.99,6.10],'CampusAccent')
# Closed low-segment orbit ribbons; flat, solid extrusions all contact the plaque.
def ribbon(n,angle,rx,rz,width,mat):
 verts=[];N=16;ca=math.cos(angle);sa=math.sin(angle)
 for y in [-8.195,-8.155]:
  for rad in [1.,-1.]:
   for j in range(N):
    a=2*math.pi*j/N;x=(rx+rad*width/2)*math.cos(a);z=(rz+rad*width/2)*math.sin(a)
    verts.append((-3+x*ca-z*sa,y,5.53+x*sa+z*ca))
 faces=[]
 for j in range(N):
  k=(j+1)%N
  faces.extend([(j,k,16+k,16+j),(32+j,48+j,48+k,32+k),(j,32+j,32+k,k),(16+j,16+k,48+k,48+j)])
 mesh=bpy.data.meshes.new(n);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(n,mesh);bpy.context.collection.objects.link(o);mesh.materials.append(materials[mat]);vg=o.vertex_groups.new(name=n);vg.add(list(range(len(verts))),1,'REPLACE')
 uv=mesh.uv_layers.new(name='UV0')
 for p in mesh.polygons:
  for li in p.loop_indices:
   v=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=(v.x/2,v.z/2)
 objects.append(o);bb=measure(o);bounds[n]=bb;components.append({'name':n,'min':bb[0],'max':bb[1],'inherited':False});newnames.append(n)
for i,a in enumerate([0,math.pi/3,-math.pi/3]):ribbon('ScienceArt_Orbit_'+str(i),a,.46,.175,.038,'LightStone')
B('ScienceArt_Nucleus',[-3.075,-8.205,5.455],[-2.925,-8.155,5.605],'LightStone')
# Diagonal tapered stylus, closed connected solid, base embeds in the plaque.
verts=[]
for y in [-8.225,-8.155]:
 for x,z in [(-3.38,5.16),(-3.30,5.12),(-2.59,5.91),(-2.57,6.00),(-2.66,5.98)]:verts.append((x,y,z))
mesh=bpy.data.meshes.new('ScienceArt_CreativeStylus');mesh.from_pydata(verts,[],[(0,4,3,2,1),(5,6,7,8,9)]+[(j,(j+1)%5,(j+1)%5+5,j+5) for j in range(5)]);mesh.update()
o=bpy.data.objects.new(mesh.name,mesh);bpy.context.collection.objects.link(o);mesh.materials.append(materials['EquipmentMetal']);vg=o.vertex_groups.new(name=o.name);vg.add(list(range(10)),1,'REPLACE');uv=mesh.uv_layers.new(name='UV0')
for li,l in enumerate(mesh.loops):v=mesh.vertices[l.vertex_index].co;uv.data[li].uv=(v.x/2,v.z/2)
objects.append(o);bb=measure(o);bounds[o.name]=bb;components.append({'name':o.name,'min':bb[0],'max':bb[1],'inherited':False});newnames.append(o.name)
def overlap(a,b):return all(min(a[1][k],b[1][k])-max(a[0][k],b[0][k])>1e-6 for k in range(3))
reservation=[[15,2,0],[23,19,14]]
for c in components:
 assert not overlap([c['min'],c['max']],reservation),c['name']
 assert c['min'][0]>=-23.5 and c['max'][0]<=23.5 and c['min'][1]>=-19.5 and c['max'][1]<=19.5,c['name']
# Reconstruct inherited pane mounting records from actual named connected geometry if no prior JSON accompanies blend.
def readjson(n,default):
 p=out/n
 try:return json.loads(p.read_text())
 except:return default
mount=readjson('window-mounts.json',{'windows':[],'doors':[]})
if not mount.get('windows'):
 for c in components[:original_components]:
  n=c['name']
  if 'pane' not in n.lower():continue
  stem=n.rsplit('_',1)[0];fs=[q['name'] for q in components[:original_components] if q['name']!=n and q['name'].startswith(stem) and any(t in q['name'].lower() for t in ['jamb','sill','head','frame'])]
  bb=bounds[n];axis=min([0,1],key=lambda k:bb[1][k]-bb[0][k]);t=1-axis
  candidates=[]
  for q in components[:original_components]:
   if q['name']==n or any(tk in q['name'].lower() for tk in ['pane','frame','jamb','sill','head','roof','glyph']):continue
   a,b=q['min'],q['max']
   if a[t]<=bb[0][t] and b[t]>=bb[1][t] and a[2]<=bb[0][2] and b[2]>=bb[1][2] and b[axis]-a[axis]>.2:
    d=min(abs(bb[0][axis]-a[axis]),abs(bb[1][axis]-b[axis]));candidates.append((d,q))
  if candidates:
   d,q=min(candidates,key=lambda x:x[0]);sg=1 if abs(bb[0][axis]-q['max'][axis])<abs(bb[1][axis]-q['min'][axis]) else -1
   mount['windows'].append({'pane':n,'frame_parts':fs,'backing':q['name'],'axis':axis,'sign':sg,'pane_bounds':bb})
mount['windows'].extend(newwindows)
# Validate new four-rim geometry independently, including clear rail ends and wall embed.
for w in newwindows:
 wall=bounds[w['backing']];axis=w['axis'];t=1-axis;pb=bounds[w['pane']]
 for f in w['frame_parts']:
  fb=bounds[f];assert fb[0][t]>=wall[0][t]+.12 and fb[1][t]<=wall[1][t]-.12
  assert fb[0][2]>=wall[0][2]+.12 and fb[1][2]<=wall[1][2]-.12
  assert overlap(fb,wall);assert not overlap(fb,pb)
 for i,f in enumerate(w['frame_parts']):
  for g in w['frame_parts'][i+1:]:assert not overlap(bounds[f],bounds[g])
# Pack and document the exact nine supplied maps, with output copies.
tex=out/'textures';tex.mkdir(exist_ok=True);maps=[]
for family,folder in [('CityBrick','BuildingSurfaces'),('CityMechanical','BuildingSurfaces'),('RoofMembrane','RoofsSigns')]:
 for kind in ['BaseColor','Normal','ORM']:
  src=Path('/repo/ArtSource/Textures')/folder/(family+'_'+kind+'.png');dst=tex/src.name;shutil.copy2(src,dst)
  matching=[im for im in bpy.data.images if im.name.split('.')[0]==src.stem or Path(bpy.path.abspath(im.filepath)).name==src.name]
  if not matching:matching=[bpy.data.images.load(str(dst))]
  for im in matching:im.filepath=str(dst);im.colorspace_settings.name='sRGB' if kind=='BaseColor' else 'Non-Color';im.pack()
  maps.append({'source':str(src),'copy':str(dst),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'copy_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'dimensions':list(matching[0].size),'colorspace':'sRGB' if kind=='BaseColor' else 'Non-Color'})
for o in objects:
 o.data.calc_loop_triangles()
 assert o.data.uv_layers.active
 for v in o.data.uv_layers.active.data:assert all(math.isfinite(x) for x in v.uv)
tri=sum(len(o.data.loop_triangles) for o in objects);assert tri<10000,tri
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
finish(objects)
def write(n,d):(out/n).write_text(json.dumps(d,indent=2))
v=readjson('validation.json',{});v.update({'components':components,'triangles_prejoin':tri,'source_id':'building.college.a','review_only':True,'integration':'HELD','reserved_box_nonintersection':True,'inherited_geometry_preserved':True,'new_window_checks':{'wall_containment':True,'rim_wall_embed':True,'pane_frame_disjoint':True,'corner_disjoint':True,'rail_end_clearance_m':.001},'inherited_window_checks':'Retained unchanged from completed v2; component measurements reconstructed, no inherited geometry modification.'});write('validation.json',v)
write('window-mounts.json',mount)
write('material-manifest.json',{'regions':list(materials),'maps':maps,'shader_policy':'Exact v2 node graphs retained, including linked warm brick/slate multiply tints and cream/teal constants. ORM R AO/G roughness/B metallic; tangent normals retained. Native reconstruction deferred.','uv_repeat_m':2,'new_materials':False})
write('upgrade-plan.json',{'existing_stages':['base'],'existing_upgrade_count':0,'gameplay_changes':False,'current_footprint_m':[24,24],'source_proposal_m':[48,40],'retained_entrances':[[-3,-8,0],[-15,-12,0]],'occupied_bounds':[ [min(c['min'][k] for c in components) for k in range(3)],[max(c['max'][k] for c in components) for k in range(3)] ],'future_reservations':[{'id':'east_rear','min':reservation[0],'max':reservation[1],'purpose':'hypothetical future wing'}],'measured_intersections':0})
write('design-response.json',{'parent':'college174-v2 exact loaded asset','revision':'raised commons lantern and science + art identity relief','retained_inherited_connected_solids':original_components,'retained_windows':72,'new_panes':6,'total_panes':78,'lantern_components':[n for n in newnames if n.startswith('Lantern')],'lantern_body_bounds':bounds['Lantern_Commons_Wall'],'lantern_base_contact':{'lobby_roof_z':7.2,'body_min_z':7.2,'gap_m':0,'body_inside_lobby_xy':True},'lantern_top_m':9.44,'academic_top_m':10.5,'emblem_components':[n for n in newnames if n.startswith('ScienceArt')],'plaque_bounds':bounds['ScienceArt_Teal_Plaque'],'plaque_wall_contact':{'lobby_front_y':-8,'plaque_back_y':-7.99,'embed_m':.01},'relief_plaque_embed_m':.005,'retained_public_door':[-3,-8,0],'retained_service_door':[-15,-12,0],'empty_future_box':reservation,'nine_packed_maps':maps,'human_review':'pending','integration':'HELD','lod_plan':'Retain old approved sources. LOD1 simplify window rims/roof hardware and bake emblem and lettering. LOD2 omit relief/monitor trim, simplify facade detail; no LOD implementation in this source preview.'})
ed=readjson('education-contract.json',{});ed.update({'source_id':'building.college.a','source_site_m':[48,40],'new_lantern_body':'Lantern_Commons_Wall','new_lantern_roofs':['Lantern_Stepped_Cap_Lower','Lantern_Stepped_Cap_Upper'],'new_lantern_windows':[w['pane'] for w in newwindows],'components':components,'future_reservation':reservation,'retained_entrances':[[-3,-8,0],[-15,-12,0]],'teaching_wings':2,'integration':'HELD'});write('education-contract.json',ed)
